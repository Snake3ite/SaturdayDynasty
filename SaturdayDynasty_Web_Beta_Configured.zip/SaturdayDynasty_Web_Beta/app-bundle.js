const TEAM_BRANDING={"1":{"primary":"#4A044E","secondary":"#F0ABFC","accent":"#FFFFFF","logo":"assets/logos/team-1.svg","abbr":"GL"},"2":{"primary":"#312E81","secondary":"#F8FAFC","accent":"#FB7185","logo":"assets/logos/team-2.svg","abbr":"CO"},"3":{"primary":"#4A044E","secondary":"#F0ABFC","accent":"#FFFFFF","logo":"assets/logos/team-3.svg","abbr":"LE"},"4":{"primary":"#082F49","secondary":"#38BDF8","accent":"#F8FAFC","logo":"assets/logos/team-4.svg","abbr":"A"},"5":{"primary":"#172554","secondary":"#60A5FA","accent":"#F8FAFC","logo":"assets/logos/team-5.svg","abbr":"GM"},"6":{"primary":"#111827","secondary":"#22D3EE","accent":"#FFFFFF","logo":"assets/logos/team-6.svg","abbr":"P"},"7":{"primary":"#7C2D12","secondary":"#FACC15","accent":"#FFF7ED","logo":"assets/logos/team-7.svg","abbr":"LS"},"8":{"primary":"#450A0A","secondary":"#FCA5A5","accent":"#FFFFFF","logo":"assets/logos/team-8.svg","abbr":"B"},"9":{"primary":"#3A0CA3","secondary":"#4CC9F0","accent":"#FFFFFF","logo":"assets/logos/team-9.svg","abbr":"OA"},"10":{"primary":"#7F1D1D","secondary":"#F8FAFC","accent":"#F59E0B","logo":"assets/logos/team-10.svg","abbr":"CC"},"11":{"primary":"#4C1D95","secondary":"#FDE047","accent":"#FFFFFF","logo":"assets/logos/team-11.svg","abbr":"K"},"12":{"primary":"#172554","secondary":"#60A5FA","accent":"#F8FAFC","logo":"assets/logos/team-12.svg","abbr":"MC"},"13":{"primary":"#1E3A8A","secondary":"#F97316","accent":"#FFFFFF","logo":"assets/logos/team-13.svg","abbr":"C"},"14":{"primary":"#082F49","secondary":"#38BDF8","accent":"#F8FAFC","logo":"assets/logos/team-14.svg","abbr":"RM"},"15":{"primary":"#7C2D12","secondary":"#FACC15","accent":"#FFF7ED","logo":"assets/logos/team-15.svg","abbr":"DV"},"16":{"primary":"#052E16","secondary":"#4ADE80","accent":"#FEFCE8","logo":"assets/logos/team-16.svg","abbr":"E"},"17":{"primary":"#052E16","secondary":"#4ADE80","accent":"#FEFCE8","logo":"assets/logos/team-17.svg","abbr":"TC"},"18":{"primary":"#3A0CA3","secondary":"#4CC9F0","accent":"#FFFFFF","logo":"assets/logos/team-18.svg","abbr":"PC"},"19":{"primary":"#4A1942","secondary":"#C9ADA7","accent":"#FFFFFF","logo":"assets/logos/team-19.svg","abbr":"JS"},"20":{"primary":"#3A0CA3","secondary":"#4CC9F0","accent":"#FFFFFF","logo":"assets/logos/team-20.svg","abbr":"BC"},"21":{"primary":"#052E16","secondary":"#4ADE80","accent":"#FEFCE8","logo":"assets/logos/team-21.svg","abbr":"NP"},"22":{"primary":"#1C1917","secondary":"#FB923C","accent":"#FFF7ED","logo":"assets/logos/team-22.svg","abbr":"PM"},"23":{"primary":"#4C1D95","secondary":"#FDE047","accent":"#FFFFFF","logo":"assets/logos/team-23.svg","abbr":"G"},"24":{"primary":"#006D77","secondary":"#E29578","accent":"#FFFFFF","logo":"assets/logos/team-24.svg","abbr":"SP"},"100":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-100.svg","abbr":"AI"},"101":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-101.svg","abbr":"ML"},"102":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-102.svg","abbr":"LP"},"103":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-103.svg","abbr":"AB"},"104":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-104.svg","abbr":"TF"},"105":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-105.svg","abbr":"KR"},"106":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-106.svg","abbr":"GS"},"107":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-107.svg","abbr":"TF"},"108":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-108.svg","abbr":"CG"},"109":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-109.svg","abbr":"CS"},"110":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-110.svg","abbr":"NS"},"111":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-111.svg","abbr":"SO"},"112":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-112.svg","abbr":"EE"},"113":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-113.svg","abbr":"SO"},"114":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-114.svg","abbr":"LC"},"115":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-115.svg","abbr":"SF"},"116":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-116.svg","abbr":"BD"},"117":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-117.svg","abbr":"MB"},"118":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-118.svg","abbr":"BS"},"119":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-119.svg","abbr":"AR"},"200":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-200.svg","abbr":"MN"},"201":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-201.svg","abbr":"IH"},"202":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-202.svg","abbr":"WR"},"203":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-203.svg","abbr":"BT"},"204":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-204.svg","abbr":"CG"},"205":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-205.svg","abbr":"PF"},"206":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-206.svg","abbr":"AW"},"207":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-207.svg","abbr":"MF"},"208":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-208.svg","abbr":"LF"},"209":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-209.svg","abbr":"WW"},"210":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-210.svg","abbr":"FR"},"211":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-211.svg","abbr":"LD"},"212":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-212.svg","abbr":"AO"},"213":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-213.svg","abbr":"OM"},"214":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-214.svg","abbr":"SI"},"215":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-215.svg","abbr":"CP"},"216":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-216.svg","abbr":"LT"},"217":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-217.svg","abbr":"FO"},"218":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-218.svg","abbr":"CT"},"219":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-219.svg","abbr":"CR"},"220":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-220.svg","abbr":"CP"},"221":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-221.svg","abbr":"RR"},"222":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-222.svg","abbr":"DS"},"223":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-223.svg","abbr":"BF"},"224":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-224.svg","abbr":"CS"},"225":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-225.svg","abbr":"LR"},"226":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-226.svg","abbr":"SS"},"227":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-227.svg","abbr":"CS"},"228":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-228.svg","abbr":"TS"},"229":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-229.svg","abbr":"TS"},"230":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-230.svg","abbr":"BS"},"231":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-231.svg","abbr":"PI"},"232":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-232.svg","abbr":"BP"},"233":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-233.svg","abbr":"SS"},"234":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-234.svg","abbr":"CT"},"235":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-235.svg","abbr":"PP"},"236":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-236.svg","abbr":"PP"},"237":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-237.svg","abbr":"HA"},"238":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-238.svg","abbr":"CR"},"239":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-239.svg","abbr":"OO"},"240":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-240.svg","abbr":"MM"},"241":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-241.svg","abbr":"TT"},"242":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-242.svg","abbr":"YF"},"243":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-243.svg","abbr":"KK"},"244":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-244.svg","abbr":"ML"},"245":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-245.svg","abbr":"AF"},"246":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-246.svg","abbr":"KL"},"247":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-247.svg","abbr":"BA"},"248":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-248.svg","abbr":"MF"},"249":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-249.svg","abbr":"DP"},"250":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-250.svg","abbr":"FF"},"251":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-251.svg","abbr":"LR"},"252":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-252.svg","abbr":"AS"},"253":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-253.svg","abbr":"LN"},"254":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-254.svg","abbr":"RS"},"255":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-255.svg","abbr":"FG"},"256":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-256.svg","abbr":"SC"},"257":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-257.svg","abbr":"HT"},"258":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-258.svg","abbr":"NC"},"259":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-259.svg","abbr":"TE"},"260":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-260.svg","abbr":"PL"},"261":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-261.svg","abbr":"GM"},"262":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-262.svg","abbr":"AA"},"263":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-263.svg","abbr":"HG"},"264":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-264.svg","abbr":"BI"},"265":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-265.svg","abbr":"SV"},"266":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-266.svg","abbr":"CM"},"267":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-267.svg","abbr":"SP"},"268":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-268.svg","abbr":"AP"},"269":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-269.svg","abbr":"TT"},"270":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-270.svg","abbr":"MB"},"271":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-271.svg","abbr":"LC"},"272":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-272.svg","abbr":"MB"},"273":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-273.svg","abbr":"JR"},"274":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-274.svg","abbr":"BB"},"275":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-275.svg","abbr":"AS"},"276":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-276.svg","abbr":"SI"},"277":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-277.svg","abbr":"PF"},"278":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-278.svg","abbr":"NE"},"279":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-279.svg","abbr":"SC"},"280":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-280.svg","abbr":"DH"},"281":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-281.svg","abbr":"MP"},"282":{"primary":"#2A4D3E","secondary":"#E9C46A","accent":"#FFFFFF","logo":"assets/logos/team-282.svg","abbr":"BS"},"283":{"primary":"#355070","secondary":"#EAAC8B","accent":"#FFFFFF","logo":"assets/logos/team-283.svg","abbr":"SG"}};
const POSITIONS=["QB","RB","WR","TE","OT","IOL","EDGE","DL","LB","CB","S","K","P"];
const STARTERS={QB:1,RB:1,WR:3,TE:1,OT:2,IOL:3,EDGE:2,DL:2,LB:3,CB:3,S:2,K:1,P:1};
const DEPTH={QB:3,RB:4,WR:8,TE:3,OT:6,IOL:7,EDGE:6,DL:6,LB:8,CB:8,S:6,K:2,P:2};
const ARCH={QB:["Field General","Improviser","Scrambler"],RB:["Power Back","Elusive Back","Receiving Back"],WR:["Deep Threat","Route Runner","Physical"],TE:["Vertical Threat","Blocking","Possession"],OT:["Pass Protector","Power"],IOL:["Power","Agile"],EDGE:["Speed Rusher","Power Rusher","Run Stopper"],DL:["Run Stopper","Power Rusher"],LB:["Field General","Coverage","Run Stopper"],CB:["Man Cover","Zone Cover","Slot"],S:["Zone","Hybrid","Run Support"],K:["Accurate","Power"],P:["Directional","Power","Coffin Corner"]};
const DEV=["Normal","Impact","Star","Elite"];
const FIRST=["Marcus","Jalen","Tyler","Cam","Darius","Evan","Malik","Noah","Trey","Jayden","Cole","Isaiah","Brandon","Andre","Caleb","Mason","Jordan","Devin","Xavier","Luke","Aiden","Dante","Khalil","Micah","Bryce","Roman","Elijah","Travis","Damien","Tyson","Zayden","Owen"];
const LAST=["Holloway","Turner","Brooks","Mitchell","Carter","Reed","Bennett","Hayes","Coleman","Foster","Davis","Parker","Simmons","Bryant","Walker","Griffin","Powell","Morgan","Bell","Howard","Price","Woods","James","Russell","Harris","King","Jackson","Scott","Young","Moore"];
const LOC=[["Cleveland","OH","Midwest",41.5,-81.7],["Columbus","OH","Midwest",39.96,-83],["Cincinnati","OH","Midwest",39.1,-84.5],["Detroit","MI","Midwest",42.33,-83.05],["Pittsburgh","PA","Northeast",40.44,-80],["Philadelphia","PA","Northeast",39.95,-75.17],["Atlanta","GA","Southeast",33.75,-84.39],["Miami","FL","Southeast",25.76,-80.19],["Tampa","FL","Southeast",27.95,-82.46],["Orlando","FL","Southeast",28.54,-81.38],["Dallas","TX","Southwest",32.78,-96.8],["Houston","TX","Southwest",29.76,-95.37],["San Antonio","TX","Southwest",29.42,-98.49],["Los Angeles","CA","West",34.05,-118.24],["San Diego","CA","West",32.72,-117.16],["Sacramento","CA","West",38.58,-121.49],["Charlotte","NC","Southeast",35.23,-80.84],["Nashville","TN","Southeast",36.16,-86.78],["Birmingham","AL","Southeast",33.52,-86.8],["Chicago","IL","Midwest",41.88,-87.63],["Indianapolis","IN","Midwest",39.77,-86.16],["Louisville","KY","Southeast",38.25,-85.76],["Baltimore","MD","Northeast",39.29,-76.61],["New Orleans","LA","Southeast",29.95,-90.07],["Phoenix","AZ","Southwest",33.45,-112.07],["Denver","CO","Mountain",39.74,-104.99],["Seattle","WA","West",47.61,-122.33],["St. Louis","MO","Midwest",38.63,-90.2],["Richmond","VA","Southeast",37.54,-77.44],["Newark","NJ","Northeast",40.74,-74.17]];
const S=(id,name,city,state,region,lat,lon,conference,prestige,recent,facilities,pro,nil,academics,expectation,pipelines,tag)=>({id,name,city,state,region,lat,lon,conference,prestige,recent,facilities,pro,nil,academics,expectation,pipelines,tag,hours:430+Math.round(prestige*2)});
const schools=[
S(1,"Great Lakes State","Cleveland","OH","Midwest",41.5,-81.7,"Great North",78,72,76,75,74,67,8,["OH","MI","PA"],"Regional power with major expectations."),
S(2,"Central Ohio","Columbus","OH","Midwest",39.96,-83,"Heartland",94,91,95,96,93,82,10,["OH","PA","FL","TX"],"A national giant built to win now."),
S(3,"Lake Erie University","Toledo","OH","Midwest",41.65,-83.54,"Great Lakes",44,38,48,35,42,60,5,["OH","MI"],"A true rebuild with room to grow."),
S(4,"Appalachian Tech","Morgantown","WV","Southeast",39.63,-79.96,"Atlantic",58,66,61,53,51,56,7,["WV","VA","PA","OH"],"Tough regional program with local ties."),
S(5,"Gulf Coast A&M","Mobile","AL","Southeast",30.69,-88.04,"Southeastern",71,64,82,79,83,54,8,["FL","GA","AL","LA"],"Elite talent nearby and brutal competition."),
S(6,"Pacific Metropolitan","Los Angeles","CA","West",34.05,-118.24,"Western",64,57,73,65,77,90,7,["CA","AZ","TX"],"Big market, academics and national reach."),
S(7,"Lone Star State","Austin","TX","Southwest",30.27,-97.74,"Southwest",89,84,92,90,95,79,10,["TX","LA","OK"],"Massive resources in football country."),
S(8,"Bayou University","Baton Rouge","LA","Southeast",30.45,-91.19,"Southeastern",88,86,90,94,88,58,10,["LA","TX","MS","AL"],"NFL pipeline and championship pressure."),
S(9,"Orlando Atlantic","Orlando","FL","Southeast",28.54,-81.38,"Atlantic",81,79,84,86,84,65,9,["FL","GA"],"Speed, talent and endless recruiting wars."),
S(10,"Carolina Coastal","Charlotte","NC","Southeast",35.23,-80.84,"Atlantic",68,74,71,68,69,74,8,["NC","SC","VA","GA"],"A rising regional contender."),
S(11,"Keystone State","Pittsburgh","PA","Northeast",40.44,-80,"Great North",76,70,74,79,70,78,8,["PA","OH","NJ","MD"],"Tradition and defensive identity."),
S(12,"Motor City University","Detroit","MI","Midwest",42.33,-83.05,"Great North",66,61,68,65,63,69,7,["MI","OH","IL"],"A sleeping Midwest giant."),
S(13,"Chicago Tech","Chicago","IL","Midwest",41.88,-87.63,"Heartland",60,58,70,57,72,95,6,["IL","IN","WI"],"Academics and a massive market."),
S(14,"Rocky Mountain State","Denver","CO","Mountain",39.74,-104.99,"Western",62,68,69,61,66,72,7,["CO","AZ","TX","CA"],"Altitude and a wide recruiting footprint."),
S(15,"Desert Valley","Phoenix","AZ","Southwest",33.45,-112.07,"Western",59,63,78,60,75,64,7,["AZ","CA","TX"],"Modern facilities and fast offense."),
S(16,"Emerald State","Seattle","WA","West",47.61,-122.33,"Western",74,77,80,78,74,85,8,["WA","CA","OR"],"Strong brand with limited local depth."),
S(17,"Tennessee Central","Nashville","TN","Southeast",36.16,-86.78,"Southeastern",67,65,74,69,72,70,7,["TN","GA","AL","KY"],"A recruiting crossroads with upside."),
S(18,"Potomac Capital","Washington","DC","Northeast",38.9,-77.04,"Atlantic",57,55,64,52,68,96,6,["MD","VA","NJ","PA"],"Elite academics in the Mid-Atlantic."),
S(19,"Jackson Delta State","Jackson","MS","Southeast",32.3,-90.18,"Southeastern",63,60,66,72,64,52,7,["MS","AL","LA","TN"],"Hard-nosed football near elite talent."),
S(20,"Boston Commonwealth","Boston","MA","Northeast",42.36,-71.06,"Great North",55,54,63,50,70,98,6,["MA","NJ","PA","MD"],"Prestigious academics and a hard region."),
S(21,"Northern Plains","Omaha","NE","Midwest",41.26,-95.94,"Heartland",72,67,77,74,65,68,8,["NE","MO","KS","TX"],"Physical football and loyal fans."),
S(22,"Prairie A&M","St. Louis","MO","Midwest",38.63,-90.2,"Heartland",51,56,58,48,57,62,6,["MO","IL","KS"],"A regional program waiting to break out."),
S(23,"Garden State","Newark","NJ","Northeast",40.74,-74.17,"Atlantic",52,50,60,49,62,73,5,["NJ","PA","MD","NY"],"Dense talent and fierce competition."),
S(24,"San Diego Pacific","San Diego","CA","West",32.72,-117.16,"Western",61,64,72,63,70,71,7,["CA","AZ"],"Perfect weather and speed-based appeal.")
];

const expandedSchools=[
["Ann Arbor Ironclads","Ann Arbor","MI","Midwest","Great North",95,90,97,97,94,91,11,["MI","OH","PA","IL","FL"],42.28,-83.74],
["Madison Lakes","Madison","WI","Midwest","Great North",79,75,83,78,72,82,8,["WI","IL","MN"],43.07,-89.40],
["Lincoln Prairie","Lincoln","NE","Midwest","Great North",82,68,85,82,78,74,8,["NE","KS","MO","TX"],40.81,-96.68],
["Athens Black Bears","Athens","GA","Southeast","Southeastern",96,95,98,98,96,78,11,["GA","FL","AL"],33.95,-83.38],
["Tuscaloosa Forge","Tuscaloosa","AL","Southeast","Southeastern",97,93,98,99,97,72,11,["AL","GA","FL","MS"],33.21,-87.57],
["Knoxville Ridge","Knoxville","TN","Southeast","Southeastern",88,85,91,89,91,76,9,["TN","GA","NC"],35.96,-83.92],
["Gainesville Swampcats","Gainesville","FL","Southeast","Southeastern",87,76,90,91,90,79,9,["FL","GA"],29.65,-82.32],
["Tallahassee Firebirds","Tallahassee","FL","Southeast","Atlantic",90,84,91,93,88,76,10,["FL","GA","AL"],30.44,-84.28],
["Clemson Gold","Clemson","SC","Southeast","Atlantic",91,84,92,94,83,81,10,["SC","GA","NC"],34.68,-82.84],
["Coral Gables Storm","Coral Gables","FL","Southeast","Atlantic",86,78,89,92,91,84,9,["FL","GA","NJ"],25.72,-80.27],
["Norman Stampede","Norman","OK","Southwest","Southwest",91,87,93,94,91,77,10,["OK","TX","KS"],35.22,-97.44],
["Stillwater Outlaws","Stillwater","OK","Southwest","Southwest",77,73,80,76,73,74,8,["OK","TX","KS"],36.12,-97.06],
["Eugene Evergreens","Eugene","OR","West","Western",93,91,98,92,99,76,11,["OR","CA","WA","TX"],44.05,-123.09],
["Seattle Orcas","Seattle","WA","West","Western",87,83,89,89,84,88,9,["WA","CA","OR"],47.65,-122.30],
["Los Angeles Centurions","Los Angeles","CA","West","Western",92,82,94,98,96,91,10,["CA","AZ","TX"],34.02,-118.29],
["South Bend Foundry","South Bend","IN","Midwest","Independent",94,88,95,97,93,98,10,["IN","OH","IL","CA","FL"],41.68,-86.25],
["Boise High Desert","Boise","ID","Mountain","Mountain",78,79,82,72,68,73,9,["ID","CA","WA"],43.62,-116.21],
["Memphis Blues","Memphis","TN","Southeast","Metro",73,76,77,70,79,68,8,["TN","MS","AR"],35.15,-90.05],
["Boone Summit","Boone","NC","Southeast","Southern Coast",72,74,73,67,60,73,8,["NC","SC","TN"],36.22,-81.68],
["Athens Riverhawks","Athens","OH","Midwest","Great Lakes",60,68,64,54,48,79,7,["OH","WV","PA"],39.33,-82.10]
];
expandedSchools.forEach((x,i)=>schools.push(S(100+i,x[0],x[1],x[2],x[3],x[13],x[14],x[4],x[5],x[6],x[7],x[8],x[9],x[10],x[11],x[12],`Expanded national program based in ${x[1]}, ${x[2]}.`)));

const nationalExpansionTeams=[
["Minneapolis Northstar","Minneapolis","MN","Midwest","Great North",78,74,80,75,72,84,8,["MN", "WI", "IA"],44.98,-93.27],
["Iowa City Harvesters","Iowa City","IA","Midwest","Great North",82,80,84,83,73,86,9,["IA", "IL", "WI"],41.66,-91.53],
["West Lafayette Riveters","West Lafayette","IN","Midwest","Great North",70,66,77,72,69,92,7,["IN", "IL", "OH"],40.43,-86.91],
["Bloomington Torch","Bloomington","IN","Midwest","Great North",68,65,75,68,71,88,7,["IN", "OH", "IL"],39.17,-86.53],
["College Park Guardians","College Park","MD","Northeast","Great North",73,70,79,74,78,89,8,["MD", "VA", "NJ"],38.99,-76.94],
["Piscataway Forge","Piscataway","NJ","Northeast","Great North",67,62,74,64,69,85,7,["NJ", "PA", "MD"],40.55,-74.46],
["Ames Windriders","Ames","IA","Midwest","Heartland",76,78,79,73,70,83,8,["IA", "MO", "NE"],42.03,-93.62],
["Manhattan Flint","Manhattan","KS","Midwest","Heartland",78,81,80,76,72,81,9,["KS", "MO", "TX"],39.18,-96.57],
["Lawrence Freeholders","Lawrence","KS","Midwest","Heartland",72,74,76,70,75,86,8,["KS", "MO", "TX"],38.97,-95.24],
["Waco Wranglers","Waco","TX","Southwest","Heartland",80,77,84,78,85,82,8,["TX", "OK", "LA"],31.55,-97.15],
["Fort Worth Railmen","Fort Worth","TX","Southwest","Heartland",84,82,87,85,88,84,9,["TX", "OK", "LA"],32.75,-97.33],
["Lubbock Dust Devils","Lubbock","TX","Southwest","Heartland",77,75,83,74,86,79,8,["TX", "NM", "OK"],33.58,-101.85],
["Auburn Oaks","Auburn","AL","Southeast","Southeastern",89,83,92,91,91,80,9,["AL", "GA", "FL"],32.61,-85.48],
["Oxford Magnolias","Oxford","MS","Southeast","Southeastern",85,84,88,87,89,77,9,["MS", "AL", "TN"],34.37,-89.52],
["Starkville Iron","Starkville","MS","Southeast","Southeastern",78,72,81,79,75,76,8,["MS", "AL", "LA"],33.45,-88.82],
["Columbia Palmettos","Columbia","SC","Southeast","Southeastern",82,78,84,82,84,79,8,["SC", "GA", "NC"],34.0,-81.03],
["Lexington Thoroughbreds","Lexington","KY","Southeast","Southeastern",79,75,82,78,80,84,8,["KY", "OH", "TN"],38.04,-84.5],
["Fayetteville Ozarks","Fayetteville","AR","Southeast","Southeastern",84,76,86,86,82,76,8,["AR", "TX", "OK"],36.06,-94.16],
["Columbia Trailblazers","Columbia","MO","Midwest","Southeastern",81,79,84,79,80,87,8,["MO", "IL", "KS"],38.95,-92.33],
["College Station Rangers","College Station","TX","Southwest","Southeastern",92,84,97,93,99,81,10,["TX", "LA", "OK"],30.63,-96.33],
["Chapel Hill Pines","Chapel Hill","NC","Southeast","Atlantic",84,80,88,86,86,96,9,["NC", "VA", "SC"],35.91,-79.05],
["Raleigh Redtails","Raleigh","NC","Southeast","Atlantic",80,77,83,78,76,90,8,["NC", "SC", "VA"],35.78,-78.64],
["Durham Scholars","Durham","NC","Southeast","Atlantic",75,73,82,72,79,99,8,["NC", "VA", "GA"],35.99,-78.9],
["Blacksburg Foundry","Blacksburg","VA","Southeast","Atlantic",82,75,85,84,74,85,8,["VA", "NC", "MD"],37.23,-80.42],
["Charlottesville Summit","Charlottesville","VA","Southeast","Atlantic",72,68,79,70,73,99,7,["VA", "MD", "NC"],38.03,-78.48],
["Louisville Riverhawks","Louisville","KY","Southeast","Atlantic",83,81,86,82,88,79,9,["KY", "OH", "TN"],38.25,-85.76],
["Syracuse Snowcats","Syracuse","NY","Northeast","Atlantic",74,69,76,73,70,87,7,["NY", "NJ", "PA"],43.05,-76.15],
["Chestnut Hill Scholars","Boston","MA","Northeast","Atlantic",69,65,74,67,68,96,7,["MA", "NJ", "NY"],42.34,-71.17],
["Tempe Scorch","Tempe","AZ","Southwest","Western",82,78,88,80,91,81,8,["AZ", "CA", "TX"],33.43,-111.94],
["Tucson Saguaros","Tucson","AZ","Southwest","Western",79,76,84,78,83,82,8,["AZ", "CA", "TX"],32.22,-110.97],
["Berkeley Sequoias","Berkeley","CA","West","Western",76,70,82,74,84,99,7,["CA", "WA", "AZ"],37.87,-122.27],
["Palo Alto Innovators","Palo Alto","CA","West","Western",81,75,86,82,88,99,8,["CA", "WA", "OR"],37.44,-122.16],
["Boulder Peaks","Boulder","CO","Mountain","Western",83,80,91,81,95,90,8,["CO", "CA", "TX"],40.01,-105.27],
["Salt Lake Sentinels","Salt Lake City","UT","Mountain","Western",85,86,88,84,77,86,9,["UT", "CA", "AZ"],40.76,-111.89],
["Corvallis Timber","Corvallis","OR","West","Western",75,73,78,74,68,88,8,["OR", "WA", "CA"],44.56,-123.26],
["Pullman Palouse","Pullman","WA","West","Western",73,72,76,71,66,85,8,["WA", "OR", "CA"],46.73,-117.18],
["Provo Peaks","Provo","UT","Mountain","Southwest",83,82,87,80,82,91,9,["UT", "AZ", "CA"],40.23,-111.66],
["Houston Apollos","Houston","TX","Southwest","Southwest",78,75,82,79,88,80,8,["TX", "LA", "OK"],29.76,-95.37],
["Cincinnati Rivermen","Cincinnati","OH","Midwest","Southwest",81,79,85,80,78,85,8,["OH", "KY", "IN"],39.1,-84.51],
["Orlando Orbit","Orlando","FL","Southeast","Southwest",80,79,86,78,91,82,8,["FL", "GA", "AL"],28.54,-81.38],
["Morgantown Miners","Morgantown","WV","Southeast","Southwest",79,74,82,79,72,80,8,["WV", "PA", "OH"],39.63,-79.96],
["Tampa Tritons","Tampa","FL","Southeast","Southwest",68,67,73,65,76,78,7,["FL", "GA"],27.95,-82.46],
["Ypsilanti Flyers","Ypsilanti","MI","Midwest","Great Lakes",55,58,60,48,44,77,6,["MI", "OH", "IN"],42.24,-83.61],
["Kalamazoo Kestrels","Kalamazoo","MI","Midwest","Great Lakes",59,61,63,53,48,75,6,["MI", "OH", "IL"],42.29,-85.59],
["Mount Pleasant Lumber","Mount Pleasant","MI","Midwest","Great Lakes",61,63,65,56,50,72,7,["MI", "OH", "IN"],43.6,-84.77],
["Akron Foundry","Akron","OH","Midwest","Great Lakes",48,47,55,42,39,73,5,["OH", "PA", "MI"],41.08,-81.52],
["Kent Lightning","Kent","OH","Midwest","Great Lakes",52,54,58,45,42,78,5,["OH", "PA", "MI"],41.15,-81.36],
["Bowling Green Aviators","Bowling Green","OH","Midwest","Great Lakes",58,60,62,52,47,76,6,["OH", "MI", "IN"],41.37,-83.65],
["Muncie Forge","Muncie","IN","Midwest","Great Lakes",56,55,60,49,45,74,6,["IN", "OH", "IL"],40.19,-85.39],
["DeKalb Prairie","DeKalb","IL","Midwest","Great Lakes",62,64,66,55,50,75,7,["IL", "WI", "IN"],41.93,-88.75],
["Fort Collins Frontiers","Fort Collins","CO","Mountain","Mountain",71,73,77,68,69,82,8,["CO", "WY", "CA"],40.59,-105.08],
["Laramie Range","Laramie","WY","Mountain","Mountain",65,67,69,61,55,77,7,["WY", "CO", "UT"],41.31,-105.59],
["Albuquerque Sol","Albuquerque","NM","Southwest","Mountain",59,57,65,54,58,75,6,["NM", "TX", "AZ"],35.08,-106.65],
["Las Vegas Neon","Las Vegas","NV","West","Mountain",70,72,82,66,81,70,8,["NV", "CA", "AZ"],36.17,-115.14],
["Reno Silver","Reno","NV","West","Mountain",66,65,71,62,65,78,7,["NV", "CA", "OR"],39.53,-119.81],
["Fresno Gold","Fresno","CA","West","Mountain",74,77,78,70,72,74,8,["CA", "NV", "AZ"],36.74,-119.79],
["San Jose Circuit","San Jose","CA","West","Mountain",67,69,73,62,70,80,7,["CA", "NV", "OR"],37.34,-121.89],
["Honolulu Tides","Honolulu","HI","West","Mountain",64,62,72,59,66,76,7,["HI", "CA", "NV"],21.31,-157.86],
["New Orleans Crescent","New Orleans","LA","Southeast","Metro",76,80,79,73,82,94,9,["LA", "TX", "MS"],29.95,-90.07],
["Tulsa Ember","Tulsa","OK","Southwest","Metro",65,64,70,60,65,89,7,["OK", "TX", "KS"],36.15,-95.99],
["Philadelphia Liberty","Philadelphia","PA","Northeast","Metro",66,62,72,61,70,84,7,["PA", "NJ", "MD"],39.95,-75.17],
["Greenville Mariners","Greenville","NC","Southeast","Metro",72,74,75,67,69,76,8,["NC", "VA", "SC"],35.61,-77.37],
["Annapolis Admirals","Annapolis","MD","Northeast","Metro",74,77,78,65,58,98,8,["MD", "VA", "PA"],38.98,-76.49],
["Hudson Valley Guard","West Point","NY","Northeast","Metro",75,76,79,66,57,99,8,["NY", "NJ", "PA"],41.39,-73.96],
["Birmingham Ironworks","Birmingham","AL","Southeast","Metro",69,71,74,64,70,78,7,["AL", "GA", "MS"],33.52,-86.8],
["San Antonio Vaqueros","San Antonio","TX","Southwest","Metro",73,76,78,68,79,72,8,["TX", "NM", "LA"],29.42,-98.49],
["Conway Marsh","Conway","SC","Southeast","Southern Coast",73,75,76,67,62,72,8,["SC", "NC", "GA"],33.84,-79.05],
["Statesboro Pines","Statesboro","GA","Southeast","Southern Coast",72,74,74,66,61,70,8,["GA", "FL", "SC"],32.45,-81.78],
["Atlanta Phoenix","Atlanta","GA","Southeast","Southern Coast",64,63,70,59,66,77,7,["GA", "AL", "SC"],33.75,-84.39],
["Troy Titans","Troy","AL","Southeast","Southern Coast",71,73,74,67,61,71,8,["AL", "GA", "FL"],31.81,-85.97],
["Mobile Baycats","Mobile","AL","Southeast","Southern Coast",67,68,71,62,63,74,7,["AL", "FL", "MS"],30.69,-88.04],
["Lafayette Cypress","Lafayette","LA","Southeast","Southern Coast",74,76,77,69,67,73,8,["LA", "TX", "MS"],30.22,-92.02],
["Monroe Bayou","Monroe","LA","Southeast","Southern Coast",57,55,61,50,46,70,6,["LA", "MS", "AR"],32.51,-92.12],
["Jonesboro Ridge","Jonesboro","AR","Southeast","Southern Coast",64,66,68,59,55,72,7,["AR", "TN", "MS"],35.84,-90.7],
["Buffalo Blizzard","Buffalo","NY","Northeast","Northeast",61,63,66,55,52,82,7,["NY", "PA", "OH"],42.89,-78.87],
["Amherst Scholars","Amherst","MA","Northeast","Northeast",50,48,57,44,43,86,5,["MA", "NY", "NJ"],42.37,-72.52],
["Storrs Ice","Storrs","CT","Northeast","Northeast",53,51,60,46,49,89,5,["CT", "NY", "NJ"],41.81,-72.25],
["Philadelphia Founders","Philadelphia","PA","Northeast","Northeast",78,80,83,76,75,96,8,["PA", "NJ", "MD"],39.95,-75.17],
["New York Empire","New York","NY","Northeast","Northeast",70,68,75,67,74,95,7,["NY", "NJ", "CT"],40.71,-74.01],
["San Luis Obispo Coast","San Luis Obispo","CA","West","Pacific",60,62,67,55,61,84,7,["CA", "AZ", "NV"],35.28,-120.66],
["Davis Harvest","Davis","CA","West","Pacific",63,65,70,58,63,96,7,["CA", "OR", "NV"],38.54,-121.74],
["Missoula Peaks","Missoula","MT","Mountain","Pacific",69,73,72,64,56,78,8,["MT", "ID", "WA"],46.87,-113.99],
["Bozeman Sky","Bozeman","MT","Mountain","Pacific",70,74,73,65,57,80,8,["MT", "ID", "WY"],45.68,-111.04],
["Sacramento Gold","Sacramento","CA","West","Pacific",65,67,72,59,68,81,7,["CA", "NV", "OR"],38.58,-121.49],
];
nationalExpansionTeams.forEach((x,i)=>schools.push(S(200+i,x[0],x[1],x[2],x[3],x[13],x[14],x[4],x[5],x[6],x[7],x[8],x[9],x[10],x[11],x[12],`National program based in ${x[1]}, ${x[2]}.`)));
const CONFERENCE_ALIGNMENT={"Great North":["Ann Arbor Ironclads","Central Ohio","Great Lakes State","Motor City University","Madison Lakes","Minneapolis Northstar","Iowa City Harvesters","Lincoln Prairie","West Lafayette Riveters","Bloomington Torch","College Park Guardians","Piscataway Forge","Chicago Tech","Keystone State","Eugene Evergreens","Seattle Orcas","Los Angeles Centurions","Pacific Metropolitan"],"Southeastern":["Athens Black Bears","Tuscaloosa Forge","Auburn Oaks","Bayou University","Knoxville Ridge","Gainesville Swampcats","Oxford Magnolias","Starkville Iron","Columbia Palmettos","Lexington Thoroughbreds","Fayetteville Ozarks","Columbia Trailblazers","College Station Rangers","Lone Star State","Norman Stampede","Jackson Delta State"],"Atlantic":["Tallahassee Firebirds","Clemson Gold","Coral Gables Storm","Chapel Hill Pines","Raleigh Redtails","Durham Scholars","Blacksburg Foundry","Charlottesville Summit","Louisville Riverhawks","Syracuse Snowcats","Chestnut Hill Scholars","Orlando Atlantic","Carolina Coastal","Appalachian Tech","Berkeley Sequoias","Palo Alto Innovators"],"Heartland":["Ames Windriders","Manhattan Flint","Lawrence Freeholders","Waco Wranglers","Fort Worth Railmen","Lubbock Dust Devils","Stillwater Outlaws","Provo Peaks","Houston Apollos","Cincinnati Rivermen","Orlando Orbit","Morgantown Miners","Tempe Scorch","Tucson Saguaros","Boulder Peaks","Salt Lake Sentinels"],"Western":["Boise High Desert","Fort Collins Frontiers","Fresno Gold","San Diego Pacific","Corvallis Timber","Pullman Palouse","Sacramento Gold","Reno Silver"],"Metro":["Memphis Blues","Tampa Tritons","New Orleans Crescent","Tulsa Ember","Greenville Mariners","San Antonio Vaqueros","Buffalo Blizzard","Storrs Ice","Garden State","Potomac Capital"],"Great Lakes":["Lake Erie University","Athens Riverhawks","Ypsilanti Flyers","Kalamazoo Kestrels","Mount Pleasant Lumber","Akron Foundry","Kent Lightning","Bowling Green Aviators","Muncie Forge","DeKalb Prairie"],"Mountain":["Rocky Mountain State","Desert Valley","Emerald State","Laramie Range","Albuquerque Sol","Las Vegas Neon","San Jose Circuit","Honolulu Tides","Missoula Peaks","Bozeman Sky"],"Southern Coast":["Boone Summit","Conway Marsh","Statesboro Pines","Atlanta Phoenix","Troy Titans","Mobile Baycats","Lafayette Cypress","Monroe Bayou","Jonesboro Ridge","Tennessee Central"],"National":["Gulf Coast A&M","Northern Plains","Prairie A&M","Philadelphia Liberty","Birmingham Ironworks","Amherst Scholars","Philadelphia Founders","New York Empire","San Luis Obispo Coast","Davis Harvest"],"Independents":["South Bend Foundry","Annapolis Admirals","Hudson Valley Guard","Boston Commonwealth"]};
const CONFERENCE_META={"Great North":{"level":"Power","className":"conference-power","region":"Midwest + Coast","championship":true},"Southeastern":{"level":"Power","className":"conference-power","region":"South + Southwest","championship":true},"Atlantic":{"level":"Power","className":"conference-power","region":"Atlantic + Coast","championship":true},"Heartland":{"level":"Power","className":"conference-power","region":"Central + Southwest","championship":true},"Western":{"level":"Upper Group","className":"conference-upper","region":"West","championship":true},"Metro":{"level":"Group","className":"conference-group","region":"East + South","championship":true},"Great Lakes":{"level":"Group","className":"conference-group","region":"Great Lakes","championship":true},"Mountain":{"level":"Group","className":"conference-group","region":"Mountain + West","championship":true},"Southern Coast":{"level":"Group","className":"conference-group","region":"Southeast","championship":true},"National":{"level":"Group","className":"conference-group","region":"National","championship":true},"Independents":{"level":"Independent","className":"conference-independent","region":"National","championship":false}};

function applyConferenceAlignment(){
 const assigned=new Set();
 Object.entries(CONFERENCE_ALIGNMENT).forEach(([conference,names])=>{
   names.forEach(name=>{
     const school=schools.find(s=>s.name===name);
     if(!school)throw new Error(`Missing aligned school: ${name}`);
     school.conference=conference;
     school.conferenceLevel=CONFERENCE_META[conference].level;
     assigned.add(name)
   })
 });
 if(assigned.size!==schools.length)console.warn(`Alignment covers ${assigned.size} of ${schools.length} programs.`);
}
applyConferenceAlignment();

let state={school:null,year:1,week:1,phase:"REGULAR",weeklyHours:0,scholarships:35,recruits:[],commits:[],roster:[],schedule:[],record:{w:0,l:0},news:[],history:[],portal:[],seasonDone:false,offense:"Spread",defense:"4-2-5",staff:null,standings:[],trophies:[],stats:{},budget:0,jobSecurity:75,boosterSupport:65,fanApproval:65,facilities:{training:1,recruiting:1,medical:1,stadium:1,academics:1},promises:[],records:{bestSeason:null,bestClass:null,passing:null,rushing:null,receiving:null,sacks:null,interceptions:null},rivalId:null,lastGameRecap:null,signingDayResolved:false,difficulty:"STANDARD",saveSlot:"1",tutorialStep:0,tutorialDone:false,world:[],rankings:[],playoff:[],pendingEvent:null,coachCareer:{name:"Coach",salary:1500000,contractYears:4,buyout:500000,reputation:50,careerWins:0,careerLosses:0,jobs:[]},staffAssignments:{head:{region:"National",position:"ALL"},oc:{region:"Southeast",position:"OFFENSE"},dc:{region:"Midwest",position:"DEFENSE"}},pipelineLevels:{},traditions:[],stadium:{name:"Memorial Stadium",capacity:55000,attendance:0,selloutStreak:0,atmosphere:55},rivalryHistory:{},draftHistory:[],allAmericans:[],conferenceChampions:[],postseasonData:null,offseasonTasks:{spring:false,battles:false,progression:false,staff:false,draft:false},springFocus:null,jobOffers:[],coachContracts:[],schedulingMode:false,achievements:{},achievementStats:{seasons:0,rivalWins:0,conferenceTitles:0,nationalTitles:0,bowlWins:0,playoffWins:0,top5Classes:0,fiveStars:0,firstRounders:0,totalDrafted:0,undefeated:0,rebuildPlayoffs:0,allAmericans:0,awardWinners:0,facilityMax:0,portalAdds:0,roadRankedWins:0},rankingMovement:[],negativeRecruitingUsed:0,headCoach:{level:1,xp:0,skillPoints:1,skills:{}},weeklyPractice:"Balanced",gamePlan:{offenseAggression:50,tempo:50,runPass:50,blitz:35,manZone:50,fourthDown:35},depthChart:{},captains:[],disciplinePolicy:"Balanced",academicPolicy:"Balanced",playerEligibility:{},nationalStats:[],classRankings:[],conferenceRecords:{},conferenceScheduleResults:[],dynamicRivalries:[],recruitingPhase:"Evaluation",nilBudget:250000,nilCommitments:{},aiRosters:{},aiRosterVersion:2,aiRosterOffseasonYear:null,aiRosterOffseasonSummary:null,aiDraftSummaries:[],nationalDraftClass:[],nationalDraftEarlyEntries:[],nationalDraftBoardYear:null,nationalDraftBoardMeta:null,saveVersion:9};
const $=x=>document.getElementById(x),rand=(a,b)=>Math.floor(Math.random()*(b-a+1))+a,choice=a=>a[Math.floor(Math.random()*a.length)],clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),avg=a=>a.length?a.reduce((s,v)=>s+v,0)/a.length:0,pname=()=>choice(FIRST)+" "+choice(LAST),star=n=>"★".repeat(n)+"☆".repeat(5-n),initials=n=>n.split(" ").map(x=>x[0]).join("").slice(0,2);
function distance(a,b){const R=3959,dLat=(b.lat-a.lat)*Math.PI/180,dLon=(b.lon-a.lon)*Math.PI/180,x=Math.sin(dLat/2)**2+Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(dLon/2)**2;return Math.round(R*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x)))}
function metric(l,v){return `<div class="metric"><span>${l}</span><strong>${v}</strong></div>`}
function rate(l,v){return `<div class="rating-row"><div>${l}<div class="rating-bar"><div class="rating-fill" style="width:${v}%"></div></div></div><b>${v}</b></div>`}

function schoolTier(s){
 const score=s.prestige*.38+s.recent*.22+s.facilities*.16+s.pro*.14+s.nil*.10;
 if(score>=89)return{key:"ELITE",label:"Elite",className:"tier-elite",maxStar:5};
 if(score>=78)return{key:"POWER",label:"Power",className:"tier-power",maxStar:5};
 if(score>=67)return{key:"RISING",label:"Rising",className:"tier-rising",maxStar:4};
 if(score>=55)return{key:"REGIONAL",label:"Regional",className:"tier-regional",maxStar:3};
 return{key:"REBUILD",label:"Rebuild",className:"tier-rebuild",maxStar:3}
}
function recruitRequirements(r){
 const starBase={5:84,4:69,3:48,2:25}[r.stars];
 return{
   minPrestige:clamp(starBase+rand(-5,6),20,96),
   minPro:clamp(starBase-3+rand(-6,7),18,96),
   minFacilities:clamp(starBase-6+rand(-7,8),15,96),
   minRecent:clamp(starBase-8+rand(-8,9),12,96),
   minAcademics:clamp((r.priority==="Academics"?starBase+4:45)+rand(-8,8),20,98),
   minNil:clamp((r.priority==="NIL opportunity"?starBase+4:40)+rand(-8,8),15,98)
 }
}
function dealbreakerFor(r){
 const options=[
  {key:"PRESTIGE",label:"Program Prestige",field:"prestige",threshold:r.requirements.minPrestige},
  {key:"PRO",label:"Pro Development",field:"pro",threshold:r.requirements.minPro},
  {key:"FACILITIES",label:"Facilities",field:"facilities",threshold:r.requirements.minFacilities},
  {key:"RECENT",label:"Winning",field:"recent",threshold:r.requirements.minRecent},
  {key:"ACADEMICS",label:"Academics",field:"academics",threshold:r.requirements.minAcademics},
  {key:"NIL",label:"NIL Opportunity",field:"nil",threshold:r.requirements.minNil}
 ];
 let preferred=r.priority==="Academics"?"ACADEMICS":r.priority==="NIL opportunity"?"NIL":r.priority==="Pro development"?"PRO":r.priority==="Winning"?"RECENT":null;
 return preferred?options.find(x=>x.key===preferred):choice(options)
}
function meetsDealbreaker(r,s){
 if(!r.dealbreaker)return true;
 let value=s[r.dealbreaker.field]??0;
 if(r.dealbreaker.key==="PRESTIGE"&&s.prestige>=r.dealbreaker.threshold)return true;
 return value>=r.dealbreaker.threshold
}
function recruitInterestCap(r,s){
 let tier=schoolTier(s),cap=100;
 if(r.stars===5){
   if(tier.key==="REBUILD")cap=42;
   else if(tier.key==="REGIONAL")cap=58;
   else if(tier.key==="RISING")cap=76;
   else if(tier.key==="POWER")cap=94;
 }
 if(r.stars===4){
   if(tier.key==="REBUILD")cap=62;
   else if(tier.key==="REGIONAL")cap=82;
 }
 if(!meetsDealbreaker(r,s))cap=Math.min(cap,49);
 if(r.priority==="Close to home"&&distance(s,r)>1200)cap=Math.min(cap,72);
 if(r.priority==="Early playing time"&&needs()[r.pos]?.sev<1)cap=Math.min(cap,78);
 return cap
}
function recruitingAccess(r,s){
 const tier=schoolTier(s),reasons=[];
 if(r.stars>tier.maxStar)reasons.push(`${tier.label} programs cannot actively recruit ${r.stars}-star prospects`);
 if(r.stars===5&&tier.key==="POWER"&&s.prestige<80)reasons.push("Five-star access requires stronger Power-tier prestige");
 const allowed=reasons.length===0;
 return{allowed,reasons,tier,maxStar:tier.maxStar}
}
function recruitingEligibility(r,s){
 const access=recruitingAccess(r,s);
 const cap=access.allowed?recruitInterestCap(r,s):Math.min(35,recruitInterestCap(r,s));
 const locked=!access.allowed||cap<50;
 const tier=schoolTier(s);
 const reasons=[...access.reasons];
 if(!meetsDealbreaker(r,s))reasons.push(`${r.dealbreaker.label} requires ${r.dealbreaker.threshold}`);
 if(r.stars===5&&["REBUILD","REGIONAL"].includes(tier.key))reasons.push("Five-star expects a stronger national profile");
 if(r.priority==="Close to home"&&distance(s,r)>1200)reasons.push("Too far from home");
 return{cap,locked,reasons}
}
function stableRecruitSeed(r){return String(r.id||r.name).split("").reduce((n,ch)=>((n*31)+ch.charCodeAt(0))>>>0,7)}
function nilOfferAmount(r){
 const ranges={5:[60000,140000],4:[25000,80000],3:[8000,35000],2:[1000,12000]},range=ranges[r.stars]||[1000,8000],seed=stableRecruitSeed(r),step=1000,steps=Math.floor((range[1]-range[0])/step);
 return range[0]+(seed%(steps+1))*step
}
function formatNilMoney(value){return "$"+Math.round((Number(value)||0)/1000)+"k"}
function nilCommittedTotal(){return Object.values(state.nilCommitments||{}).reduce((sum,value)=>sum+(Number(value)||0),0)}
function recruitingActionStatus(r){
 const access=recruitingAccess(r,state.school),eligibility=recruitingEligibility(r,state.school),lockedOut=!!r.lockedOut?.includes(state.school.id),committed=!!r.committedTo;
 const evaluateReasons=[];
 if(committed)evaluateReasons.push(`Committed to ${schoolName(r.committedTo)}`);
 if(!access.allowed)evaluateReasons.push(...access.reasons);
 if(lockedOut)evaluateReasons.push("Your school was cut from this recruit's list");
 const canEvaluate=evaluateReasons.length===0;
 const activeReasons=[...evaluateReasons];
 if(canEvaluate&&eligibility.locked)activeReasons.push(...eligibility.reasons);
 return{access,eligibility,lockedOut,committed,canEvaluate,canRecruit:activeReasons.length===0,evaluateReason:evaluateReasons.join(" · "),activeReason:[...new Set(activeReasons)].join(" · ")}
}
function rejectRecruitAction(r,reason){if(reason)state.news.push(`${r.name}: ${reason}.`);renderAll()}
function renderSchools(){let c=$("conferencePicker").value,r=$("regionPicker").value,p=$("prestigePicker").value,q=($("teamSearch")?.value||"").trim().toLowerCase();let filtered=schools.filter(s=>(c==="ALL"||s.conference===c)&&(r==="ALL"||s.region===r)&&(p==="ALL"||(p==="ELITE"&&s.prestige>=85)||(p==="POWER"&&s.prestige>=65&&s.prestige<85)||(p==="BUILD"&&s.prestige<65))&&(!q||`${s.name} ${s.city} ${s.state} ${s.conference}`.toLowerCase().includes(q)));if($("visibleTeamCount"))$("visibleTeamCount").textContent=filtered.length;$("schoolGrid").innerHTML=filtered.map(s=>`<article class="school-card"><div class="tier-line"><span class="tier-badge ${schoolTier(s).className}">${schoolTier(s).label}</span><small class="muted">Max natural target: ${schoolTier(s).maxStar}★</small></div><h3>${s.name}</h3><div class="school-location">${s.city}, ${s.state} · ${s.conference}<span class="sub">${CONFERENCE_META[s.conference]?.level||""}</span></div><p class="tagline">${s.tag}</p>${rate("Prestige",s.prestige)}${rate("Facilities",s.facilities)}${rate("Recent Success",s.recent)}${rate("Pro Pipeline",s.pro)}<button class="btn primary full choose" data-id="${s.id}">Take Over Program</button></article>`).join("");document.querySelectorAll(".choose").forEach(b=>b.onclick=()=>start(+b.dataset.id))}
function makeCoach(role,base){return{name:pname(),role,recruiting:clamp(base+rand(-10,10),45,95),development:clamp(base+rand(-10,10),45,95),game:clamp(base+rand(-10,10),45,95)}}

function difficultyConfig(){
 const base=state.difficulty==="CASUAL"?{hours:1.2,ai:.82,injury:.7,job:.6,portal:.7}:
 state.difficulty==="DYNASTY"?{hours:.88,ai:1.18,injury:1.25,job:1.35,portal:1.3}:
 state.difficulty==="COMMISSIONER"?{hours:1.5,ai:.7,injury:.4,job:0,portal:.5}:
 {hours:1,ai:1,injury:1,job:1,portal:1};
 const recruiting=Math.max(.8,Math.min(1.3,Number(state.realismSettings?.recruiting||1)));
 return{...base,hours:base.hours/Math.sqrt(recruiting),ai:base.ai*recruiting}
}
function rollDevelopment(stars=0,ovr=65){
 const roll=Math.random();
 // Elite development is intentionally rare. Higher-rated prospects get a
 // modestly better chance, but normal and impact development remain common.
 let elite=.012,star=.075,impact=.255;
 if(stars>=5){elite=.075;star=.22;impact=.36}
 else if(stars===4){elite=.035;star=.15;impact=.33}
 else if(stars===3){elite=.01;star=.075;impact=.26}
 else if(stars===2){elite=.004;star=.035;impact=.20}
 else if(ovr>=82){elite=.035;star=.14;impact=.34}
 else if(ovr>=74){elite=.02;star=.10;impact=.30}
 if(roll<elite)return "Elite";
 if(roll<elite+star)return "Star";
 if(roll<elite+star+impact)return "Impact";
 return "Normal"
}
function buildWorld(){
 return schools.map(s=>({id:s.id,name:s.name,conference:s.conference,prestige:s.prestige,recent:s.recent,facilities:s.facilities,pro:s.pro,coach:rand(55,92),offense:choice(["Pro Style","Spread","Air Raid","Power Run","Option","Tempo Spread"]),defense:choice(["4-3","3-4","4-2-5","3-3-5","Multiple"]),record:{w:0,l:0},rosterPower:Math.round((s.prestige+s.recent+s.facilities)/3)+rand(-5,5),classRank:rand(10,90)}))
}
function simulateWorldWeek(){
 state.world.filter(t=>t.id!==state.school.id).forEach(t=>{let opponent=choice(state.world.filter(x=>x.id!==t.id)),edge=t.rosterPower-opponent.rosterPower+rand(-12,12);edge>=0?t.record.w++:t.record.l++;t.recent=clamp(t.recent+(edge>=0?.3:-.3),20,99)})
 updateRankings()
}
function updateRankings(){
 let user={id:state.school.id,name:state.school.name,conference:state.school.conference,prestige:state.school.prestige,recent:state.school.recent,record:state.record,rosterPower:teamRatings().overall};
 let all=state.world.filter(t=>t.id!==state.school.id).concat(user);
 const oldRanks=Object.fromEntries((state.rankings||[]).map(t=>[t.id,t.rank]));state.rankings=all.map(t=>({...t,score:(t.record.w*18-t.record.l*8)+(t.rosterPower||70)*.7+(t.prestige||60)*.2+(t.recent||60)*.2})).sort((a,b)=>b.score-a.score).map((t,i)=>({...t,rank:i+1}));
 state.playoff=state.rankings.slice(0,12);state.rankingMovement=state.rankings.slice(0,25).map(t=>({id:t.id,name:t.name,from:oldRanks[t.id]||null,to:t.rank,change:oldRanks[t.id]?oldRanks[t.id]-t.rank:0}))
}
function findRival(id){let s=schools.find(x=>x.id===id),same=schools.filter(x=>x.id!==id&&x.region===s.region).sort((a,b)=>Math.abs(a.prestige-s.prestige)-Math.abs(b.prestige-s.prestige));return (same[0]||schools.find(x=>x.id!==id)).id}

function start(id){state.school=JSON.parse(JSON.stringify(schools.find(s=>s.id===id)));let b=Math.round((state.school.prestige+state.school.recent)/2);state.staff={head:makeCoach("Head Coach",b),oc:makeCoach("Offensive Coordinator",b-2),dc:makeCoach("Defensive Coordinator",b-2)};state.difficulty=$("difficultyPicker")?.value||"STANDARD";state.saveSlot=$("saveSlotPicker")?.value||"1";state.coachCareer??={name:"Coach",salary:1500000,contractYears:4,buyout:500000,reputation:50,careerWins:0,careerLosses:0,jobs:[]};state.coachCareer.salary=Math.round((650000+Number(state.school.prestige||50)*20000)/10000)*10000;let programAllocation=Math.round((2400000+Number(state.school.prestige||50)*40000+Number(state.school.recent||50)*15000+Number(state.school.facilities||50)*10000+Math.round((Number(state.school.prestige||50)+Number(state.school.recent||50))/2)*8000)/10000)*10000,coordinatorPayroll=['oc','dc'].reduce((sum,key)=>{let coach=state.staff[key],rating=(Number(coach.recruiting||50)+Number(coach.development||50)+Number(coach.game||50))/3;return sum+Math.round((240000+rating*9000)/10000)*10000},0);state.budget=Math.max(500000,programAllocation-Number(state.coachCareer.salary||0)-coordinatorPayroll);state._staffPayrollYear=state.year;state._programAllocationYear=state.year;state._budgetAuditV144=false;state._salaryScaleV144=false;state.boosterSupport=clamp(Math.round((state.school.prestige+state.school.recent)/2),35,95);state.fanApproval=state.boosterSupport;state.rivalId=findRival(id);state.roster=genRoster();state.world=buildWorld();beginYear();$("schoolScreen").classList.add("hidden");$("gameScreen").classList.remove("hidden");$("mobileBottomNav")?.classList.remove("hidden");$("mobileStatus")?.classList.remove("hidden");initializeExpansion();renderAll();startTutorial()}
function attrsFor(pos,ovr){let speed=clamp(ovr+rand(-10,10),45,99),strength=clamp(ovr+rand(-10,10),45,99),skill=clamp(ovr+rand(-8,8),45,99),awareness=clamp(ovr+rand(-12,8),40,99);return{speed,strength,skill,awareness}}
function genRoster(){let a=[];POSITIONS.forEach(p=>{for(let i=0;i<DEPTH[p]+rand(-1,1);i++){let h=choice(LOC),yr=rand(1,4),base=(state.school.prestige+state.school.recent)/2,ovr=clamp(Math.round(base)+rand(-16,8)-(yr===1?6:0),48,93);a.push({id:crypto.randomUUID(),name:pname(),pos:p,arch:choice(ARCH[p]),hometown:`${h[0]}, ${h[1]}`,year:yr,ovr,pot:clamp(ovr+rand(3,10),ovr,95),dev:rollDevelopment(0,ovr),morale:rand(65,95),seasonStats:emptySeasonStats(),statHistory:[],gameLog:[],personality:choice(["Loyal","Ambitious","Team-first","Competitive","Money-driven","Homesick","Academic","Volatile"]),starter:false,redshirt:false,redshirtUsed:false,redshirtSeason:null,progressionHistory:[],injury:null,stats:{games:0,yards:0,td:0,tackles:0,sacks:0,int:0},attrs:attrsFor(p,ovr)})}});autoDepth(a);return a}
function beginYear(){ensureV9State();initializeDepthChart();updateEligibility();state.week=1;state.phase="REGULAR";state.record={w:0,l:0};state.seasonDone=false;state.commits=[];state.scholarships=35;state.signingDayResolved=false;state.lastGameRecap=null;state.recruits=genRecruits(3000);window.SDF_AI_ROSTERS?.ensureAll?.();state.schedule=genSchedule();state.portal=[];state.news=[`Year ${state.year} recruiting opened with the complete ${state.recruits.length}-prospect national class.`];state.standings=schools.filter(s=>s.conference===state.school.conference).map(s=>({id:s.id,name:s.name,w:0,l:0}));state.promises=state.promises.filter(p=>!p.resolved);resetHours()}
function genRecruits(n){
 return Array.from({length:n},()=>{
  const roll=Math.random(),st=roll>.98?5:roll>.85?4:roll>.32?3:2,p=choice(POSITIONS),l=choice(LOC),interest={};
  const generatedGem=st===3&&Math.random()<.025;
  let ovr;if(st===5)ovr=rand(82,91);else if(st===4)ovr=rand(73,83);else if(st===3)ovr=generatedGem?rand(78,82):rand(64,76);else ovr=rand(54,65);
  const priority=choice(["Early playing time","Pro development","Close to home","Winning","NIL opportunity","Academics"]);
  const r={id:crypto.randomUUID(),name:pname(),pos:p,arch:choice(ARCH[p]),city:l[0],home:l[1],region:l[2],lat:l[3],lon:l[4],stars:st,ovr,pot:0,dev:rollDevelopment(st,ovr),generatedGem,scouted:false,onBoard:false,offered:false,committedTo:null,interest,visit:false,promise:null,priority,personality:choice(["Loyal","Ambitious","Team-first","Competitive","Money-driven","Homesick","Academic","Volatile"]),weeklyPlan:"NONE",stage:"Open",attrs:null,pitchHistory:{},lockedOut:[]};
  r.requirements=recruitRequirements(r);r.dealbreaker=dealbreakerFor(r);return r
 }).sort((a,b)=>b.stars-a.stars||b.ovr-a.ovr).map((r,i)=>{r.rank=i+1;applyHiddenEvaluation(r);relationshipForRecruit(r);return r})
}
function genSchedule(){let pool=schools.filter(s=>s.id!==state.school.id&&s.id!==state.rivalId).sort(()=>Math.random()-.5),rival=schools.find(s=>s.id===state.rivalId);return Array.from({length:12},(_,i)=>{let o=i===11?rival:pool[i%pool.length],world=state.world?.find(t=>Number(t.id)===Number(o.id)),persistent=window.SDF_AI_ROSTERS?.get?.(o.id),ratings=persistent?.length?window.SDF_AI_ROSTERS?.teamRatings?.(persistent):null;let g={week:i+1,opponent:o.name,oppId:o.id,oppPower:Number(ratings?.overall||world?.rosterPower||Math.round((o.prestige+o.recent)/2)),home:Math.random()>.45,result:null,score:null,conference:(world?.conference||o.conference)===state.school.conference,rivalry:o.id===state.rivalId};g.weather=weatherForGame(g);return g})}
function calculateRecruitingHours(s=state.school){
 if(!s)return 350;
 const prestige=Number(s.prestige||50),tier=schoolTier(s);
 const base=prestige<=44?350:prestige<=54?400:prestige<=64?500:prestige<=74?650:prestige<=84?800:1000;
 const facilityBonus=Math.max(0,(Number(state.facilities?.recruiting||1)-1)*35);
 const staffRating=Number(state.staff?.head?.recruiting||55);
 const staffBonus=clamp(Math.round((staffRating-55)*2),-25,100);
 const last=state.history?.at(-1);
 const performance=last?clamp((Number(last.wins||0)-Number(s.expectation||6))*15,-45,75):0;
 const mult=Number(difficultyConfig?.().hours||1);
 const bounds={REBUILD:[350,500],REGIONAL:[400,650],RISING:[500,800],POWER:[650,1000],ELITE:[850,1150]}[tier.key]||[350,1150];
 return clamp(Math.round((base+facilityBonus+staffBonus+performance)*mult),bounds[0],bounds[1])
}
window.calculateRecruitingHours=calculateRecruitingHours;
function resetHours(){
 const cap=calculateRecruitingHours();
 state.weeklyHours=cap;
 state.recruitingHoursCapacity=cap;
 state._recruitingHoursWeekKey=`${state.year}-${state.week}`
}
function migrateDynastyCore(){
 if(!state?.school)return;
 const cap=calculateRecruitingHours();
 const oldCap=Number(state.recruitingHoursCapacity||0);
 const remaining=Number(state.weeklyHours||0);
 if(oldCap<200){
  const spent=oldCap>0?Math.max(0,oldCap-remaining):0;
  state.recruitingHoursCapacity=cap;
  state.weeklyHours=Math.max(0,cap-spent);
  state._recruitingHoursWeekKey=`${state.year}-${state.week}`;
  state.news??=[];
  state.news.push(`Clean Core upgraded weekly recruiting capacity to ${cap} hours.`)
 }else{
  state.recruitingHoursCapacity=Math.max(oldCap,cap);
  state.weeklyHours=Math.min(Math.max(0,remaining),state.recruitingHoursCapacity)
 }
 if(Number(state.budget||0)<0){
  const s=state.school;
  const annual=Math.round((2400000+Number(s.prestige||50)*40000+Number(s.recent||50)*15000+Number(s.facilities||50)*10000+Number(state.boosterSupport||55)*8000)/10000)*10000;
  const recovery=Math.max(500000,Math.round(annual*.32/10000)*10000);
  state.budget=recovery;
  state.news??=[];
  state.news.push(`Clean Core repaired negative Program Funds and restored $${Math.round(recovery/1000)}k.`)
 }
 (state.recruits||[]).forEach(r=>{r.actionHistory??={}})
}
window.migrateDynastyCore=migrateDynastyCore;

function autoDepth(r=state.roster){POSITIONS.forEach(p=>r.filter(x=>x.pos===p&&!x.redshirt&&!x.injury).sort((a,b)=>b.ovr-a.ovr).forEach((x,i)=>x.starter=i<STARTERS[p]));r.filter(x=>x.redshirt||x.injury).forEach(x=>x.starter=false)}
function autoRedshirt(){state.roster.filter(p=>p.year===1&&!p.starter).sort((a,b)=>a.ovr-b.ovr).slice(0,12).forEach(p=>p.redshirt=true);autoDepth();renderAll()}
function needs(){let o={};POSITIONS.forEach(p=>{let a=state.roster.filter(x=>x.pos===p),sen=a.filter(x=>x.year===4).length,q=Math.round(avg(a.filter(x=>!x.injury).sort((x,y)=>y.ovr-x.ovr).slice(0,STARTERS[p]).map(x=>x.ovr))),sev=Math.max(0,DEPTH[p]-a.length)*3+sen*1.4+(q<65?3:q<72?1.5:0);o[p]={count:a.length,sen,q,sev,label:sev>=5?"Immediate":sev>=2.5?"High":sev>=1?"Future":"Low"}});return o}
function teamRatings(){ensureV9State();applyDepthChart();let by=p=>avg(state.roster.filter(x=>x.pos===p&&x.starter&&!x.injury).map(x=>x.ovr));return{offense:Math.round(avg(["QB","RB","WR","TE","OT","IOL"].map(by))),defense:Math.round(avg(["EDGE","DL","LB","CB","S"].map(by))),special:Math.round(by("K")),overall:Math.round(avg(state.roster.filter(x=>x.starter&&!x.injury).map(x=>x.ovr)))}}

const HEAD_COACH_SKILLS=[
{id:"RECRUITER_1",name:"Relationship Builder",branch:"Recruiting",cost:1,requires:[],desc:"+3 Recruit rating and +6% recruiting action effectiveness."},
{id:"RECRUITER_2",name:"National Reach",branch:"Recruiting",cost:2,requires:["RECRUITER_1"],desc:"+4 Recruit rating; reduces distance penalties and improves pipelines."},
{id:"EVALUATOR",name:"Talent Evaluator",branch:"Recruiting",cost:2,requires:["RECRUITER_1"],desc:"+3 Recruit rating; raises scouting confidence and gem identification."},
{id:"DEVELOPER_1",name:"Teacher",branch:"Development",cost:1,requires:[],desc:"+3 Develop rating and stronger offseason development for young players."},
{id:"DEVELOPER_2",name:"Player Developer",branch:"Development",cost:2,requires:["DEVELOPER_1"],desc:"+5 Develop rating; improves progression and position changes."},
{id:"IRON_MEN",name:"Conditioning Program",branch:"Development",cost:2,requires:["DEVELOPER_1"],desc:"+2 Develop rating and reduced injury risk."},
{id:"TACTICIAN_1",name:"Prepared",branch:"Game Planning",cost:1,requires:[],desc:"+3 Game rating; practice focus has a stronger game effect."},
{id:"TACTICIAN_2",name:"Matchup Expert",branch:"Game Planning",cost:2,requires:["TACTICIAN_1"],desc:"+5 Game rating; opponent scouting reveals more weaknesses."},
{id:"AGGRESSIVE",name:"Calculated Aggression",branch:"Game Planning",cost:2,requires:["TACTICIAN_1"],desc:"+2 Game rating; improves fourth-down and late-game outcomes."},
{id:"CULTURE_1",name:"Culture Builder",branch:"Leadership",cost:1,requires:[],desc:"+1 to all coach ratings; raises morale and reduces discipline events."},
{id:"CULTURE_2",name:"Players' Coach",branch:"Leadership",cost:2,requires:["CULTURE_1"],desc:"+1 to all coach ratings; loyalty improves and portal risk declines."},
{id:"CEO",name:"Program CEO",branch:"Leadership",cost:3,requires:["CULTURE_1","RECRUITER_1"],desc:"+2 to all coach ratings; improves staff retention, boosters, and job security."}
];
function ensureV9State(){
 state.headCoach??={level:1,xp:0,skillPoints:1,skills:{}};
 state.weeklyPractice??="Balanced";state.gamePlan??={offenseAggression:50,tempo:50,runPass:50,blitz:35,manZone:50,fourthDown:35};
 state.depthChart??={};state.captains??=[];state.disciplinePolicy??="Balanced";state.academicPolicy??="Balanced";state.playerEligibility??={};
 state.nationalStats??=[];state.classRankings??=[];state.conferenceRecords??={};state.conferenceScheduleResults??=[];state.dynamicRivalries??=[];
 state.recruitingPhase??="Evaluation";state.nilBudget??=250000;state.nilCommitments??={};state.aiRosters??={};state.aiRosterVersion??=2;state.aiDraftSummaries??=[];state.nationalDraftClass??=[];state.nationalDraftEarlyEntries??=[];state.saveVersion=9;syncHeadCoachRatings();
}
const HEAD_COACH_RATING_BONUSES={
 RECRUITER_1:{recruiting:3},RECRUITER_2:{recruiting:4},EVALUATOR:{recruiting:3},
 DEVELOPER_1:{development:3},DEVELOPER_2:{development:5},IRON_MEN:{development:2},
 TACTICIAN_1:{game:3},TACTICIAN_2:{game:5},AGGRESSIVE:{game:2},
 CULTURE_1:{recruiting:1,development:1,game:1},CULTURE_2:{recruiting:1,development:1,game:1},CEO:{recruiting:2,development:2,game:2}
};
function syncHeadCoachRatings(){
 if(!state.staff?.head||!state.headCoach)return;const head=state.staff.head;
 if(!state.headCoach.baseRatings)state.headCoach.baseRatings={recruiting:Number(head.recruiting||55),development:Number(head.development||55),game:Number(head.game||55)};
 const base=state.headCoach.baseRatings,bonus={recruiting:0,development:0,game:0};for(const [id,on] of Object.entries(state.headCoach.skills||{})){if(!on)continue;const b=HEAD_COACH_RATING_BONUSES[id]||{};bonus.recruiting+=Number(b.recruiting||0);bonus.development+=Number(b.development||0);bonus.game+=Number(b.game||0)}
 head.recruiting=clamp(Math.round(Number(base.recruiting||55)+bonus.recruiting),0,99);head.development=clamp(Math.round(Number(base.development||55)+bonus.development),0,99);head.game=clamp(Math.round(Number(base.game||55)+bonus.game),0,99);state.headCoach.ratingBonuses=bonus;
}
window.syncHeadCoachRatings=syncHeadCoachRatings;
function hasCoachSkill(id){return !!state.headCoach.skills[id]}
function coachRecruitingMult(){return 1+(hasCoachSkill("RECRUITER_1")?.06:0)+(hasCoachSkill("RECRUITER_2")?.04:0)}
function coachPracticeBonus(){return hasCoachSkill("TACTICIAN_1")?1.35:1}
function coachInjuryMult(){return hasCoachSkill("IRON_MEN")?.72:1}
function addCoachXP(amount){ensureV9State();state.headCoach.xp+=amount;while(state.headCoach.xp>=state.headCoach.level*100){state.headCoach.xp-=state.headCoach.level*100;state.headCoach.level++;state.headCoach.skillPoints++;state.news.push(`Head coach reached Level ${state.headCoach.level} and earned a skill point.`)}}
function unlockCoachSkill(id){
 const skill=HEAD_COACH_SKILLS.find(s=>s.id===id);if(!skill||hasCoachSkill(id)||state.headCoach.skillPoints<skill.cost||!skill.requires.every(hasCoachSkill))return;
 state.headCoach.skillPoints-=skill.cost;state.headCoach.skills[id]=true;syncHeadCoachRatings();renderCoachTab();window.renderStaff11?.();window.renderAll?.()
}
window.unlockCoachSkill=unlockCoachSkill;
function renderCoachTab(){
 if(!$("coachSkillTree"))return;ensureV9State();syncHeadCoachRatings();
 $("coachSkillSummary").innerHTML=`<b>Level ${state.headCoach.level}</b> · ${state.headCoach.skillPoints} skill points · ${state.headCoach.xp}/${state.headCoach.level*100} XP`;
 $("coachSkillTree").innerHTML=HEAD_COACH_SKILLS.map(s=>{let unlocked=hasCoachSkill(s.id),available=!unlocked&&state.headCoach.skillPoints>=s.cost&&s.requires.every(hasCoachSkill);return`<div class="skill-node ${unlocked?"unlocked":available?"":"locked"}"><span class="eyebrow">${s.branch}</span><h4>${s.name}</h4><span class="sub">${s.desc}</span><small>Cost ${s.cost} · Requires ${s.requires.length?s.requires.map(x=>HEAD_COACH_SKILLS.find(y=>y.id===x)?.name).join(", "):"None"}</small><button class="btn ${unlocked?"success":"primary"}" onclick="unlockCoachSkill('${s.id}')" ${unlocked||!available?"disabled":""}>${unlocked?"Unlocked":"Unlock"}</button></div>`}).join("");
 renderLeadershipPanel()
}
function initializeDepthChart(){
 ensureV9State();POSITIONS.forEach(pos=>{let eligible=state.roster.filter(p=>p.pos===pos&&!p.redshirt).sort((a,b)=>b.ovr-a.ovr);state.depthChart[pos]??={slots:eligible.slice(0,3).map((p,i)=>({playerId:p.id,snapShare:i===0?70:i===1?25:5}))}})
}
function normalizeSnapShares(pos){
 let slots=state.depthChart[pos]?.slots||[],total=slots.reduce((n,s)=>n+Number(s.snapShare||0),0);if(!total)return;slots.forEach(s=>s.snapShare=Math.round(Number(s.snapShare||0)/total*100))
}
function setDepthPlayer(pos,index,id){initializeDepthChart();state.depthChart[pos].slots[index]??={playerId:null,snapShare:0};state.depthChart[pos].slots[index].playerId=id;applyDepthChart();renderDepthManager()}
function setSnapShare(pos,index,value){initializeDepthChart();state.depthChart[pos].slots[index].snapShare=clamp(Number(value)||0,0,100);normalizeSnapShares(pos);applyDepthChart();renderDepthManager()}
window.setDepthPlayer=setDepthPlayer;window.setSnapShare=setSnapShare;
function applyDepthChart(){
 state.roster.forEach(p=>p.starter=false);Object.values(state.depthChart).forEach(d=>{let first=d.slots?.[0];if(first){let p=state.roster.find(x=>x.id===first.playerId);if(p)p.starter=true}})
}
function renderDepthManager(){
 if(!$("depthChartManager"))return;initializeDepthChart();
 $("depthChartManager").innerHTML=POSITIONS.map(pos=>{let players=state.roster.filter(p=>p.pos===pos&&!p.redshirt),slots=state.depthChart[pos]?.slots||[];return`<div class="depth-position"><div class="depth-position-head"><b>${pos}</b><span class="sub">${players.length} available</span></div><div class="depth-slots">${[0,1,2].map(i=>`<div class="depth-slot"><small>${i===0?"Starter":i===1?"Rotation":"Reserve"}</small><select onchange="setDepthPlayer('${pos}',${i},this.value)"><option value="">Unassigned</option>${players.map(p=>`<option value="${p.id}" ${slots[i]?.playerId===p.id?"selected":""}>${p.name} · ${p.ovr}</option>`).join("")}</select><input type="range" min="0" max="100" value="${slots[i]?.snapShare||0}" onchange="setSnapShare('${pos}',${i},this.value)"><span class="sub">${slots[i]?.snapShare||0}% snaps</span></div>`).join("")}</div></div>`}).join("")
}
function currentOpponent(){return state.schedule?.[state.week-1]||null}
function opponentProfile(g){
 if(!g)return null;let s=schools.find(x=>x.id===g.oppId),power=g.oppPower||70;
 return{school:s,offense:clamp(power+rand(-4,4),45,99),defense:clamp(power+rand(-4,4),45,99),tendency:choice(["Pass Heavy","Balanced","Run Heavy","Tempo","Ball Control"]),front:choice(["4-3","3-4","4-2-5","3-3-5"]),weakness:choice(["Pass protection","Run defense","Secondary depth","Turnover margin","Red-zone offense","Special teams"]),star:choice(["Quarterback","Running back","Edge rusher","Cornerback","Wide receiver"]),injuries:rand(0,3),form:choice(["Hot","Steady","Inconsistent","Slumping"])}
}
function choosePracticeFocus(f){state.weeklyPractice=f;renderGamePlan()}
window.choosePracticeFocus=choosePracticeFocus;
function updateGamePlan(key,value){state.gamePlan[key]=Number(value);renderGamePlan()}
window.updateGamePlan=updateGamePlan;
function renderGamePlan(){
 if(!$("opponentScoutPanel"))return;ensureV9State();let g=currentOpponent(),o=opponentProfile(g);
 if(!g){$("opponentScoutPanel").innerHTML='<p class="muted">No upcoming game.</p>';return}
 $("opponentScoutPanel").innerHTML=`<div class="scout-report"><div><small>OPPONENT</small><b>${g.opponent}</b></div><div><small>POWER</small><b>${g.oppPower}</b></div><div><small>TENDENCY</small><b>${o.tendency}</b></div><div><small>DEFENSIVE FRONT</small><b>${o.front}</b></div><div><small>WEAKNESS</small><b>${hasCoachSkill("TACTICIAN_2")?o.weakness:"Partially scouted"}</b></div><div><small>STAR UNIT</small><b>${o.star}</b></div><div><small>FORM</small><b>${o.form}</b></div><div><small>WEATHER</small><b>${g.weather||"Clear"}</b></div></div>`;
 const focuses=["Balanced","Opponent Scouting","Passing Offense","Rushing Offense","Run Defense","Pass Defense","Turnover Prevention","Young Player Development","Injury Prevention"];
 $("practiceFocusGrid").innerHTML=focuses.map(f=>`<div class="choice-card ${state.weeklyPractice===f?"active":""}"><h4>${f}</h4><span class="sub">${practiceDescription(f)}</span><button class="btn primary" onclick="choosePracticeFocus('${f}')">Select</button></div>`).join("");
 const controls=[["runPass","Run ←→ Pass"],["tempo","Slow ←→ Fast"],["offenseAggression","Conservative ←→ Aggressive"],["blitz","Coverage ←→ Blitz"],["manZone","Man ←→ Zone"],["fourthDown","Punt ←→ Go For It"]];
 $("gamePlanControls").innerHTML=controls.map(([key,label])=>`<div class="gameplan-card"><h4>${label}</h4><input type="range" min="0" max="100" value="${state.gamePlan[key]}" onchange="updateGamePlan('${key}',this.value)"><b>${state.gamePlan[key]}</b></div>`).join("")
}
function practiceDescription(f){
 return{Balanced:"Small benefit across the roster.","Opponent Scouting":"Improves matchup performance and reveals tendencies.","Passing Offense":"Boosts quarterbacks and receivers this week.","Rushing Offense":"Boosts backs and offensive line this week.","Run Defense":"Improves front-seven performance.","Pass Defense":"Improves coverage and pressure.","Turnover Prevention":"Reduces offensive turnovers.","Young Player Development":"Backups gain development but game readiness suffers slightly.","Injury Prevention":"Reduces injury and fatigue risk."}[f]
}
function weeklyGamePlanModifier(g){
 let mod=0,m=coachPracticeBonus();if(state.weeklyPractice==="Opponent Scouting")mod+=3*m;if(state.weeklyPractice==="Passing Offense"&&state.gamePlan.runPass>=50)mod+=3*m;if(state.weeklyPractice==="Rushing Offense"&&state.gamePlan.runPass<50)mod+=3*m;if(state.weeklyPractice==="Run Defense")mod+=2*m;if(state.weeklyPractice==="Pass Defense")mod+=2*m;if(state.weeklyPractice==="Turnover Prevention")mod+=1.5*m;
 mod+=(state.captains.length>=2?1:0);return Math.round(mod)
}
function updateRecruitingPhase(){
 state.recruitingPhase=state.week<=3?"Open Evaluation":state.week<=6?"Contact Period":state.week<=8?"Top-10 Watch":state.week<=10?"Final-Five Push":state.week<=12?"Finalists & Visits":"Signing Day"
}
function offerNil(id){
 if(window.SDF_RECRUITING_V2?.openNilNegotiation)return window.SDF_RECRUITING_V2.openNilNegotiation(id);
 const r=findR(id);if(!r)return;
 alert('The recruiting engine is still loading. Please reopen the prospect.')
}
window.offerNil=offerNil;
function setCaptain(id){
 state.captains??=[];if(state.captains.includes(id))state.captains=state.captains.filter(x=>x!==id);else if(state.captains.length<4)state.captains.push(id);renderLeadershipPanel()
}
window.setCaptain=setCaptain;
function renderLeadershipPanel(){
 if(!$("leadershipPanel"))return;let candidates=state.roster.slice().sort((a,b)=>(b.year*8+b.ovr+b.morale)-(a.year*8+a.ovr+a.morale)).slice(0,12);
 $("leadershipPanel").innerHTML=`<div class="metric-grid">${metric("Captains",state.captains.length+"/4")}${metric("Discipline",state.disciplinePolicy)}${metric("Academic Policy",state.academicPolicy)}${metric("Eligible Players",state.roster.filter(p=>state.playerEligibility[p.id]!==false).length)}</div><h3>Team Captains</h3>${candidates.map(p=>`<button class="btn ${state.captains.includes(p.id)?"success":"neutral"}" onclick="setCaptain('${p.id}')">${p.name} · ${p.pos} · Year ${p.year}</button>`).join("")}<div class="gameplan-grid"><div class="gameplan-card"><h4>Discipline Policy</h4><select onchange="state.disciplinePolicy=this.value;renderLeadershipPanel()">${["Strict","Balanced","Player-Friendly"].map(x=>`<option ${state.disciplinePolicy===x?"selected":""}>${x}</option>`).join("")}</select></div><div class="gameplan-card"><h4>Academic Policy</h4><select onchange="state.academicPolicy=this.value;renderLeadershipPanel()">${["Strict","Balanced","Football-First"].map(x=>`<option ${state.academicPolicy===x?"selected":""}>${x}</option>`).join("")}</select></div></div>`
}
function updateEligibility(){
 state.roster.forEach(p=>{let academicRisk=Math.random()<(state.academicPolicy==="Strict"?.015:state.academicPolicy==="Balanced"?.035:.07);state.playerEligibility[p.id]=!academicRisk;if(academicRisk)p.injury={weeks:1,type:"Academically ineligible"}})
}
function renderNationalLeaders(){
 if(window.SDF_V175?.renderNationalStats)return window.SDF_V175.renderNationalStats();
 if(!$("nationalLeaderGrid"))return;$("nationalLeaderGrid").innerHTML='<p class="muted">National statistics become available after the dynasty statistics engine initializes.</p>'
}
function computeClassRankings(){
 state.classRankings=schools.map(s=>{let user=s.id===state.school.id,commits=user?state.commits.length:rand(10,27),five=user?state.commits.filter(r=>r.stars===5).length:Math.max(0,Math.round((s.prestige-72)/10)+rand(-1,2)),four=user?state.commits.filter(r=>r.stars===4).length:Math.max(0,Math.round((s.prestige-55)/7)+rand(-2,3)),avgRating=user?(state.commits.length?Math.round(avg(state.commits.map(r=>r.ovr))):0):clamp(Math.round(s.prestige*.72+rand(8,22)),45,94);return{id:s.id,name:s.name,commits,five,four,avgRating,score:commits*2+five*18+four*8+avgRating*.8}}).sort((a,b)=>b.score-a.score).map((x,i)=>({...x,rank:i+1}))
}
function renderClassRankings(){
 if(!$("classRankingGrid"))return;computeClassRankings();$("classRankingGrid").innerHTML=state.classRankings.slice(0,25).map(x=>`<div class="class-ranking-card"><b>#${x.rank} ${x.name}</b><span class="sub">${x.commits} commits · ${x.five} five-stars · ${x.four} four-stars · Avg ${x.avgRating}</span></div>`).join("")
}
function maybeCreateDynamicRivalry(g){
 let opp=schools.find(s=>s.id===g.oppId);if(!opp||g.rivalry)return;let meetings=state.history.filter(h=>h.opponents?.includes?.(opp.name)).length;if((meetings>=3||Math.abs(Number(g.score?.split("-")[0])-Number(g.score?.split("-")[1]))<=3)&&Math.random()<.2&&!state.dynamicRivalries.some(r=>r.id===opp.id)){state.dynamicRivalries.push({id:opp.id,name:opp.name,formedYear:state.year,reason:"Repeated high-stakes meetings"});state.news.push(`A new rivalry has formed with ${opp.name}.`)}
}
function exportDynastySave(){
 const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=`Saturday-Dynasty-Football-Year-${state.year}-Save.json`;a.click();URL.revokeObjectURL(url)
}
function importDynastySave(file){
 const reader=new FileReader();reader.onload=()=>{try{const imported=JSON.parse(reader.result);if(!imported.school||!imported.roster)throw new Error("Invalid save");state=imported;ensureExpansionState();ensureV9State();save();location.reload()}catch(e){alert("That file is not a valid Saturday Dynasty Football save.")}};reader.readAsText(file)
}
function renderV9(){
 ensureV9State();renderDepthManager();renderGamePlan();renderCoachTab();renderNationalLeaders();renderClassRankings();updateRecruitingPhase()
}

function renderAll(){if(!state.school)return;migrateDynastyCore();$("yearLabel").textContent=state.year;$("weekLabel").textContent=state.phase==="REGULAR"?state.week:state.phase;$("recordLabel").textContent=`${state.record.w}-${state.record.l}`;if($("mobileYear"))$("mobileYear").textContent=state.year;if($("mobileWeek"))$("mobileWeek").textContent=state.phase==="REGULAR"?state.week:state.phase;if($("mobileRecord"))$("mobileRecord").textContent=`${state.record.w}-${state.record.l}`;$("hoursLabel").textContent=state.weeklyHours;$("scholarshipLabel").textContent=state.scholarships;$("schoolName").textContent=state.school.name;$("schoolMeta").textContent=`${state.school.city}, ${state.school.state} · ${state.school.conference}`;$("programMark").textContent=initials(state.school.name);$("offenseScheme").value=state.offense;$("defenseScheme").value=state.defense;ensureExpansionState();renderSidebar();renderDashboard();renderStaff();renderStaffAssignments();renderNeeds();renderRecruiting();renderRoster();renderTeam();renderSchedule();renderStandings();renderProgram();renderTraditionsAndStadium();renderStats();renderV9();renderRankings();renderConferenceDirectory();renderDynasty();renderOffseasonHub();renderHistory()}
function renderSidebar(){$("schoolSummary").innerHTML=[["Prestige",state.school.prestige],["Recent success",state.school.recent],["Record",`${state.record.w}-${state.record.l}`],["Expectation",`${state.school.expectation} wins`],["Pipelines",state.school.pipelines.join(", ")]].map(x=>`<div class="stat-line"><span>${x[0]}</span><b>${x[1]}</b></div>`).join("")}
function renderDashboard(){let ca=Math.round(avg(state.commits.map(r=>r.ovr))||0),t=teamRatings();$("programCards").innerHTML=metric("Team OVR",t.overall)+metric("Offense",t.offense)+metric("Defense",t.defense)+metric("Roster Size",state.roster.length)+metric("Commits",state.commits.length)+metric("Class Average",ca||"-")+metric("Budget","$"+Math.round(state.budget/1000)+"k")+metric("Job Security",state.jobSecurity+"%");$("newsFeed").innerHTML=state.news.slice(-10).reverse().map(n=>`<div class="news-item"><span class="news-dot"></span><div>${n}</div></div>`).join("");$("advanceWeekBtn").disabled=state.phase!=="REGULAR"||state.seasonDone;$("recruitAdvanceBtn").disabled=state.phase!=="REGULAR"||state.seasonDone}
function renderStaff(){$("staffGrid").innerHTML=Object.values(state.staff).map(c=>`<div class="coach-card"><h3>${c.name}</h3><div class="muted">${c.role}</div><div class="coach-ratings"><div><small>Recruit</small><b>${c.recruiting}</b></div><div><small>Develop</small><b>${c.development}</b></div><div><small>Game</small><b>${c.game}</b></div></div></div>`).join("")}
function renderNeeds(){let n=needs();$("needsGrid").innerHTML=POSITIONS.map(p=>`<div class="need ${n[p].label.toLowerCase()}"><b>${p} · ${n[p].label}</b><small>${n[p].count} players · ${n[p].sen} seniors · starter ${n[p].q}</small></div>`).join("")}
function recStage(r){let v=r.interest[state.school.id];if(r.committedTo)return"Committed";if(v>=88)return"Top 3";if(v>=78)return"Top 5";if(v>=66)return"Top 8";return"Open"}
function schoolName(id){return id===state.school.id?state.school.name:schools.find(s=>s.id===id)?.name||"Unknown"}
function renderRecruiting(){
 if(window.SDF_RECRUITING_V2?.renderRecruitingV2)return window.SDF_RECRUITING_V2.renderRecruitingV2();
 const host=$("recruitingOverview");if(host)host.innerHTML=metric("Recruiting","Loading modern recruiting engine…")
}

function findR(id){return state.recruits.find(r=>r.id===id)}
window.setPlan=(id,plan)=>{let r=findR(id);if(!r)return;if(plan==="NONE"){r.weeklyPlan="NONE";renderAll();return}let status=recruitingActionStatus(r);if(!status.canRecruit){r.weeklyPlan="NONE";rejectRecruitAction(r,status.activeReason);return}r.weeklyPlan=plan;renderAll()}
window.toggleBoard=id=>{let r=findR(id);if(!r)return;let status=recruitingActionStatus(r);if(!status.canEvaluate){rejectRecruitAction(r,status.evaluateReason);return}r.onBoard=!r.onBoard;renderAll()};
window.offer=id=>{let r=findR(id);if(!r)return;let status=recruitingActionStatus(r);if(!status.canRecruit){rejectRecruitAction(r,status.activeReason);return}if(r.offered||state.scholarships<=0)return;r.offered=true;r.onBoard=true;state.scholarships--;r.interest[state.school.id]=clamp(r.interest[state.school.id]+6,0,status.eligibility.cap);renderAll()};
window.scout=id=>{let r=findR(id);if(!r)return;let status=recruitingActionStatus(r);if(!status.canEvaluate){rejectRecruitAction(r,status.evaluateReason);return}if(r.scouted||state.weeklyHours<8)return;state.weeklyHours-=8;r.scouted=true;if(!r.trueOvr)applyHiddenEvaluation(r);const confidence=scoutAccuracy();r.scoutConfidence=Math.min(100,Math.round(confidence+rand(-4,5)));if(r.scoutConfidence>=88)revealTrueEvaluation(r);else{const spread=Math.max(2,Math.round((100-r.scoutConfidence)/5));r.ovrLow=clamp(r.trueOvr-spread,45,99);r.ovrHigh=clamp(r.trueOvr+spread,45,99);r.potLow=clamp(r.truePot-spread,45,99);r.potHigh=clamp(r.truePot+spread,45,99)}r.attrs=attrsFor(r.pos,r.trueOvr);renderAll()};
window.spend=(id,hours)=>{
 const key={1:'TEXT',5:'CALL',10:'FAMILY',25:'HARD_SELL',50:'COACH_VISIT'}[Number(hours)];
 const r=findR(id);
 if(r&&key&&window.SDF_RECRUITING_V2?.performAction)return window.SDF_RECRUITING_V2.performAction(r,key)
};

function fit(r,s){let need=needs()[r.pos].sev*2,scheme=(state.offense==="Option"&&r.pos==="QB"&&r.arch==="Scrambler"?10:0)+(state.offense==="Air Raid"&&["QB","WR"].includes(r.pos)?8:0)+(state.defense==="4-2-5"&&["CB","S"].includes(r.pos)?7:0);return s.prestige*.16+s.pro*.18+s.recent*.16+s.facilities*.11+s.nil*.1+(s.pipelines.includes(r.home)?18:0)+(r.priority==="Academics"?s.academics*.2:0)-distance(s,r)/180+need+scheme}
window.openRecruit=id=>{
 if(window.SDF_RECRUITING_V2?.openRecruit)return window.SDF_RECRUITING_V2.openRecruit(id);
 alert('The recruiting engine is still loading. Please try again.')
};

window.visit=id=>{let r=findR(id);if(!r)return;let status=recruitingActionStatus(r);if(!status.canRecruit){rejectRecruitAction(r,status.activeReason);return}if(state.weeklyHours<20||r.visit)return;state.weeklyHours-=20;r.visit=true;r.onBoard=true;$("modal").classList.add("hidden");renderAll()};window.promise=(id,p)=>{let r=findR(id);if(!r)return;let status=recruitingActionStatus(r);if(!status.canRecruit){rejectRecruitAction(r,status.activeReason);return}r.promise=p;r.interest[state.school.id]=clamp(r.interest[state.school.id]+8,0,status.eligibility.cap);state.promises.push({id:crypto.randomUUID(),targetId:r.id,target:r.name,type:p,year:state.year,resolved:false,kept:null});$("modal").classList.add("hidden");renderAll()}
function autoBoard(){
 if(window.SDF_RECRUITING_V2?.autoBoard)return window.SDF_RECRUITING_V2.autoBoard();
}

function advanceWeek(){if(state.phase!=="REGULAR"||state.seasonDone)return;resolveRecruiting();weeklyEvent();simGame(state.week);simulateWorldWeek();healInjuries();state.week++;if(state.week>12)prepareSigningDay();else resetHours();renderAll()}


function createDecisionEvent(){
 const options=[
  {title:"Unhappy Backup Quarterback",text:"Your backup quarterback wants a path to playing time.",choices:[
   ["Promise an open competition",()=>{let p=state.roster.filter(x=>x.pos==="QB"&&!x.starter)[0];if(p){p.morale+=12;state.promises.push({id:crypto.randomUUID(),targetId:p.id,target:p.name,type:"Open competition",year:state.year,resolved:false,kept:null})}}],
   ["Offer NIL support",()=>{let amount=Math.min(50000,Math.max(0,Number(state.nilBudget||0)));state.nilBudget=Math.max(0,Number(state.nilBudget||0)-amount);let p=state.roster.filter(x=>x.pos==="QB"&&!x.starter)[0];if(p)p.morale+=amount>=50000?9:amount>0?3:0;state.news.push(amount>=50000?"The NIL collective funded a full $50,000 player-support package.":amount>0?`The NIL collective funded a limited $${Math.round(amount/1000)}k player-support package.`:"The NIL collective could not fund the requested player-support package.")}],
   ["Encourage a transfer",()=>{let p=state.roster.filter(x=>x.pos==="QB"&&!x.starter)[0];if(p)state.roster=state.roster.filter(x=>x.id!==p.id)}]]},
  {title:"Discipline Decision",text:"A starting player violated team rules before a conference game.",choices:[
   ["Suspend one game",()=>{let p=choice(state.roster.filter(x=>x.starter));if(p){p.injury={weeks:1,type:"Team suspension"};state.fanApproval+=4}}],
   ["Internal punishment",()=>{state.fanApproval-=2;state.boosterSupport+=2}],
   ["Allow him to play",()=>{state.fanApproval-=7;state.jobSecurity-=3}]]},
  {title:"Booster Pressure",text:"Boosters want you to prioritize a high-profile recruit over roster need.",choices:[
   ["Follow their request",()=>{state.boosterSupport+=7;state.weeklyHours+=8}],
   ["Stick to the roster plan",()=>{state.boosterSupport-=4;state.jobSecurity+=2}]]}
 ];
 state.pendingEvent=choice(options);showDecisionEvent()
}
function showDecisionEvent(){
 let e=state.pendingEvent;if(!e)return;
 $("modalBody").innerHTML=`<span class="eyebrow">PROGRAM DECISION</span><h2>${e.title}</h2><p>${e.text}</p><div>${e.choices.map((c,i)=>`<button class="btn primary full" onclick="chooseDecision(${i})">${c[0]}</button>`).join("")}</div>`;
 $("modal").classList.remove("hidden")
}
window.chooseDecision=i=>{let e=state.pendingEvent;if(!e)return;e.choices[i][1]();state.news.push(`${e.title}: ${e.choices[i][0]}.`);state.pendingEvent=null;$("modal").classList.add("hidden");renderAll()}

function weeklyEvent(){
 if(Math.random()<.18){createDecisionEvent();return}
 if(Math.random()>.50)return;
 const events=[
  ()=>{state.weeklyHours+=8;state.news.push("A booster funded additional recruiting travel: +8 hours this week.");},
  ()=>{let p=choice(state.roster);p.morale=clamp(p.morale+8,0,99);state.news.push(`${p.name} emerged as a locker-room leader.`);},
  ()=>{state.boosterSupport=clamp(state.boosterSupport+4,0,100);state.news.push("A major donor publicly backed the program.");},
  ()=>{let r=choice(state.recruits.filter(x=>x.onBoard&&!x.committedTo)||[]);if(r){r.interest[state.school.id]=clamp(r.interest[state.school.id]+9,0,100);state.news.push(`${r.name}'s family had a strong conversation with your staff.`)}},
  ()=>{state.budget+=50000;state.news.push("Merchandise and ticket sales exceeded projections: +$50k.");}
 ];
 choice(events)();
}
function prepareSigningDay(){
 state.phase="SIGNING";state.seasonDone=true;
 const undecided=state.recruits.filter(r=>!r.committedTo&&r.offered&&r.interest[state.school.id]>=70).sort((a,b)=>b.interest[state.school.id]-a.interest[state.school.id]).slice(0,18);
 $("signingDayList").innerHTML=undecided.map(r=>`<div class="commit-card"><h4>${r.name}</h4><div>${r.pos} · ${r.arch} · <span class="star">${star(r.stars)}</span></div><span class="sub">${r.city}, ${r.home} · Interest ${Math.round(r.interest[state.school.id])}%</span></div>`).join("")||'<p class="muted">No major decisions remain.</p>';
 $("signingDayPanel").classList.remove("hidden");
 showTab("season");
}
function resolveSigningDay(){
 if(state.signingDayResolved)return;
 state.recruits.filter(r=>!r.committedTo&&r.offered&&r.interest[state.school.id]>=70).forEach(r=>{
  let ranking=Object.entries(r.interest).sort((a,b)=>b[1]-a[1]),leader=+ranking[0][0];
  if(Math.random()<.18&&ranking[1])leader=+ranking[1][0];
  r.committedTo=leader;
  if(leader===state.school.id){state.commits.push(r);state.news.push(`Signing Day: ${r.name} signed with ${state.school.name}.`)}
 });
 checkDecommits();
 state.signingDayResolved=true;
 $("signingDayPanel").classList.add("hidden");
 prepareChampionshipWeek();
 renderAll();
}
function checkDecommits(){
 state.commits.slice().forEach(r=>{
  let broken=state.promises.some(p=>p.targetId===r.id&&p.type==="No same-position signing"&&state.commits.filter(c=>c.pos===r.pos).length>1);
  if(broken&&Math.random()<.55){state.commits=state.commits.filter(c=>c.id!==r.id);r.committedTo=null;state.news.push(`${r.name} decommitted after a broken position-exclusivity promise.`)}
  else if(Math.random()<.04){state.commits=state.commits.filter(c=>c.id!==r.id);r.committedTo=null;state.news.push(`${r.name} shocked the program with a late decommitment.`)}
 })
}
function applyWeeklyPlans(){
 const costs={NONE:0,MINIMAL:5,STANDARD:10,MAX:20,FAMILY:15,COACH:20};
 const gains={NONE:0,MINIMAL:4,STANDARD:8,MAX:15,FAMILY:11,COACH:14};
 state.recruits.filter(r=>!r.committedTo&&r.weeklyPlan!=="NONE"&&recruitingActionStatus(r).canRecruit).sort((a,b)=>b.interest[state.school.id]-a.interest[state.school.id]).forEach(r=>{
   let c=costs[r.weeklyPlan];if(state.weeklyHours<c)return;
   state.weeklyHours-=c;
   let status=recruitingActionStatus(r),bonus=gains[r.weeklyPlan]+(r.weeklyPlan==="FAMILY"&&["Close to home","Academics"].includes(r.priority)?5:0)+(r.weeklyPlan==="COACH"?Math.round(state.staff.head.recruiting/18):0);
   r.interest[state.school.id]=clamp(r.interest[state.school.id]+bonus+rand(-2,3),0,status.eligibility.cap);r.onBoard=true
 })
}
function resolveRecruiting(){applyWeeklyPlans();state.recruits.filter(r=>!r.committedTo).forEach(r=>{schools.filter(s=>s.id!==state.school.id).forEach(s=>r.interest[s.id]=clamp(r.interest[s.id]+Math.round((rand(0,12)+fit(r,s)/58)*difficultyConfig().ai),0,recruitInterestCap(r,s)));if(r.visit){r.interest[state.school.id]=clamp(r.interest[state.school.id]+rand(11,20)+(state.schedule[state.week-1]?.home?4:0),0,recruitInterestCap(r,state.school));r.visit=false}let rank=Object.entries(r.interest).sort((a,b)=>b[1]-a[1]);if(state.week>=5){let cut=state.week>=10?3:state.week>=8?5:8;r.lockedOut=Object.entries(r.interest).sort((a,b)=>b[1]-a[1]).slice(cut).map(([id])=>+id);r.lockedOut.forEach(id=>r.interest[id]=Math.min(r.interest[id],35))}let [leader,val]=rank[0],second=rank[1]?.[1]||0,ch=(val-80)*3+(val-second)*2+(state.week-7)*3;let leaderSchool=schools.find(s=>s.id===+leader)||state.school,leaderEligibility=recruitingEligibility(r,leaderSchool);if(!leaderEligibility.locked&&val>=84&&Math.random()*100<ch){r.committedTo=+leader;if(r.committedTo===state.school.id&&r.offered){state.commits.push(r);state.news.push(`${r.stars}-star ${r.pos} ${r.name} committed from ${r.city}, ${r.home}.`)}}})}
function maybeInjury(){if(Math.random()<.22*difficultyConfig().injury*coachInjuryMult()*(state.weeklyPractice==="Injury Prevention"?.65:1)){let pool=state.roster.filter(p=>p.starter&&!p.injury);if(pool.length){let p=choice(pool),weeks=rand(1,4);p.injury={weeks,type:choice(["Ankle sprain","Shoulder strain","Hamstring injury","Concussion"])};p.starter=false;state.news.push(`${p.name} suffered a ${p.injury.type} and will miss about ${weeks} week(s).`);autoDepth()}}}
function healInjuries(){state.roster.filter(p=>p.injury).forEach(p=>{p.injury.weeks--;if(p.injury.weeks<=0){state.news.push(`${p.name} has returned from injury.`);p.injury=null}});autoDepth()}
function simDrive(offenseRating,defenseRating,tempo,context={}){
 const edge=clamp(Number(offenseRating||65)-Number(defenseRating||65)+rand(-7,7),-35,35);
 const late=!!context.late,lead=Number(context.lead||0),ownScore=Number(context.ownScore||0);
 let td=.235+edge*.0048,fg=.13+edge*.0012,turnover=.115-edge*.0017,miss=.065-edge*.0004;
 if(late&&lead>=21){td*=.78;fg*=.9;turnover*=.86}
 if(late&&lead<=-14){td*=1.06;turnover*=1.12}
 if(ownScore>=49)td*=.84;
 if(ownScore>=63)td*=.70;
 td=clamp(td,.055,.47);fg=clamp(fg,.07,.19);turnover=clamp(turnover,.055,.19);miss=clamp(miss,.035,.10);
 const roll=Math.random();
 if(roll<turnover)return{result:"Turnover",points:0};
 if(roll<turnover+td)return{result:"Touchdown",points:7};
 if(roll<turnover+td+fg)return{result:"Field Goal",points:3};
 if(roll<turnover+td+fg+miss)return{result:Math.random()<.55?"Missed field goal":"Turnover on downs",points:0};
 return{result:edge<-11&&Math.random()<.38?"Three-and-out":"Punt",points:0}
}

function simOvertimeDrive(offenseRating,defenseRating){
 const edge=clamp(Number(offenseRating||65)-Number(defenseRating||65)+rand(-6,6),-30,30),roll=Math.random();
 const td=clamp(.46+edge*.006,.25,.68),fg=clamp(.30+edge*.0015,.20,.36),turnover=clamp(.12-edge*.002,.06,.20);
 if(roll<turnover)return{result:"Overtime turnover",points:0};
 if(roll<turnover+td)return{result:"Overtime touchdown",points:7};
 if(roll<turnover+td+fg)return{result:"Overtime field goal",points:3};
 return{result:"Overtime stop",points:0}
}
function simGame(w){
 let g=state.schedule[w-1],t=teamRatings(),planMod=weeklyGamePlanModifier(g),weatherMod=weatherModifier(g.weather,state.offense),siteEdge=g.home?1.5:-1.5;
 let ourOff=t.offense+weatherMod+planMod+siteEdge,ourDef=t.defense+Math.round(planMod/2)+siteEdge,oppOff=g.oppPower+rand(-3,3)-siteEdge,oppDef=g.oppPower+rand(-3,3)-siteEdge;
 let drives=[],us=0,them=0,base=state.offense==="Tempo Spread"?14:state.offense==="Power Run"?11:12,count=clamp(base+rand(-1,1),10,15);
 const first=Math.random()<.5?"us":"them";
 for(let i=1;i<=count;i++){
  const progress=i/count,late=progress>=.72;
  const order=first==="us"?["us","them"]:["them","us"];
  for(const side of order){
   if(side==="us"){
    const a=simDrive(ourOff,oppDef,state.offense,{late,lead:us-them,ownScore:us});us+=a.points;drives.push(`Drive ${i}: ${state.school.name} ${a.result}`)
   }else{
    const b=simDrive(oppOff,ourDef,"",{late,lead:them-us,ownScore:them});them+=b.points;drives.push(`Drive ${i}: ${g.opponent} ${b.result}`)
   }
  }
 }
 if(us===them){
  for(let ot=1;ot<=5&&us===them;ot++){
   const a=simOvertimeDrive(ourOff,oppDef),b=simOvertimeDrive(oppOff,ourDef);us+=a.points;them+=b.points;drives.push(`OT ${ot}: ${state.school.name} ${a.result}; ${g.opponent} ${b.result}`)
  }
  if(us===them){Math.random()>.5?us+=2:them+=2;drives.push("Overtime ended on a two-point conversion.")}
 }
 let win=us>them;g.result=win?"W":"L";g.score=`${us}-${them}`;win?state.record.w++:state.record.l++;
 state.conferenceRecords[state.school.id]??={w:0,l:0};if(g.conference){win?state.conferenceRecords[state.school.id].w++:state.conferenceRecords[state.school.id].l++}let me=state.standings.find(x=>x.id===state.school.id);if(me){win?me.w++:me.l++}state.standings.filter(x=>x.id!==state.school.id).forEach(x=>Math.random()>.5?x.w++:x.l++);
 let qb=best("QB"),rb=best("RB"),def=best("EDGE")||best("LB");
 state.lastGameRecap={opponent:g.opponent,home:g.home,win,us,them,rivalry:g.rivalry,boxScore:{firstDowns:rand(14,29),rushYds:rand(70,220),passYds:rand(150,390),turnovers:rand(0,3),thirdDown:`${rand(3,9)}/${rand(10,17)}`,redZone:`${rand(2,5)}/${rand(3,6)}`,sacksAllowed:rand(0,5),timePossession:`${rand(25,35)}:${rand(0,59).toString().padStart(2,"0")}`},headline:win?choice(["Fourth-quarter surge seals the win","Defense dominates in statement victory","Balanced attack powers another win"]):choice(["Turnovers prove costly","Late rally falls short","Offense stalls in tough defeat"]),stars:[qb?`${qb.name}: ${rand(180,390)} pass yds, ${rand(1,4)} TD`:"",rb?`${rb.name}: ${rand(55,180)} rush yds`:"",def?`${def.name}: ${rand(5,13)} tackles, ${rand(0,3)} sacks`:""].filter(Boolean),drives};
 if(g.rivalry){state.fanApproval=clamp(state.fanApproval+(win?8:-8),0,100);state.boosterSupport=clamp(state.boosterSupport+(win?5:-5),0,100);let rh=state.rivalryHistory[state.rivalId];if(rh){win?rh.wins++:rh.losses++;rh.streak=win?Math.max(1,rh.streak+1):Math.min(-1,rh.streak-1);rh.bestMargin=Math.max(rh.bestMargin,win?us-them:0);rh.last={year:state.year,win,score:`${us}-${them}`};if(win)state.achievementStats.rivalWins++}}updateAttendance(win,g.rivalry);state.coachCareer.careerWins+=win?1:0;state.coachCareer.careerLosses+=win?0:1;if(win&&us-them>=35)state.achievementStats.bigWin=true;state.achievementStats.weatherConditions??={};if(win&&["Snow","Rain","Heavy Wind","Extreme Heat"].includes(g.weather))state.achievementStats.weatherConditions[g.weather]=true;
 addCoachXP(win?18:7);maybeCreateDynamicRivalry(g);state.news.push(`${g.result} ${g.score} ${g.home?"vs":"at"} ${g.opponent} <span class="weather-badge">${g.weather||"TBD"}</span>${g.rivalry?" in the rivalry game":""}.`);simDetailedPlayerStats(g,win,us,them);updateStats(win);maybeInjury();state.roster.forEach(p=>p.morale=clamp(p.morale+(win?rand(0,3):rand(-3,1)),35,99))
}
function updateStats(win){let qb=best("QB"),rb=best("RB"),wr=best("WR"),lb=best("LB"),edge=best("EDGE"),cb=best("CB");if(qb){qb.stats.games++;qb.stats.yards+=rand(180,380);qb.stats.td+=rand(1,4)}if(rb){rb.stats.games++;rb.stats.yards+=rand(55,170);rb.stats.td+=rand(0,2)}if(wr){wr.stats.games++;wr.stats.yards+=rand(45,150);wr.stats.td+=rand(0,2)}if(lb){lb.stats.games++;lb.stats.tackles+=rand(5,13)}if(edge){edge.stats.games++;edge.stats.sacks+=rand(0,2)}if(cb){cb.stats.games++;cb.stats.int+=Math.random()<.3?1:0}}
function best(pos){return state.roster.filter(p=>p.pos===pos&&p.starter&&!p.injury).sort((a,b)=>b.ovr-a.ovr)[0]}
function finishSeason(){state.seasonDone=true;state.phase="AWARDS";let w=state.record.w,l=state.record.l,d=w-state.school.expectation,grade=d>=3?"A+":d===2?"A":d===1?"B+":d===0?"B":d===-1?"C+":d===-2?"C":d===-3?"D":"F",ca=Math.round(avg(state.commits.map(r=>r.trueOvr||r.ovr))||0),rank=clamp(100-Math.round(state.commits.length*2.2+(ca-66)*1.5),1,100),post=w>=11?"Playoff":w>=6?"Bowl":"None";
 const totalGames=Math.max(1,w+l),winPct=w/totalGames,currentRecent=Number(state.school.recent||50);
 const wonConference=state.trophies.some(t=>t.year===state.year&&t.type==="Conference Championship"),wonTitle=state.trophies.some(t=>t.year===state.year&&t.type==="National Championship");
 const recentTarget=clamp(Math.round(24+winPct*62+Math.max(0,w-6)*1.2+(w>=10?4:0)+(wonConference?4:0)+(wonTitle?8:0)),20,99);
 let recentDelta=clamp(Math.round((recentTarget-currentRecent)*.42),-14,16);if(w>=11)recentDelta=Math.max(recentDelta,8);if(w<=3)recentDelta=Math.min(recentDelta,-7);state.school.recent=clamp(currentRecent+recentDelta,20,99);
 let prestigeDelta=0;if(wonTitle)prestigeDelta=6;else if(w>=12)prestigeDelta=4;else if(w>=10)prestigeDelta=3;else if(w>=8)prestigeDelta=2;else if(w>=7)prestigeDelta=1;else if(w<=2)prestigeDelta=-4;else if(w<=4)prestigeDelta=-3;else if(w<=5)prestigeDelta=-2;else if(w<=6&&d<0)prestigeDelta=-1;if(d>=4&&!wonTitle)prestigeDelta++;if(d<=-4)prestigeDelta--;state.school.prestige=clamp(state.school.prestige+clamp(prestigeDelta,-5,6),25,99);
 state.news.push(`Program ratings updated: Recent Success ${recentDelta>=0?'+':''}${recentDelta} to ${state.school.recent}; Prestige ${prestigeDelta>=0?'+':''}${prestigeDelta} to ${state.school.prestige}.`);
 state.jobSecurity=clamp(state.jobSecurity+(d*7+(w>=10?5:0))*difficultyConfig().job,5,100);state.fanApproval=clamp(state.fanApproval+d*5,5,100);state.boosterSupport=clamp(state.boosterSupport+d*4,5,100);state.budget+=w*45000+(post==="Playoff"?500000:post==="Bowl"?180000:0);let baseAwards=seasonAwards(),expanded=seasonAwardsExpanded(),awards=baseAwards.concat(expanded.awards);state.awardsWeek={year:state.year,awards:[...awards],allAmericans:(expanded.allAmerican||[]).map(p=>({player:p.name,pos:p.pos,ovr:p.ovr})),presented:false};state.history.push({year:state.year,wins:w,losses:l,grade,classRank:rank,post,awards,recentDelta,prestigeDelta});updateRecordBook(rank);if(state.postseasonData?.playoffField?.some(t=>t.id===state.school.id))state.trophies.push({year:state.year,type:"Playoff Appearance"});state.achievementStats.seasons++;if(state.record.l===0)state.achievementStats.undefeated++;if(rank<=5)state.achievementStats.top5Classes++;if(rank===1)state.achievementStats.classOne=true;state.achievementStats.fiveStars+=state.commits.filter(r=>r.stars===5).length;updatePipelines();state.coachCareer.reputation=clamp(state.coachCareer.reputation+(state.record.w-state.school.expectation)*2+(state.achievementStats.nationalTitles?1:0),20,99);state.coachCareer.contractYears=Math.max(0,state.coachCareer.contractYears-1);$("seasonReview").innerHTML=`<div class="metric-grid">${metric("Record",`${w}-${state.record.l}`)}${metric("Coach Grade",grade)}${metric("Recruiting Rank","#"+rank)}${metric("Postseason",post)}${metric("Recent Success",`${state.school.recent} (${recentDelta>=0?'+':''}${recentDelta})`)}${metric("Prestige",`${state.school.prestige} (${prestigeDelta>=0?'+':''}${prestigeDelta})`)}</div><h3>Season Awards</h3><div class="commit-grid">${awards.map(a=>`<div class="commit-card"><h4>${a.title}</h4><span class="sub">${a.player}</span></div>`).join("")}</div>`;$("postseasonPanel").classList.remove("hidden")}
function seasonAwards(){let list=[],qb=bestBy("yards"),rb=state.roster.filter(p=>p.pos==="RB").sort((a,b)=>b.stats.yards-a.stats.yards)[0],def=state.roster.slice().sort((a,b)=>(b.stats.tackles+b.stats.sacks*4+b.stats.int*5)-(a.stats.tackles+a.stats.sacks*4+a.stats.int*5))[0];if(qb)list.push({title:"Offensive Player of the Year",player:qb.name});if(def)list.push({title:"Defensive Player of the Year",player:def.name});if(rb&&rb.stats.yards>900)list.push({title:"All-Conference Running Back",player:rb.name});let punter=state.roster.filter(p=>p.pos==="P").sort((a,b)=>((b.seasonStats?.puntYds||0)/Math.max(1,b.seasonStats?.punts||0))-((a.seasonStats?.puntYds||0)/Math.max(1,a.seasonStats?.punts||0)))[0];if(punter&&(punter.seasonStats?.punts||0)>0)list.push({title:"All-Conference Punter",player:punter.name});return list}
function bestBy(k){return state.roster.slice().sort((a,b)=>(b.stats[k]||0)-(a.stats[k]||0))[0]}
function offseason(){state.phase="PORTAL";state.offseasonTasks={spring:false,battles:false,progression:false,staff:false,draft:false};window.SDF_AI_ROSTERS?.processOffseason?.();state.roster.forEach(p=>{
 const beforeOvr=Number(p.ovr||45),baseGain=rand(1,2),devBonus=p.dev==="Elite"?3:p.dev==="Star"?2:p.dev==="Impact"?1:0,coachRating=Number(state.staff?.head?.development||55),coachBonus=coachRating>=82?1:coachRating>=68&&Math.random()<.6?1:0,trainingLevel=Number(state.facilities?.training||1),trainingBonus=trainingLevel>=4?1:trainingLevel>=2&&Math.random()<.4?1:0,youngBonus=Number(p.year||1)<=2&&Math.random()<.35?1:0,starterBonus=p.starter&&Math.random()<.25?1:0;
 const requestedGain=Math.max(1,baseGain+devBonus+coachBonus+trainingBonus+youngBonus+starterBonus),ceiling=Math.max(beforeOvr,Number(p.pot||beforeOvr)),nextOvr=clamp(Math.min(ceiling,beforeOvr+requestedGain),45,99),actualGain=nextOvr-beforeOvr;p.ovr=nextOvr;if(actualGain>0){if(!p.attrs)p.attrs=attrsFor(p.pos,p.ovr);else Object.keys(p.attrs).forEach(k=>p.attrs[k]=clamp(Number(p.attrs[k]||beforeOvr)+Math.max(0,actualGain+rand(-1,1)),40,99))}p.year++;if(p.redshirt){p.year--;p.redshirt=false}});
 let transfers=state.roster.filter(p=>!p.starter&&p.morale<60&&Math.random()<.35*difficultyConfig().portal);transfers.forEach(p=>state.news.push(`${p.name} entered the transfer portal.`));state.roster=state.roster.filter(p=>p.year<=4&&!transfers.includes(p));
 state.commits.forEach(r=>{const actualOvr=Number(r.trueOvr||r.ovr),actualPot=Math.max(actualOvr,Number(r.truePot||r.pot||actualOvr+7));state.roster.push({id:crypto.randomUUID(),name:r.name,pos:r.pos,arch:r.arch,hometown:`${r.city}, ${r.home}`,year:1,ovr:actualOvr,pot:actualPot,dev:r.dev||rollDevelopment(r.stars,actualOvr),morale:82,starter:false,redshirt:false,redshirtUsed:false,redshirtSeason:null,progressionHistory:[],seasonStats:emptySeasonStats(),statHistory:[],gameLog:[],injury:null,stats:{games:0,yards:0,td:0,tackles:0,sacks:0,int:0},attrs:r.attrs||attrsFor(r.pos,actualOvr)})});
 autoDepth();state.portal=Array.from({length:35},()=>{let l=choice(LOC),roll=Math.random(),o=roll>.94?rand(82,87):roll>.72?rand(74,82):rand(64,76),p=choice(POSITIONS);return{id:crypto.randomUUID(),name:pname(),pos:p,arch:choice(ARCH[p]),reason:choice(["Buried on depth chart","Coach departed","Homesick","Seeking NIL opportunity","Wants stronger competition","Graduate transfer"]),hometown:`${l[0]}, ${l[1]}`,year:rand(2,4),ovr:o,pot:clamp(o+rand(2,6),o,93),dev:rollDevelopment(0,o),cost:rand(12,30),taken:false,redshirt:false,redshirtUsed:false,redshirtSeason:null,progressionHistory:[],seasonStats:emptySeasonStats(),statHistory:[],gameLog:[],injury:null,stats:{games:0,yards:0,td:0,tackles:0,sacks:0,int:0},attrs:attrsFor(p,o)}});renderPortal();$("portalPanel").classList.remove("hidden");$("offseasonHub").classList.remove("hidden");$("postseasonPanel").classList.add("hidden");$("bowlsPanel").classList.add("hidden");renderOffseasonHub();renderAll()}
function renderPortal(){$("portalList").innerHTML=state.portal.map(p=>`<div class="commit-card"><h4>${p.name}</h4><div>${p.pos} · ${p.arch} · Year ${p.year}</div><span class="sub">${p.hometown} · ${p.reason||"Seeking opportunity"} · OVR ${p.ovr} · POT ${p.pot} · ${p.dev} DEV</span><button class="btn small primary" onclick="takePortal('${p.id}')" ${p.taken||state.weeklyHours<p.cost?"disabled":""}>Recruit · ${p.cost}</button></div>`).join("")}
window.takePortal=id=>{let p=state.portal.find(x=>x.id===id);if(!p||p.taken||state.weeklyHours<p.cost)return;state.weeklyHours-=p.cost;p.taken=true;state.achievementStats.portalAdds++;state.roster.push({...p,morale:80,starter:false});renderPortal();renderAll()}
function finishOffseason(){archiveSeasonStats();const missing=Object.entries(state.offseasonTasks).filter(([,v])=>!v).map(([k])=>k);if(missing.length&& !confirm(`You have not completed: ${missing.join(", ")}. Continue anyway?`))return;state.world.forEach(t=>{if(t.id===state.school.id){t.prestige=state.school.prestige;t.recent=state.school.recent;t.rosterPower=teamRatings().overall;t.record={w:0,l:0};t.classRank=rand(1,100);return}const w=Number(t.record?.w||0),l=Number(t.record?.l||0),pct=w/Math.max(1,w+l),recentTarget=clamp(Math.round(25+pct*62+Math.max(0,w-7)*1.4),20,97),recentDelta=clamp(Math.round((recentTarget-Number(t.recent||50))*.30),-10,10);let prestigeDelta=w>=11?3:w>=9?2:w>=8?1:w<=2?-3:w<=4?-2:w<=5?-1:0;t.recent=clamp(Number(t.recent||50)+recentDelta,20,99);t.prestige=clamp(Number(t.prestige||50)+prestigeDelta,25,99);const aiRoster=window.SDF_AI_ROSTERS?.get?.(t.id),aiRatings=aiRoster?.length?window.SDF_AI_ROSTERS?.teamRatings?.(aiRoster):null;t.rosterPower=clamp(Number(aiRatings?.overall||t.rosterPower||70),45,99);const actualClass=(state.classRankings||[]).find(x=>Number(x.id)===Number(t.id));t.record={w:0,l:0};t.classRank=Number(actualClass?.rank||t.classRank||rand(1,100))});state.year++;state.conferenceRecords={};autoDepth();initializeDepthChart();beginYear();$("portalPanel").classList.add("hidden");$("offseasonHub").classList.add("hidden");$("postseasonPanel").classList.add("hidden");$("bowlsPanel").classList.add("hidden");state.postseasonData=null;showTab("dashboard");renderAll()}

function emptySeasonStats(){
 return{games:0,passAtt:0,passComp:0,passYds:0,passTD:0,passINT:0,rushAtt:0,rushYds:0,rushTD:0,rec:0,recYds:0,recTD:0,tackles:0,tfl:0,sacks:0,defINT:0,ff:0,fgm:0,fga:0,xpm:0,xpa:0,points:0,punts:0,puntYds:0,puntLong:0,inside20:0,touchbacks:0}
}
function ensurePlayerStats(p){
 p.seasonStats??=emptySeasonStats();p.statHistory??=[];p.gameLog??=[];return p.seasonStats
}
function recordPlayerGame(p,week,opponent,result,line){
 ensurePlayerStats(p);p.gameLog.push({year:state.year,week,opponent,result,...line})
}
function playerStatLine(p){
 const s=ensurePlayerStats(p);
 if(p.pos==="QB")return `${s.passComp}/${s.passAtt}, ${s.passYds} pass yds, ${s.passTD} TD, ${s.passINT} INT`;
 if(["RB","FB"].includes(p.pos))return `${s.rushAtt} carries, ${s.rushYds} rush yds, ${s.rushTD} TD`;
 if(["WR","TE"].includes(p.pos))return `${s.rec} rec, ${s.recYds} yds, ${s.recTD} TD`;
 if(["EDGE","DL","LB","CB","S"].includes(p.pos))return `${s.tackles} tackles, ${s.tfl} TFL, ${s.sacks} sacks, ${s.defINT} INT`;
 if(p.pos==="K")return `${s.fgm}/${s.fga} FG, ${s.xpm}/${s.xpa} XP`;
 if(p.pos==="P")return `${s.punts} punts, ${s.puntYds} yds, ${s.punts?(s.puntYds/s.punts).toFixed(1):"0.0"} avg, ${s.inside20} inside 20`;
 return `${s.games} games`
}
function simDetailedPlayerStats(g,win,us,them){
 state.roster.forEach(ensurePlayerStats);
 const starters=state.roster.filter(p=>p.starter&&!p.injury);
 const qb=starters.find(p=>p.pos==="QB")||best("QB");
 const rb=starters.find(p=>p.pos==="RB")||best("RB");
 const wrs=starters.filter(p=>["WR","TE"].includes(p.pos)).sort((a,b)=>b.ovr-a.ovr).slice(0,4);
 const defenders=starters.filter(p=>["EDGE","DL","LB","CB","S"].includes(p.pos));
 const kicker=starters.find(p=>p.pos==="K")||state.roster.find(p=>p.pos==="K");
 const passYds=clamp(rand(150,360)+Math.round((teamRatings().offense-g.oppPower)*3),70,520);
 const passTD=Math.max(0,Math.min(6,Math.round(us/14)+rand(-1,1)));
 const passINT=rand(0,Math.max(1,Math.round(g.oppPower/42)));
 if(qb){let s=ensurePlayerStats(qb),att=rand(22,42),comp=clamp(Math.round(att*(.54+(qb.ovr-65)/180)),10,att);Object.assign(s,{games:s.games+1,passAtt:s.passAtt+att,passComp:s.passComp+comp,passYds:s.passYds+passYds,passTD:s.passTD+passTD,passINT:s.passINT+passINT,rushAtt:s.rushAtt+rand(1,8),rushYds:s.rushYds+rand(-5,48),rushTD:s.rushTD+(Math.random()<.18?1:0)});recordPlayerGame(qb,state.week,g.opponent,win?"W":"L",{passYds,passTD,passINT})}
 if(rb){let s=ensurePlayerStats(rb),att=rand(12,27),yds=clamp(rand(45,145)+Math.round((rb.ovr-g.oppPower)/3),10,230),td=Math.max(0,Math.min(4,Math.round((us-passTD*7)/14)+rand(0,1)));Object.assign(s,{games:s.games+1,rushAtt:s.rushAtt+att,rushYds:s.rushYds+yds,rushTD:s.rushTD+td,rec:s.rec+rand(0,5),recYds:s.recYds+rand(0,55)});recordPlayerGame(rb,state.week,g.opponent,win?"W":"L",{rushYds:yds,rushTD:td})}
 let remaining=passYds;
 wrs.forEach((p,i)=>{let s=ensurePlayerStats(p),share=i===0?.34:i===1?.26:i===2?.2:.12,yds=i===wrs.length-1?Math.max(0,remaining):Math.round(passYds*share),rec=clamp(Math.round(yds/rand(9,16)),0,12),td=i<passTD?1:Math.random()<.12?1:0;remaining-=yds;Object.assign(s,{games:s.games+1,rec:s.rec+rec,recYds:s.recYds+yds,recTD:s.recTD+td});recordPlayerGame(p,state.week,g.opponent,win?"W":"L",{rec,recYds:yds,recTD:td})});
 defenders.forEach(p=>{let s=ensurePlayerStats(p),t=rand(2,11),tfl=Math.random()<.45?rand(0,3):0,sacks=["EDGE","DL","LB"].includes(p.pos)&&Math.random()<.3?rand(0,2):0,ints=["CB","S","LB"].includes(p.pos)&&Math.random()<.12?1:0;Object.assign(s,{games:s.games+1,tackles:s.tackles+t,tfl:s.tfl+tfl,sacks:s.sacks+sacks,defINT:s.defINT+ints,ff:s.ff+(Math.random()<.05?1:0)});recordPlayerGame(p,state.week,g.opponent,win?"W":"L",{tackles:t,tfl,sacks,defINT:ints})});
 if(kicker){let s=ensurePlayerStats(kicker),fga=rand(0,3),fgm=Math.max(0,fga-(Math.random()<.25?1:0)),xpa=Math.floor(us/7),xpm=Math.max(0,xpa-(Math.random()<.04?1:0));Object.assign(s,{games:s.games+1,fga:s.fga+fga,fgm:s.fgm+fgm,xpa:s.xpa+xpa,xpm:s.xpm+xpm,points:s.points+fgm*3+xpm});recordPlayerGame(kicker,state.week,g.opponent,win?"W":"L",{fgm,fga,xpm,xpa})}
}
function archiveSeasonStats(){
 state.roster.forEach(p=>{ensurePlayerStats(p);if(p.seasonStats.games>0)p.statHistory.push({year:state.year,team:state.school.name,ovr:p.ovr,...p.seasonStats});p.seasonStats=emptySeasonStats();p.gameLog=[]})
}
function statRows(category){
 let players=state.roster.map(p=>({p,s:ensurePlayerStats(p)}));
 if(category==="PASSING")players=players.filter(x=>x.s.passAtt>0).sort((a,b)=>b.s.passYds-a.s.passYds);
 if(category==="RUSHING")players=players.filter(x=>x.s.rushAtt>0).sort((a,b)=>b.s.rushYds-a.s.rushYds);
 if(category==="RECEIVING")players=players.filter(x=>x.s.rec>0).sort((a,b)=>b.s.recYds-a.s.recYds);
 if(category==="DEFENSE")players=players.filter(x=>x.s.tackles>0).sort((a,b)=>b.s.tackles-a.s.tackles||b.s.sacks-a.s.sacks);
 if(category==="KICKING")players=players.filter(x=>x.s.fga>0||x.s.xpa>0).sort((a,b)=>b.s.points-a.s.points);
 return players
}
function renderStats(){
 if(!$("playerStatsTable"))return;const category=$("statsCategory")?.value||"PASSING",rows=statRows(category);
 const headers={
  PASSING:["Player","G","Cmp","Att","Cmp%","Yds","TD","INT","Rating"],
  RUSHING:["Player","G","Att","Yds","Avg","TD"],
  RECEIVING:["Player","G","Rec","Yds","Avg","TD"],
  DEFENSE:["Player","G","Tkl","TFL","Sack","INT","FF"],
  KICKING:["Player","G","FG","FG%","XP","Pts"],
  ALL:["Player","Pos","G","Season Summary"]
 }[category];
 $("playerStatsTable").innerHTML=`<thead><tr>${headers.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.map(({p,s})=>{
  if(category==="PASSING"){let pct=s.passAtt?Math.round(s.passComp/s.passAtt*100):0,rating=Math.round((s.passYds/Math.max(1,s.passAtt))*8+s.passTD*6-s.passINT*5);return`<tr><td><button class="link-button" onclick="openPlayerProfile('${p.id}')">${p.name}</button></td><td>${s.games}</td><td>${s.passComp}</td><td>${s.passAtt}</td><td>${pct}%</td><td>${s.passYds}</td><td>${s.passTD}</td><td>${s.passINT}</td><td>${rating}</td></tr>`}
  if(category==="RUSHING")return`<tr><td><button class="link-button" onclick="openPlayerProfile('${p.id}')">${p.name}</button></td><td>${s.games}</td><td>${s.rushAtt}</td><td>${s.rushYds}</td><td>${s.rushAtt?(s.rushYds/s.rushAtt).toFixed(1):"0.0"}</td><td>${s.rushTD}</td></tr>`;
  if(category==="RECEIVING")return`<tr><td><button class="link-button" onclick="openPlayerProfile('${p.id}')">${p.name}</button></td><td>${s.games}</td><td>${s.rec}</td><td>${s.recYds}</td><td>${s.rec?(s.recYds/s.rec).toFixed(1):"0.0"}</td><td>${s.recTD}</td></tr>`;
  if(category==="DEFENSE")return`<tr><td><button class="link-button" onclick="openPlayerProfile('${p.id}')">${p.name}</button></td><td>${s.games}</td><td>${s.tackles}</td><td>${s.tfl}</td><td>${s.sacks}</td><td>${s.defINT}</td><td>${s.ff}</td></tr>`;
  if(category==="KICKING")return`<tr><td><button class="link-button" onclick="openPlayerProfile('${p.id}')">${p.name}</button></td><td>${s.games}</td><td>${s.fgm}/${s.fga}</td><td>${s.fga?Math.round(s.fgm/s.fga*100):0}%</td><td>${s.xpm}/${s.xpa}</td><td>${s.points}</td></tr>`;
  return`<tr><td><button class="link-button" onclick="openPlayerProfile('${p.id}')">${p.name}</button></td><td>${p.pos}</td><td>${s.games}</td><td>${playerStatLine(p)}</td></tr>`
 }).join("")}</tbody>`;
 const team=state.roster.reduce((a,p)=>{let s=ensurePlayerStats(p);a.passYds+=s.passYds;a.rushYds+=s.rushYds;a.passTD+=s.passTD;a.rushTD+=s.rushTD;a.sacks+=s.sacks;a.ints+=s.defINT;return a},{passYds:0,rushYds:0,passTD:0,rushTD:0,sacks:0,ints:0});
 $("teamStatSummary").innerHTML=metric("Passing",team.passYds+" yds")+metric("Rushing",team.rushYds+" yds")+metric("Offensive TD",team.passTD+team.rushTD)+metric("Sacks",team.sacks)+metric("Takeaways",team.ints)+metric("Points/Game",state.schedule.filter(g=>g.score).length?Math.round(state.schedule.filter(g=>g.score).reduce((sum,g)=>sum+Number(g.score.split("-")[0]),0)/state.schedule.filter(g=>g.score).length):"—");
 const recent=state.roster.flatMap(p=>(p.gameLog||[]).map(g=>({player:p.name,pos:p.pos,...g}))).filter(g=>g.year===state.year).sort((a,b)=>b.week-a.week).slice(0,30);
 $("gameLogGrid").innerHTML=recent.map(g=>`<div class="game-log-card"><h4>${g.player} · ${g.pos}</h4><b>Week ${g.week} vs ${g.opponent}</b><span class="sub">${Object.entries(g).filter(([k])=>!["player","pos","year","week","opponent","result"].includes(k)).map(([k,v])=>`${k}: ${v}`).join(" · ")}</span></div>`).join("")||'<p class="muted">Game logs appear after games are played.</p>';
 renderAwardWatch();renderStatArchive()
}
function renderAwardWatch(){
 const candidates=state.roster.map(p=>({p,s:ensurePlayerStats(p),score:ensurePlayerStats(p).passYds/100+ensurePlayerStats(p).rushYds/80+ensurePlayerStats(p).recYds/90+ensurePlayerStats(p).passTD*2+ensurePlayerStats(p).rushTD*2+ensurePlayerStats(p).recTD*2+ensurePlayerStats(p).tackles/8+ensurePlayerStats(p).sacks*3+ensurePlayerStats(p).defINT*4})).sort((a,b)=>b.score-a.score).slice(0,8);
 $("awardWatchGrid").innerHTML=candidates.map((x,i)=>`<div class="award-watch-card"><span class="eyebrow">#${i+1} TEAM BALLOT</span><h4>${x.p.name}</h4><b>${x.p.pos} · OVR ${x.p.ovr}</b><span class="sub">${playerStatLine(x.p)}</span></div>`).join("")||'<p class="muted">Award candidates emerge during the season.</p>'
}
function renderStatArchive(){
 const records=[];
 state.roster.forEach(p=>(p.statHistory||[]).forEach(h=>records.push({name:p.name,pos:p.pos,...h})));
 $("statArchiveGrid").innerHTML=records.sort((a,b)=>(b.passYds+b.rushYds+b.recYds)-(a.passYds+a.rushYds+a.recYds)).slice(0,24).map(h=>`<div class="stat-archive-card"><h4>${h.name}</h4><b>${h.year} · ${h.pos}</b><span class="sub">${h.passYds?`${h.passYds} passing yards · `:""}${h.rushYds?`${h.rushYds} rushing yards · `:""}${h.recYds?`${h.recYds} receiving yards · `:""}${h.tackles?`${h.tackles} tackles · `:""}${h.sacks?`${h.sacks} sacks`:""}</span></div>`).join("")||'<p class="muted">Completed seasons will appear here.</p>'
}
function playerProfileStatsHtml(p){
 ensurePlayerStats(p);const current={year:state.year,team:state.school.name,...p.seasonStats},years=[...(p.statHistory||[]),current].filter(h=>h.games>0);
 return `<section class="player-profile-stats"><span class="eyebrow">YEARLY TOTALS</span><h3>Season & Career Statistics</h3><div class="table-wrap"><table><thead><tr><th>Dynasty Year</th><th>Team</th><th>G</th><th>Pass</th><th>Rush</th><th>Receiving</th><th>Defense</th><th>Kicking</th></tr></thead><tbody>${years.map(h=>`<tr><td>${h.year}</td><td>${h.team}</td><td>${h.games}</td><td>${h.passYds||0} yds · ${h.passTD||0} TD · ${h.passINT||0} INT</td><td>${h.rushYds||0} yds · ${h.rushTD||0} TD</td><td>${h.rec||0} rec · ${h.recYds||0} yds · ${h.recTD||0} TD</td><td>${h.tackles||0} tkl · ${h.sacks||0} sack · ${h.defINT||0} INT</td><td>${h.fgm||0}/${h.fga||0} FG · ${h.points||0} pts</td></tr>`).join("")}</tbody></table></div><div>${["passYds","rushYds","recYds","passTD","rushTD","recTD","tackles","sacks","defINT"].map(k=>`<span class="stat-pill">${k}: ${years.reduce((n,h)=>n+(h[k]||0),0)}</span>`).join("")}</div></section>`
}
function openPlayerProfile(id){
 const p=state.roster.find(x=>x.id===id);if(!p)return;
 $("modalBody").innerHTML=`<span class="eyebrow">PLAYER PROFILE</span><h2>${p.name}</h2><p class="muted">${p.pos} · ${p.arch} · ${p.hometown}</p><div class="metric-grid">${metric("OVR",p.ovr)}${metric("Potential",p.pot)}${metric("Year",p.year)}${metric("Morale",p.morale)}${metric("Development",p.dev)}${metric("Status",p.injury?p.injury.type:p.starter?"Starter":p.redshirt?"Redshirt":"Backup")}</div>${playerProfileStatsHtml(p)}`;$("modal").classList.remove("hidden")
}
window.openPlayerProfile=openPlayerProfile;
function renderRoster(){let n=needs();$("depthChart").innerHTML=POSITIONS.map(p=>{let a=state.roster.filter(x=>x.pos===p).sort((x,y)=>y.starter-x.starter||y.ovr-x.ovr).slice(0,Math.max(STARTERS[p]+3,4));return `<div class="depth-card"><strong>${p} · ${n[p].label}</strong>${a.map((x,i)=>`<div class="depth-line"><span>${i+1}</span><span>${x.name}<small class="sub">${x.arch} · Year ${x.year}${x.starter?" · Starter":""}${x.redshirt?" · RS":""}${x.injury?` · ${x.injury.type}`:""}</small></span><b>${x.ovr}</b></div>`).join("")}</div>`}).join("");$("rosterSummary").innerHTML=metric("Players",state.roster.length)+metric("Average OVR",Math.round(avg(state.roster.map(p=>p.ovr))))+metric("Seniors",state.roster.filter(p=>p.year===4).length)+metric("Redshirts",state.roster.filter(p=>p.redshirt).length)+metric("Injured",state.roster.filter(p=>p.injury).length)+metric("High Portal Risk",state.roster.filter(p=>!p.starter&&p.morale<62).length);$("rosterTable").innerHTML=state.roster.slice().sort((a,b)=>POSITIONS.indexOf(a.pos)-POSITIONS.indexOf(b.pos)||b.ovr-a.ovr).map(p=>`<tr><td><b>${p.name}</b></td><td>${p.pos}</td><td>${p.arch}</td><td>${p.hometown}</td><td>${p.year}</td><td>${p.ovr}</td><td>${p.pot}</td><td>${p.dev}</td><td>${p.morale}</td><td>${p.injury?p.injury.type:p.redshirt?"Redshirt":p.starter?"Starter":"Backup"}</td><td>${!p.starter&&p.morale<62?"High":!p.starter&&p.morale<72?"Medium":"Low"}</td></tr>`).join("")}
function renderTeam(){let t=teamRatings();$("teamRatings").innerHTML=metric("Overall",t.overall)+metric("Offense",t.offense)+metric("Defense",t.defense)+metric("Special Teams",t.special)+metric("Injuries",state.roster.filter(p=>p.injury).length)+metric("Avg Morale",Math.round(avg(state.roster.map(p=>p.morale))));$("offenseSummary").textContent=state.offense==="Air Raid"?"Heavy passing volume; boosts QB and WR production.":state.offense==="Power Run"?"Physical rushing attack built around backs and linemen.":state.offense==="Option"?"Maximizes mobile quarterbacks and rushing depth.":"Balanced system with flexible personnel.";$("defenseSummary").textContent=state.defense==="4-2-5"?"Extra defensive back helps against spread offenses.":state.defense==="3-4"?"Linebacker-heavy pressure system.":state.defense==="3-3-5"?"Speed-focused defense with flexible pressure.":"Balanced front with traditional personnel.";let leaders=[["Passing",bestByPos("QB","yards"),"yards"],["Rushing",bestByPos("RB","yards"),"yards"],["Receiving",bestByPos("WR","yards"),"yards"],["Tackles",bestByAny("tackles"),"tackles"],["Sacks",bestByAny("sacks"),"sacks"],["Interceptions",bestByAny("int"),"int"]];$("leaderGrid").innerHTML=leaders.map(([l,p,k])=>`<div class="leader-card"><h4>${l}</h4><b>${p?.name||"-"}</b><span class="sub">${p?.stats[k]||0}</span></div>`).join("")}
function bestByPos(pos,k){return state.roster.filter(p=>p.pos===pos).sort((a,b)=>(b.stats[k]||0)-(a.stats[k]||0))[0]}function bestByAny(k){return state.roster.slice().sort((a,b)=>(b.stats[k]||0)-(a.stats[k]||0))[0]}
function renderSchedule(){$("schedule").innerHTML=state.schedule.map(g=>`<div class="schedule-row"><b>Wk ${g.week}</b><span class="${g.rivalry?"rivalry":""}">${g.home?"vs":"at"} ${g.opponent} <span class="weather-badge">${g.weather||"TBD"}</span>${g.rivalry?' · RIVALRY':g.conference?' <small class="sub">Conference</small>':""}</span><b class="${g.result==="W"?"win":g.result==="L"?"loss":""}">${g.result||"-"} ${g.score||""}</b><span class="extra muted">Power ${g.oppPower}</span></div>`).join("");if(state.lastGameRecap){let r=state.lastGameRecap;$("gameRecapPanel").classList.remove("hidden");$("gameRecapPanel").innerHTML=`<span class="eyebrow">LATEST GAME</span><h3>${r.headline}</h3><div class="recap-score"><span>${state.school.name}</span><strong>${r.us}-${r.them}</strong><span>${r.opponent}</span></div>${r.rivalry?'<p class="rivalry">Rivalry game</p>':""}<div class="commit-grid">${r.stars.map(s=>`<div class="commit-card">${s}</div>`).join("")}</div><div class="box-score-grid">${Object.entries(r.boxScore||{}).map(([k,v])=>`<div class="box-stat"><small>${k}</small><b>${v}</b></div>`).join("")}</div><div class="drive-list">${(r.drives||[]).slice(0,10).map(d=>`<div class="drive">${d}</div>`).join("")}</div>`}else $("gameRecapPanel").classList.add("hidden")}
function renderStandings(){if($("conferenceStandingsTitle"))$("conferenceStandingsTitle").textContent=`${state.school.conference} Standings`;$("standings").innerHTML=state.standings.slice().sort((a,b)=>b.w-a.w).map((s,i)=>`<div class="standing-card"><h4>#${i+1} ${s.name}</h4><span class="sub">${s.w}-${s.l}</span></div>`).join("")}

function facilityCost(key){return 150000*state.facilities[key]+(state.facilities[key]-1)*80000}
function upgradeFacility(key){
 let cost=facilityCost(key);if(state.budget<cost||state.facilities[key]>=5)return;
 state.budget-=cost;state.facilities[key]++;if(state.facilities[key]>=5)state.achievementStats.facilityMax++;
 if(key==="training")state.school.facilities=clamp(state.school.facilities+3,0,99);
 if(key==="recruiting")state.school.prestige=clamp(state.school.prestige+1,0,99);
 if(key==="stadium")state.fanApproval=clamp(state.fanApproval+5,0,100);
 if(key==="academics")state.school.academics=clamp(state.school.academics+3,0,99);
 state.news.push(`${key[0].toUpperCase()+key.slice(1)} facilities upgraded to Level ${state.facilities[key]}.`);
 renderAll()
}
window.upgradeFacility=upgradeFacility;
function replaceCoach(key){
 let role=key==="head"?"Head Coach":key==="oc"?"Offensive Coordinator":"Defensive Coordinator";
 let fee=key==="head"?450000:220000;if(state.budget<fee)return;
 state.budget-=fee;let base=Math.round((state.school.prestige+state.school.recent)/2)+4;
 state.staff[key]=makeCoach(role,base);if(key==='head'&&state.headCoach){state.headCoach.baseRatings={recruiting:Number(state.staff.head.recruiting),development:Number(state.staff.head.development),game:Number(state.staff.head.game)};syncHeadCoachRatings()}state.achievementStats.firedCoach=true;state.jobSecurity=clamp(state.jobSecurity-5,0,100);
 state.news.push(`${role} replaced during the coaching carousel.`);renderAll()
}
window.replaceCoach=replaceCoach;
function renderProgram(){
 if(!$("programManagementCards"))return;
 let status=state.jobSecurity>=75?"Secure":state.jobSecurity>=45?"Warm":"Hot Seat";
 $("programManagementCards").innerHTML=metric("Budget","$"+Math.round(state.budget/1000)+"k")+metric("Job Security",status)+metric("Fan Approval",state.fanApproval+"%")+metric("Booster Support",state.boosterSupport+"%")+metric("Prestige",state.school.prestige)+metric("Recent Success",state.school.recent)+metric("Program Tier",schoolTier(state.school).label);if($("tierExplanation"))$("tierExplanation").innerHTML=`Your program is currently <b>${schoolTier(state.school).label}</b>. Stronger prestige, recent success, facilities, pro development, and NIL support raise your tier and unlock higher-level recruits.`;
 const names={training:"Training Center",recruiting:"Recruiting Department",medical:"Sports Medicine",stadium:"Stadium & Atmosphere",academics:"Academic Support"};
 $("facilityGrid").innerHTML=Object.entries(state.facilities).map(([k,v])=>`<div class="facility-card"><h3>${names[k]}</h3><div class="level">Level ${v}</div><div class="progress"><div style="width:${v*20}%"></div></div><span class="sub">${v>=5?"Maximum level":"Next upgrade: $"+Math.round(facilityCost(k)/1000)+"k"}</span><button class="btn small primary full" onclick="upgradeFacility('${k}')" ${v>=5||state.budget<facilityCost(k)?"disabled":""}>Upgrade</button></div>`).join("");
 $("staffManagement").innerHTML=Object.entries(state.staff).map(([k,c])=>`<div class="coach-card"><h3>${c.name}</h3><div class="muted">${c.role}</div><div class="coach-ratings"><div><small>Recruit</small><b>${c.recruiting}</b></div><div><small>Develop</small><b>${c.development}</b></div><div><small>Game</small><b>${c.game}</b></div></div><button class="btn small danger full" onclick="replaceCoach('${k}')" ${state.budget<(k==="head"?450000:220000)?"disabled":""}>Replace Coach</button></div>`).join("");
 $("promiseList").innerHTML=state.promises.map(p=>`<div class="event-card"><b>${p.target}</b><span class="sub">${p.type} · Year ${p.year} · ${p.resolved?(p.kept?"Kept":"Broken"):"Active"}</span></div>`).join("")||'<p class="muted">No active promises.</p>'
}
function updateRecordBook(classRank){
 let w=state.record.w;if(!state.records.bestSeason||w>state.records.bestSeason.wins)state.records.bestSeason={year:state.year,wins:w,losses:state.record.l};
 if(!state.records.bestClass||classRank<state.records.bestClass.rank)state.records.bestClass={year:state.year,rank:classRank};
 [["passing","QB","yards"],["rushing","RB","yards"],["receiving","WR","yards"],["sacks",null,"sacks"],["interceptions",null,"int"]].forEach(([key,pos,stat])=>{let p=(pos?state.roster.filter(x=>x.pos===pos):state.roster).sort((a,b)=>(b.stats[stat]||0)-(a.stats[stat]||0))[0];if(p&&(!state.records[key]||p.stats[stat]>state.records[key].value))state.records[key]={player:p.name,value:p.stats[stat],year:state.year}})
}

function renderRankings(){
 if(!$("rankingGrid"))return;updateRankings();
 $("rankingGrid").innerHTML=state.rankings.slice(0,25).map(t=>`<div class="ranking-card"><div class="rank">${t.rank}</div><div><b>${t.name}</b><span class="sub">${t.conference} · ${(state.rankingMovement.find(m=>m.id===t.id)?.change||0)>0?"▲ "+state.rankingMovement.find(m=>m.id===t.id).change:(state.rankingMovement.find(m=>m.id===t.id)?.change||0)<0?"▼ "+Math.abs(state.rankingMovement.find(m=>m.id===t.id).change):"—"}</span></div><strong>${t.record.w}-${t.record.l}</strong></div>`).join("");
 $("playoffBracket").innerHTML=state.playoff.map((t,i)=>`<div class="playoff-card"><span class="eyebrow">SEED ${i+1}</span><h3>${t.name}</h3><span class="sub">${t.record.w}-${t.record.l} · ${t.conference}</span></div>`).join("")
}


function renderConferenceDirectory(){
 if(!$("conferenceDirectory"))return;
 const groups={};schools.forEach(s=>(groups[s.conference]??=[]).push(s));
 const order=["Great North","Southeastern","Atlantic","Heartland","Western","Metro","Great Lakes","Mountain","Southern Coast","National","Independents"];
 $("conferenceDirectory").innerHTML=order.filter(name=>groups[name]).map(name=>{
   const teams=groups[name],meta=CONFERENCE_META[name],avgPrestige=Math.round(avg(teams.map(t=>t.prestige))),avgPower=Math.round(avg(teams.map(t=>(t.prestige+t.recent+t.facilities)/3)));
   return `<div class="conference-directory-card">
     <span class="conference-level ${meta.className}">${meta.level}</span>
     <h3>${name}</h3>
     <strong>${teams.length}</strong><span class="sub"> programs · ${meta.region}</span>
     <div class="conference-stats"><div><small>AVG PRESTIGE</small><b>${avgPrestige}</b></div><div><small>AVG POWER</small><b>${avgPower}</b></div></div>
     <div class="sub">${teams.slice().sort((a,b)=>b.prestige-a.prestige).slice(0,4).map(t=>t.name).join(" · ")}</div>
   </div>`
 }).join("")
}
function renderHistory(){$("historyList").innerHTML=state.history.slice().reverse().map(h=>`<div class="news-item"><span class="news-dot"></span><div><b>Year ${h.year}: ${h.wins}-${h.losses}</b><div class="sub">Grade ${h.grade} · Class #${h.classRank} · ${h.post}</div></div></div>`).join("")||`<p class="muted">No completed seasons yet.</p>`;$("trophyGrid").innerHTML=state.trophies.map(t=>`<div class="trophy-card"><h4>${t.type}</h4><span class="sub">Year ${t.year}</span></div>`).join("")||`<p class="muted">No trophies yet.</p>`;let r=state.records;$("recordBook").innerHTML=[["Best Season",r.bestSeason?`${r.bestSeason.wins}-${r.bestSeason.losses} · Year ${r.bestSeason.year}`:"-"],["Best Recruiting Class",r.bestClass?`#${r.bestClass.rank} · Year ${r.bestClass.year}`:"-"],["Passing Yards",r.passing?`${r.passing.player} · ${r.passing.value}`:"-"],["Rushing Yards",r.rushing?`${r.rushing.player} · ${r.rushing.value}`:"-"],["Receiving Yards",r.receiving?`${r.receiving.player} · ${r.receiving.value}`:"-"],["Sacks",r.sacks?`${r.sacks.player} · ${r.sacks.value}`:"-"],["Interceptions",r.interceptions?`${r.interceptions.player} · ${r.interceptions.value}`:"-"]].map(x=>`<div class="record-card"><h4>${x[0]}</h4><span>${x[1]}</span></div>`).join("")}
function simEnd(){while(state.phase==="REGULAR"&&!state.seasonDone)advanceWeek()}
function showTab(n){document.querySelectorAll(".nav-tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===n));document.querySelectorAll(".tab-page").forEach(p=>p.classList.add("hidden"));$(n+"Tab").classList.remove("hidden")}
function save(){localStorage.setItem(`SaturdayArchitectCompleteV9_slot${state.saveSlot}`,JSON.stringify(state));alert(`Dynasty saved to slot ${state.saveSlot}.`)}function load(){let slot=$("saveSlotPicker")?.value||"1",s=localStorage.getItem(`SaturdayArchitectCompleteV9_slot${slot}`);if(!s)return;try{state=JSON.parse(s);$("schoolScreen").classList.add("hidden");$("gameScreen").classList.remove("hidden");$("mobileBottomNav")?.classList.remove("hidden");$("mobileStatus")?.classList.remove("hidden");renderAll();if(state.phase==="SIGNING")$("signingDayPanel").classList.remove("hidden");if(state.phase==="AWARDS")$("awardsWeekPanel")?.classList.remove("hidden");if(state.phase==="POST")$("postseasonPanel").classList.remove("hidden");if(state.phase==="PORTAL"){renderPortal();$("portalPanel").classList.remove("hidden")}}catch{}}
[...new Set(schools.map(s=>s.conference))].sort().forEach(v=>$("conferencePicker").insertAdjacentHTML("beforeend",`<option>${v}</option>`));[...new Set(schools.map(s=>s.region))].sort().forEach(v=>{$("regionPicker").insertAdjacentHTML("beforeend",`<option>${v}</option>`);$("recruitRegionFilter").insertAdjacentHTML("beforeend",`<option>${v}</option>`)});POSITIONS.forEach(p=>$("positionFilter").insertAdjacentHTML("beforeend",`<option>${p}</option>`));

const ACHIEVEMENT_DEFS=[
{id:"FIRST_WIN",name:"First Saturday",desc:"Win your first game.",icon:"🏈",goal:1,stat:"careerWins"},
{id:"TEN_WINS",name:"Double Digits",desc:"Win 10 games in one season.",icon:"🔟",goal:10,seasonStat:"wins"},
{id:"UNDEFEATED",name:"Perfect Season",desc:"Finish a season undefeated.",icon:"💯",goal:1,stat:"undefeated"},
{id:"RIVALRY_5",name:"Own the Rivalry",desc:"Win five rivalry games.",icon:"⚔️",goal:5,stat:"rivalWins"},
{id:"CONF_TITLE",name:"Conference Champion",desc:"Win a conference championship.",icon:"🏆",goal:1,stat:"conferenceTitles"},
{id:"CONF_DYNASTY",name:"Conference Dynasty",desc:"Win five conference championships.",icon:"👑",goal:5,stat:"conferenceTitles"},
{id:"PLAYOFF",name:"Playoff Bound",desc:"Reach the 12-team playoff.",icon:"🎟️",goal:1,custom:"playoff"},
{id:"PLAYOFF_WIN",name:"Advance",desc:"Win a playoff game.",icon:"📈",goal:1,stat:"playoffWins"},
{id:"NATIONAL_TITLE",name:"National Champion",desc:"Win the national championship.",icon:"🏆",goal:1,stat:"nationalTitles"},
{id:"THREE_TITLES",name:"Modern Dynasty",desc:"Win three national championships.",icon:"👑",goal:3,stat:"nationalTitles"},
{id:"BOWL_WIN",name:"Bowl Victor",desc:"Win a bowl game.",icon:"🥣",goal:1,stat:"bowlWins"},
{id:"TOP5_CLASS",name:"Signing Day Power",desc:"Sign a top-five recruiting class.",icon:"✍️",goal:1,stat:"top5Classes"},
{id:"FIVE_STAR",name:"Blue-Chip Signature",desc:"Sign a five-star recruit.",icon:"⭐",goal:1,stat:"fiveStars"},
{id:"FIVE_5STARS",name:"Loaded Class",desc:"Sign five five-stars across your career.",icon:"🌟",goal:5,stat:"fiveStars"},
{id:"GEM",name:"Found a Gem",desc:"Sign a prospect who outperforms his listed ranking.",icon:"💎",goal:1,custom:"gem"},
{id:"PIPELINE",name:"Own the State",desc:"Build a Dominant recruiting pipeline.",icon:"🗺️",goal:1,custom:"pipeline"},
{id:"DRAFTED",name:"Pro Pipeline",desc:"Have a player drafted.",icon:"📣",goal:1,stat:"totalDrafted"},
{id:"FIRST_ROUND",name:"First-Round Factory",desc:"Produce a first-round pick.",icon:"1️⃣",goal:1,stat:"firstRounders"},
{id:"TEN_DRAFTED",name:"NFL Factory",desc:"Produce ten drafted players.",icon:"🏭",goal:10,stat:"totalDrafted"},
{id:"ALL_AMERICAN",name:"All-American",desc:"Produce an All-American.",icon:"🇺🇸",goal:1,stat:"allAmericans"},
{id:"AWARD",name:"Hardware",desc:"Produce a national award winner.",icon:"🏅",goal:1,stat:"awardWinners"},
{id:"MAX_FACILITY",name:"Arms Race",desc:"Max out a facility.",icon:"🏗️",goal:1,stat:"facilityMax"},
{id:"PORTAL_KING",name:"Portal King",desc:"Add ten transfer players.",icon:"🚪",goal:10,stat:"portalAdds"},
{id:"ROAD_WARRIOR",name:"Road Warrior",desc:"Win five ranked road games.",icon:"🚌",goal:5,stat:"roadRankedWins"},
{id:"REBUILD_PLAYOFF",name:"From Nothing",desc:"Take a Rebuild-tier program to the playoff.",icon:"🔥",goal:1,stat:"rebuildPlayoffs"},
{id:"COACH_100",name:"Century Club",desc:"Win 100 career games.",icon:"💯",goal:100,stat:"careerWins"},
{id:"COACH_250",name:"Legend",desc:"Win 250 career games.",icon:"🧢",goal:250,stat:"careerWins"},
{id:"SELL_OUT",name:"Pack the House",desc:"Reach a five-game sellout streak.",icon:"🏟️",goal:5,custom:"sellout"},
{id:"FACILITIES",name:"Five-Star Campus",desc:"Reach Level 4 or better in every facility.",icon:"🏛️",goal:1,custom:"facilities"},
{id:"RANK_ONE",name:"Number One",desc:"Reach #1 in the national rankings.",icon:"🥇",goal:1,custom:"rankOne"},
{id:"CLASS_ONE",name:"Recruiting Champion",desc:"Sign the #1 recruiting class.",icon:"📝",goal:1,custom:"classOne"},
{id:"BEAT_TOP5",name:"Giant Killer",desc:"Beat a top-five opponent.",icon:"🗡️",goal:1,custom:"beatTop5"},
{id:"FIRE_COACH",name:"Make the Tough Call",desc:"Replace a coordinator or head coach.",icon:"📋",goal:1,custom:"firedCoach"},
{id:"LOYAL",name:"Program Builder",desc:"Remain at one school for ten seasons.",icon:"🏠",goal:10,stat:"seasons"},
{id:"ACADEMICS",name:"Academic Power",desc:"Reach 95 Academic Support.",icon:"🎓",goal:1,custom:"academics"},
{id:"BIG_WIN",name:"Statement Win",desc:"Win a game by 35 or more.",icon:"💥",goal:1,custom:"bigWin"},
{id:"COMEBACK",name:"Comeback Culture",desc:"Win a close game after trailing in the simulation.",icon:"↗️",goal:1,custom:"comeback"},
{id:"WEATHER",name:"Built for Anything",desc:"Win games in three different adverse weather conditions.",icon:"🌨️",goal:3,custom:"weatherWins"}
];
function ensureExpansionState(){
 state.coachCareer??={name:"Coach",salary:1500000,contractYears:4,buyout:500000,reputation:50,careerWins:0,careerLosses:0,jobs:[]};
 state.staffAssignments??={head:{region:"National",position:"ALL"},oc:{region:"Southeast",position:"OFFENSE"},dc:{region:"Midwest",position:"DEFENSE"}};
 state.pipelineLevels??={};state.traditions??=[];state.stadium??={name:"Memorial Stadium",capacity:55000,attendance:0,selloutStreak:0,atmosphere:55};
 state.rivalryHistory??={};state.draftHistory??=[];state.allAmericans??=[];state.conferenceChampions??=[];state.offseasonTasks??={spring:false,battles:false,progression:false,staff:false,draft:false};
 state.achievementStats??={seasons:0,rivalWins:0,conferenceTitles:0,nationalTitles:0,bowlWins:0,playoffWins:0,top5Classes:0,fiveStars:0,firstRounders:0,totalDrafted:0,undefeated:0,rebuildPlayoffs:0,allAmericans:0,awardWinners:0,facilityMax:0,portalAdds:0,roadRankedWins:0};
 state.achievements??={};state.rankingMovement??=[];state.negativeRecruitingUsed??=0;
}
function programTraditions(s){
 const traditions=[];
 if(s.pro>=88)traditions.push({name:"Pro Factory",desc:"Extra pro-development recruiting strength and draft progression."});
 if(s.academics>=92)traditions.push({name:"Academic Power",desc:"Academic recruits receive a major interest bonus."});
 if(s.facilities>=90)traditions.push({name:"State-of-the-Art",desc:"Improved development and recruiting visits."});
 if(s.prestige>=90)traditions.push({name:"National Brand",desc:"Reduced distance penalties and stronger initial interest."});
 if(s.recent>=88)traditions.push({name:"Championship Standard",desc:"Winning-focused recruits value the program more."});
 if(s.pipelines.length>=4)traditions.push({name:"National Recruiting Reach",desc:"Pipelines grow faster and decay slower."});
 if(traditions.length<2)traditions.push({name:"Sleeping Giant",desc:"Prestige gains are larger after breakthrough seasons."});
 return traditions.slice(0,3)
}
function initializeExpansion(){
 ensureExpansionState();
 if(!state.traditions.length)state.traditions=programTraditions(state.school);
 if(!state.stadium.capacity){state.stadium={name:`${state.school.city} Memorial Stadium`,capacity:35000+state.school.prestige*650,attendance:0,selloutStreak:0,atmosphere:clamp(Math.round((state.school.prestige+state.fanApproval)/2),35,98)}}
 state.school.pipelines.forEach(st=>{if(!state.pipelineLevels[st])state.pipelineLevels[st]={points:65,level:"Strong"}});
 if(!state.rivalryHistory[state.rivalId])state.rivalryHistory[state.rivalId]={wins:0,losses:0,streak:0,bestMargin:0,last:null,trophy:`${state.school.state} Border Trophy`}
}
function pipelineLevel(points){return points>=90?"Dominant":points>=65?"Strong":points>=40?"Established":points>=20?"Emerging":"None"}
function updatePipelines(){
 const signed={};state.commits.forEach(r=>signed[r.home]=(signed[r.home]||0)+1);
 Object.keys(state.pipelineLevels).forEach(st=>state.pipelineLevels[st].points=Math.max(0,state.pipelineLevels[st].points-3));
 Object.entries(signed).forEach(([st,n])=>{state.pipelineLevels[st]??={points:0,level:"None"};state.pipelineLevels[st].points=clamp(state.pipelineLevels[st].points+n*12,0,100)});
 Object.values(state.pipelineLevels).forEach(p=>p.level=pipelineLevel(p.points));
 state.school.pipelines=Object.entries(state.pipelineLevels).filter(([,p])=>p.points>=20).sort((a,b)=>b[1].points-a[1].points).slice(0,6).map(([st])=>st)
}
function scoutAccuracy(){
 const staff=avg(Object.values(state.staff).map(c=>c.recruiting));
 return clamp(45+staff*.35+state.facilities.recruiting*5,55,96)
}
function applyHiddenEvaluation(r){
 if(r.trueOvr)return;
 const accuracy=scoutAccuracy(),variance=Math.min(8,Math.round((100-accuracy)/5)+2);
 r.trueOvr=r.ovr;r.truePot=r.pot||clamp(r.ovr+rand(3,10),r.ovr,96);
 const listedCeiling=r.stars===3?(r.generatedGem?84:80):r.stars===2?72:96;
 r.listedOvr=clamp(r.trueOvr+rand(-variance,variance),50,listedCeiling);
 r.listedPot=clamp(r.truePot+rand(-variance,variance),r.listedOvr,98);
 r.scoutConfidence=Math.round(accuracy);
 r.evalTag=(r.generatedGem||r.trueOvr-r.listedOvr>=5)?"Gem":r.listedOvr-r.trueOvr>=5?"Bust":"Normal";
 r.ovr=r.listedOvr;r.pot=r.listedPot
}
function revealTrueEvaluation(r){if(r.trueOvr){r.ovr=r.trueOvr;r.pot=r.truePot;r.scoutConfidence=100}}
function relationshipForRecruit(r){
 if(r.relationship)return r.relationship;
 const candidates=state.recruits.filter(x=>x!==r&&x.home===r.home&&Math.abs(x.rank-r.rank)<160);
 if(candidates.length&&Math.random()<.24){const other=choice(candidates);r.relationship={type:choice(["High-school teammate","Brother","7-on-7 teammate","Close friend","Rival"]),otherId:other.id,otherName:other.name};return r.relationship}
 return null
}
function useNegativeRecruiting(id){
 const r=findR(id);if(!r)return;const status=recruitingActionStatus(r);if(!status.canRecruit){rejectRecruitAction(r,status.activeReason);return}if(state.weeklyHours<15)return;
 state.weeklyHours-=15;state.negativeRecruitingUsed++;
 const leaders=Object.entries(r.interest).filter(([sid])=>+sid!==state.school.id).sort((a,b)=>b[1]-a[1]);
 if(!leaders.length)return;
 const [targetId]=leaders[0],target=schools.find(s=>s.id===+targetId);
 const weakness=choice(["facilities","recent","pro","nil"]);
 const gap=(state.school[weakness]||0)-(target?.[weakness]||0);
 if(gap>0||Math.random()<.55){r.interest[targetId]=clamp(r.interest[targetId]-rand(5,11),0,100);r.interest[state.school.id]=clamp(r.interest[state.school.id]+rand(2,6),0,recruitInterestCap(r,state.school));state.news.push(`Negative recruiting against ${target.name} gained traction with ${r.name}.`)}
 else{r.interest[state.school.id]=clamp(r.interest[state.school.id]-rand(4,8),0,100);state.news.push(`Negative recruiting backfired with ${r.name}.`)}
 renderAll()
}
window.useNegativeRecruiting=useNegativeRecruiting;
function weatherForGame(g){
 if(g.home&&["MI","OH","WI","MN","PA","NY","MA","NE","CO"].includes(state.school.state)&&state.week>=10)return choice(["Snow","Cold","Heavy Wind"]);
 if(["FL","GA","AL","TX","LA","MS","AZ"].includes((schools.find(s=>s.id===g.oppId)||state.school).state)&&state.week<=4)return choice(["Extreme Heat","Humid","Clear"]);
 return choice(["Clear","Clear","Cloudy","Rain","Wind"])
}
function weatherModifier(weather,scheme){
 if(weather==="Snow"||weather==="Rain")return scheme==="Power Run"||scheme==="Option"?3:-2;
 if(weather==="Heavy Wind"||weather==="Wind")return scheme==="Air Raid"?-4:1;
 if(weather==="Extreme Heat")return state.facilities.medical>=4?1:-2;
 return 0
}
function customSchedulingModal(){
 const nonConf=state.schedule.filter(g=>!g.conference&&!g.rivalry);
 $("modalBody").innerHTML=`<span class="eyebrow">FUTURE SCHEDULING</span><h2>Edit Non-Conference Games</h2><p class="muted">Choose up to three replacements. Stronger games improve playoff résumé and recruiting exposure but increase risk.</p>${nonConf.slice(0,4).map(g=>`<div class="event-card"><b>Week ${g.week}: ${g.opponent}</b><select onchange="replaceScheduledOpponent(${g.week},this.value)"><option value="">Keep opponent</option>${schools.filter(s=>s.id!==state.school.id&&!state.schedule.some(x=>x.oppId===s.id)).sort((a,b)=>b.prestige-a.prestige).slice(0,40).map(s=>`<option value="${s.id}">${s.name} · Power ${Math.round((s.prestige+s.recent)/2)}</option>`).join("")}</select></div>`).join("")}`;$("modal").classList.remove("hidden")
}
function replaceScheduledOpponent(week,id){
 if(!id)return;const g=state.schedule.find(x=>x.week===week),s=schools.find(x=>x.id===+id);if(!g||!s)return;
 Object.assign(g,{opponent:s.name,oppId:s.id,oppPower:Math.round((s.prestige+s.recent)/2),conference:false,rivalry:false});state.news.push(`Scheduled ${s.name} for Week ${week}.`);renderAll()
}
window.replaceScheduledOpponent=replaceScheduledOpponent;
function conferenceChampionshipMatchups(){
 const conferences=Object.keys(CONFERENCE_ALIGNMENT).filter(c=>c!=="Independents");
 return conferences.map(conf=>{
  const members=state.world.filter(t=>t.conference===conf).concat(state.school.conference===conf?[{id:state.school.id,name:state.school.name,record:state.record,rosterPower:teamRatings().overall,conference:conf}]:[]).filter((v,i,a)=>a.findIndex(x=>x.id===v.id)===i).sort((a,b)=>b.record.w-a.record.w||a.record.l-b.record.l||b.rosterPower-a.rosterPower);
  return{conference:conf,a:members[0],b:members[1]}
 }).filter(x=>x.a&&x.b)
}
function simulateNeutralGame(a,b,label){
 const ap=a.id===state.school.id?teamRatings().overall:(a.rosterPower||Math.round((Number(a.prestige||70)+Number(a.recent||70))/2)),bp=b.id===state.school.id?teamRatings().overall:(b.rosterPower||Math.round((Number(b.prestige||70)+Number(b.recent||70))/2));
 let as=0,bs=0,count=rand(11,14);
 for(let i=1;i<=count;i++){
  const late=i/count>=.72;
  as+=simDrive(ap,bp,"",{late,lead:as-bs,ownScore:as}).points;
  bs+=simDrive(bp,ap,"",{late,lead:bs-as,ownScore:bs}).points
 }
 if(as===bs){
  for(let ot=0;ot<5&&as===bs;ot++){as+=simOvertimeDrive(ap,bp).points;bs+=simOvertimeDrive(bp,ap).points}
  if(as===bs)Math.random()>.5?as+=2:bs+=2
 }
 return{label,a,b,aScore:Math.max(0,as),bScore:Math.max(0,bs),winner:as>bs?a:b,loser:as>bs?b:a}
}
function prepareChampionshipWeek(){
 state.phase="CHAMP";state.postseasonData={conferenceGames:conferenceChampionshipMatchups(),conferenceResults:[],bowls:[],playoffRounds:[],champions:[]};
 $("championshipPanel").classList.remove("hidden");$("championshipGames").innerHTML=state.postseasonData.conferenceGames.map(g=>`<div class="bracket-card"><span class="eyebrow">${g.conference}</span><h3>${g.a.name} vs ${g.b.name}</h3><span class="sub">${g.a.record.w}-${g.a.record.l} · ${g.b.record.w}-${g.b.record.l}</span></div>`).join("");showTab("season")
}
function playChampionshipWeek(){
 if(state.phase!=="CHAMP")return;
 state.postseasonData.conferenceResults=state.postseasonData.conferenceGames.map(g=>simulateNeutralGame(g.a,g.b,`${g.conference} Championship`));
 state.postseasonData.champions=state.postseasonData.conferenceResults.map(r=>r.winner);
 const userResult=state.postseasonData.conferenceResults.find(r=>r.a.id===state.school.id||r.b.id===state.school.id);
 if(userResult){if(userResult.winner.id===state.school.id){state.achievementStats.conferenceTitles++;state.conferenceChampions.push({year:state.year,conference:state.school.conference});state.trophies.push({year:state.year,type:`${state.school.conference} Champion`});state.news.push(`Won the ${state.school.conference} Championship ${userResult.aScore}-${userResult.bScore}.`)}else state.news.push(`Lost the ${state.school.conference} Championship.`)}
 updateRankings();prepareBowlsAndPlayoff()
}
function prepareBowlsAndPlayoff(){
 state.phase="BOWLS";
 const champs=state.postseasonData.champions.map(c=>state.rankings.find(r=>r.id===c.id)||c).sort((a,b)=>(a.rank||99)-(b.rank||99));
 const auto=champs.slice(0,5),atLarge=state.rankings.filter(t=>!auto.some(a=>a.id===t.id)).slice(0,7);
 const field=auto.concat(atLarge).sort((a,b)=>(a.rank||99)-(b.rank||99)).slice(0,12).map((t,i)=>({...t,seed:i+1}));
 state.postseasonData.playoffField=field;
 state.postseasonData.bowls=state.rankings.filter(t=>!field.some(f=>f.id===t.id)&&t.record.w>=6).slice(0,20).reduce((arr,t,i)=>{if(i%2===0&&state.rankings.filter(x=>!field.some(f=>f.id===x.id)&&x.record.w>=6)[i+1])arr.push({name:choice(["Lakes Bowl","Liberty Bowl","Sun Coast Bowl","Frontier Bowl","Heritage Bowl","Citrus Classic","Desert Bowl","Motor City Bowl"]),a:t,b:state.rankings.filter(x=>!field.some(f=>f.id===x.id)&&x.record.w>=6)[i+1]});return arr},[]);
 $("championshipPanel").classList.add("hidden");$("bowlsPanel").classList.remove("hidden");
 renderPostseasonBrackets()
}
function renderPostseasonBrackets(){
 const d=state.postseasonData;if(!d)return;
 $("bowlGames").innerHTML=(d.bowls||[]).map(b=>`<div class="bracket-card"><span class="eyebrow">${b.name}</span><h3>${b.a.name} vs ${b.b.name}</h3></div>`).join("");
 const f=d.playoffField||[];$("fullPlayoffBracket").innerHTML=`<div class="playoff-round"><h3>12-Team CFP Field</h3><div class="playoff-matchups">${f.map(t=>`<div class="bracket-card"><b>#${t.seed} ${t.name}</b><span class="sub">${t.record.w}-${t.record.l}</span></div>`).join("")}</div></div>`
}
function playPostseason(){
 if(state.phase!=="BOWLS")return;const d=state.postseasonData,f=d.playoffField;
 d.bowlResults=d.bowls.map(b=>simulateNeutralGame(b.a,b.b,b.name));
 const userBowl=d.bowlResults.find(r=>r.a.id===state.school.id||r.b.id===state.school.id);if(userBowl&&userBowl.winner.id===state.school.id){state.achievementStats.bowlWins++;state.trophies.push({year:state.year,type:userBowl.label})}
 const r1=[[f[4],f[11]],[f[5],f[10]],[f[6],f[9]],[f[7],f[8]]].filter(x=>x[0]&&x[1]).map(x=>simulateNeutralGame(x[0],x[1],"CFP First Round"));
 const q=[[f[0],r1[3]?.winner],[f[3],r1[0]?.winner],[f[1],r1[2]?.winner],[f[2],r1[1]?.winner]].filter(x=>x[0]&&x[1]).map(x=>simulateNeutralGame(x[0],x[1],"CFP Quarterfinal"));
 const s=[[q[0]?.winner,q[1]?.winner],[q[2]?.winner,q[3]?.winner]].filter(x=>x[0]&&x[1]).map(x=>simulateNeutralGame(x[0],x[1],"CFP Semifinal"));
 const title=s.length===2?simulateNeutralGame(s[0].winner,s[1].winner,"National Championship"):null;
 d.playoffRounds=[{name:"First Round",games:r1},{name:"Quarterfinals",games:q},{name:"Semifinals",games:s},{name:"National Championship",games:title?[title]:[]}];
 const userGames=d.playoffRounds.flatMap(r=>r.games).filter(g=>g.a.id===state.school.id||g.b.id===state.school.id);
 const wins=userGames.filter(g=>g.winner.id===state.school.id).length;state.achievementStats.playoffWins+=wins;
 if(f.some(t=>t.id===state.school.id)&&schoolTier(state.school).key==="REBUILD")state.achievementStats.rebuildPlayoffs++;
 if(title?.winner.id===state.school.id){state.achievementStats.nationalTitles++;state.trophies.push({year:state.year,type:"National Championship"});state.school.prestige=clamp(state.school.prestige+5,25,99)}
 d.nationalChampion=title?.winner;
 $("fullPlayoffBracket").innerHTML=d.playoffRounds.map(r=>`<div class="playoff-round"><h3>${r.name}</h3><div class="playoff-matchups">${r.games.map(g=>`<div class="bracket-card ${g.winner.id===state.school.id?"champion-card":""}"><b>${g.a.name} ${g.aScore}</b><br><b>${g.b.name} ${g.bScore}</b><span class="sub">Winner: ${g.winner.name}</span></div>`).join("")}</div></div>`).join("");
 finishSeason()
}
function assignCoachRecruiting(key,field,value){state.staffAssignments[key][field]=value;renderStaffAssignments()}
window.assignCoachRecruiting=assignCoachRecruiting;
function renderStaffAssignments(){
 if(!$("staffAssignments"))return;const regions=["National","Midwest","Northeast","Southeast","Southwest","Mountain","West"],positions=["ALL","OFFENSE","DEFENSE",...POSITIONS];
 $("staffAssignments").innerHTML=Object.entries(state.staff).map(([key,c])=>`<div class="assignment-card"><h4>${c.role} Assignment</h4><span class="sub">${c.name} recruits most effectively inside his assignment.</span><select onchange="assignCoachRecruiting('${key}','region',this.value)">${regions.map(x=>`<option ${state.staffAssignments[key].region===x?"selected":""}>${x}</option>`).join("")}</select><select onchange="assignCoachRecruiting('${key}','position',this.value)">${positions.map(x=>`<option ${state.staffAssignments[key].position===x?"selected":""}>${x}</option>`).join("")}</select></div>`).join("")
}
function runSpringPractice(){
 const focuses=["Quarterback Development","Offensive Line Cohesion","Defensive Fundamentals","Conditioning","Youth Development","Scheme Installation","Injury Prevention"];
 $("modalBody").innerHTML=`<span class="eyebrow">SPRING PRACTICE</span><h2>Choose a Team Focus</h2>${focuses.map(f=>`<button class="btn primary full" onclick="selectSpringFocus('${f}')">${f}</button>`).join("")}`;$("modal").classList.remove("hidden")
}
function selectSpringFocus(f){
 state.springFocus=f;state.offseasonTasks.spring=true;
 state.roster.forEach(p=>{let boost=0;if(f==="Quarterback Development"&&p.pos==="QB")boost=2;if(f==="Offensive Line Cohesion"&&["OT","IOL"].includes(p.pos))boost=2;if(f==="Defensive Fundamentals"&&["EDGE","DL","LB","CB","S"].includes(p.pos))boost=1;if(f==="Youth Development"&&p.year<=2)boost=2;if(f==="Conditioning")p.morale=clamp(p.morale+4,0,99);p.ovr=clamp(Math.min(p.pot,p.ovr+boost),45,99)});
 if(f==="Injury Prevention")state.facilities.medical=Math.min(5,state.facilities.medical+.25);
 $("modal").classList.add("hidden");renderOffseasonHub();renderAll()
}
window.selectSpringFocus=selectSpringFocus;
function runPositionBattles(){
 const battles=POSITIONS.map(pos=>({pos,players:state.roster.filter(p=>p.pos===pos&&!p.injury&&!p.redshirt).sort((a,b)=>b.ovr-a.ovr).slice(0,3)})).filter(b=>b.players.length>1);
 $("modalBody").innerHTML=`<span class="eyebrow">TRAINING CAMP</span><h2>Position Battles</h2>${battles.map(b=>`<div class="event-card"><b>${b.pos}</b>${b.players.map(p=>`<button class="btn neutral full" onclick="chooseStarter('${b.pos}','${p.id}')">${p.name} · OVR ${p.ovr} · ${p.arch} · Leadership ${p.attrs?.awareness||p.ovr}</button>`).join("")}</div>`).join("")}<button class="btn success full" onclick="finishBattles()">Finish Position Battles</button>`;$("modal").classList.remove("hidden")
}
function chooseStarter(pos,id){state.roster.filter(p=>p.pos===pos).forEach(p=>p.starter=p.id===id);let selected=state.roster.find(p=>p.id===id);if(selected)selected.morale=clamp(selected.morale+5,0,99)}
function finishBattles(){state.offseasonTasks.battles=true;$("modal").classList.add("hidden");renderOffseasonHub();renderAll()}
window.chooseStarter=chooseStarter;window.finishBattles=finishBattles;
function runPlayerProgression(){
 const top=state.roster.slice().sort((a,b)=>b.pot-b.ovr-(a.pot-a.ovr)).slice(0,18);
 $("modalBody").innerHTML=`<span class="eyebrow">PLAYER DEVELOPMENT</span><h2>Assign Individual Focus</h2>${top.map(p=>`<div class="event-card"><b>${p.name} · ${p.pos} · ${p.ovr}/${p.pot}</b><select onchange="applyPlayerFocus('${p.id}',this.value)"><option value="">Choose focus</option><option>Strength</option><option>Speed</option><option>Awareness</option><option>Technique</option><option>Leadership</option><option>Position Change</option></select></div>`).join("")}<button class="btn success full" onclick="finishProgression()">Finish Development</button>`;$("modal").classList.remove("hidden")
}
function applyPlayerFocus(id,focus){
 const p=state.roster.find(x=>x.id===id);if(!p||!focus)return;p.attrs??=attrsFor(p.pos,p.ovr);
 if(focus==="Strength")p.attrs.strength=clamp(p.attrs.strength+3,40,99);if(focus==="Speed")p.attrs.speed=clamp(p.attrs.speed+3,40,99);if(focus==="Awareness")p.attrs.awareness=clamp(p.attrs.awareness+3,40,99);if(focus==="Technique")p.attrs.skill=clamp(p.attrs.skill+3,40,99);if(focus==="Leadership")p.morale=clamp(p.morale+7,0,99);
 if(focus==="Position Change"){const map={QB:"WR",RB:"WR",WR:"CB",TE:"OT",OT:"IOL",IOL:"OT",EDGE:"LB",DL:"EDGE",LB:"S",CB:"S",S:"LB"};if(map[p.pos]){p.pos=map[p.pos];p.arch=choice(ARCH[p.pos]);p.ovr=clamp(p.ovr+rand(-4,2),45,99)}}
}
function finishProgression(){state.offseasonTasks.progression=true;$("modal").classList.add("hidden");autoDepth();renderOffseasonHub();renderAll()}
window.applyPlayerFocus=applyPlayerFocus;window.finishProgression=finishProgression;
function carouselCoachRating(c){return Math.round(avg([Number(c?.recruiting||50),Number(c?.development||50),Number(c?.game||50)]))}
function carouselMoney(v){return "$"+(Number(v||0)>=1000000?(Number(v||0)/1000000).toFixed(2).replace(/0+$/,'').replace(/\.$/,'')+"M":Math.round(Number(v||0)/1000)+"k")}
function carouselProgramPower(s){const w=state.world?.find(t=>Number(t.id)===Number(s.id));return Math.round(Number(w?.rosterPower||((Number(s.prestige||50)+Number(s.recent||50)+Number(s.facilities||50))/3)))}
function carouselConferenceTier(conf){return ({"Great North":5,"Southeastern":5,"Atlantic":5,"Heartland":5,"Western":4,"Metro":3,"Great Lakes":3,"Mountain":3,"Southern Coast":3,"National":3,"Independents":2})[conf]||2}
function carouselCoordinatorCandidates(key,departing){
 const role=key==="oc"?"Offensive Coordinator":"Defensive Coordinator",base=Math.round((state.school.prestige+state.school.recent)/2),styles=key==="oc"?["Recruiting specialist","Quarterback developer","Offensive strategist","Youth developer"]:["Recruiting specialist","Secondary developer","Defensive strategist","Culture builder"];
 return Array.from({length:3},(_,i)=>{const coach=makeCoach(role,base-rand(2,10)+i*2),rating=carouselCoachRating(coach),specialty=styles[(i+state.year)%styles.length],salary=Math.round((260000+rating*8500+i*35000)/10000)*10000,hireCost=Math.round((75000+salary*.18)/10000)*10000;return{coach,specialty,salary,hireCost,fit:rating>=82?"A":rating>=76?"B+":rating>=70?"B":"C+"}})
}
function carouselOfferReason(s,type,performance){
 if(type==="PROMOTION")return `Your ${state.record.w}-win season and rising reputation put you on a bigger program's shortlist.`;
 if(type==="REBUILD")return `${s.name} wants a program builder to restore recent success without starting from zero.`;
 if(performance>=2)return `Strong results above expectations made you a priority candidate.`;
 return `Your recruiting, development and career profile match the program's direction.`
}
function coordinatorCarousel(){
 ensureExpansionState();
 const existing=(state.jobOffers||[]).filter(o=>Number(o.carouselYear)===Number(state.year));if(existing.length&&!state.offseasonTasks.staff){state.jobOffers=existing;renderCarouselModal();return}
 const wins=Number(state.record.w||0),expected=Number(state.seasonExpectations?.expectedWins||state.school.expectation||6),performance=wins-expected,reputation=Number(state.coachCareer.reputation||50),currentPrestige=Number(state.school.prestige||50),currentTier=carouselConferenceTier(state.school.conference),offers=[];
 for(const [key,c] of Object.entries(state.staff||{}).filter(([k])=>k!=="head")){
  const rating=carouselCoachRating(c),chance=clamp(.08+Math.max(0,rating-76)*.018+Math.max(0,wins-8)*.045-(hasCoachSkill?.("CEO")?.16:0),.05,.72);
  if(Math.random()<chance){const destinations=schools.filter(s=>s.id!==state.school.id&&s.prestige>=state.school.prestige-10).sort((a,b)=>Math.abs(a.prestige-(rating+5))-Math.abs(b.prestige-(rating+5))),destination=choice(destinations.slice(0,12))||choice(schools),retainCost=Math.round((140000+rating*4200+wins*12000)/10000)*10000;offers.push({type:"STAFF_DEPARTURE",carouselYear:state.year,key,coach:c,destination:destination.name,retainCost,status:"PENDING",impact:`${c.role} ratings: Recruiting ${c.recruiting} · Development ${c.development} · Game ${c.game}`})}
 }
 const jobEligible=wins>=7||reputation>=60||performance>=2;
 if(jobEligible){
  const pool=schools.filter(s=>s.id!==state.school.id).map(s=>{const targetTier=carouselConferenceTier(s.conference),prestige=Number(s.prestige||50),recent=Number(s.recent||50),need=Math.max(0,prestige-recent),delta=prestige-currentPrestige;let jobType=delta>=7||targetTier>currentTier?"PROMOTION":delta<=-7||need>=10?"REBUILD":"LATERAL";const fit=reputation+wins*2.2+performance*4+need*.7-Math.max(0,delta-18)*2+rand(-12,12),opening=(need>=6||recent<58||Math.random()<.28);return{s,fit,opening,jobType,delta,targetTier,prestige,recent}}).filter(x=>x.opening&&x.fit>=72).sort((a,b)=>b.fit-a.fit);
  const desired=wins>=11||reputation>=86?5:wins>=9||reputation>=74?4:Math.max(1,Math.min(3,pool.length));
  const selected=[];for(const type of ["PROMOTION","LATERAL","REBUILD"]){const x=pool.find(p=>p.jobType===type&&!selected.includes(p));if(x)selected.push(x)}for(const x of pool)if(selected.length<desired&&!selected.includes(x))selected.push(x);
  selected.slice(0,desired).forEach(x=>{const s=x.s,power=carouselProgramPower(s),salary=Math.round((700000+x.prestige*22500+x.targetTier*90000+reputation*6000)/10000)*10000,years=x.jobType==="REBUILD"?rand(5,7):rand(3,6),security=x.jobType==="REBUILD"?82:x.jobType==="PROMOTION"?62:72,expectedWins=clamp(Math.round((x.prestige+x.recent+power)/28)-1,4,11);offers.push({type:"HEAD_JOB",carouselYear:state.year,school:JSON.parse(JSON.stringify(s)),salary,years,security,expectedWins,jobType:x.jobType,status:"PENDING",reason:carouselOfferReason(s,x.jobType,performance),programPower:power})})
 }
 state.jobOffers=offers;state.carouselMessage=offers.length?"Review coordinator decisions and head-coaching opportunities.":"The market was quiet this offseason. Your current job remains available.";renderCarouselModal()
}
function renderCarouselModal(){
 const staffOffers=(state.jobOffers||[]).filter(o=>o.type==="STAFF_DEPARTURE"),headOffers=(state.jobOffers||[]).filter(o=>o.type==="HEAD_JOB"),unresolvedStaff=staffOffers.filter(o=>!["RETAINED","HIRED"].includes(o.status));
 const staffHtml=staffOffers.map((o,i)=>{const idx=state.jobOffers.indexOf(o);if(o.status==="RETAINED")return `<div class="offer-card resolved"><b>${o.coach.name} retained</b><span class="sub">${o.coach.role} returns after a ${carouselMoney(o.retainCost)} raise.</span></div>`;if(o.status==="HIRED")return `<div class="offer-card resolved"><b>${state.staff[o.key]?.name} hired</b><span class="sub">New ${state.staff[o.key]?.role} · ${o.hiredSpecialty||'Balanced staff fit'}</span></div>`;if(o.status==="SEARCH")return `<div class="offer-card"><b>Replace ${o.coach.name} — ${o.coach.role}</b><span class="sub">Choose a candidate. Ratings and one-time hiring cost are shown below.</span>${(o.candidates||[]).map((c,ci)=>`<div class="carousel-candidate"><strong>${c.coach.name} · ${c.fit} fit</strong><span>${c.specialty}</span><small>REC ${c.coach.recruiting} · DEV ${c.coach.development} · GAME ${c.coach.game} · Salary ${carouselMoney(c.salary)}</small><button class="btn primary full" onclick="hireCoordinator(${idx},${ci})" ${state.budget<c.hireCost?'disabled':''}>Hire · ${carouselMoney(c.hireCost)} cost</button></div>`).join('')}<button class="btn neutral full" onclick="promoteAnalyst(${idx})" ${state.budget<75000?'disabled':''}>Promote Analyst · $75k</button></div>`;return `<div class="offer-card"><b>${o.coach.name} received a head-coaching offer from ${o.destination}</b><span class="sub">${o.impact}</span><button class="btn primary full" onclick="retainCoordinator(${idx})" ${state.budget<o.retainCost?'disabled':''}>Retain with raise · ${carouselMoney(o.retainCost)}</button><button class="btn neutral full" onclick="letCoordinatorLeave(${idx})">Let Coach Leave & Interview Replacements</button></div>`}).join('')||'<p class="muted">No coordinator departures this offseason.</p>';
 const headHtml=headOffers.map(o=>{const i=state.jobOffers.indexOf(o),resolved=o.status!=="PENDING";return `<div class="offer-card ${resolved?'resolved':''}"><div class="carousel-offer-head"><b>${o.jobType}: ${o.school.name}</b><span class="stage">${o.school.conference}</span></div><span class="sub">${o.reason}</span><div class="metric-grid compact">${metric("Program OVR",o.programPower)}${metric("Prestige",o.school.prestige)}${metric("Recent",o.school.recent)}${metric("Expected Wins",o.expectedWins)}${metric("Contract",`${o.years} years`)}${metric("Starting Security",`${o.security}%`)}</div><span class="sub">Salary ${carouselMoney(o.salary)} · ${o.status==='DECLINED'?'Declined':o.status==='ACCEPTED'?'Accepted':'Decision pending'}</span>${resolved?'':`<button class="btn primary full" onclick="acceptJob(${i})">Accept Job</button><button class="btn neutral full" onclick="declineJob(${i})">Decline</button>`}</div>`}).join('')||'<p class="muted">No head-coaching offers matched your current profile.</p>';
 $("modalBody").innerHTML=`<span class="eyebrow">COACHING CAROUSEL</span><h2>Staff & Job Market</h2><p class="muted">${state.carouselMessage||''}</p><div class="metric-grid">${metric("Current School",state.school.name)}${metric("Season Record",`${state.record.w}-${state.record.l}`)}${metric("Coach Reputation",state.coachCareer.reputation)}${metric("Program Prestige",state.school.prestige)}${metric("Available Budget",carouselMoney(state.budget))}</div><h3>Coordinator Market</h3>${staffHtml}<h3>Head-Coaching Opportunities</h3>${headHtml}<div class="carousel-stay"><b>Stay at ${state.school.name}</b><span class="sub">Declining or ignoring head jobs keeps your coach and program-building progress here.</span></div>${unresolvedStaff.length?`<p class="warning-text">Resolve ${unresolvedStaff.length} coordinator decision${unresolvedStaff.length===1?'':'s'} before finishing.</p>`:''}<button class="btn success full" onclick="finishCarousel()" ${unresolvedStaff.length?'disabled':''}>Stay / Finish Carousel</button>`;$("modal").classList.remove("hidden")
}
function retainCoordinator(i){const o=state.jobOffers[i];if(!o||o.type!=="STAFF_DEPARTURE"||o.status!=="PENDING"||state.budget<o.retainCost)return;state.budget-=o.retainCost;o.status="RETAINED";o.resolved=true;o.coach.recruiting=clamp(o.coach.recruiting+1,45,99);o.coach.development=clamp(o.coach.development+1,45,99);renderCarouselModal();renderAll()}
function letCoordinatorLeave(i){const o=state.jobOffers[i];if(!o||o.type!=="STAFF_DEPARTURE")return;o.status="SEARCH";o.candidates=carouselCoordinatorCandidates(o.key,o.coach);renderCarouselModal()}
function hireCoordinator(i,ci){const o=state.jobOffers[i],c=o?.candidates?.[ci];if(!o||!c||state.budget<c.hireCost)return;state.budget-=c.hireCost;state.staff[o.key]=c.coach;state.staff[o.key].salary=c.salary;o.status="HIRED";o.resolved=true;o.hiredSpecialty=c.specialty;state.achievementStats.firedCoach=(state.achievementStats.firedCoach||0)+1;renderCarouselModal();renderAll()}
function promoteAnalyst(i){const o=state.jobOffers[i];if(!o||state.budget<75000)return;state.budget-=75000;const role=o.key==="oc"?"Offensive Coordinator":"Defensive Coordinator",coach=makeCoach(role,Math.round((state.school.prestige+state.school.recent)/2)-12);coach.salary=260000;state.staff[o.key]=coach;o.status="HIRED";o.resolved=true;o.hiredSpecialty="Low-cost internal promotion";renderCarouselModal();renderAll()}
function acceptJob(i){
 const o=state.jobOffers[i];if(!o||o.type!=="HEAD_JOB"||o.status!=="PENDING")return;
 const oldSchool=JSON.parse(JSON.stringify(state.school)),oldWorld=state.world?.find(t=>Number(t.id)===Number(oldSchool.id));window.SDF_AI_ROSTERS?.storeUserProgram?.(oldSchool.id,state.roster);if(oldWorld){oldWorld.prestige=oldSchool.prestige;oldWorld.recent=oldSchool.recent;oldWorld.facilities=oldSchool.facilities;oldWorld.pro=oldSchool.pro;oldWorld.rosterPower=teamRatings().overall;oldWorld.record={...state.record}}
 state.coachCareer.jobs??=[];state.coachCareer.jobs.push({school:oldSchool.name,conference:oldSchool.conference,startYear:state.coachCareer.currentJobStartYear||1,endYear:state.year,seasons:Math.max(1,state.year-(state.coachCareer.currentJobStartYear||1)+1),record:`${state.record.w}-${state.record.l}`,prestigeAtExit:oldSchool.prestige});state.coachCareer.currentJobStartYear=state.year+1;
 const targetWorld=state.world?.find(t=>Number(t.id)===Number(o.school.id)),target=JSON.parse(JSON.stringify(o.school));if(targetWorld){target.prestige=targetWorld.prestige;target.recent=targetWorld.recent;target.facilities=targetWorld.facilities;target.pro=targetWorld.pro??target.pro;target.conference=targetWorld.conference||target.conference}
 state.school=target;state.coachCareer.salary=o.salary;state.coachCareer.contractYears=o.years;state.jobSecurity=o.security;state.fanApproval=clamp(Math.round((target.prestige+target.recent)/2),35,95);state.boosterSupport=state.fanApproval;
 const level=clamp(Math.round((Number(target.facilities||50)-40)/14)+1,1,5),academicLevel=clamp(Math.round((Number(target.academics||50)-45)/14)+1,1,5);state.facilities={training:level,recruiting:level,medical:Math.max(1,level-1),stadium:level,academics:academicLevel};
 const head=state.staff?.head||makeCoach("Head Coach",target.prestige);head.name=state.coachCareer.name||head.name;state.staff={head,oc:makeCoach("Offensive Coordinator",Math.round((target.prestige+target.recent)/2)-2),dc:makeCoach("Defensive Coordinator",Math.round((target.prestige+target.recent)/2)-2)};state.staffAssignments={head:{region:"National",position:"ALL"},oc:{region:target.region||"National",position:"OFFENSE"},dc:{region:target.region||"National",position:"DEFENSE"}};
 state.rivalId=findRival(target.id);state.roster=window.SDF_AI_ROSTERS?.takeProgramForUser?.(target.id)||genRoster();state.realDepthChart={};state.depthChart={};state.captains=[];state.traditions=programTraditions(target);state.pipelineLevels={};state.rivalryHistory={};state.stadium={name:`${target.city} Memorial Stadium`,capacity:35000+target.prestige*650,attendance:0,selloutStreak:0,atmosphere:clamp(Math.round((target.prestige+state.fanApproval)/2),35,98)};initializeExpansion();
 const programAllocation=Math.round((2400000+target.prestige*40000+target.recent*15000+target.facilities*10000+state.boosterSupport*8000)/10000)*10000,coordinatorPayroll=['oc','dc'].reduce((sum,key)=>sum+Math.round((240000+carouselCoachRating(state.staff[key])*9000)/10000)*10000,0);state.budget=Math.max(500000,programAllocation-o.salary-coordinatorPayroll);state.news??=[];state.news.push(`${state.coachCareer.name||'Coach'} accepted the ${target.name} job. The career history follows the coach; ${oldSchool.name} keeps its program history.`);o.status="ACCEPTED";o.resolved=true;state.jobOffers.filter(x=>x.type==="HEAD_JOB"&&x!==o).forEach(x=>{if(x.status==="PENDING")x.status="DECLINED"});state.offseasonTasks.staff=true;$("modal").classList.add("hidden");renderOffseasonHub();renderAll()
}
function declineJob(i){if(state.jobOffers[i]?.type==="HEAD_JOB"&&state.jobOffers[i].status==="PENDING"){state.jobOffers[i].status="DECLINED";state.jobOffers[i].resolved=true;renderCarouselModal()}}
function finishCarousel(){const unresolved=(state.jobOffers||[]).filter(o=>o.type==="STAFF_DEPARTURE"&&!["RETAINED","HIRED"].includes(o.status));if(unresolved.length){state.carouselMessage="Resolve every coordinator departure before finishing.";renderCarouselModal();return}(state.jobOffers||[]).filter(o=>o.type==="HEAD_JOB"&&o.status==="PENDING").forEach(o=>{o.status="DECLINED";o.resolved=true});state.offseasonTasks.staff=true;$("modal").classList.add("hidden");renderOffseasonHub();renderAll()}
window.retainCoordinator=retainCoordinator;window.letCoordinatorLeave=letCoordinatorLeave;window.hireCoordinator=hireCoordinator;window.promoteAnalyst=promoteAnalyst;window.acceptJob=acceptJob;window.declineJob=declineJob;window.finishCarousel=finishCarousel;
function runDraft(){
 const grads=state.roster.filter(p=>p.year>=4);const drafted=[];
 grads.forEach(p=>{const score=p.ovr+state.school.pro*.15+(p.stats.td||0)*.25+(p.stats.sacks||0)*1.5+(p.stats.int||0)*2+rand(-10,8);let round=null;if(score>=105)round=1;else if(score>=98)round=rand(2,3);else if(score>=91)round=rand(4,5);else if(score>=84)round=rand(6,7);if(round)drafted.push({player:p.name,pos:p.pos,round,pick:rand(1,32),year:state.year})});
 state.draftHistory.push(...drafted);state.achievementStats.totalDrafted+=drafted.length;state.achievementStats.firstRounders+=drafted.filter(d=>d.round===1).length;state.school.pro=clamp(state.school.pro+Math.min(3,drafted.length*.4),20,99);state.offseasonTasks.draft=true;
 $("offseasonResults").innerHTML=`<h3>Pro Draft Results</h3><div class="draft-grid">${drafted.map(d=>`<div class="draft-card"><h4>${d.player}</h4><span>Round ${d.round}, Pick ${d.pick}</span><span class="sub">${d.pos}</span></div>`).join("")||'<p class="muted">No players were drafted.</p>'}</div>`;renderOffseasonHub();renderAll()
}
function renderOffseasonHub(){
 if(!$("offseasonHub"))return;$("offseasonHub").classList.toggle("hidden",state.phase!=="PORTAL");
 document.querySelectorAll("[data-offseason-action]").forEach(b=>b.classList.toggle("done",!!state.offseasonTasks[b.dataset.offseasonAction]));
}
function handleOffseasonAction(action){if(action==="spring")runSpringPractice();if(action==="battles")runPositionBattles();if(action==="progression")runPlayerProgression();if(action==="staff")coordinatorCarousel();if(action==="draft")runDraft()}
function seasonAwardsExpanded(){
 const candidates=state.roster.map(p=>({p,score:(p.stats.yards||0)/100+(p.stats.td||0)*3+(p.stats.tackles||0)/8+(p.stats.sacks||0)*3+(p.stats.int||0)*4+p.ovr/5})).sort((a,b)=>b.score-a.score);
 const awards=[];if(candidates[0])awards.push({title:"National Player of the Year",player:candidates[0].p.name});const freshman=candidates.filter(x=>x.p.year===1)[0];if(freshman)awards.push({title:"Freshman of the Year",player:freshman.p.name});
 const allAmerican=candidates.slice(0,Math.min(4,candidates.length)).filter(x=>x.p.ovr>=82);allAmerican.forEach(x=>state.allAmericans.push({year:state.year,player:x.p.name,pos:x.p.pos}));state.achievementStats.allAmericans+=allAmerican.length;state.achievementStats.awardWinners+=awards.length;
 return{awards,allAmerican:allAmerican.map(x=>x.p)}
}
function checkAchievements(){
 ensureExpansionState();const custom={
 playoff:()=>!!state.postseasonData?.playoffField?.some(t=>t.id===state.school.id),
 gem:()=>state.commits.some(r=>r.evalTag==="Gem"),
 pipeline:()=>Object.values(state.pipelineLevels).some(p=>p.level==="Dominant"),
 sellout:()=>state.stadium.selloutStreak>=5,
 facilities:()=>Object.values(state.facilities).every(v=>v>=4),
 rankOne:()=>state.rankings[0]?.id===state.school.id,
 classOne:()=>state.history.some(h=>h.classRank===1),
 beatTop5:()=>!!state.achievementStats.beatTop5,
 firedCoach:()=>!!state.achievementStats.firedCoach,
 academics:()=>state.school.academics>=95,
 bigWin:()=>!!state.achievementStats.bigWin,
 comeback:()=>!!state.achievementStats.comeback,
 weatherWins:()=>Object.keys(state.achievementStats.weatherConditions||{}).length
 };
 ACHIEVEMENT_DEFS.forEach(a=>{let progress=0;if(a.stat==="careerWins")progress=state.coachCareer.careerWins;else if(a.stat)progress=state.achievementStats[a.stat]||0;else if(a.seasonStat==="wins")progress=Math.max(0,...state.history.map(h=>h.wins),state.record.w);else if(a.custom)progress=custom[a.custom]?.()||0;const unlocked=typeof progress==="boolean"?progress:progress>=a.goal;if(unlocked&&!state.achievements[a.id]){state.achievements[a.id]={year:state.year,date:Date.now()};state.news.push(`Achievement unlocked: ${a.name}.`)}});
}
function renderAchievements(){
 if(!$("achievementGrid"))return;checkAchievements();const filter=$("achievementFilter")?.value||"ALL",defs=ACHIEVEMENT_DEFS.filter(a=>filter==="ALL"||(filter==="UNLOCKED"&&state.achievements[a.id])||(filter==="LOCKED"&&!state.achievements[a.id]));
 $("achievementGrid").innerHTML=defs.map(a=>{const u=state.achievements[a.id],progress=a.stat==="careerWins"?state.coachCareer.careerWins:a.stat?(state.achievementStats[a.stat]||0):a.seasonStat?Math.max(0,...state.history.map(h=>h.wins),state.record.w):u?a.goal:0;return`<div class="achievement-card ${u?"unlocked":"locked"}"><div class="achievement-icon">${a.icon}</div><h4>${a.name}</h4><span class="sub">${a.desc}</span><div class="achievement-progress"><div style="width:${Math.min(100,(Number(progress)||0)/a.goal*100)}%"></div></div><span class="sub">${u?`Unlocked Year ${u.year}`:`${Math.min(a.goal,Number(progress)||0)} / ${a.goal}`}</span></div>`}).join("");
 const unlocked=Object.keys(state.achievements).length;$("achievementSummary").innerHTML=`<b>${unlocked}/${ACHIEVEMENT_DEFS.length}</b> unlocked`
}
function renderDynasty(){
 if(!$("coachCareerPanel"))return;
 $("coachCareerPanel").innerHTML=`<div class="metric-grid">${metric("Career Record",`${state.coachCareer.careerWins}-${state.coachCareer.careerLosses}`)}${metric("Reputation",state.coachCareer.reputation)}${metric("Salary","$"+Math.round(state.coachCareer.salary/100000)/10+"M")}${metric("Contract",state.coachCareer.contractYears+" years")}${metric("National Titles",state.achievementStats.nationalTitles)}${metric("Draft Picks",state.achievementStats.totalDrafted)}</div>`;
 const rh=state.rivalryHistory[state.rivalId]||{};$("rivalryHistory").innerHTML=`<div class="rivalry-card"><h4>${rh.trophy||"Rivalry Trophy"}</h4><b>${state.school.name} vs ${schoolName(state.rivalId)}</b><span class="sub">Record ${rh.wins||0}-${rh.losses||0} · Current streak ${rh.streak||0} · Best margin ${rh.bestMargin||0}</span></div>`;
 $("draftHistory").innerHTML=state.draftHistory.slice().reverse().map(d=>`<div class="draft-card"><h4>${d.player}</h4><b>Round ${d.round}, Pick ${d.pick}</b><span class="sub">${d.pos} · Year ${d.year}</span></div>`).join("")||'<p class="muted">No draft picks yet.</p>';renderAchievements()
}
function renderTraditionsAndStadium(){
 if(!$("traditionGrid"))return;$("traditionGrid").innerHTML=state.traditions.map(t=>`<div class="tradition-card"><h4>${t.name}</h4><span class="sub">${t.desc}</span></div>`).join("");
 const attendance=Math.round(state.stadium.attendance||state.stadium.capacity*(.55+state.fanApproval/220));$("stadiumPanel").innerHTML=`<h3>${state.stadium.name}</h3><div class="metric-grid">${metric("Capacity",state.stadium.capacity.toLocaleString())}${metric("Attendance",attendance.toLocaleString())}${metric("Atmosphere",state.stadium.atmosphere)}${metric("Sellout Streak",state.stadium.selloutStreak)}</div>`
}
function updateAttendance(win,rivalry){
 const demand=state.school.prestige*.35+state.fanApproval*.35+state.record.w*2+(rivalry?15:0);state.stadium.attendance=Math.min(state.stadium.capacity,Math.round(state.stadium.capacity*clamp(demand/100,.45,1)));if(state.stadium.attendance>=state.stadium.capacity*.98)state.stadium.selloutStreak++;else state.stadium.selloutStreak=0;state.lastGameRevenue=Math.min(180000,Math.round(state.stadium.attendance*2.25+Math.max(0,state.boosterSupport-50)*750));state.budget+=state.lastGameRevenue
}

["conferencePicker","regionPicker","prestigePicker"].forEach(id=>$(id).onchange=renderSchools);if($("teamSearch"))$("teamSearch").oninput=renderSchools;["positionFilter","starFilter","recruitRegionFilter","statusFilter","sortFilter"].forEach(id=>$(id).onchange=renderRecruiting);document.querySelectorAll(".nav-tab").forEach(b=>b.onclick=()=>showTab(b.dataset.tab));$("advanceWeekBtn").onclick=advanceWeek;$("recruitAdvanceBtn").onclick=advanceWeek;$("autoBoardBtn").onclick=autoBoard;$("autoDepthBtn").onclick=()=>{autoDepth();renderAll()};$("autoRedshirtBtn").onclick=autoRedshirt;$("simToEndBtn").onclick=simEnd;$("resolveSigningDayBtn").onclick=resolveSigningDay;$("offseasonBtn").onclick=offseason;$("finishOffseasonBtn").onclick=finishOffseason;$("saveBtn").onclick=save;$("resetBtn").onclick=()=>{if(confirm("Delete save and restart?")){localStorage.removeItem(`SaturdayArchitectCompleteV9_slot${state.saveSlot||"1"}`);location.reload()}};$("closeModal").onclick=()=>$("modal").classList.add("hidden");$("tutorialNext").onclick=tutorialNext;$("tutorialBack").onclick=tutorialBack;$("tutorialSkip").onclick=tutorialSkip;$("offenseScheme").onchange=e=>{state.offense=e.target.value;renderAll()};$("defenseScheme").onchange=e=>{state.defense=e.target.value;renderAll()};

const tutorialSteps=[
 ["Welcome to Saturday Dynasty Football","This guide covers the main dynasty loop. You can skip it at any time."],
 ["Evaluate Team Needs","The Overview and Roster tabs show immediate and future needs based on depth, seniors and starter quality."],
 ["Build a Recruiting Board","Add prospects, scout them, offer scholarships and assign a weekly recruiting plan."],
 ["Set Your Depth Chart","The strongest healthy players start automatically. Redshirts preserve eligibility for young backups."],
 ["Choose Your Identity","Offensive and defensive schemes affect recruiting fit, production and game simulation."],
 ["Advance the Week","Each week resolves recruiting plans, AI recruiting, program events, injuries, your game and the national universe."],
 ["Manage the Program","Use budget for facilities and staff. Job security, boosters and fan approval react to your decisions."],
 ["Finish the Season","Rankings, playoffs, signing day, awards, development and the portal complete the yearly cycle."]
];
function startTutorial(){if(state.tutorialDone)return;$("tutorialPanel").classList.remove("hidden");renderTutorial()}
function renderTutorial(){let s=tutorialSteps[state.tutorialStep];$("tutorialTitle").textContent=s[0];$("tutorialText").textContent=s[1];$("tutorialBack").disabled=state.tutorialStep===0;$("tutorialNext").textContent=state.tutorialStep===tutorialSteps.length-1?"Finish":"Next"}
function tutorialNext(){if(state.tutorialStep>=tutorialSteps.length-1){state.tutorialDone=true;$("tutorialPanel").classList.add("hidden")}else{state.tutorialStep++;renderTutorial()}}
function tutorialBack(){state.tutorialStep=Math.max(0,state.tutorialStep-1);renderTutorial()}
function tutorialSkip(){state.tutorialDone=true;$("tutorialPanel").classList.add("hidden")}


function mobileNavigate(target){
 showTab(target);
 $("mobileMoreMenu")?.classList.add("hidden");
 document.querySelectorAll("[data-mobile-target]").forEach(b=>b.classList.toggle("active",b.dataset.mobileTarget===target));
 window.scrollTo({top:0,behavior:"smooth"})
}
document.querySelectorAll("[data-mobile-target]").forEach(b=>b.onclick=()=>mobileNavigate(b.dataset.mobileTarget));
$("mobileMoreBtn").onclick=()=>$("mobileMoreMenu").classList.toggle("hidden");
$("mobileMoreClose").onclick=()=>$("mobileMoreMenu").classList.add("hidden");
$("mobileAdvance").onclick=advanceWeek;


$("openSchedulingBtn").onclick=customSchedulingModal;
$("playChampionshipBtn").onclick=playChampionshipWeek;
$("playPostseasonBtn").onclick=playPostseason;
document.querySelectorAll("[data-offseason-action]").forEach(b=>b.onclick=()=>handleOffseasonAction(b.dataset.offseasonAction));
$("achievementFilter").onchange=renderAchievements;$("statsCategory").onchange=renderStats;


$("exportSaveBtn").onclick=exportDynastySave;
$("importSaveInput").onchange=e=>{if(e.target.files[0])importDynastySave(e.target.files[0])};

renderSchools();
if(location.protocol==="http:"||location.protocol==="https:"){
 const link=document.createElement("link");link.rel="manifest";link.href="manifest.webmanifest";document.head.appendChild(link);
}

(()=>{
'use strict';
const RELEASE='Android V1.7.6 National Stats & Persistent AI Game History';
const SAVE_PREFIX='SaturdayDynastyFootballAndroidV1';
const LEGACY_PREFIXES=['SaturdayArchitectAndroidV1','SaturdayArchitectCompleteV9','SaturdayArchitectStatsV82','SaturdayArchitectDynastyV81','SaturdayArchitectRealignmentV74','SaturdayArchitectRecruitingV73','SaturdayArchitect128V72','SaturdayArchitectMobileV71'];
const ui={activeTab:'dashboard',recruitPage:1,recruitPageSize:window.innerWidth<=760?30:75,rosterQuery:'',recruitQuery:''};
let saveTimer=null,toastTimer=null,isHydrating=false,lastSaveAt=0,deletionInProgress=false;const deletedSlots=new Set();
const base={
 start:window.start,beginYear:window.beginYear,advanceWeek:window.advanceWeek,resolveSigningDay:window.resolveSigningDay,
 playChampionshipWeek:window.playChampionshipWeek,playPostseason:window.playPostseason,offseason:window.offseason,finishOffseason:window.finishOffseason,
 renderSchools:window.renderSchools,renderRecruiting:window.renderRecruiting,renderRoster:window.renderRoster,renderSchedule:window.renderSchedule,
 renderRankings:window.renderRankings,renderStats:window.renderStats,renderAll:window.renderAll,showTab:window.showTab,
 seasonAwards:window.seasonAwards,updateRecordBook:window.updateRecordBook,genSchedule:window.genSchedule,findRival:window.findRival,
 opponentProfile:window.opponentProfile,computeClassRankings:window.computeClassRankings,save:window.save,load:window.load
};
function hashInt(v){let h=2166136261;for(const ch of String(v)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function brandFor(s){return TEAM_BRANDING?.[s?.id]||{primary:'#2563eb',secondary:'#22d3ee',accent:'#fff',logo:'icon-192.png',abbr:'SDF'}}
function logoHtml(id,cls=''){let b=TEAM_BRANDING?.[id];return b?`<img class="${cls}" src="${b.logo}" alt="" loading="lazy">`:''}
function applyBrand(){if(!state.school)return;let b=brandFor(state.school);document.documentElement.style.setProperty('--team-primary',b.primary);document.documentElement.style.setProperty('--team-secondary',b.secondary);document.documentElement.style.setProperty('--team-accent',b.accent);['appTeamLogo','mobileTeamLogo','programLogo'].forEach(id=>{let el=$(id);if(el)el.src=b.logo});document.querySelector('meta[name="theme-color"]')?.setAttribute('content',b.primary)}


// New-dynasty setup is owned here instead of being scattered across the team screen.
// The existing hidden selectors remain only as compatibility inputs for the core startup.
const NEW_DYNASTY_ARCHETYPES={
 RECRUITER:{label:'Recruiter',description:'Win more recruiting battles and build stronger classes.',benefits:['Starts with Relationship Builder','Recruiting actions are 6% more effective','Natural path toward pipelines and scouting'],skill:'RECRUITER_1'},
 DEVELOPER:{label:'Player Developer',description:'Turn young players into dependable starters more quickly.',benefits:['Starts with Teacher','Young players receive +1 offseason development','Natural path toward progression and conditioning'],skill:'DEVELOPER_1'},
 STRATEGIST:{label:'Strategist',description:'Create stronger weekly preparation and matchup advantages.',benefits:['Starts with Prepared','Practice-focus effects are 35% stronger','Natural path toward scouting and late-game decisions'],skill:'TACTICIAN_1'},
 BUILDER:{label:'Program Builder',description:'Create a stable culture that players want to stay in.',benefits:['Starts with Culture Builder','Improves morale and reduces discipline problems','Natural path toward retention, boosters and job security'],skill:'CULTURE_1'}
};
const NEW_DYNASTY_PRESETS={
 CASUAL:{label:'Casual',description:'More forgiving recruiting and job security, faster growth, and fewer injuries or transfers.',legacyDifficulty:'CASUAL',settings:{upsetVariance:.82,scoring:1.02,injuries:.72,progression:1.16,transfers:.72,jobSecurity:.72,recruiting:.88,realignment:.80}},
 STANDARD:{label:'Standard',description:'Balanced recruiting, progression, injuries, transfers, scoring, and coaching pressure.',legacyDifficulty:'STANDARD',settings:{upsetVariance:1,scoring:1,injuries:1,progression:1,transfers:1,jobSecurity:1,recruiting:1,realignment:1}},
 CHALLENGING:{label:'Challenging',description:'Tougher recruiting, slower growth, more roster pressure, and stricter job security.',legacyDifficulty:'DYNASTY',settings:{upsetVariance:1.05,scoring:.98,injuries:1.08,progression:.94,transfers:1.12,jobSecurity:1.15,recruiting:1.12,realignment:.90}},
 REALISTIC:{label:'Realistic',description:'College-football volatility with realistic growth, injuries, transfers, scoring, and occasional upsets.',legacyDifficulty:'STANDARD',settings:{upsetVariance:1.12,scoring:.98,injuries:1.04,progression:.96,transfers:1.08,jobSecurity:1.08,recruiting:1.06,realignment:.85}},
 CUSTOM:{label:'Custom',description:'Tune every realism setting yourself.',legacyDifficulty:'STANDARD',settings:{upsetVariance:1,scoring:1,injuries:1,progression:1,transfers:1,jobSecurity:1,recruiting:1,realignment:1}}
};
const SETUP_SLIDERS=[
 ['recruiting','Recruiting difficulty',.80,1.30,.05,'Higher values strengthen AI recruiting and reduce your margin for error.'],
 ['upsetVariance','Upset / game-day variance',.70,1.35,.05,'Higher values create more week-to-week volatility and more possible upsets.'],
 ['scoring','Scoring environment',.85,1.15,.05,'Controls the overall scoring level without changing who is favored.'],
 ['progression','Progression speed',.75,1.30,.05,'Controls how quickly players improve during the offseason.'],
 ['injuries','Injury frequency',.50,1.50,.05,'Controls how often injuries occur.'],
 ['transfers','Transfer activity',.60,1.50,.05,'Controls how aggressively unhappy players enter the portal.'],
 ['jobSecurity','Coach-firing strictness',.60,1.50,.05,'Controls how strongly results affect job security.'],
 ['realignment','Conference realignment activity',.50,1.50,.05,'Controls how often qualifying programs receive conference invitations.']
];
function setupEsc(value){return String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}
function cloneSetupSettings(value){return JSON.parse(JSON.stringify(value||NEW_DYNASTY_PRESETS.STANDARD.settings))}
function selectedSetupStyle(){return document.querySelector('input[name="newCoachStyle"]:checked')?.value||'BUILDER'}
function selectedSetupPreset(){return document.querySelector('input[name="newDifficultyPreset"]:checked')?.value||'STANDARD'}
function setupSummary(){
 const pending=window.SDF_NEW_DYNASTY_PENDING;if(!pending)return;
 const school=schools.find(s=>Number(s.id)===Number(pending.teamId)),name=($('newCoachName')?.value||'Coach').trim()||'Coach',style=NEW_DYNASTY_ARCHETYPES[selectedSetupStyle()]||NEW_DYNASTY_ARCHETYPES.BUILDER,preset=NEW_DYNASTY_PRESETS[selectedSetupPreset()]||NEW_DYNASTY_PRESETS.STANDARD;
 pending.coachName=name;pending.archetype=selectedSetupStyle();pending.preset=selectedSetupPreset();
 const host=$('newDynastySummary');if(host)host.innerHTML=`<span class="eyebrow">CAREER SUMMARY</span><div class="new-dynasty-summary-grid"><div><small>COACH</small><b>${setupEsc(name)}</b></div><div><small>STYLE</small><b>${style.label}</b></div><div><small>TEAM</small><b>${setupEsc(school?.name||'Program')}</b></div><div><small>DIFFICULTY</small><b>${preset.label}</b></div><div><small>SAVE</small><b>Slot ${pending.slot}</b></div></div>`;
}
function renderCoachStyleExplanation(){
 const key=selectedSetupStyle(),def=NEW_DYNASTY_ARCHETYPES[key]||NEW_DYNASTY_ARCHETYPES.BUILDER,host=$('coachStyleExplanation');
 if(host)host.innerHTML=`<b>${def.label}</b><span>${def.description}</span><ul>${def.benefits.map(x=>`<li>${x}</li>`).join('')}</ul>`;
 setupSummary();
}
function renderDifficultyExplanation(){
 const pending=window.SDF_NEW_DYNASTY_PENDING;if(!pending)return;const key=selectedSetupPreset(),def=NEW_DYNASTY_PRESETS[key]||NEW_DYNASTY_PRESETS.STANDARD;
 if(key!=='CUSTOM')pending.settings=cloneSetupSettings(def.settings);pending.preset=key;pending.legacyDifficulty=def.legacyDifficulty;
 const host=$('difficultyExplanation');if(host)host.innerHTML=`<b>${def.label}</b><span>${def.description}</span>`;
 const details=$('customDifficultyDetails');if(details&&key==='CUSTOM')details.open=true;
 document.querySelectorAll('[data-setup-setting]').forEach(input=>{const value=Number(pending.settings[input.dataset.setupSetting]??1);input.value=String(value);const out=input.closest('label')?.querySelector('output');if(out)out.textContent=value.toFixed(2)});
 setupSummary();
}
function closeCoachCreation(){
 $('modal')?.classList.add('hidden');window.SDF_NEW_DYNASTY_PENDING=null;
}
function startCoachCareer(){
 const pending=window.SDF_NEW_DYNASTY_PENDING;if(!pending)return;const name=($('newCoachName')?.value||'').trim();
 if(!name){$('newCoachName')?.focus();toast('Enter a coach name.','error');return}
 pending.coachName=name.slice(0,28);pending.archetype=selectedSetupStyle();pending.preset=selectedSetupPreset();
 const preset=NEW_DYNASTY_PRESETS[pending.preset]||NEW_DYNASTY_PRESETS.STANDARD;pending.legacyDifficulty=preset.legacyDifficulty;
 $('saveSlotPicker').value=String(pending.slot);$('difficultyPicker').value=pending.legacyDifficulty;
 $('modal')?.classList.add('hidden');window.start(Number(pending.teamId));
}
function openCoachCreation(teamId){
 const school=schools.find(s=>Number(s.id)===Number(teamId));if(!school)return;const slot=String($('saveSlotPicker')?.value||'1'),summary=readSlotSummary(slot),branding=brandFor(school);
 window.SDF_NEW_DYNASTY_PENDING={teamId:Number(teamId),slot,coachName:'Coach',archetype:'BUILDER',preset:'STANDARD',legacyDifficulty:'STANDARD',settings:cloneSetupSettings(NEW_DYNASTY_PRESETS.STANDARD.settings)};
 $('modalBody').innerHTML=`<section class="new-dynasty-setup"><div class="new-dynasty-team-head"><img src="${branding.logo}" alt=""><div><span class="eyebrow">NEW DYNASTY · SLOT ${slot}</span><h2>Create Your Coach</h2><p>${setupEsc(school.name)} · ${setupEsc(school.conference)}${summary.empty?'':` · <strong>Will replace ${setupEsc(summary.name)}</strong>`}</p></div></div><label class="new-dynasty-name"><span>Coach name</span><input id="newCoachName" type="text" maxlength="28" value="Coach" autocomplete="name" placeholder="Enter coach name"></label><fieldset class="new-dynasty-fieldset"><legend>Coach style</legend><div class="new-dynasty-choice-grid coach-style-grid">${Object.entries(NEW_DYNASTY_ARCHETYPES).map(([key,def])=>`<label class="setup-choice"><input type="radio" name="newCoachStyle" value="${key}" ${key==='BUILDER'?'checked':''}><span><b>${def.label}</b><small>${def.description}</small></span></label>`).join('')}</div><div id="coachStyleExplanation" class="setup-explanation"></div></fieldset><fieldset class="new-dynasty-fieldset"><legend>Difficulty</legend><div class="new-dynasty-choice-grid difficulty-choice-grid">${Object.entries(NEW_DYNASTY_PRESETS).map(([key,def])=>`<label class="setup-choice"><input type="radio" name="newDifficultyPreset" value="${key}" ${key==='STANDARD'?'checked':''}><span><b>${def.label}</b><small>${def.description}</small></span></label>`).join('')}</div><div id="difficultyExplanation" class="setup-explanation"></div><details id="customDifficultyDetails" class="custom-difficulty-details"><summary>View detailed settings</summary><p class="muted">Changing a slider switches this dynasty to Custom difficulty.</p><div class="new-dynasty-slider-grid">${SETUP_SLIDERS.map(([key,label,min,max,step,help])=>`<label><span><b>${label}</b><small>${help}</small></span><input type="range" min="${min}" max="${max}" step="${step}" value="1" data-setup-setting="${key}"><output>1.00</output></label>`).join('')}</div></details></fieldset><div id="newDynastySummary" class="new-dynasty-summary"></div><div class="new-dynasty-actions"><button id="cancelCoachCreation" class="btn neutral" type="button">Back to Teams</button><button id="startCoachCareer" class="btn success" type="button">Start Coaching Career</button></div></section>`;
 $('modal').classList.remove('hidden');
 $('newCoachName').addEventListener('input',setupSummary);
 document.querySelectorAll('input[name="newCoachStyle"]').forEach(x=>x.addEventListener('change',renderCoachStyleExplanation));
 document.querySelectorAll('input[name="newDifficultyPreset"]').forEach(x=>x.addEventListener('change',renderDifficultyExplanation));
 document.querySelectorAll('[data-setup-setting]').forEach(input=>input.addEventListener('input',()=>{const pending=window.SDF_NEW_DYNASTY_PENDING;if(!pending)return;pending.settings[input.dataset.setupSetting]=Number(input.value);pending.preset='CUSTOM';pending.legacyDifficulty='STANDARD';const custom=document.querySelector('input[name="newDifficultyPreset"][value="CUSTOM"]');if(custom)custom.checked=true;const out=input.closest('label')?.querySelector('output');if(out)out.textContent=Number(input.value).toFixed(2);renderDifficultyExplanation()}));
 $('cancelCoachCreation').addEventListener('click',closeCoachCreation);$('startCoachCareer').addEventListener('click',startCoachCareer);
 renderCoachStyleExplanation();renderDifficultyExplanation();$('newCoachName').focus();$('newCoachName').select();
}
window.openCoachCreation=openCoachCreation;
window.SDF_NEW_DYNASTY_OPTIONS={archetypes:NEW_DYNASTY_ARCHETYPES,presets:NEW_DYNASTY_PRESETS,sliders:SETUP_SLIDERS};

const releaseStart=window.start;
window.start=function(id){
 const setup=window.SDF_NEW_DYNASTY_PENDING;
 let slot=String(setup?.slot||$('saveSlotPicker')?.value||'1'),existing=readSlotSummary(slot);
 if(!existing.empty){
  let name=existing.name||'the existing dynasty';
  if(!confirm(`Slot ${slot} already contains ${name}. Starting a new dynasty here will overwrite that save. Continue?`))return;
  if(!deleteSlotCompletely(slot)){toast(`Slot ${slot} could not be cleared. Please try again.`,'error');return}
 }
 // Starting a fresh dynasty is the one action allowed to reopen a slot that was
 // explicitly deleted. The old in-memory dynasty has already been detached.
 deletedSlots.delete(slot);deletionInProgress=false;
 if(setup){$('saveSlotPicker').value=slot;$('difficultyPicker').value=setup.legacyDifficulty||'STANDARD'}
 releaseStart(id);
 state.saveSlot=slot;
 if(setup&&state.school){
  state.difficulty=setup.legacyDifficulty||'STANDARD';
  state.realismSettings={preset:setup.preset||'STANDARD',...cloneSetupSettings(setup.settings)};
  state.coachCareer??={name:'Coach',salary:1500000,contractYears:4,buyout:500000,reputation:50,careerWins:0,careerLosses:0,jobs:[]};
  state.coachCareer.name=setup.coachName||'Coach';
  state.coachCareer.archetype=setup.archetype||'BUILDER';
  state.coachCareer.archetypeLabel=NEW_DYNASTY_ARCHETYPES[state.coachCareer.archetype]?.label||'Program Builder';
 }
 window.SDF_NEW_DYNASTY_PENDING=null;
 window.scrollTo({top:0,behavior:'auto'});
 saveNow('New dynasty created',false,true);
}

window.renderSchools=function(){let c=$('conferencePicker').value,r=$('regionPicker').value,p=$('prestigePicker').value,q=($('teamSearch')?.value||'').trim().toLowerCase(),filtered=schools.filter(s=>(c==='ALL'||s.conference===c)&&(r==='ALL'||s.region===r)&&(p==='ALL'||(p==='ELITE'&&s.prestige>=85)||(p==='POWER'&&s.prestige>=65&&s.prestige<85)||(p==='BUILD'&&s.prestige<65))&&(!q||`${s.name} ${s.city} ${s.state} ${s.conference}`.toLowerCase().includes(q)));$('visibleTeamCount').textContent=filtered.length;$('schoolGrid').innerHTML=filtered.map(s=>{let b=brandFor(s),tier=schoolTier(s);return`<article class="school-card" style="--card-primary:${b.primary};--card-secondary:${b.secondary}"><div class="tier-line"><span class="tier-badge ${tier.className}">${tier.label}</span><small class="muted">${s.conference}</small></div><div class="school-card-brand"><img class="school-card-logo" src="${b.logo}" alt="${s.name} original logo" loading="lazy"><div class="school-card-title"><h3>${s.name}</h3><div class="school-location">${s.city}, ${s.state}<span class="sub">${CONFERENCE_META[s.conference]?.level||'Independent'}</span></div></div></div><p class="tagline">${s.tag}</p>${rate('Prestige',s.prestige)}${rate('Facilities',s.facilities)}${rate('Recent Success',s.recent)}${rate('Pro Pipeline',s.pro)}<button class="btn primary full choose" data-id="${s.id}">Take Over Program</button></article>`}).join('');document.querySelectorAll('.choose').forEach(b=>b.onclick=()=>openCoachCreation(+b.dataset.id))};
function toast(message,type='success'){let el=$('toast');if(!el)return;el.textContent=message;el.className=`toast ${type}`;clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.add('hidden'),2400)}
function setSaveStatus(text,status='saved'){let el=$('autosaveStatus');if(!el)return;el.className=`autosave-status ${status}`;el.querySelector('span:last-child').textContent=text}
function deterministicInterest(r,s){let locationPenalty=distance(s,r)/180,pipeline=s.pipelines?.includes(r.home)?13:0,jitter=(hashInt(`${r.id}-${s.id}`)%28)-12;return clamp(Math.round(s.prestige*.31+s.recent*.15+s.pro*.13+pipeline-locationPenalty+jitter-(r.stars-3)*7),4,82)}
function compactState(){
 let copy=JSON.parse(JSON.stringify(state));copy._release={version:1,savedAt:Date.now(),name:RELEASE};copy.news=(copy.news||[]).slice(-160);copy.nationalStats=[];copy.classRankings=[];copy.nationalGameResults=(copy.nationalGameResults||[]).filter(x=>Number(x.year)===Number(copy.year)).slice(-950);copy.nationalWorldWeeks=(copy.nationalWorldWeeks||[]).filter(k=>String(k).startsWith(`${copy.year}-`));delete copy.teamSeasonStats;delete copy._v175StatsReady;
 copy.recruitingNeedsRecalcAll=true;
 copy.recruits=(copy.recruits||[]).map(r=>{
  let out={...r};
  delete out.interest;
  if((r.lockedOut||[]).length)out.shortlist=(schools||[]).filter(s=>!r.lockedOut.includes(s.id)).map(s=>s.id);
  if(Array.isArray(out.motivations)){out.motivationData=out.motivations.map(m=>[m.key,m.weight]);delete out.motivations}
  if(out.dealbreaker){out.dealbreakerData=[out.dealbreaker.key,out.dealbreaker.threshold];delete out.dealbreaker}
  if(out.recruitInfluence){out.influenceData=Object.entries(out.recruitInfluence).filter(([,v])=>Number(v)>0).map(([k,v])=>[Number(k),Math.round(Number(v)*10)/10]);delete out.recruitInfluence;if(!out.influenceData.length)delete out.influenceData}
  if(out.offerBySchool){out.aiOfferIds=Object.entries(out.offerBySchool).filter(([,v])=>!!v).map(([k])=>Number(k));delete out.offerBySchool;if(!out.aiOfferIds.length)delete out.aiOfferIds}
  if(out.visitBoostBySchool){out.visitData=Object.entries(out.visitBoostBySchool).filter(([,v])=>Number(v)>0).map(([k,v])=>[Number(k),Math.round(Number(v)*10)/10]);delete out.visitBoostBySchool;if(!out.visitData.length)delete out.visitData}
  if(out.promiseBoostBySchool){out.promiseData=Object.entries(out.promiseBoostBySchool).filter(([,v])=>Number(v)>0).map(([k,v])=>[Number(k),Math.round(Number(v)*10)/10]);delete out.promiseBoostBySchool;if(!out.promiseData.length)delete out.promiseData}
  if(out.aiVisitWeeks){out.aiVisitData=Object.entries(out.aiVisitWeeks).map(([k,v])=>[Number(k),v]);delete out.aiVisitWeeks;if(!out.aiVisitData.length)delete out.aiVisitData}
  if(out.actionHistory){let key=`${copy.year}-${copy.week}`,current=out.actionHistory[key];out.actionHistory=current?{[key]:current}:undefined;if(!out.actionHistory)delete out.actionHistory}
  delete out.interestTrend;delete out.lastInterestSnapshot;delete out.aiPursuerIds;delete out.lockedOut;delete out.requirements;delete out._modernDealbreaker;delete out.recruitingNeedsRecalc;delete out.listedOvr;delete out.listedPot;
  if(!out.entryWeek||out.entryWeek===1)delete out.entryWeek;if(!out.committedWeek)delete out.committedWeek;if(!out.attrs)delete out.attrs;if(!out.pitchHistory||!Object.keys(out.pitchHistory).length)delete out.pitchHistory;if(!out.promise)delete out.promise;if(!out.committedTo)delete out.committedTo;if(out.stage==='Open')delete out.stage;if(out.weeklyPlan==='NONE')delete out.weeklyPlan;if(!out.scouted)delete out.scoutConfidence;
  return out
 });
 copy.roster=(copy.roster||[]).map(p=>({...p,gameLog:(p.gameLog||[]).slice(-28)}));if(copy.aiRosters){for(const [teamId,roster] of Object.entries(copy.aiRosters)){copy.aiRosters[teamId]=(roster||[]).map(p=>{const out={id:p.id,name:p.name,pos:p.pos,arch:p.arch,hometown:p.hometown,year:Number(p.year||1),ovr:Number(p.ovr||60),pot:Number(p.pot||p.ovr||60),dev:p.dev||'Normal',morale:Number(p.morale||75)};if(p.redshirt)out.redshirt=true;if(p.redshirtUsed)out.redshirtUsed=true;if(p.walkOn)out.walkOn=true;if(p.signedYear)out.signedYear=p.signedYear;if(Number(p.stars)>0)out.stars=Number(p.stars);if(Number(p.recruitRank)>0)out.recruitRank=Number(p.recruitRank);if((p.statHistory||[]).length)out.statHistory=(p.statHistory||[]).slice(-4);return out})}}return copy
}
function hydrateState(data){
 state=data;ensureExpansionState?.();ensureV9State?.();state.saveSlot=state.saveSlot||$('saveSlotPicker')?.value||'1';state.news=state.news||[];state.scoutingReports=state.scoutingReports||{};
 (state.recruits||[]).forEach(r=>{r.interest=r.interest||{};schools.forEach(s=>{if(r.interest[s.id]==null)r.interest[s.id]=deterministicInterest(r,s)});if(r.shortlist){let set=new Set(r.shortlist);r.lockedOut=schools.filter(s=>!set.has(s.id)).map(s=>s.id);delete r.shortlist}else r.lockedOut=r.lockedOut||[]});
 (state.roster||[]).forEach(p=>ensurePlayerStats?.(p));window.migrateDynastyCore?.();window.SDF_V165?.migrateState?.();window.SDF_AI_ROSTERS?.ensureAll?.();initializeDepthChartSafe();applyBrand();window.SDF_V175?.rehydrate?.();
}
function saveKey(slot=state.saveSlot||'1'){return `${SAVE_PREFIX}_slot${slot}`}
function nativeReadSlot(slot,backup=false){try{const bridge=window.SDFNative,method=backup?'readSlotBackup':'readSlot';if(!bridge||typeof bridge[method]!=='function')return null;return bridge[method](String(slot))||null}catch(error){console.warn('Native save read unavailable',error);return null}}
function nativeWriteSlot(slot,json){try{const bridge=window.SDFNative;if(!bridge||typeof bridge.writeSlot!=='function')return null;return !!bridge.writeSlot(String(slot),json)}catch(error){console.error('Native save write failed',error);return false}}
function nativeDeleteSlot(slot){try{const bridge=window.SDFNative;if(!bridge||typeof bridge.deleteSlot!=='function')return null;return !!bridge.deleteSlot(String(slot))}catch(error){console.error('Native save delete failed',error);return false}}
function saveNow(reason='Autosaved',manual=false,backup=false){
 if(!state.school||isHydrating||deletionInProgress||deletedSlots.has(String(state.saveSlot||'1')))return false;
 clearTimeout(saveTimer);setSaveStatus('Saving…','saving');
 try{
  let key=saveKey(),payload=compactState();
  // Keep saves well below Android WebView localStorage limits by trimming only
  // derived/rebuildable history when a dynasty has become very large.
  let json=JSON.stringify(payload);
  if(json.length>4_200_000){
   payload.news=(payload.news||[]).slice(-60);payload.conferenceScheduleResults=(payload.conferenceScheduleResults||[]).slice(-160);payload.scoutingReports={};
   payload.roster=(payload.roster||[]).map(p=>({...p,gameLog:(p.gameLog||[]).slice(-10),statHistory:(p.statHistory||[]).slice(-4),progressionHistory:(p.progressionHistory||[]).slice(-6)}));
   if(payload.aiRosters)for(const roster of Object.values(payload.aiRosters))for(const p of roster||[])if(p.statHistory)p.statHistory=p.statHistory.slice(-2);
   if(payload.liveGame?.feed)payload.liveGame.feed=payload.liveGame.feed.slice(-35);
   json=JSON.stringify(payload);
  }
  const slot=String(state.saveSlot||'1'),nativeResult=nativeWriteSlot(slot,json);let verified;
  if(nativeResult!==null){
   if(!nativeResult)throw new Error('Android save file could not be written');
   verified=nativeReadSlot(slot,false);if(!verified||verified.length!==json.length)throw new Error('Android save verification failed');JSON.parse(verified);
   // Once the verified native file exists, remove oversized WebView copies that
   // previously caused quota errors and made deleted saves reappear.
   try{localStorage.removeItem(key);localStorage.removeItem(`${key}_backup`)}catch{}
  }else{
   if(backup){let previous=localStorage.getItem(key);if(previous&&previous.length<1200000)try{localStorage.setItem(`${key}_backup`,previous)}catch{}}
   localStorage.setItem(key,json);
   verified=localStorage.getItem(key);if(!verified||verified.length!==json.length)throw new Error('Save verification failed');JSON.parse(verified);
  }
  lastSaveAt=Date.now();setSaveStatus(`Saved ${new Date(lastSaveAt).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}`,'saved');if(manual)toast('Dynasty saved and verified.');return true
 }catch(err){console.error('Autosave failed',err);setSaveStatus('Save failed','error');if(manual)toast(`Save failed: ${err?.message||'storage error'}. Export a backup from Dynasty.`,'error');return false}
}
function scheduleSave(reason='Autosaved',delay=550){if(!state.school||isHydrating)return;clearTimeout(saveTimer);setSaveStatus('Saving…','saving');saveTimer=setTimeout(()=>saveNow(reason,false,false),delay)}

function saveCandidates(slot){
 const nativeRaw=nativeReadSlot(slot,false),items=[];
 if(nativeRaw)items.push({prefix:SAVE_PREFIX,current:true,native:true,key:`native_slot${slot}`,raw:nativeRaw});
 if(!nativeRaw){const currentRaw=localStorage.getItem(`${SAVE_PREFIX}_slot${slot}`);if(currentRaw)items.push({prefix:SAVE_PREFIX,current:true,native:false,key:`${SAVE_PREFIX}_slot${slot}`,raw:currentRaw})}
 for(const prefix of LEGACY_PREFIXES){const raw=localStorage.getItem(`${prefix}_slot${slot}`);if(raw)items.push({prefix,current:false,native:false,key:`${prefix}_slot${slot}`,raw})}
 return items;
}
function readSlotSummary(slot){
 let item=saveCandidates(slot)[0];
 if(!item)return{slot,empty:true};
 try{
  let data=JSON.parse(item.raw),school=data.school||{},releaseData=data._release||{};
  return{
   slot,empty:false,current:item.current,schoolId:school.id,name:school.name||'Unknown Program',
   conference:school.conference||'',year:data.year||1,week:data.week||1,phase:data.phase||'REGULAR',
   wins:data.record?.w||0,losses:data.record?.l||0,savedAt:releaseData.savedAt||null
  }
 }catch{
  return{slot,empty:false,corrupt:true,name:'Unreadable save'}
 }
}
function selectSaveSlot(slot){
 $('saveSlotPicker').value=String(slot);
 renderSaveManager();
}
window.selectSaveSlot=selectSaveSlot;
function renderSaveManager(){
 let host=$('saveSlotCards');if(!host)return;
 let selected=String($('saveSlotPicker')?.value||'1'),summaries=[1,2,3].map(readSlotSummary);
 host.innerHTML=summaries.map(s=>{
  let chosen=String(s.slot)===selected;
  if(s.empty)return`<button type="button" class="save-slot-card empty ${chosen?'selected':''}" onclick="selectSaveSlot(${s.slot})"><span class="eyebrow">SLOT ${s.slot}</span><h3>Empty Slot</h3><span class="sub">Choose a team below to start a new dynasty here.</span></button>`;
  if(s.corrupt)return`<button type="button" class="save-slot-card ${chosen?'selected':''}" onclick="selectSaveSlot(${s.slot})"><span class="eyebrow">SLOT ${s.slot}</span><h3>Save needs attention</h3><span class="sub">Delete this slot or try its recovery backup.</span></button>`;
  let b=TEAM_BRANDING?.[Number(s.schoolId)],saved=s.savedAt?new Date(s.savedAt).toLocaleString():'Legacy save';
  return`<button type="button" class="save-slot-card ${chosen?'selected':''}" onclick="selectSaveSlot(${s.slot})"><span class="eyebrow">SLOT ${s.slot}${s.current?'':' · LEGACY'}</span><div class="slot-school">${b?`<img class="slot-logo" src="${b.logo}" alt="">`:''}<div><h3>${s.name}</h3><span class="sub">${s.conference}</span></div></div><b>Year ${s.year} · ${s.phase==='REGULAR'?'Week '+s.week:s.phase}</b><span class="sub">${s.wins}-${s.losses} · ${saved}</span></button>`
 }).join('');
 let selectedInfo=summaries.find(x=>String(x.slot)===selected);
 $('loadSelectedSaveBtn').disabled=!!selectedInfo?.empty;
 $('deleteSelectedSaveBtn').disabled=!!selectedInfo?.empty;
 $('saveSlotMessage').textContent=selectedInfo?.empty
  ?`Slot ${selected} is empty. Select a team below to begin.`
  :`Slot ${selected} contains ${selectedInfo?.name||'a dynasty'}.`;
}
function deleteSlotCompletely(slot){
 slot=String(slot);deletionInProgress=true;deletedSlots.add(slot);clearTimeout(saveTimer);saveTimer=null;
 try{
  // Clear the active school before removing storage so pagehide/visibility autosave
  // handlers cannot immediately recreate the deleted dynasty during reload.
  if(String(state.saveSlot||'1')===slot)state.school=null;
  const nativeResult=nativeDeleteSlot(slot);if(nativeResult===false)throw new Error('Android save file could not be deleted');
  let prefixes=[SAVE_PREFIX,...LEGACY_PREFIXES];
  prefixes.forEach(prefix=>{
   localStorage.removeItem(`${prefix}_slot${slot}`);
   localStorage.removeItem(`${prefix}_slot${slot}_backup`);
  });
  const remaining=saveCandidates(slot);if(remaining.length){console.error('Save deletion verification failed',remaining);return false}
  return true;
 }catch(error){console.error('Save deletion failed',error);return false}
 finally{deletionInProgress=false}
}
function showDynastyPicker(){
 $('schoolScreen').classList.remove('hidden');
 $('gameScreen').classList.add('hidden');
 $('mobileBottomNav')?.classList.add('hidden');
 $('mobileStatus')?.classList.add('hidden');
 window.scrollTo({top:0,behavior:'auto'});
 renderSaveManager();
 window.renderSchools();
}

function loadReleaseSave(requestedSlot){
 let slot=String(requestedSlot||$('saveSlotPicker')?.value||'1');$('saveSlotPicker').value=slot;let raw=nativeReadSlot(slot,false),source=raw?'native':'current';
 if(!raw)raw=localStorage.getItem(`${SAVE_PREFIX}_slot${slot}`);
 if(!raw){for(const prefix of LEGACY_PREFIXES){raw=localStorage.getItem(`${prefix}_slot${slot}`);if(raw){source='legacy';break}}}
 if(!raw){$('saveSlotMessage').textContent=`Slot ${slot} is empty.`;return false}
 deletedSlots.delete(slot);deletionInProgress=false;
 try{isHydrating=true;hydrateState(JSON.parse(raw));state.saveSlot=slot;$('schoolScreen').classList.add('hidden');$('gameScreen').classList.remove('hidden');$('mobileBottomNav')?.classList.remove('hidden');$('mobileStatus')?.classList.remove('hidden');ui.activeTab='dashboard';window.renderAll();if(source==='legacy'){isHydrating=false;saveNow('Migrated',false,false);toast('Existing dynasty upgraded to Android V1.')}return true}catch(err){console.error(err);let backup=nativeReadSlot(slot,true)||localStorage.getItem(`${SAVE_PREFIX}_slot${slot}_backup`);if(backup)try{hydrateState(JSON.parse(backup));toast('Recovered the previous autosave.');return true}catch{}setSaveStatus('Save could not load','error');return false}finally{isHydrating=false}
}
window.save=()=>saveNow('Manual save',true,true);window.load=()=>loadReleaseSave();

const rivalryIds={100:2,2:100,104:212,212:104,103:106,106:103,110:7,7:110,114:6,6:114,108:215,215:108,107:109,109:107,201:206,206:201};
window.findRival=function(id){return rivalryIds[Number(id)]||base.findRival(id)};
function shuffle(a){return a.slice().sort(()=>Math.random()-.5)}
window.genSchedule=function(){
 let rival=schools.find(s=>s.id===state.rivalId),conference=schools.filter(s=>s.id!==state.school.id&&s.conference===state.school.conference&&s.id!==state.rivalId),confTarget=state.school.conference==='Independents'?0:Math.min(8,conference.length+(rival?.conference===state.school.conference?1:0));let conf=shuffle(conference).slice(0,Math.max(0,confTarget-(rival?.conference===state.school.conference?1:0)));
 let used=new Set([state.school.id,state.rivalId,...conf.map(s=>s.id)]),non=shuffle(schools.filter(s=>!used.has(s.id))).sort((a,b)=>{let ar=a.region===state.school.region?0:1,br=b.region===state.school.region?0:1;return ar-br||Math.abs(a.prestige-state.school.prestige)-Math.abs(b.prestige-state.school.prestige)}).slice(0,11-conf.length);
 let opponents=shuffle([...conf,...non]).slice(0,11);opponents.push(rival||choice(schools.filter(s=>s.id!==state.school.id)));return opponents.map((o,i)=>{let g={week:i+1,opponent:o.name,oppId:o.id,oppPower:Math.round((o.prestige+o.recent)/2),home:i===11?state.year%2===1:Math.random()>.47,result:null,score:null,conference:o.conference===state.school.conference,rivalry:o.id===state.rivalId};g.weather=window.weatherForGame(g);return g})
};
window.weatherForGame=function(g){let opponent=schools.find(s=>s.id===g.oppId),site=g.home?state.school:opponent||state.school,week=g.week||state.week;if(['MI','OH','WI','MN','PA','NY','MA','NE','CO'].includes(site.state)&&week>=10)return ['Cold','Heavy Wind','Snow'][hashInt(`${state.year}-${g.oppId}-${week}`)%3];if(['FL','GA','AL','TX','LA','MS','AZ'].includes(site.state)&&week<=4)return ['Clear','Humid','Extreme Heat'][hashInt(`${state.year}-${g.oppId}`)%3];return ['Clear','Clear','Cloudy','Rain','Wind'][hashInt(`${state.year}-${g.oppId}-${week}`)%5]};
const oldBegin=window.beginYear;window.beginYear=function(){state.depthChart={};state.scoutingReports={};state.nationalStats=[];state.classRankings=[];oldBegin();initializeDepthChartSafe();scheduleSave('New season')};
function initializeDepthChartSafe(){if(!state.roster)return;state.depthChart=state.depthChart||{};POSITIONS.forEach(pos=>{let valid=state.roster.filter(p=>p.pos===pos&&!p.redshirt),existing=(state.depthChart[pos]?.slots||[]).filter(slot=>valid.some(p=>p.id===slot.playerId));let used=new Set(existing.map(s=>s.playerId));valid.sort((a,b)=>b.ovr-a.ovr).forEach(p=>{if(existing.length<3&&!used.has(p.id)){existing.push({playerId:p.id,snapShare:existing.length===0?70:existing.length===1?25:5});used.add(p.id)}});state.depthChart[pos]={slots:existing.slice(0,3)}});applyDepthChart?.()}
const oldStart=window.start;window.start=function(id){oldStart(id);applyBrand();saveNow('Dynasty created',false,false)};
const originalDashboard=window.renderDashboard;window.renderDashboard=function(){originalDashboard();let g=currentOpponent(),opp=g&&schools.find(s=>s.id===g.oppId);$('nextGameCard').innerHTML=g?`${logoHtml(g.oppId,'')}<div><small class="eyebrow">NEXT GAME · WEEK ${g.week}</small><strong>${g.home?'vs':'at'} ${g.opponent}</strong><span class="sub">${g.conference?'Conference · ':''}${g.weather||'Clear'} · Opponent power ${g.oppPower}</span></div><div class="spacer"></div><button class="btn neutral" onclick="showTab('gameplan')">Prepare</button>`:'<span class="muted">Season complete.</span>'};


window.opponentProfile=function(g){if(!g)return null;state.scoutingReports=state.scoutingReports||{};let key=`${state.year}-${g.week}-${g.oppId}`;if(!state.scoutingReports[key]){let s=schools.find(x=>x.id===g.oppId),power=g.oppPower||70,h=hashInt(key);let pick=(arr,n)=>arr[(h>>n)%arr.length];state.scoutingReports[key]={school:s,offense:clamp(power+((h%9)-4),45,99),defense:clamp(power+(((h>>4)%9)-4),45,99),tendency:pick(['Pass Heavy','Balanced','Run Heavy','Tempo','Ball Control'],2),front:pick(['4-3','3-4','4-2-5','3-3-5'],5),weakness:pick(['Pass protection','Run defense','Secondary depth','Turnover margin','Red-zone offense','Special teams'],8),star:pick(['Quarterback','Running back','Edge rusher','Cornerback','Wide receiver'],11),injuries:h%4,form:pick(['Hot','Steady','Inconsistent','Slumping'],14)}}return state.scoutingReports[key]};
window.computeClassRankings=function(){const bySchool=new Map();for(const r of state.recruits||[]){const id=Number(r.committedTo);if(!id)continue;if(!bySchool.has(id))bySchool.set(id,[]);bySchool.get(id).push(r)}state.classRankings=schools.map(s=>{const commits=bySchool.get(Number(s.id))||[],five=commits.filter(r=>Number(r.stars)===5).length,four=commits.filter(r=>Number(r.stars)===4).length,avgRating=commits.length?Math.round(avg(commits.map(r=>Number(r.trueOvr||r.ovr||0)))):0,score=commits.length?commits.length*2+five*18+four*8+avgRating*.8:0;return{id:s.id,name:s.name,commits:commits.length,five,four,avgRating,score}}).sort((a,b)=>b.score-a.score||b.five-a.five||b.four-a.four||b.commits-a.commits||a.name.localeCompare(b.name)).map((x,i)=>({...x,rank:i+1}))};
function filteredRecruits(){let n=needs(),q=ui.recruitQuery.trim().toLowerCase(),a=state.recruits.filter(r=>{let st=$('statusFilter').value;return(!q||`${r.name} ${r.city} ${r.home} ${r.pos}`.toLowerCase().includes(q))&&($('positionFilter').value==='ALL'||r.pos===$('positionFilter').value)&&($('starFilter').value==='ALL'||r.stars===+$('starFilter').value)&&($('recruitRegionFilter').value==='ALL'||r.region===$('recruitRegionFilter').value)&&(st==='AVAILABLE'?!r.committedTo:st==='BOARD'?r.onBoard&&!r.committedTo:st==='OFFERED'?r.offered&&!r.committedTo:!!r.committedTo)});let sort=$('sortFilter').value;if(sort==='INTEREST')a.sort((x,y)=>y.interest[state.school.id]-x.interest[state.school.id]);if(sort==='NEED')a.sort((x,y)=>n[y.pos].sev-n[x.pos].sev);if(sort==='DISTANCE')a.sort((x,y)=>distance(state.school,x)-distance(state.school,y));if(sort==='FIT')a.sort((x,y)=>fit(y,state.school)-fit(x,state.school));if(sort==='RANK')a.sort((x,y)=>x.rank-y.rank);return a}
window.renderRecruiting=function(){
 return window.SDF_RECRUITING_V2?.renderRecruitingV2?.()
};

window.changeRecruitPage=function(delta){ui.recruitPage+=delta;window.renderRecruiting();window.scrollTo({top:$('recruitPager').offsetTop-120,behavior:'smooth'})};

window.renderRoster=function(){let n=needs(),q=ui.rosterQuery.trim().toLowerCase(),players=state.roster.slice().sort((a,b)=>POSITIONS.indexOf(a.pos)-POSITIONS.indexOf(b.pos)||b.ovr-a.ovr).filter(p=>!q||`${p.name} ${p.pos} ${p.hometown}`.toLowerCase().includes(q));$('depthChart').innerHTML=POSITIONS.map(p=>{let a=state.roster.filter(x=>x.pos===p).sort((x,y)=>y.starter-x.starter||y.ovr-x.ovr).slice(0,Math.max(STARTERS[p]+3,4));return `<div class="depth-card"><strong>${p} · ${n[p].label}</strong>${a.map((x,i)=>`<div class="depth-line"><span>${i+1}</span><button class="link-button" onclick="openPlayerProfile('${x.id}')">${x.name}<small class="sub">${x.arch} · Year ${x.year}${x.starter?' · Starter':''}${x.redshirt?' · RS':''}${x.injury?` · ${x.injury.type}`:''}</small></button><b>${x.ovr}</b></div>`).join('')}</div>`}).join('');$('rosterSummary').innerHTML=metric('Players',state.roster.length)+metric('Average OVR',Math.round(avg(state.roster.map(p=>p.ovr))))+metric('Seniors',state.roster.filter(p=>p.year===4).length)+metric('Redshirts',state.roster.filter(p=>p.redshirt).length)+metric('Injured',state.roster.filter(p=>p.injury).length)+metric('Portal Risk',state.roster.filter(p=>!p.starter&&p.morale<62).length);$('rosterTable').innerHTML=players.map(p=>`<tr><td><button class="link-button" onclick="openPlayerProfile('${p.id}')">${p.name}</button><span class="sub">${playerStatLine(p)}</span></td><td>${p.pos}</td><td>${p.arch}</td><td>${p.hometown}</td><td>${p.year}</td><td>${p.ovr}</td><td>${p.pot}</td><td>${p.dev}</td><td>${p.morale}</td><td>${p.injury?p.injury.type:p.redshirt?'Redshirt':p.starter?'Starter':'Backup'}</td><td>${!p.starter&&p.morale<62?'High':!p.starter&&p.morale<72?'Medium':'Low'}</td></tr>`).join('');$('rosterCardList').innerHTML=players.map(p=>`<article class="mobile-data-card"><div class="mobile-data-head"><div><h3>${p.name}</h3><span class="sub">${p.pos} · ${p.arch} · Year ${p.year}</span></div><b>${p.ovr}</b></div><div class="mobile-data-grid"><div><small>POT</small><b>${p.pot}</b></div><div><small>MORALE</small><b>${p.morale}</b></div><div><small>STATUS</small><b>${p.starter?'Starter':p.redshirt?'RS':'Backup'}</b></div></div><span class="sub">${playerStatLine(p)}</span><button class="btn primary full" onclick="openPlayerProfile('${p.id}')">Player Profile</button></article>`).join('')};

window.renderStandings=function(){if($('conferenceStandingsTitle'))$('conferenceStandingsTitle').textContent=`${state.school.conference} Standings`;let entries=state.standings.slice().sort((a,b)=>{let ac=state.conferenceRecords[a.id]||{w:a.w||0,l:a.l||0},bc=state.conferenceRecords[b.id]||{w:b.w||0,l:b.l||0};return bc.w-ac.w||ac.l-bc.l||(b.w||0)-(a.w||0)||(a.l||0)-(b.l||0)});$('standings').innerHTML=entries.map((t,i)=>`<div class="standing-card"><div class="team-mini">${logoHtml(t.id,'')}<div><h4>${i+1}. ${t.name}</h4><span class="sub">Conference ${(state.conferenceRecords[t.id]?.w||0)}-${(state.conferenceRecords[t.id]?.l||0)}</span></div></div><b>${t.w}-${t.l}</b></div>`).join('')};
window.renderSchedule=function(){$('schedule').innerHTML=state.schedule.map(g=>`<div class="schedule-row"><b>Wk ${g.week}</b><span class="team-mini ${g.rivalry?'rivalry':''}">${logoHtml(g.oppId,'')}<div><b>${g.home?'vs':'at'} ${g.opponent}</b><small class="sub">${g.conference?'Conference · ':''}${g.weather||'TBD'}${g.rivalry?' · Rivalry':''}</small></div></span><b class="${g.result==='W'?'win':g.result==='L'?'loss':''}">${g.result||'—'} ${g.score||''}</b><span class="extra muted">Power ${g.oppPower}</span></div>`).join('');if(state.lastGameRecap){let r=state.lastGameRecap;$('gameRecapPanel').classList.remove('hidden');$('gameRecapPanel').innerHTML=`<span class="eyebrow">LATEST GAME</span><h3>${r.headline}</h3><div class="recap-score"><span>${state.school.name}</span><strong>${r.us}-${r.them}</strong><span>${r.opponent}</span></div>${r.rivalry?'<p class="rivalry">Rivalry game</p>':''}<div class="commit-grid">${r.stars.map(s=>`<div class="commit-card">${s}</div>`).join('')}</div><div class="box-score-grid">${Object.entries(r.boxScore||{}).map(([k,v])=>`<div class="box-stat"><small>${k.replace(/([A-Z])/g,' $1')}</small><b>${v}</b></div>`).join('')}</div><div class="drive-list">${(r.drives||[]).slice(0,10).map(d=>`<div class="drive">${d}</div>`).join('')}</div>`}else $('gameRecapPanel').classList.add('hidden')};
window.renderRankings=function(){if(!$('rankingGrid'))return;updateRankings();$('rankingGrid').innerHTML=state.rankings.slice(0,25).map(t=>`<div class="ranking-card"><div class="rank">${t.rank}</div><div class="team-mini">${logoHtml(t.id,'')}<div><b>${t.name}</b><span class="sub">${t.conference}</span></div></div><strong>${t.record.w}-${t.record.l}</strong></div>`).join('');$('playoffBracket').innerHTML=state.playoff.map((t,i)=>`<div class="playoff-card"><span class="eyebrow">SEED ${i+1}</span><div class="team-mini">${logoHtml(t.id,'')}<div><h3>${t.name}</h3><span class="sub">${t.record.w}-${t.record.l} · ${t.conference}</span></div></div></div>`).join('')};

window.seasonAwards=function(){let list=[],qb=state.roster.filter(p=>p.pos==='QB').sort((a,b)=>(b.seasonStats?.passYds||0)-(a.seasonStats?.passYds||0))[0],rb=state.roster.filter(p=>p.pos==='RB').sort((a,b)=>(b.seasonStats?.rushYds||0)-(a.seasonStats?.rushYds||0))[0],def=state.roster.filter(p=>['EDGE','DL','LB','CB','S'].includes(p.pos)).sort((a,b)=>((b.seasonStats?.tackles||0)+(b.seasonStats?.sacks||0)*4+(b.seasonStats?.defINT||0)*5)-((a.seasonStats?.tackles||0)+(a.seasonStats?.sacks||0)*4+(a.seasonStats?.defINT||0)*5))[0];if(qb)list.push({title:'Offensive Player of the Year',player:qb.name});if(def)list.push({title:'Defensive Player of the Year',player:def.name});if(rb&&(rb.seasonStats?.rushYds||0)>900)list.push({title:'All-Conference Running Back',player:rb.name});return list};
window.updateRecordBook=function(classRank){let w=state.record.w;if(!state.records.bestSeason||w>state.records.bestSeason.wins)state.records.bestSeason={year:state.year,wins:w,losses:state.record.l};if(!state.records.bestClass||classRank<state.records.bestClass.rank)state.records.bestClass={year:state.year,rank:classRank};let categories=[['passing','QB','passYds'],['rushing','RB','rushYds'],['receiving','WR','recYds'],['sacks',null,'sacks'],['interceptions',null,'defINT']];categories.forEach(([key,pos,stat])=>{let pool=pos?state.roster.filter(p=>p.pos===pos):state.roster,p=pool.sort((a,b)=>(b.seasonStats?.[stat]||0)-(a.seasonStats?.[stat]||0))[0],value=p?.seasonStats?.[stat]||0;if(p&&(!state.records[key]||value>state.records[key].value))state.records[key]={player:p.name,value,year:state.year}})};

function renderCore(){if(!state.school)return;$('yearLabel').textContent=state.year;$('weekLabel').textContent=state.phase==='REGULAR'?state.week:state.phase;$('recordLabel').textContent=`${state.record.w}-${state.record.l}`;$('mobileYear').textContent=state.year;$('mobileWeek').textContent=state.phase==='REGULAR'?state.week:state.phase;$('mobileRecord').textContent=`${state.record.w}-${state.record.l}`;$('hoursLabel').textContent=state.weeklyHours;$('scholarshipLabel').textContent=state.scholarships;$('schoolName').textContent=state.school.name;$('schoolMeta').textContent=`${state.school.city}, ${state.school.state} · ${state.school.conference}`;$('programMark').textContent=initials(state.school.name);$('offenseScheme').value=state.offense;$('defenseScheme').value=state.defense;applyBrand()}
const tabRenders={
 dashboard:()=>{renderSidebar();renderDashboard();renderStaff();renderStaffAssignments();renderNeeds()},recruiting:()=>window.renderRecruiting(),roster:()=>{renderDepthManager();window.renderRoster()},team:()=>renderTeam(),gameplan:()=>renderGamePlan(),coach:()=>renderCoachTab(),stats:()=>{base.renderStats();renderNationalLeaders();renderClassRankings()},season:()=>{window.renderSchedule();renderStandings();if(state.postseasonData)renderPostseasonBrackets();renderOffseasonHub()},program:()=>{renderProgram();renderTraditionsAndStadium()},rankings:()=>{window.renderRankings();renderConferenceDirectory()},dynasty:()=>renderDynasty(),history:()=>renderHistory()};
window.renderAll=function(){if(!state.school)return;ensureExpansionState();ensureV9State();renderCore();(tabRenders[ui.activeTab]||tabRenders.dashboard)();$('advanceWeekBtn').disabled=state.phase!=='REGULAR'||state.seasonDone;$('recruitAdvanceBtn').disabled=state.phase!=='REGULAR'||state.seasonDone};
window.showTab=function(n){ui.activeTab=n;document.querySelectorAll('.nav-tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===n));document.querySelectorAll('.tab-page').forEach(p=>p.classList.add('hidden'));$(n+'Tab')?.classList.remove('hidden');window.renderAll();window.scrollTo({top:0,behavior:document.body.classList.contains('reduce-motion')?'auto':'smooth'})};

function wrap(name,{immediate=false,backup=false}={}){let fn=window[name];if(typeof fn!=='function')return;window[name]=function(...args){if(backup)saveNow('Safety backup',false,true);let result=fn.apply(this,args);immediate?saveNow(name,false,false):scheduleSave(name);return result}}
['toggleBoard','offer','scout','spend','visit','promise','autoBoard','setPlan','offerNil','useNegativeRecruiting','takePortal','chooseDecision','unlockCoachSkill','setDepthPlayer','setSnapShare','choosePracticeFocus','updateGamePlan','setCaptain','upgradeFacility','replaceCoach','assignCoachRecruiting','replaceScheduledOpponent','selectSpringFocus','chooseStarter','finishBattles','applyPlayerFocus','finishProgression','retainCoordinator','letCoordinatorLeave','acceptJob','declineJob','finishCarousel','runDraft'].forEach(n=>wrap(n));
['advanceWeek','resolveSigningDay','playChampionshipWeek','playPostseason','offseason','finishOffseason'].forEach(n=>wrap(n,{immediate:true,backup:true}));
// Rebind buttons that held references to the old functions.
$('advanceWeekBtn').onclick=()=>window.advanceWeek();$('recruitAdvanceBtn').onclick=()=>window.advanceWeek();$('mobileAdvance').onclick=()=>window.advanceWeek();$('saveBtn').onclick=()=>window.save();$('resolveSigningDayBtn').onclick=()=>window.resolveSigningDay();$('playChampionshipBtn').onclick=()=>window.playChampionshipWeek();$('playPostseasonBtn').onclick=()=>window.playPostseason();$('offseasonBtn').onclick=()=>window.offseason();$('finishOffseasonBtn').onclick=()=>window.finishOffseason();
$('dynastyMenuBtn').onclick=()=>{saveNow('Returned to dynasty menu',false,false);location.reload()};
$('resetBtn').onclick=()=>{let slot=String(state.saveSlot||$('saveSlotPicker')?.value||'1');if(confirm(`Permanently delete the dynasty in Slot ${slot}? This cannot be undone unless you exported a backup.`)){if(deleteSlotCompletely(slot))location.reload();else toast(`Slot ${slot} could not be deleted.`,'error')}};
$('loadSelectedSaveBtn').onclick=()=>loadReleaseSave($('saveSlotPicker').value);
$('deleteSelectedSaveBtn').onclick=()=>{let slot=String($('saveSlotPicker').value),info=readSlotSummary(slot);if(info.empty)return;if(confirm(`Delete ${info.name||'the dynasty'} from Slot ${slot}?`)){if(deleteSlotCompletely(slot)){renderSaveManager();toast(`Slot ${slot} deleted.`)}else toast(`Slot ${slot} could not be deleted.`,'error')}};
$('newDynastyBtn').onclick=()=>{document.querySelector('.hero-copy')?.scrollIntoView({behavior:'smooth',block:'start'})};

document.querySelectorAll('.nav-tab').forEach(b=>b.onclick=()=>window.showTab(b.dataset.tab));
document.querySelectorAll('[data-mobile-target]').forEach(b=>b.onclick=()=>{window.showTab(b.dataset.mobileTarget);$('mobileMoreMenu')?.classList.add('hidden');document.querySelectorAll('[data-mobile-target]').forEach(x=>x.classList.toggle('active',x.dataset.mobileTarget===b.dataset.mobileTarget))});
['positionFilter','starFilter','recruitRegionFilter','statusFilter','sortFilter'].forEach(id=>$(id).onchange=()=>{ui.recruitPage=1;window.renderRecruiting()});$('recruitSearch').oninput=e=>{ui.recruitQuery=e.target.value;ui.recruitPage=1;window.renderRecruiting()};$('rosterSearch').oninput=e=>{ui.rosterQuery=e.target.value;window.renderRoster()};
function loadSettings(){let s={};try{s=JSON.parse(localStorage.getItem('SaturdayDynastyFootballDisplay')||localStorage.getItem('SaturdayArchitectDisplay')||'{}')}catch{}$('textSizeSetting').value=s.textSize||'normal';$('densitySetting').value=s.density||'comfortable';$('motionSetting').checked=!!s.reduceMotion;applySettings()}
function applySettings(){document.body.classList.toggle('text-large',$('textSizeSetting').value==='large');document.body.classList.toggle('density-compact',$('densitySetting').value==='compact');document.body.classList.toggle('reduce-motion',$('motionSetting').checked);localStorage.setItem('SaturdayDynastyFootballDisplay',JSON.stringify({textSize:$('textSizeSetting').value,density:$('densitySetting').value,reduceMotion:$('motionSetting').checked}))}
['textSizeSetting','densitySetting','motionSetting'].forEach(id=>$(id).onchange=applySettings);loadSettings();
$('saveSlotPicker').onchange=()=>{if(!state.school){renderSaveManager();return}let slot=$('saveSlotPicker').value;if(String(state.saveSlot)!==String(slot)){if(confirm(`Return to the dynasty menu and select Slot ${slot}? Your current dynasty will autosave first.`)){saveNow('Changed slot',false,false);location.reload()}else $('saveSlotPicker').value=state.saveSlot}};
document.addEventListener('change',()=>scheduleSave('Changed setting'));document.addEventListener('click',e=>{if(e.target.closest('button')&&state.school)scheduleSave('Action')});document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')saveNow('Background save',false,false)});window.addEventListener('pagehide',()=>saveNow('Exit save',false,false));setInterval(()=>{if(state.school&&Date.now()-lastSaveAt>45000)saveNow('Periodic save',false,false)},45000);
// Always begin at the dynasty menu. Saves load only after the user presses Load Selected Save.
state.school=null;
showDynastyPicker();
renderSaveManager();
window.SDF_RELEASE_TEST={compactState,hydrateState,saveNow,filteredRecruits,ui,readSlotSummary,deleteSlotCompletely,renderSaveManager,loadReleaseSave};
})();
(()=>{
'use strict';

const RECRUITING_MODEL_VERSION=7;
const RECRUIT_BOARD_LIMIT=35,CLASS_SIGNING_LIMIT=25,AI_BOARD_LIMIT=35;
const USER_ID=()=>state.school?.id;
const CONTACT_CAP=50;
const ACTIONS={
 TEXT:{key:'TEXT',label:'Text Message',hours:1,base:1.25,description:'A quick relationship touch for a leftover hour. It can be used once per prospect each week.'},
 CALL:{key:'CALL',label:'Phone Call',hours:5,base:5.2,description:'A focused conversation with the prospect. It can be used once per prospect each week.'},
 FAMILY:{key:'FAMILY',label:'Contact Family',hours:10,base:9.2,description:'Builds trust with the recruit and family, especially for location, academics and playing time.'},
 HARD_SELL:{key:'HARD_SELL',label:'Hard Sell',hours:25,base:16.0,description:'A major pitch around the recruit’s priorities. Strong fits gain more; poor fits gain less.'},
 COACH_VISIT:{key:'COACH_VISIT',label:'Head Coach Visit',hours:50,base:24.0,description:'Your head coach travels to the recruit. This uses the full 50-hour weekly contact allowance.'}
};
const MOTIVATIONS={
 HOME:{label:'Close to Home'},
 PLAYING_TIME:{label:'Early Playing Time'},
 WINNING:{label:'Championship Contender'},
 PRESTIGE:{label:'Program Tradition'},
 PRO:{label:'Pro Potential'},
 FACILITIES:{label:'Athletic Facilities'},
 ACADEMICS:{label:'Academic Prestige'},
 NIL:{label:'NIL Opportunity'},
 SCHEME:{label:'Scheme Fit'}
};
const PRIORITY_MAP={
 'Close to home':'HOME','Early playing time':'PLAYING_TIME','Winning':'WINNING','Pro development':'PRO','NIL opportunity':'NIL','Academics':'ACADEMICS'
};
const PERSONALITY_POOLS={
 Loyal:['HOME','PLAYING_TIME','ACADEMICS'],Homesick:['HOME','PLAYING_TIME','ACADEMICS'],Ambitious:['PRO','PRESTIGE','WINNING'],
 'Team-first':['PLAYING_TIME','SCHEME','WINNING'],Competitive:['WINNING','PRESTIGE','PRO'],'Money-driven':['NIL','PRO','FACILITIES'],
 Academic:['ACADEMICS','FACILITIES','HOME'],Volatile:['NIL','PLAYING_TIME','PRESTIGE']
};
const PLAN_ACTION_MAP={NONE:null,MINIMAL:'TEXT',STANDARD:'FAMILY',MAX:'HARD_SELL',FAMILY:'FAMILY',COACH:'COACH_VISIT',TEXT:'TEXT',CALL:'CALL',HARD_SELL:'HARD_SELL',COACH_VISIT:'COACH_VISIT'};
const PLAN_OPTIONS=[['NONE','No weekly action'],['TEXT','Text Message · 1 hr'],['CALL','Phone Call · 5 hrs'],['FAMILY','Contact Family · 10 hrs'],['HARD_SELL','Hard Sell · 25 hrs'],['COACH_VISIT','Head Coach Visit · 50 hrs']];

function hashInt(value){let h=2166136261;for(const ch of String(value)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function seededRange(seed,min,max){return min+(hashInt(seed)%((max-min)+1))}
function seededFloat(seed){return (hashInt(seed)%100000)/100000}
function schoolById(id){return schools.find(s=>s.id===Number(id))||(Number(id)===USER_ID()?state.school:null)}
function logoFor(id){const b=typeof TEAM_BRANDING!=='undefined'?TEAM_BRANDING?.[Number(id)]:null;return b?.logo||'icon.svg'}
function letterGrade(score){score=Math.round(score);if(score>=97)return'A+';if(score>=93)return'A';if(score>=90)return'A-';if(score>=87)return'B+';if(score>=83)return'B';if(score>=80)return'B-';if(score>=77)return'C+';if(score>=73)return'C';if(score>=70)return'C-';if(score>=67)return'D+';if(score>=63)return'D';if(score>=60)return'D-';return'F'}
function importanceLabel(weight){return weight>=46?'Very High':weight>=30?'High':'Medium'}
function unique(list){return [...new Set(list)]}
function autosave(reason='Recruiting update'){try{window.SDF_RELEASE_TEST?.saveNow?.(reason,false,false)}catch{}}
function actionWeekKey(){return`${state.year}-${state.week}`}
function boardCount(){return(state.recruits||[]).filter(r=>r.onBoard&&!r.committedTo).length}
function boardHasRoom(r){return!!r?.onBoard||boardCount()<RECRUIT_BOARD_LIMIT}
function addToBoard(r,{quiet=false}={}){
 if(r.onBoard)return true;
 if(!boardHasRoom(r)){if(!quiet)rejectRecruitAction(r,`recruiting board full — remove a prospect before adding another (${RECRUIT_BOARD_LIMIT} maximum)`);return false}
 r.onBoard=true;return true
}
function canSchoolSign(id){id=Number(id);if(id===USER_ID())return(state.commits||[]).length<CLASS_SIGNING_LIMIT;state.aiSigningCounts??={};return Number(state.aiSigningCounts[id]||0)<CLASS_SIGNING_LIMIT}
function aiClassCount(id){state.aiSigningCounts??={};return Number(state.aiSigningCounts[Number(id)]||0)}
function aiTargetScore(r,s){
 const starFit=(r.stars*8)*(s.prestige/100),need=seededRange(`${state.year}-${s.id}-${r.pos}-need`,0,16),rankValue=Math.max(0,18-(r.rank||3000)/170);
 return contenderScore(r,s)+starFit+need+rankValue
}
function buildAiRecruitingBoards(force=false){
 if(!state.school||!state.recruits?.length)return;
 if(!force&&state.aiRecruitingBoardYear===state.year&&state.aiRecruitingBoardPool===state.recruits.length&&state.aiRecruitingBoards)return;
 state.aiRecruitingBoards={};state.aiSigningCounts={};for(const r of state.recruits){const id=Number(r.committedTo);if(id&&id!==USER_ID())state.aiSigningCounts[id]=Number(state.aiSigningCounts[id]||0)+1}state.aiRecruitingBoardYear=state.year;state.aiRecruitingBoardPool=state.recruits.length;
 state.recruits.forEach(r=>r.aiPursuerIds=[]);const recruitById=new Map(state.recruits.map(r=>[r.id,r]));
 for(const s of schools){
  if(Number(s.id)===USER_ID())continue;const maxStar=schoolTier(s).maxStar,posCounts={};
  const ordered=state.recruits.filter(r=>r.stars<=maxStar).map(r=>({r,score:aiTargetScore(r,s)})).sort((a,b)=>b.score-a.score||a.r.rank-b.r.rank),chosen=[];
  for(const item of ordered){const pos=item.r.pos;if((posCounts[pos]||0)>=4)continue;chosen.push(item.r.id);posCounts[pos]=(posCounts[pos]||0)+1;if(chosen.length>=AI_BOARD_LIMIT)break}
  if(chosen.length<AI_BOARD_LIMIT){for(const item of ordered){if(chosen.includes(item.r.id))continue;chosen.push(item.r.id);if(chosen.length>=AI_BOARD_LIMIT)break}}
  state.aiRecruitingBoards[s.id]=chosen;chosen.forEach(id=>{const r=recruitById.get(id);if(r)r.aiPursuerIds.push(s.id)})
 }
 state.recruits.forEach(r=>{establishContenders(r,false);recalculateRecruit(r,false)})
}

function recruitingYield(){return new Promise(resolve=>requestAnimationFrame(()=>setTimeout(resolve,0)))}
async function initializeRecruitingModelAsync(onProgress=()=>{}){
 if(!state.school||!state.recruits?.length)return;
 const recruits=state.recruits,force=!!state.recruitingNeedsRecalcAll;delete state.recruitingNeedsRecalcAll;
 onProgress(12,'Evaluating all 3,000 prospects…');
 for(let i=0;i<recruits.length;i+=90){for(const r of recruits.slice(i,i+90))ensureRecruit(r,force);onProgress(12+Math.round((i/recruits.length)*34),`Evaluating prospects ${Math.min(i+90,recruits.length).toLocaleString()} / ${recruits.length.toLocaleString()}…`);await recruitingYield()}
 onProgress(47,'Building computer recruiting boards…');state.aiRecruitingBoards={};state.aiSigningCounts={};
 for(const r of recruits){const id=Number(r.committedTo);if(id&&id!==USER_ID())state.aiSigningCounts[id]=Number(state.aiSigningCounts[id]||0)+1;r.aiPursuerIds=[]}
 state.aiRecruitingBoardYear=state.year;state.aiRecruitingBoardPool=recruits.length;const recruitById=new Map(recruits.map(r=>[r.id,r])),aiSchools=schools.filter(s=>Number(s.id)!==USER_ID());
 for(let si=0;si<aiSchools.length;si++){
  const s=aiSchools[si],maxStar=schoolTier(s).maxStar,posCounts={},ordered=recruits.filter(r=>r.stars<=maxStar).map(r=>({r,score:aiTargetScore(r,s)})).sort((a,b)=>b.score-a.score||a.r.rank-b.r.rank),chosen=[];
  for(const item of ordered){const pos=item.r.pos;if((posCounts[pos]||0)>=4)continue;chosen.push(item.r.id);posCounts[pos]=(posCounts[pos]||0)+1;if(chosen.length>=AI_BOARD_LIMIT)break}
  if(chosen.length<AI_BOARD_LIMIT){for(const item of ordered){if(chosen.includes(item.r.id))continue;chosen.push(item.r.id);if(chosen.length>=AI_BOARD_LIMIT)break}}
  state.aiRecruitingBoards[s.id]=chosen;for(const id of chosen){const r=recruitById.get(id);if(r)r.aiPursuerIds.push(s.id)}
  if(si%3===0){onProgress(47+Math.round((si/aiSchools.length)*34),`Building recruiting boards ${si+1} / ${aiSchools.length}…`);await recruitingYield()}
 }
 onProgress(82,'Finalizing recruiting battles…');
 for(let i=0;i<recruits.length;i+=110){for(const r of recruits.slice(i,i+110)){establishContenders(r,false);recalculateRecruit(r,false)}onProgress(82+Math.round((i/recruits.length)*16),`Finalizing prospects ${Math.min(i+110,recruits.length).toLocaleString()} / ${recruits.length.toLocaleString()}…`);await recruitingYield()}
 state.recruitingInitializationPending=false;onProgress(99,'Finishing the dynasty home screen…')
}

function aiBoardHas(schoolId,recruitId){buildAiRecruitingBoards(false);return(state.aiRecruitingBoards?.[schoolId]||[]).includes(recruitId)}

function userNeed(r){try{return needs()[r.pos]||{sev:0,q:68,count:0,sen:0}}catch{return{sev:0,q:68,count:0,sen:0}}}
function currentSchemeGrade(r){
 let grade=58;
 if(['QB','RB','WR','TE','OT','IOL'].includes(r.pos)){
  if(state.offense==='Air Raid'&&['QB','WR','TE'].includes(r.pos))grade+=25;
  if(state.offense==='Power Run'&&['RB','OT','IOL','TE'].includes(r.pos))grade+=24;
  if(state.offense==='Option'&&r.pos==='QB'&&r.arch==='Scrambler')grade+=31;
  if(state.offense==='Tempo Spread'&&['QB','WR','RB'].includes(r.pos))grade+=18;
  if(state.offense==='Spread'&&['QB','WR','RB','TE'].includes(r.pos))grade+=14;
 }else{
  if(state.defense==='4-2-5'&&['CB','S','LB'].includes(r.pos))grade+=23;
  if(state.defense==='3-4'&&['EDGE','LB','DL'].includes(r.pos))grade+=23;
  if(state.defense==='4-3'&&['DL','LB'].includes(r.pos))grade+=20;
  if(state.defense==='3-3-5'&&['LB','CB','S'].includes(r.pos))grade+=20;
 }
 return clamp(grade,35,99)
}
function playingTimeGrade(r,s){
 if(s.id===USER_ID()){
  const n=userNeed(r),rating=r.trueOvr||r.ovr||68;
  return clamp(Math.round(42+n.sev*7+(rating-(n.q||68))*1.7+(n.sen||0)*4-Math.max(0,(n.count||0)-(DEPTH[r.pos]||3))*2),18,99)
 }
 const competition=s.prestige*.34+s.recent*.12+s.pro*.08;
 const jitter=seededRange(`${r.id}-${s.id}-playing`,-16,18);
 return clamp(Math.round(92-competition+jitter+(r.stars<=3?5:0)),18,96)
}
function schoolGrade(r,s,key){
 if(!s)return 0;
 if(key==='HOME'){
  const miles=distance(s,r),pipeline=s.pipelines?.includes(r.home)?9:0;
  return clamp(Math.round(101-miles/17+pipeline),8,100)
 }
 if(key==='PLAYING_TIME')return playingTimeGrade(r,s);
 if(key==='WINNING')return clamp(Math.round(s.recent*.72+s.prestige*.28),10,99);
 if(key==='PRESTIGE')return clamp(Math.round(s.prestige),10,99);
 if(key==='PRO')return clamp(Math.round(s.pro),10,99);
 if(key==='FACILITIES')return clamp(Math.round(s.facilities),10,99);
 if(key==='ACADEMICS')return clamp(Math.round(s.academics),10,99);
 if(key==='NIL')return clamp(Math.round(s.nil),10,99);
 if(key==='SCHEME')return s.id===USER_ID()?currentSchemeGrade(r):clamp(seededRange(`${r.id}-${s.id}-scheme`,48,94),25,98);
 return 50
}
function buildMotivations(r){
 const primary=PRIORITY_MAP[r.priority]||'PRESTIGE',pool=PERSONALITY_POOLS[r.personality]||['WINNING','PRO','HOME'];
 const remaining=unique([...pool,'PLAYING_TIME','HOME','WINNING','PRO','PRESTIGE','FACILITIES','ACADEMICS','NIL','SCHEME']).filter(k=>k!==primary);
 const offset=hashInt(`${r.id}-motivation`)%remaining.length;
 const secondary=remaining[offset],tertiary=remaining[(offset+3)%remaining.length]===secondary?remaining[(offset+4)%remaining.length]:remaining[(offset+3)%remaining.length];
 const primaryWeight=48+seededRange(`${r.id}-pw`,0,8),secondaryWeight=28+seededRange(`${r.id}-sw`,0,7),tertiaryWeight=100-primaryWeight-secondaryWeight;
 return[{key:primary,label:MOTIVATIONS[primary].label,weight:primaryWeight},{key:secondary,label:MOTIVATIONS[secondary].label,weight:secondaryWeight},{key:tertiary,label:MOTIVATIONS[tertiary].label,weight:tertiaryWeight}]
}
function weightedFit(r,s){
 r.motivations??=buildMotivations(r);
 return clamp(Math.round(r.motivations.reduce((sum,m)=>sum+schoolGrade(r,s,m.key)*m.weight,0)/100),0,100)
}
function baseInterest(r,s){
 const fitScore=weightedFit(r,s),pipeline=s.pipelines?.includes(r.home)?4:0,brand=s.prestige*.07+s.recent*.035,noise=seededRange(`${r.id}-${s.id}-base`,-5,5);
 let value=8+fitScore*.56+brand+pipeline+noise;
 const tier=schoolTier(s);if(r.stars>tier.maxStar)value-=25;if(r.stars===5&&tier.key==='POWER'&&s.prestige<80)value-=10;
 return clamp(value,4,82)
}
function dealbreakerMet(r,s){
 if(!r.dealbreaker)return true;
 if(r.dealbreaker.key==='HOME')return distance(s,r)<=Number(r.dealbreaker.threshold||800);
 if(r.dealbreaker.key==='PLAYING_TIME')return playingTimeGrade(r,s)>=Number(r.dealbreaker.threshold||70);
 if(r.dealbreaker.key==='SCHEME')return schoolGrade(r,s,'SCHEME')>=Number(r.dealbreaker.threshold||68);
 const value=s?.[r.dealbreaker.field]??0;return value>=Number(r.dealbreaker.threshold||0)
}
function accessFor(r,s){
 const tier=schoolTier(s),reasons=[];
 if(r.stars>tier.maxStar)reasons.push(`${tier.label} programs cannot actively recruit ${r.stars}-star prospects`);
 if(r.stars===5&&tier.key==='POWER'&&s.prestige<80)reasons.push('Five-star access requires stronger Power-tier prestige');
 return{allowed:reasons.length===0,reasons,tier,maxStar:tier.maxStar}
}
function capFor(r,s){
 const tier=schoolTier(s);let cap=100;
 if(r.stars===5){if(tier.key==='REBUILD')cap=42;else if(tier.key==='REGIONAL')cap=58;else if(tier.key==='RISING')cap=76}
 if(r.stars===4){if(tier.key==='REBUILD')cap=62;else if(tier.key==='REGIONAL')cap=82}
 if(!dealbreakerMet(r,s)){
  const hardStage=state.phase!=='REGULAR'||state.week>=9;
  cap=Math.min(cap,hardStage?49:94)
 }
 return cap
}
function eligibilityFor(r,s){
 const access=accessFor(r,s),dealbreakerMissing=!dealbreakerMet(r,s),hardDealbreaker=dealbreakerMissing&&(state.phase!=='REGULAR'||state.week>=9),cap=access.allowed?capFor(r,s):Math.min(35,capFor(r,s)),reasons=[],warnings=[];
 reasons.push(...access.reasons);
 if(dealbreakerMissing){
  let detail='';
  if(r.dealbreaker?.key==='HOME')detail=`Must be within ${r.dealbreaker.threshold} miles`;
  else if(r.dealbreaker?.key==='PLAYING_TIME')detail=`Playing-time grade must be ${letterGrade(r.dealbreaker.threshold)} or better`;
  else if(r.dealbreaker?.key==='SCHEME')detail=`Scheme-fit grade must be ${letterGrade(r.dealbreaker.threshold)} or better`;
  else detail=`${r.dealbreaker?.label||'Dealbreaker'} requires ${r.dealbreaker?.threshold}`;
  (hardDealbreaker?reasons:warnings).push(hardDealbreaker?detail:`Interest limit ${cap}/100: ${detail}. Recruiting actions stop adding interest at this limit. Meet the requirement before final cuts to unlock 100 interest.`)
 }
 return{cap,locked:!access.allowed||hardDealbreaker,reasons,warnings,hardDealbreaker}
}
function setModernDealbreaker(r){
 if(r._modernDealbreaker)return;
 const primary=r.motivations[0]?.key;
 if(primary==='HOME'&&seededFloat(`${r.id}-db-home`)<.52)r.dealbreaker={key:'HOME',label:'Proximity to Home',field:null,threshold:[450,650,850][hashInt(r.id)%3]};
 else if(primary==='PLAYING_TIME'&&seededFloat(`${r.id}-db-pt`)<.55)r.dealbreaker={key:'PLAYING_TIME',label:'Early Playing Time',field:null,threshold:68+seededRange(`${r.id}-pt-th`,0,10)};
 else if(primary==='SCHEME'&&seededFloat(`${r.id}-db-scheme`)<.45)r.dealbreaker={key:'SCHEME',label:'Scheme Fit',field:null,threshold:65+seededRange(`${r.id}-scheme-th`,0,12)};
 r._modernDealbreaker=true
}
function contenderScore(r,s){return weightedFit(r,s)*.7+s.prestige*.16+s.recent*.08+s.pro*.06+seededRange(`${r.id}-${s.id}-contender`,-5,5)}
function establishContenders(r,force=false){
 const includeUser=r.onBoard||r.offered||(r.recruitInfluence?.[USER_ID()]||0)>0;
 const rankIds=ids=>unique(ids.map(Number).filter(id=>schoolById(id))).map(id=>{const s=schoolById(id);return{id,score:contenderScore(r,s)}}).sort((a,b)=>b.score-a.score).map(x=>x.id);
 if(!force&&Array.isArray(r.contenderIds)&&r.contenderIds.length>=8){
  const candidates=[...r.contenderIds,...(r.aiPursuerIds||[])];if(includeUser)candidates.push(USER_ID());r.contenderIds=rankIds(candidates).slice(0,13);return
 }
 const ranked=schools.map(s=>({id:s.id,score:contenderScore(r,s)})).sort((a,b)=>b.score-a.score).slice(0,12).map(x=>x.id),existing=new Set((r.contenderIds||[]).map(Number));
 ranked.forEach(id=>existing.add(id));(r.aiPursuerIds||[]).forEach(id=>existing.add(Number(id)));if(includeUser)existing.add(USER_ID());r.contenderIds=rankIds([...existing]).slice(0,13)
}
function migratePlan(r){if(r.weeklyPlan&&PLAN_ACTION_MAP[r.weeklyPlan]!==undefined)r.weeklyPlan=PLAN_ACTION_MAP[r.weeklyPlan]||'NONE';else r.weeklyPlan='NONE'}
function ensureRecruit(r,forceRefresh=false){
 if(!r)return r;
 if(!r.motivations&&Array.isArray(r.motivationData)){r.motivations=r.motivationData.map(([key,weight])=>({key,label:MOTIVATIONS[key]?.label||key,weight}));delete r.motivationData}r.motivations??=buildMotivations(r);
 if(!r.dealbreaker&&Array.isArray(r.dealbreakerData)){const [key,threshold]=r.dealbreakerData,defs={PRESTIGE:['Program Prestige','prestige'],PRO:['Pro Development','pro'],FACILITIES:['Facilities','facilities'],RECENT:['Winning','recent'],ACADEMICS:['Academics','academics'],NIL:['NIL Opportunity','nil'],HOME:['Proximity to Home',null],PLAYING_TIME:['Early Playing Time',null],SCHEME:['Scheme Fit',null]},def=defs[key]||[key,null];r.dealbreaker={key,label:def[0],field:def[1],threshold};delete r.dealbreakerData}
 setModernDealbreaker(r);
 if(!r.recruitInfluence&&Array.isArray(r.influenceData)){r.recruitInfluence=Object.fromEntries(r.influenceData);delete r.influenceData}r.recruitInfluence??={};
 if(!r.offerBySchool&&Array.isArray(r.aiOfferIds)){r.offerBySchool=Object.fromEntries(r.aiOfferIds.map(id=>[id,true]));delete r.aiOfferIds}r.offerBySchool??={};
 if(!r.visitBoostBySchool&&Array.isArray(r.visitData)){r.visitBoostBySchool=Object.fromEntries(r.visitData);delete r.visitData}r.visitBoostBySchool??={};
 if(!r.promiseBoostBySchool&&Array.isArray(r.promiseData)){r.promiseBoostBySchool=Object.fromEntries(r.promiseData);delete r.promiseData}r.promiseBoostBySchool??={};
 if(!r.aiVisitWeeks&&Array.isArray(r.aiVisitData)){r.aiVisitWeeks=Object.fromEntries(r.aiVisitData);delete r.aiVisitData}r.aiVisitWeeks??={};
 r.actionHistory??={};r.interestTrend??={};r.lastInterestSnapshot??={};migratePlan(r);
 const isUpgrade=forceRefresh||!!state.recruitingNeedsRecalcAll||r.recruitingModelVersion!==RECRUITING_MODEL_VERSION||!!r.recruitingNeedsRecalc;delete r.recruitingNeedsRecalc;establishContenders(r,isUpgrade||!r.contenderIds?.length);
 if(r.stars===3){
  const ceiling=r.generatedGem?84:80;
  if(Number(r.trueOvr||0)>ceiling)r.trueOvr=ceiling;
  if(Number(r.listedOvr||0)>ceiling)r.listedOvr=ceiling;
  if(Number(r.ovr||0)>ceiling)r.ovr=r.scouted&&r.trueOvr?Math.min(ceiling,r.trueOvr):ceiling;
 }
 if(isUpgrade){
  r.lockedOut=[];
  for(const id of unique([...r.contenderIds,USER_ID()])){
   const s=schoolById(id);if(!s)continue;const old=Number(r.interest?.[id]||0),base=baseInterest(r,s);r.recruitInfluence[id]=clamp(Math.max(Number(r.recruitInfluence[id]||0),old-base),0,32)
  }
  r.recruitingModelVersion=RECRUITING_MODEL_VERSION;recalculateRecruit(r,false)
 }
 return r
}
function ensureAllRecruits(){if(!state.school)return;const force=!!state.recruitingNeedsRecalcAll;delete state.recruitingNeedsRecalcAll;(state.recruits||[]).forEach(r=>ensureRecruit(r,force))}
function offerBonus(r,id){return Number(id)===USER_ID()?(r.offered?5:0):(r.offerBySchool?.[id]?5:0)}
function nilReaction(amount,demand){
 const ratio=Number(amount||0)/Math.max(1,Number(demand||1));
 if(!amount)return{label:'No offer',tone:'neutral',bonus:0,ratio};
 if(ratio>=1.25)return{label:'Thrilled — above asking price',tone:'great',bonus:12,ratio};
 if(ratio>=1.05)return{label:'Impressed — strong offer',tone:'great',bonus:9,ratio};
 if(ratio>=.90)return{label:'Satisfied',tone:'good',bonus:6,ratio};
 if(ratio>=.75)return{label:'Interested, but wants more',tone:'warning',bonus:2,ratio};
 if(ratio>=.65)return{label:'Disappointed by the low offer',tone:'bad',bonus:-4,ratio};
 return{label:'Insulted by the offer',tone:'bad',bonus:-8,ratio}
}
function nilBonus(r,id){
 if(Number(id)!==USER_ID())return 0;const paid=Number(state.nilCommitments?.[r.id]||0),demand=Number(nilOfferAmount(r)||1),reaction=nilReaction(paid,demand);return reaction.bonus-Number(r.nilTrustPenalty||0)
}
function relationshipBonus(r,id){return Number(id)===USER_ID()&&r.relationship&&state.commits?.some(x=>x.id===r.relationship.otherId)&&r.relationship.type!=='Rival'?4:0}
function totalInterest(r,s){
 const id=s.id,cap=capFor(r,s),value=baseInterest(r,s)+Number(r.recruitInfluence?.[id]||0)+offerBonus(r,id)+Number(r.visitBoostBySchool?.[id]||0)+Number(r.promiseBoostBySchool?.[id]||0)+nilBonus(r,id)+relationshipBonus(r,id);
 return clamp(value,2,cap)
}
function recalculateRecruit(r,trackTrend=true){
 if(!r.contenderIds?.length)establishContenders(r,true);r.interest??={};const ids=unique([...r.contenderIds,USER_ID()]);
 ids.forEach(id=>{const s=schoolById(id);if(!s)return;const previous=Number(r.interest[id]||0),next=totalInterest(r,s);if(trackTrend)r.interestTrend[id]=next-previous;r.lastInterestSnapshot[id]=previous;r.interest[id]=next});
 return r
}
function race(r){
 ensureRecruit(r);const ids=unique([...r.contenderIds,USER_ID()]).filter(id=>schoolById(id)&&!(r.lockedOut||[]).includes(Number(id)));
 const entries=ids.map(id=>{const s=schoolById(id);return{id:Number(id),school:s,score:Number(r.interest[id]||totalInterest(r,s)),fit:weightedFit(r,s),grade:letterGrade(weightedFit(r,s)),trend:Number(r.interestTrend?.[id]||0),offered:Number(id)===USER_ID()?!!r.offered:!!r.offerBySchool?.[id]}}).sort((a,b)=>b.score-a.score||b.fit-a.fit);
 entries.forEach((x,i)=>x.rank=i+1);const user=entries.find(x=>x.id===USER_ID()),leader=entries[0],second=entries[1];return{entries,user,leader,second,gap:user&&leader?Math.max(0,leader.score-user.score):null}
}
function stageFor(r){if(r.committedTo)return'Committed';const rc=race(r),rank=rc.user?.rank||99;if(rank<=3)return'Top 3';if(rank<=5)return'Top 5';if(rank<=8)return'Top 8';return'Open'}
function statusFor(r){
 ensureRecruit(r);const access=accessFor(r,state.school),eligibility=eligibilityFor(r,state.school),lockedOut=!!r.lockedOut?.includes(USER_ID()),committed=!!r.committedTo,evaluateReasons=[];
 if(committed)evaluateReasons.push(`Committed to ${schoolName(r.committedTo)}`);if(!access.allowed)evaluateReasons.push(...access.reasons);if(lockedOut)evaluateReasons.push("Your school was cut from this recruit's list");
 const canEvaluate=evaluateReasons.length===0,activeReasons=[...evaluateReasons];if(canEvaluate&&eligibility.locked)activeReasons.push(...eligibility.reasons);
 const boardFull=!r.onBoard&&!committed&&!boardHasRoom(r),classFull=!committed&&(state.commits||[]).length>=CLASS_SIGNING_LIMIT;if(boardFull){evaluateReasons.push(`Recruiting board full (${RECRUIT_BOARD_LIMIT}/${RECRUIT_BOARD_LIMIT})`);activeReasons.push(`Recruiting board full — remove a prospect before adding another`)}if(classFull)activeReasons.push(`Signing class full (${CLASS_SIGNING_LIMIT}/${CLASS_SIGNING_LIMIT})`);return{access,eligibility,lockedOut,committed,boardFull,classFull,canEvaluate:evaluateReasons.length===0,canRecruit:activeReasons.length===0,evaluateReason:unique(evaluateReasons).join(' · '),activeReason:unique(activeReasons).join(' · '),warning:unique(eligibility.warnings||[]).join(' · ')}
}
function actionCount(r,key){return Number(r.actionHistory?.[actionWeekKey()]?.[key]||0)}
function weeklyContactHours(r){const week=r.actionHistory?.[actionWeekKey()]||{};return Object.entries(week).reduce((sum,[key,count])=>sum+Number(ACTIONS[key]?.hours||0)*Number(count||0),0)}
function actionMatch(r,action,s){
 const grades=r.motivations.map(m=>schoolGrade(r,s,m.key)),weighted=weightedFit(r,s)/100;
 if(action.key==='TEXT')return 1;
 if(action.key==='CALL')return .78+grades[0]/230;
 if(action.key==='FAMILY'){const familyKeys=new Set(['HOME','ACADEMICS','PLAYING_TIME']);const familyWeight=r.motivations.filter(m=>familyKeys.has(m.key)).reduce((n,m)=>n+m.weight,0);return .78+familyWeight/160+grades[0]/480}
 if(action.key==='HARD_SELL')return clamp(.38+weighted,0.5,1.45);
 if(action.key==='COACH_VISIT')return clamp(.72+weighted*.55,0.82,1.42);
 return 1
}
function actionPreview(r,key){
 const action=ACTIONS[key],used=actionCount(r,key)>0,weeklySpent=weeklyContactHours(r),fitMult=actionMatch(r,action,state.school),estimate=action.base*fitMult*coachRecruitingMult();
 return{action,count:used?1:0,used,weeklySpent,remaining:Math.max(0,CONTACT_CAP-weeklySpent),fitMult,diminishing:1,repeat:used?0:1,estimate:Math.max(.1,estimate)}
}
function canUseAction(r,key,status=statusFor(r)){
 const preview=actionPreview(r,key),action=ACTIONS[key];
 if(!status.canRecruit)return{allowed:false,reason:status.activeReason,preview};
 const currentScore=Number(race(r).user?.score||0),interestCap=Number(status.eligibility?.cap||100);
 if(interestCap<100&&currentScore>=interestCap-.05)return{allowed:false,reason:`Interest is already at the ${interestCap}/100 limit. ${status.warning||'Meet the recruit requirement to unlock more interest.'}`,preview};
 if(preview.used)return{allowed:false,reason:`${action.label} already used on this prospect this week`,preview};
 if(preview.weeklySpent+action.hours>CONTACT_CAP)return{allowed:false,reason:`Only ${preview.remaining} of ${CONTACT_CAP} contact hours remain for this prospect this week`,preview};
 if(state.weeklyHours<action.hours)return{allowed:false,reason:`Only ${state.weeklyHours} school recruiting hours remain`,preview};
 return{allowed:true,reason:'',preview}
}
function performAction(r,key,{silent=false,fromPlan=false}={}){
 ensureRecruit(r);const action=ACTIONS[key],status=statusFor(r);if(!action)return false;const availability=canUseAction(r,key,status);if(!availability.allowed){if(!silent)rejectRecruitAction(r,availability.reason);return false}if(!addToBoard(r,{quiet:silent}))return false;
 const beforeScore=race(r).user?.score||0;state.weeklyHours-=action.hours;r.actionHistory[actionWeekKey()]??={};r.actionHistory[actionWeekKey()][key]=1;
 let gain=Math.max(.25,availability.preview.estimate*(.90+Math.random()*.20));r.recruitInfluence[USER_ID()]=clamp(Number(r.recruitInfluence[USER_ID()]||0)+gain,0,58);recalculateRecruit(r,true);
 let afterScore=race(r).user?.score||0;if(afterScore<beforeScore){r.recruitInfluence[USER_ID()]=clamp(Number(r.recruitInfluence[USER_ID()]||0)+(beforeScore-afterScore),0,58);recalculateRecruit(r,true);afterScore=race(r).user?.score||beforeScore}
 maybeImmediateCommit(r);const rc=race(r),rank=rc.user?.rank||'—',gap=rc.gap==null?'—':Math.round(rc.gap),displayGain=Math.max(0,afterScore-beforeScore),spent=weeklyContactHours(r);
 const currentStatus=statusFor(r),interestCap=Number(currentStatus.eligibility?.cap||100),capMessage=interestCap<100&&afterScore>=interestCap-.05?` Interest has reached its ${interestCap}/100 limit. ${currentStatus.warning}`:'';
 r.lastActionMessage=`${action.label} increased your score by ${displayGain<1?displayGain.toFixed(1):Math.round(displayGain)}. Contact allocation: ${spent}/${CONTACT_CAP} hours this week. You are #${rank}${gap>0?`, ${gap} behind ${rc.leader.school.name}`:', currently leading'}. Action limits reset next week.${capMessage}`;
 if(!silent)state.news.push(`${r.name}: ${r.lastActionMessage}`);if(!fromPlan){window.renderAll();autosave(action.label)}return true
}
function actionButtons(r,status,compact=false){
 const cls=compact?'':' small';return Object.values(ACTIONS).map(a=>{const availability=canUseAction(r,a.key,status),p=availability.preview,coach=a.key==='COACH_VISIT';return`<button class="btn${cls} ${coach?'success':a.key==='HARD_SELL'?'primary':a.key==='FAMILY'?'warning':'neutral'}" onclick="recruitAction('${r.id}','${a.key}')" ${!availability.allowed?'disabled':''} title="${availability.allowed?`Estimated influence ${p.estimate.toFixed(1)} · ${p.weeklySpent}/${CONTACT_CAP} contact hours used`:availability.reason}">${p.used?'Used: ':''}${a.label} (${a.hours} hr${a.hours===1?'':'s'})</button>`}).join('')
}
window.recruitAction=(id,key)=>{const r=findR(id);if(r)performAction(r,key)};
window.toggleBoard=id=>{const r=findR(id);if(!r)return;ensureRecruit(r);if(r.onBoard){r.onBoard=false;r.weeklyPlan='NONE';window.renderAll();autosave('Removed from recruiting board');return}if(!addToBoard(r))return;window.renderAll();autosave('Added to recruiting board')};
const boardAwareScout=window.scout;window.scout=id=>{const r=findR(id);if(!r||!addToBoard(r))return;return boardAwareScout(id)};

window.spend=(id,hours)=>{const key={1:'TEXT',5:'CALL',10:'FAMILY',25:'HARD_SELL',50:'COACH_VISIT'}[Number(hours)];const r=findR(id);if(r&&key)performAction(r,key)};
window.recruitingAccess=accessFor;window.recruitingEligibility=eligibilityFor;window.recruitInterestCap=capFor;window.meetsDealbreaker=dealbreakerMet;window.recStage=stageFor;window.recruitingActionStatus=statusFor;

function motivationChips(r){return r.motivations.map(m=>`<span class="motivation-chip"><b>${m.label}</b><small>${importanceLabel(m.weight)} · ${m.weight}%</small></span>`).join('')}
function raceCompact(r,max=3){const rc=race(r);return rc.entries.slice(0,max).map(e=>`<div class="race-mini-row ${e.id===USER_ID()?'user-school':''}"><span><img src="${logoFor(e.id)}" alt=""><b>#${e.rank} ${e.school.name}</b></span><strong>${Math.round(e.score)}</strong></div>`).join('')}
function userRaceSummary(r){const rc=race(r);if(!rc.user)return'<span class="sub">Not in current top schools</span>';const gap=rc.user.rank===1?`Leading by ${Math.max(0,Math.round(rc.user.score-(rc.second?.score||0)))}`:`${Math.round(rc.leader.score-rc.user.score)} behind ${rc.leader.school.name}`,cap=Number(eligibilityFor(r,state.school).cap||100);return`<b>#${rc.user.rank} · ${Math.round(rc.user.score)} interest</b><span class="sub">${gap} · Fit ${rc.user.grade}${cap<100?` · Limit ${cap}/100`:''}</span>`}
function dealbreakerDisplay(r){if(!r.dealbreaker)return'None';if(r.dealbreaker.key==='HOME')return`${r.dealbreaker.label}<span class="sub">Within ${r.dealbreaker.threshold} miles · You: ${distance(state.school,r)} mi</span>`;if(r.dealbreaker.key==='PLAYING_TIME')return`${r.dealbreaker.label}<span class="sub">Needs ${letterGrade(r.dealbreaker.threshold)} · You: ${letterGrade(playingTimeGrade(r,state.school))}</span>`;if(r.dealbreaker.key==='SCHEME')return`${r.dealbreaker.label}<span class="sub">Needs ${letterGrade(r.dealbreaker.threshold)} · You: ${letterGrade(schoolGrade(r,state.school,'SCHEME'))}</span>`;return`${r.dealbreaker.label}<span class="sub">Needs ${r.dealbreaker.threshold} · You: ${state.school[r.dealbreaker.field]??'—'}</span>`}
function planSelect(r,status){return`<select class="plan-select" onchange="setPlan('${r.id}',this.value)" ${!status.canRecruit?'disabled':''}>${PLAN_OPTIONS.map(([v,l])=>`<option value="${v}" ${r.weeklyPlan===v?'selected':''}>${l}</option>`).join('')}</select>`}
function nilButton(r,status,compact=false){const amount=nilOfferAmount(r),offered=Number(state.nilCommitments?.[r.id]||0),reaction=nilReaction(offered,amount),cls=compact?'':' small',available=Number(state.nilBudget||0)+offered;return`<button class="btn${cls} neutral" onclick="offerNil('${r.id}')" ${!status.canRecruit||available<1000?'disabled':''}>${offered?`Revise NIL ${formatNilMoney(offered)} · ${reaction.label}`:`Set NIL Offer · Ask ${formatNilMoney(amount)}`}</button>`}
function recruitButtons(r,status,compact=false){
 const cls=compact?'':' small';
 return`<button class="btn${cls} neutral" onclick="toggleBoard('${r.id}')" ${(!r.onBoard&&status.boardFull)||!status.canEvaluate?'disabled':''}>${r.onBoard?'Remove':'Board'}</button><button class="btn${cls} neutral" onclick="offer('${r.id}')" ${!status.canRecruit||r.offered||state.scholarships<=0?'disabled':''}>${r.offered?'Offered':'Scholarship'}</button><button class="btn${cls} neutral" onclick="scout('${r.id}')" ${!status.canEvaluate||r.scouted||state.weeklyHours<8?'disabled':''}>Scout (8 hrs)</button>${actionButtons(r,status,compact)}<button class="btn${cls} quick-more" onclick="openRecruitQuickMenu('${r.id}')" aria-label="More recruiting options">⋯</button><button class="btn${cls} success" onclick="openRecruit('${r.id}')">Profile</button>${nilButton(r,status,compact)}`
}
function lateOpportunity(r){
 if(r.committedTo)return false;if(Number(r.entryWeek||1)>1&&state.week-Number(r.entryWeek||1)<=2)return true;const rc=race(r),offers=rc.entries.filter(e=>e.offered).length,user=rc.user;
 if(r.stars===2&&state.week>=4)return true;return state.week>=3&&!statusFor(r).lockedOut&&(rc.leader?.score<78||offers<=3||(user&&user.rank<=10&&rc.gap<=16))
}
function recruitableNow(r){
 const s=statusFor(r);
 // Recruit-specific eligibility only. Global board/class capacity should not hide the entire pool.
 return !r.committedTo&&s.access.allowed&&!s.lockedOut&&!s.eligibility.locked
}
function filteredProspects(){
 const n=needs(),q=(document.getElementById('recruitSearch')?.value||'').trim().toLowerCase(),pos=$('positionFilter').value,starFilter=$('starFilter').value,region=$('recruitRegionFilter').value,status=$('statusFilter').value,sort=$('sortFilter').value;
 const list=state.recruits.filter(r=>{ensureRecruit(r);return(!q||`${r.name} ${r.city} ${r.home} ${r.pos}`.toLowerCase().includes(q))&&(pos==='ALL'||r.pos===pos)&&(starFilter==='ALL'||r.stars===Number(starFilter))&&(region==='ALL'||r.region===region)&&(status==='AVAILABLE'?!r.committedTo:status==='RECRUITABLE'?recruitableNow(r):status==='UNCONTACTED'?!r.committedTo&&!r.onBoard&&!r.offered&&Number(r.recruitInfluence?.[USER_ID()]||0)===0:status==='LATE'?lateOpportunity(r):status==='BOARD'?r.onBoard&&!r.committedTo:status==='OFFERED'?r.offered&&!r.committedTo:!!r.committedTo)});
 if(sort==='INTEREST')list.sort((a,b)=>(race(a).user?.rank||99)-(race(b).user?.rank||99)||(race(b).user?.score||0)-(race(a).user?.score||0));
 else if(sort==='NEED')list.sort((a,b)=>n[b.pos].sev-n[a.pos].sev||a.rank-b.rank);
 else if(sort==='DISTANCE')list.sort((a,b)=>distance(state.school,a)-distance(state.school,b));
 else if(sort==='FIT')list.sort((a,b)=>weightedFit(b,state.school)-weightedFit(a,state.school));
 else list.sort((a,b)=>a.rank-b.rank);return list
}
function renderRecruitingV2(){
 const recruitTab=$('recruitingTab');if(recruitTab)recruitTab.dataset.recruitingEngine='modern-v5';
 if(!$('recruitTable'))return;ensureAllRecruits();const n=needs(),all=filteredProspects(),pageSize=window.innerWidth<=760?30:75;window.SDF_RECRUIT_UI??={page:1};const pages=Math.max(1,Math.ceil(all.length/pageSize));window.SDF_RECRUIT_UI.page=clamp(window.SDF_RECRUIT_UI.page,1,pages);const rows=all.slice((window.SDF_RECRUIT_UI.page-1)*pageSize,window.SDF_RECRUIT_UI.page*pageSize),board=state.recruits.filter(r=>r.onBoard&&!r.committedTo).length,led=state.recruits.filter(r=>r.onBoard&&!r.committedTo&&race(r).user?.rank===1).length,close=state.recruits.filter(r=>r.onBoard&&!r.committedTo&&race(r).user?.rank<=3&&race(r).gap<=8).length;
 $('recruitingOverview').innerHTML=metric('Weekly Recruiting Hours',state.weeklyHours)+metric('Open Prospects',state.recruits.filter(r=>!r.committedTo).length)+metric('Recruitable Now',state.recruits.filter(recruitableNow).length)+metric('Recruiting Board',`${board}/${RECRUIT_BOARD_LIMIT}`)+metric('Board Slots',Math.max(0,RECRUIT_BOARD_LIMIT-board))+metric('Offers Left',state.scholarships)+metric('Signed Class',`${state.commits.length}/${CLASS_SIGNING_LIMIT}`)+metric('Battles Led',led)+metric('Late Opportunities',state.recruits.filter(lateOpportunity).length)+metric('Recruiting NIL Pool',formatNilMoney(state.nilBudget))+metric('NIL Offered',formatNilMoney(nilCommittedTotal()))+metric('Program Funds',formatNilMoney(state.budget))+metric('Recruiting Phase',state.recruitingPhase);
 $('recruitPager').innerHTML=`<div class="pager-info">Showing ${(window.SDF_RECRUIT_UI.page-1)*pageSize+1}-${Math.min(window.SDF_RECRUIT_UI.page*pageSize,all.length)} of ${all.length}</div><div class="pager-actions"><button class="btn neutral" onclick="changeRecruitRacePage(-1)" ${window.SDF_RECRUIT_UI.page<=1?'disabled':''}>Previous</button><span>${window.SDF_RECRUIT_UI.page}/${pages}</span><button class="btn neutral" onclick="changeRecruitRacePage(1)" ${window.SDF_RECRUIT_UI.page>=pages?'disabled':''}>Next</button></div>`;
 $('recruitTable').innerHTML=rows.map(r=>{const status=statusFor(r),rc=race(r),reason=status.canRecruit?status.warning:status.activeReason;return`<tr class="${!status.canRecruit?'recruit-blocked':''}"><td>${r.rank}</td><td><button class="link-button" onclick="openRecruit('${r.id}')">${r.name}</button><span class="sub">${r.arch} · ${r.personality}</span><div class="motivation-inline">${r.motivations.slice(0,2).map(m=>`<span>${m.label}</span>`).join('')}</div></td><td>${r.pos}</td><td class="star">${star(r.stars)}${!status.access.allowed?'<span class="lock-badge">TIER</span>':status.lockedOut?'<span class="lock-badge">CUT</span>':status.eligibility.locked?'<span class="lock-badge">DEALBREAKER</span>':''}</td><td>${r.city}, ${r.home}<span class="sub">${distance(state.school,r)} mi${state.school.pipelines.includes(r.home)?' · PIPELINE':''}</span></td><td><span class="stage">${stageFor(r)}</span></td><td>${r.scouted?r.ovr:'??'}</td><td>${projectedRecruitUpside(r)}</td><td>${r.scouted?(r.scoutConfidence||0)+'%':'—'}</td><td>${n[r.pos].label}<span class="sub">PT grade ${letterGrade(playingTimeGrade(r,state.school))}</span></td><td><span class="dealbreaker-badge">${dealbreakerDisplay(r)}</span></td><td><div class="race-summary">${userRaceSummary(r)}<div class="race-compact">${raceCompact(r,3)}</div></div>${reason?`<span class="sub ineligible">${reason}</span>`:''}</td><td>${planSelect(r,status)}</td><td><div class="actions">${recruitButtons(r,status)}</div></td></tr>`}).join('');
 $('recruitCardList').innerHTML=rows.map(r=>{const status=statusFor(r),rc=race(r),notice=status.canRecruit?status.warning:status.activeReason;return`<article class="mobile-data-card ${!status.canRecruit?'recruit-blocked':''}"><div class="mobile-data-head"><div><h3>#${r.rank} ${r.name}</h3><span class="sub">${r.pos} · ${r.arch} · ${r.city}, ${r.home}</span></div><span class="star">${star(r.stars)}</span></div><div class="motivation-row">${motivationChips(r)}</div><div class="mobile-data-grid"><div><small>YOUR RANK</small><b>#${rc.user?.rank||'—'}</b></div><div><small>YOUR INTEREST</small><b>${Math.round(rc.user?.score||0)}</b></div><div><small>LEADER</small><b>${rc.leader?.school.name||'—'}</b></div><div><small>FIT</small><b>${rc.user?.grade||'—'}</b></div><div><small>PLAYING TIME</small><b>${letterGrade(playingTimeGrade(r,state.school))}</b></div><div><small>NIL ASK</small><b>${formatNilMoney(nilOfferAmount(r))}</b></div></div><div class="mobile-race-list">${raceCompact(r,5)}</div>${notice?`<div class="recruit-status-message ${status.canRecruit?'warning':''}"><b>${status.canRecruit?'Dealbreaker warning':'Active recruiting locked'}</b><span>${notice}</span></div>`:planSelect(r,status)}<div class="mobile-actions">${recruitButtons(r,status,true)}</div></article>`}).join('')||'<p class="muted">No prospects match these filters.</p>';
 const ca=Math.round(avg(state.commits.map(r=>r.ovr))||0),score=Math.round(state.commits.reduce((s,r)=>s+r.ovr+r.stars*5+(r.pot||r.ovr)*.2,0));$('classCards').innerHTML=metric('Commits',state.commits.length)+metric('Average OVR',ca||'—')+metric('5-stars',state.commits.filter(r=>r.stars===5).length)+metric('Class Score',score);$('commitList').innerHTML=state.commits.map(r=>`<div class="commit-card"><h4>${r.name}</h4><div>${r.pos} · ${r.arch} · <span class="star">${star(r.stars)}</span></div><span class="sub">${r.city}, ${r.home} · OVR ${r.ovr} · ${state.signingDayResolved?`POT ${r.truePot||r.pot||'?'}`:`Projected Upside ${projectedRecruitUpside(r)}`}</span></div>`).join('')||'<p class="muted">No commitments yet.</p>'
}
window.changeRecruitRacePage=delta=>{window.SDF_RECRUIT_UI??={page:1};window.SDF_RECRUIT_UI.page+=delta;renderRecruitingV2();window.scrollTo({top:$('recruitPager').offsetTop-100,behavior:'smooth'})};
window.renderRecruiting=renderRecruitingV2;

window.openRecruit=id=>{
 const r=findR(id);if(!r)return;ensureRecruit(r);const attrs=r.attrs||{},status=statusFor(r),amount=nilOfferAmount(r),nilOffered=state.nilCommitments?.[r.id],rc=race(r),leader=rc.leader,comparison=leader?.id===USER_ID()?rc.second:leader;
 const topSchools=rc.entries.slice(0,8).map(e=>`<div class="top-school-row ${e.id===USER_ID()?'user-school':''}"><span class="top-school-rank">#${e.rank}</span><img src="${logoFor(e.id)}" alt=""><div><b>${e.school.name}</b><small>${e.offered?'Scholarship offered · ':''}Fit ${e.grade}${e.trend?` · ${e.trend>0?'▲':'▼'}${Math.abs(e.trend).toFixed(1)}`:''}</small></div><strong>${Math.round(e.score)}</strong></div>`).join('');
 const comparisons=r.motivations.map(m=>{const your=schoolGrade(r,state.school,m.key),best=comparison?schoolGrade(r,comparison.school,m.key):0;return`<div class="motivation-grade"><div><b>${m.label}</b><small>${importanceLabel(m.weight)} · ${m.weight}% of decision</small></div><span><em>You</em><strong class="grade-${letterGrade(your).charAt(0).toLowerCase()}">${letterGrade(your)}</strong></span><span><em>${leader?.id===USER_ID()?'Next best':'Leader'}</em><strong>${letterGrade(best)}</strong></span></div>`}).join('');
 $('modalBody').innerHTML=`<span class="eyebrow">PROSPECT PROFILE</span><h2>${r.name}</h2><p>${r.pos} · ${r.arch} · <span class="star">${star(r.stars)}</span> · #${r.rank} nationally · ${r.personality}</p><div class="metric-grid">${metric('Hometown',`${r.city}, ${r.home}`)}${metric('Distance',distance(state.school,r)+' mi')}${metric('Your Rank',rc.user?`#${rc.user.rank}`:'Outside top schools')}${metric('Your Interest',Math.round(rc.user?.score||0))}${metric('Interest Limit',status.eligibility.cap>=100?'100/100':`${status.eligibility.cap}/100`)}${metric('Leader',leader?.school.name||'—')}${metric('Gap',rc.user?.rank===1?'Leading':`${Math.round(rc.gap||0)} points`)}${metric('Program Fit',rc.user?.grade||'—')}${metric('Playing Time',letterGrade(playingTimeGrade(r,state.school)))}${metric('Overall',r.scouted?r.ovr:'??')}${metric('Projected Upside',projectedRecruitUpside(r))}${metric('Recruiting Access',status.canRecruit?'Eligible':'Locked')}${metric('NIL Remaining',formatNilMoney(state.nilBudget))}</div>${!status.canRecruit?`<div class="recruit-lock-message"><b>Active recruiting locked</b><span>${status.activeReason}</span><small>You may still view the race${status.canEvaluate?' and evaluate the prospect':''}.</small></div>`:status.warning?`<div class="recruit-status-message warning"><b>Dealbreaker warning</b><span>${status.warning}</span></div>`:''}<section class="recruit-profile-section"><h3>What Matters to ${r.name.split(' ')[0]}</h3><div class="motivation-row">${motivationChips(r)}</div><div class="motivation-comparison">${comparisons}</div></section><section class="recruit-profile-section"><h3>Top Schools</h3><p class="muted">Interest combines natural school fit, recruiting effort, scholarship offers, visits, promises, and NIL. Other schools recruit every week too.</p><div class="top-schools-list">${topSchools}</div></section>${r.relationship?`<div class="event-card relationship-line"><b>${r.relationship.type}</b><span class="sub">${r.relationship.otherName}</span></div>`:''}${r.scouted?`<section class="recruit-profile-section"><h3>Scouting</h3><div class="metric-grid">${metric('Confidence',(r.scoutConfidence||0)+'%')}${metric('Evaluation',r.evalTag||'On track')}${metric('Overall',r.ovr)}${metric('Projected Upside',projectedRecruitUpside(r))}</div>${window.SDF_V144?.attributeHtml?.(r)||`<div class="metric-grid">${metric('Speed',attrs.speed)}${metric('Strength',attrs.strength)}${metric('Skill',attrs.skill)}${metric('Awareness',attrs.awareness)}</div>`}</section>`:''}<section class="recruit-profile-section"><h3>Recruiting Actions</h3><p class="muted">Available school pool: <b>${state.weeklyHours} hours</b>. Each prospect has a ${CONTACT_CAP}-hour weekly cap, and each contact action may be used once. All limits reset next week.</p>${r.lastActionMessage?`<div class="action-feedback">${r.lastActionMessage}</div>`:''}<div class="recruit-action-grid">${Object.values(ACTIONS).map(a=>{const p=actionPreview(r,a.key);return`<div class="recruit-action-card"><h4>${a.label} <span>${a.hours} hr${a.hours===1?'':'s'}</span></h4><p>${a.description}</p><small>${p.used?'Already used this week':`${p.weeklySpent}/${CONTACT_CAP} contact hours used`} · Estimated influence: ${p.estimate.toFixed(1)}</small><button class="btn ${a.key==='HARD_SELL'?'primary':a.key==='FAMILY'?'warning':'neutral'} full" onclick="recruitAction('${r.id}','${a.key}')" ${!canUseAction(r,a.key,status).allowed?'disabled':''}>Use ${a.label}</button></div>`}).join('')}</div></section><section class="recruit-profile-section"><h3>Scholarship, Visit & NIL</h3><div class="actions"><button class="btn neutral" onclick="offer('${r.id}')" ${!status.canRecruit||r.offered||state.scholarships<=0?'disabled':''}>${r.offered?'Scholarship Offered':'Offer Scholarship'}</button>${nilButton(r,status,true)}<button class="btn warning" onclick="visit('${r.id}')" ${!status.canRecruit||state.weeklyHours<20||r.visit?'disabled':''}>${r.visit?'Visit Scheduled':'Schedule Official Visit (20 hrs)'}</button><button class="btn neutral" onclick="promise('${r.id}','Early playing time')" ${!status.canRecruit?'disabled':''}>Promise Playing Time</button><button class="btn neutral" onclick="promise('${r.id}','No same-position signing')" ${!status.canRecruit?'disabled':''}>Promise Position Exclusivity</button><button class="btn danger" onclick="useNegativeRecruiting('${r.id}')" ${!status.canRecruit||state.weeklyHours<15?'disabled':''}>Negative Recruit Leader (15 hrs)</button></div><div class="nil-detail"><b>NIL request: ${formatNilMoney(amount)}</b><span>${nilOffered?`You offered ${formatNilMoney(nilOffered)} against a ${formatNilMoney(amount)} request — ${nilReaction(nilOffered,amount).label}.`:`You have ${formatNilMoney(state.nilBudget)} remaining. Choose the offer amount yourself.`}</span></div></section>`;
 $('modal').classList.remove('hidden');const card=$('modal').querySelector('.modal-card');if(card)card.scrollTop=0
};

window.openRecruitQuickMenu=id=>{
 const r=findR(id);if(!r)return;ensureRecruit(r);const status=statusFor(r),rc=race(r),amount=nilOfferAmount(r),notice=status.canRecruit?status.warning:status.activeReason;
 $('modalBody').innerHTML=`<span class="eyebrow">QUICK RECRUITING</span><div class="quick-recruit-head"><div><h2>${r.name}</h2><p>${r.pos} · ${r.arch} · <span class="star">${star(r.stars)}</span></p></div><button class="btn success" onclick="openRecruit('${r.id}')">Full Profile</button></div><div class="metric-grid">${metric('Your Rank',rc.user?`#${rc.user.rank}`:'Outside list')}${metric('Interest',Math.round(rc.user?.score||0))}${metric('Interest Limit',status.eligibility.cap>=100?'100/100':`${status.eligibility.cap}/100`)}${metric('Leader',rc.leader?.school.name||'—')}${metric('Hours Left',state.weeklyHours)}${metric('NIL Pool',formatNilMoney(state.nilBudget))}${metric('NIL Ask',formatNilMoney(amount))}</div>${notice?`<div class="recruit-status-message ${status.canRecruit?'warning':''}"><b>${status.canRecruit?'Dealbreaker warning':'Active recruiting locked'}</b><span>${notice}</span></div>`:''}<h3>Contact Actions</h3><div class="quick-action-grid">${Object.values(ACTIONS).map(a=>{const p=actionPreview(r,a.key);return`<button class="btn ${a.key==='HARD_SELL'?'primary':a.key==='FAMILY'?'warning':'neutral'}" onclick="recruitAction('${r.id}','${a.key}');openRecruitQuickMenu('${r.id}')" ${!canUseAction(r,a.key,status).allowed?'disabled':''}><b>${p.used?'Used: ':''}${a.label}</b><span>${a.hours} hr${a.hours===1?'':'s'} · ${p.weeklySpent}/${CONTACT_CAP} used · est. ${p.estimate.toFixed(1)}</span></button>`}).join('')}</div><h3>More Options</h3><div class="quick-action-grid"><button class="btn neutral" onclick="offer('${r.id}');openRecruitQuickMenu('${r.id}')" ${!status.canRecruit||r.offered||state.scholarships<=0?'disabled':''}>${r.offered?'Scholarship Offered':'Offer Scholarship'}</button><button class="btn neutral" onclick="scout('${r.id}');openRecruitQuickMenu('${r.id}')" ${!status.canEvaluate||r.scouted||state.weeklyHours<8?'disabled':''}>${r.scouted?'Scouted':'Scout · 8 hrs'}</button>${nilButton(r,status,true)}<button class="btn warning" onclick="visit('${r.id}');openRecruitQuickMenu('${r.id}')" ${!status.canRecruit||state.weeklyHours<20||r.visit?'disabled':''}>${r.visit?'Visit Scheduled':'Official Visit · 20 hrs'}</button><button class="btn neutral" onclick="promise('${r.id}','Early playing time');openRecruitQuickMenu('${r.id}')" ${!status.canRecruit?'disabled':''}>Promise Playing Time</button><button class="btn neutral" onclick="promise('${r.id}','No same-position signing');openRecruitQuickMenu('${r.id}')" ${!status.canRecruit?'disabled':''}>Promise Position Exclusivity</button><button class="btn danger" onclick="useNegativeRecruiting('${r.id}');openRecruitQuickMenu('${r.id}')" ${!status.canRecruit||state.weeklyHours<15?'disabled':''}>Negative Recruit · 15 hrs</button></div>`;
 $('modal').classList.remove('hidden');const card=$('modal').querySelector('.modal-card');if(card)card.scrollTop=0
};
window.setPlan=(id,plan)=>{const r=findR(id);if(!r)return;ensureRecruit(r);if(plan==='NONE'){r.weeklyPlan='NONE';window.renderAll();autosave();return}if(!addToBoard(r))return;const status=statusFor(r);if(!status.canRecruit){r.weeklyPlan='NONE';rejectRecruitAction(r,status.activeReason);return}r.weeklyPlan=PLAN_ACTION_MAP[plan]||plan;window.renderAll();autosave('Weekly recruiting plan')};
window.offer=id=>{const r=findR(id);if(!r)return;ensureRecruit(r);const status=statusFor(r);if(!status.canRecruit){rejectRecruitAction(r,status.activeReason);return}if(r.offered||state.scholarships<=0||!addToBoard(r))return;r.offered=true;state.scholarships--;recalculateRecruit(r,true);maybeImmediateCommit(r);state.news.push(`${r.name} received a scholarship offer from ${state.school.name}.`);window.renderAll();autosave('Scholarship offer')};
function updateNilOfferPreview(id){const r=findR(id),input=$('nilOfferInput'),out=$('nilOfferPreview');if(!r||!input||!out)return;const amount=Math.max(0,Number(input.value||0)),ask=nilOfferAmount(r),reaction=nilReaction(amount,ask),diff=amount-ask;out.className=`nil-offer-reaction ${reaction.tone}`;out.innerHTML=`<b>${reaction.label}</b><span>${formatNilMoney(amount)} offer · ${diff===0?'matches the request':diff>0?`${formatNilMoney(diff)} above the request`:`${formatNilMoney(Math.abs(diff))} below the request`} · Interest effect ${reaction.bonus>=0?'+':''}${reaction.bonus}</span>`}
window.setNilOfferPreset=(id,amount)=>{const input=$('nilOfferInput'),number=$('nilOfferNumber');if(!input)return;const value=Math.max(0,Math.round(Number(amount||0)/1000)*1000);input.value=value;if(number)number.value=value;updateNilOfferPreview(id)};
window.submitNilOffer=id=>{const r=findR(id);if(!r)return;ensureRecruit(r);const status=statusFor(r),ask=nilOfferAmount(r),current=Number(state.nilCommitments?.[r.id]||0),input=$('nilOfferInput'),amount=Math.max(0,Math.round(Number(input?.value||0)/1000)*1000),available=Number(state.nilBudget||0)+current;if(!status.canRecruit){rejectRecruitAction(r,status.activeReason);return}if(!addToBoard(r))return;if(amount>available){rejectRecruitAction(r,`not enough NIL money — ${formatNilMoney(available)} is available including your current offer`);return}state.nilCommitments??={};state.nilBudget=available-amount;if(amount)state.nilCommitments[r.id]=amount;else delete state.nilCommitments[r.id];const reaction=nilReaction(amount,ask);if(reaction.bonus<0)r.nilTrustPenalty=clamp(Number(r.nilTrustPenalty||0)+Math.abs(reaction.bonus)*.25,0,4);else if(reaction.bonus>=9)r.nilTrustPenalty=Math.max(0,Number(r.nilTrustPenalty||0)-2);r.nilReaction={amount,ask,label:reaction.label,bonus:reaction.bonus,week:state.week,year:state.year};recalculateRecruit(r,true);maybeImmediateCommit(r);state.news.push(`${r.name}: NIL offer set at ${formatNilMoney(amount)} against a ${formatNilMoney(ask)} request — ${reaction.label}.`);$('modal').classList.add('hidden');window.renderAll();autosave('NIL negotiation')};
window.offerNil=id=>{const r=findR(id);if(!r)return;ensureRecruit(r);const status=statusFor(r),ask=nilOfferAmount(r),current=Number(state.nilCommitments?.[r.id]||0),available=Number(state.nilBudget||0)+current;if(!status.canRecruit){rejectRecruitAction(r,status.activeReason);return}const max=Math.max(ask*2,available),defaultOffer=current||ask,presets=[Math.round(ask*.67/1000)*1000,Math.round(ask/1000)*1000,Math.round(ask*1.33/1000)*1000];$('modalBody').innerHTML=`<span class="eyebrow">NIL NEGOTIATION</span><h2>${r.name}</h2><p class="muted">Choose the actual NIL offer. Meeting or beating the request helps; a lowball can reduce interest.</p><div class="metric-grid">${metric('Requested',formatNilMoney(ask))}${metric('Current Offer',current?formatNilMoney(current):'None')}${metric('Available Pool',formatNilMoney(available))}${metric('Priority',r.motivations?.find(m=>m.key==='NIL')?.label||r.priority)}</div><div class="nil-preset-row"><button class="btn danger" onclick="setNilOfferPreset('${r.id}',${presets[0]})">Lowball ${formatNilMoney(presets[0])}</button><button class="btn neutral" onclick="setNilOfferPreset('${r.id}',${presets[1]})">Meet Ask ${formatNilMoney(presets[1])}</button><button class="btn success" onclick="setNilOfferPreset('${r.id}',${presets[2]})">Beat Ask ${formatNilMoney(presets[2])}</button></div><label class="nil-offer-control"><span>Custom NIL offer</span><input id="nilOfferInput" type="range" min="0" max="${Math.max(1000,Math.min(max,available))}" step="1000" value="${Math.min(defaultOffer,available)}" oninput="updateNilOfferPreview('${r.id}')"><input id="nilOfferNumber" class="nil-number-input" type="number" min="0" max="${available}" step="1000" value="${Math.min(defaultOffer,available)}" onchange="document.getElementById('nilOfferInput').value=this.value;updateNilOfferPreview('${r.id}')" oninput="document.getElementById('nilOfferInput').value=this.value;updateNilOfferPreview('${r.id}')"></label><div id="nilOfferPreview" class="nil-offer-reaction"></div><div class="actions"><button class="btn primary" onclick="submitNilOffer('${r.id}')">Submit NIL Offer</button>${current?`<button class="btn danger" onclick="setNilOfferPreset('${r.id}',0);submitNilOffer('${r.id}')">Withdraw NIL Offer</button>`:''}<button class="btn neutral" onclick="openRecruit('${r.id}')">Back to Profile</button></div>`;$('modal').classList.remove('hidden');updateNilOfferPreview(r.id);const card=$('modal').querySelector('.modal-card');if(card)card.scrollTop=0};
window.updateNilOfferPreview=updateNilOfferPreview;
window.visit=id=>{const r=findR(id);if(!r)return;ensureRecruit(r);const status=statusFor(r);if(!status.canRecruit){rejectRecruitAction(r,status.activeReason);return}if(state.weeklyHours<20||r.visit||!addToBoard(r))return;state.weeklyHours-=20;r.visit=true;state.news.push(`${r.name} scheduled an official visit.`);$('modal').classList.add('hidden');window.renderAll();autosave('Official visit')};
window.promise=(id,p)=>{const r=findR(id);if(!r)return;ensureRecruit(r);const status=statusFor(r);if(!status.canRecruit){rejectRecruitAction(r,status.activeReason);return}if(!addToBoard(r))return;r.promise=p;const motivation=p==='Early playing time'?'PLAYING_TIME':'PLAYING_TIME',grade=schoolGrade(r,state.school,motivation),boost=clamp(2+(grade-55)/12,1,7);r.promiseBoostBySchool[USER_ID()]=Math.max(Number(r.promiseBoostBySchool[USER_ID()]||0),boost);state.promises.push({id:crypto.randomUUID(),targetId:r.id,target:r.name,type:p,year:state.year,resolved:false,kept:null});recalculateRecruit(r,true);maybeImmediateCommit(r);$('modal').classList.add('hidden');window.renderAll();autosave('Recruiting promise')};
window.useNegativeRecruiting=id=>{const r=findR(id);if(!r)return;ensureRecruit(r);const status=statusFor(r),rc=race(r);if(!status.canRecruit){rejectRecruitAction(r,status.activeReason);return}if(state.weeklyHours<15||!rc.leader||rc.leader.id===USER_ID()||!addToBoard(r))return;state.weeklyHours-=15;const target=rc.leader,ourFit=weightedFit(r,state.school),theirFit=weightedFit(r,target.school),success=ourFit+seededRange(`${r.id}-${state.week}-neg`,0,18)>theirFit+8;if(success){r.recruitInfluence[target.id]=Math.max(0,Number(r.recruitInfluence[target.id]||0)-seededRange(`${r.id}-${state.week}-negdrop`,3,7));r.recruitInfluence[USER_ID()]=clamp(Number(r.recruitInfluence[USER_ID()]||0)+2,0,36);state.news.push(`Negative recruiting against ${target.school.name} gained traction with ${r.name}.`)}else{r.recruitInfluence[USER_ID()]=Math.max(0,Number(r.recruitInfluence[USER_ID()]||0)-2);state.news.push(`Negative recruiting backfired with ${r.name}.`)}recalculateRecruit(r,true);maybeImmediateCommit(r);window.renderAll();autosave('Negative recruiting')};
window.autoBoard=()=>{const n=needs(),tier=schoolTier(state.school),preserved=state.recruits.filter(r=>!r.committedTo&&(r.offered||r.onBoard&&r.weeklyPlan&&r.weeklyPlan!=='NONE')).slice(0,RECRUIT_BOARD_LIMIT);state.recruits.filter(r=>r.onBoard&&!preserved.includes(r)).forEach(r=>{r.onBoard=false;r.weeklyPlan='NONE'});preserved.forEach(r=>r.onBoard=true);const eligible=state.recruits.filter(r=>{ensureRecruit(r);return!r.committedTo&&!preserved.includes(r)&&statusFor(r).access.allowed&&dealbreakerMet(r,state.school)}).sort((a,b)=>n[b.pos].sev-n[a.pos].sev||weightedFit(b,state.school)-weightedFit(a,state.school)||a.rank-b.rank),chosen=[...preserved,...eligible.slice(0,Math.max(0,28-preserved.length))];if(state.week>=4&&['REBUILD','REGIONAL'].includes(tier.key)){eligible.filter(r=>r.stars===2&&!chosen.includes(r)).sort((a,b)=>n[b.pos].sev-n[a.pos].sev||weightedFit(b,state.school)-weightedFit(a,state.school)).slice(0,Math.max(0,RECRUIT_BOARD_LIMIT-chosen.length)).forEach(r=>chosen.push(r))}eligible.filter(r=>!chosen.includes(r)).slice(0,Math.max(0,RECRUIT_BOARD_LIMIT-chosen.length)).forEach(r=>chosen.push(r));chosen.slice(0,RECRUIT_BOARD_LIMIT).forEach(r=>r.onBoard=true);window.renderAll();autosave('Auto board')};

function applyPlans(){
 state.recruits.filter(r=>!r.committedTo&&r.weeklyPlan&&r.weeklyPlan!=='NONE'&&statusFor(r).canRecruit).sort((a,b)=>(race(a).user?.rank||99)-(race(b).user?.rank||99)||a.rank-b.rank).forEach(r=>{const key=PLAN_ACTION_MAP[r.weeklyPlan]||r.weeklyPlan;if(ACTIONS[key]&&canUseAction(r,key,statusFor(r)).allowed)performAction(r,key,{silent:true,fromPlan:true})})
}
function advanceAi(r){
 ensureRecruit(r);buildAiRecruitingBoards(false);const active=r.contenderIds.filter(id=>id!==USER_ID()&&!(r.lockedOut||[]).includes(id)&&aiBoardHas(id,r.id)&&canSchoolSign(id)).map(schoolById).filter(Boolean).sort((a,b)=>contenderScore(r,b)-contenderScore(r,a)).slice(0,8);
 active.forEach((s,index)=>{
  if(state.week>=2&&index<Math.min(6,2+r.stars))r.offerBySchool[s.id]=true;
  const fitScore=weightedFit(r,s),power=(s.prestige+s.recent+s.facilities+s.pro)/4,diff=difficultyConfig().ai||1,gain=(1.1+fitScore/52+power/72+seededRange(`${r.id}-${s.id}-${state.year}-${state.week}-ai`,0,20)/10)*diff*(index<3?1.13:.83);
  r.recruitInfluence[s.id]=clamp(Number(r.recruitInfluence[s.id]||0)+gain,0,50);
  if(state.week>=5&&state.week<=9&&index<3&&!r.aiVisitWeeks[s.id]&&seededFloat(`${r.id}-${s.id}-visit-${state.week}`)<.24){r.aiVisitWeeks[s.id]=state.week;r.visitBoostBySchool[s.id]=clamp(Number(r.visitBoostBySchool[s.id]||0)+4+fitScore/25,0,12)}
 })
}
function resolveVisit(r){if(!r.visit)return;const fitScore=weightedFit(r,state.school),home=state.schedule?.[Math.max(0,state.week-1)]?.home?2:0,boost=clamp(4+fitScore/18+home+seededRange(`${r.id}-${state.week}-visit`,0,3),5,13);r.visitBoostBySchool[USER_ID()]=clamp(Number(r.visitBoostBySchool[USER_ID()]||0)+boost,0,14);r.visit=false;state.news.push(`${r.name}'s official visit added ${Math.round(boost)} influence.`)}
function makeCuts(r){
 // List cuts are based on how long this prospect has been available, not only
 // the global season week. Late evaluations therefore receive a real open period.
 const entryWeek=Math.max(1,Number(r.entryWeek||1)),recruitWeek=Math.max(1,state.week-entryWeek+1);
 if(r.stars===2){
  if(recruitWeek<8)return;
  if(r.onBoard&&r.offered)return;
 }
 const openingWeek=r.stars===3?7:6;
 if(recruitWeek<openingWeek)return;const rc=race(r),leader=rc.leader;if(!leader)return;
 const offered=rc.entries.filter(e=>e.offered).length;
 let cut,margin,minimum;
 if(r.stars===2){cut=10;margin=20;minimum=56}
 else if(recruitWeek>=10){cut=3;margin=7;minimum=74}
 else if(recruitWeek>=8){cut=5;margin=10;minimum=68}
 else{cut=10;margin=16;minimum=60}
 if(leader.score<minimum||offered<Math.min(r.stars===2?3:4,cut))return;
 const cutoff=rc.entries[Math.min(cut-1,rc.entries.length-1)]?.score||0;
 const userProtection=e=>e.id===USER_ID()&&r.onBoard&&r.offered&&(r.stars===2||e.score>=cutoff-12);
 const keep=rc.entries.filter((e,i)=>i<cut||e.score>=cutoff-margin||userProtection(e)).map(e=>e.id);
 const newlyCut=rc.entries.filter(e=>!keep.includes(e.id)).map(e=>e.id);
 r.lockedOut=unique([...(r.lockedOut||[]),...newlyCut]);
 if(r.lockedOut.includes(USER_ID()))r.weeklyPlan='NONE'
}
function commitRecruit(r,entry,reason){
 if(!entry||r.committedTo||!canSchoolSign(entry.id))return false;r.committedTo=entry.id;r.committedWeek=state.week;r.weeklyPlan='NONE';r.onBoard=false;
 if(entry.id===USER_ID()){
  if(r.trueOvr){r.ovr=r.trueOvr;r.pot=r.truePot||r.pot;r.scoutConfidence=100}
  if(!state.commits.some(x=>x.id===r.id))state.commits.push(r);
  state.news.push(`${r.stars}-star ${r.pos} ${r.name} committed to ${state.school.name}${reason?` ${reason}`:''}.`)
 }else{state.aiSigningCounts??={};state.aiSigningCounts[entry.id]=aiClassCount(entry.id)+1;state.news.push(`${r.name} committed to ${entry.school.name}${reason?` ${reason}`:''}.`)}
 return true
}
function maybeImmediateCommit(r){
 if(r.committedTo)return true;const rc=race(r),eligible=rc.entries.filter(e=>e.offered&&e.score>=99.5&&canSchoolSign(e.id)).sort((a,b)=>b.score-a.score||b.fit-a.fit);
 if(!eligible.length)return false;return commitRecruit(r,eligible[0],'after reaching 100 interest')
}
function maybeCommit(r){
 if(r.committedTo||maybeImmediateCommit(r)||state.week<3)return;const rc=race(r),eligible=rc.entries.filter(e=>e.offered&&canSchoolSign(e.id)),leader=eligible[0],second=eligible[1];if(!leader)return;
 const score=leader.score,lead=score-(second?.score||0);
 const threshold=state.week>=11?66:state.week>=9?72:state.week>=7?78:state.week>=5?84:90;
 const requiredLead=state.week>=9?2:state.week>=5?4:5;
 if(score<threshold||lead<requiredLead)return;
 let chance=(state.week-2)*4+(score-threshold)*1.6+lead*2;
 if(['Loyal','Homesick'].includes(r.personality))chance+=7;
 if(r.personality==='Ambitious')chance-=4;
 if(r.personality==='Volatile')chance+=seededRange(`${r.id}-volatile-${state.week}`,-8,8);
 if(Math.random()*100<chance)commitRecruit(r,leader,'after winning the recruiting battle')
}
window.applyWeeklyPlans=applyPlans;
window.resolveRecruiting=()=>{ensureAllRecruits();applyPlans();state.recruits.filter(r=>!r.committedTo).forEach(r=>{advanceAi(r);resolveVisit(r);recalculateRecruit(r,true);if(maybeImmediateCommit(r))return;makeCuts(r);recalculateRecruit(r,true);maybeCommit(r)})};
window.prepareSigningDay=()=>{state.phase='SIGNING';state.seasonDone=true;const undecided=state.recruits.filter(r=>!r.committedTo&&r.offered&&race(r).user?.rank<=5).sort((a,b)=>(race(a).user?.rank||99)-(race(b).user?.rank||99)||race(b).user.score-race(a).user.score).slice(0,24);$('signingDayList').innerHTML=undecided.map(r=>{const rc=race(r);return`<div class="commit-card"><h4>${r.name}</h4><div>${r.pos} · ${r.arch} · <span class="star">${star(r.stars)}</span></div><span class="sub">You are #${rc.user?.rank||'—'} · ${Math.round(rc.user?.score||0)} interest · Leader ${rc.leader?.school.name||'—'}</span></div>`}).join('')||'<p class="muted">No major decisions remain.</p>';$('signingDayPanel').classList.remove('hidden');showTab('season')};
window.resolveSigningDay=()=>{if(state.signingDayResolved)return;state.recruits.filter(r=>!r.committedTo).forEach(r=>{ensureRecruit(r);const rc=race(r),top=rc.entries.slice(0,5).filter(e=>e.offered&&canSchoolSign(e.id));if(!top.length)return;const total=top.reduce((n,e)=>n+Math.exp(e.score/13),0),roll=Math.random()*total;let acc=0,winner=top[0];for(const e of top){acc+=Math.exp(e.score/13);if(roll<=acc){winner=e;break}}commitRecruit(r,winner,'on Signing Day')});checkDecommits();state.signingDayResolved=true;$('signingDayPanel').classList.add('hidden');prepareChampionshipWeek();window.renderAll();autosave('Signing Day')};

const originalGenRecruits=window.genRecruits;window.genRecruits=function(n){const result=originalGenRecruits(n);if(!window.SDF_DEFER_RECRUITING_INIT)result.forEach(ensureRecruit);return result};
const originalStart=window.start;window.start=function(...args){const result=originalStart.apply(this,args);if(window.SDF_DEFER_RECRUITING_INIT){state.recruitingInitializationPending=true;return result}ensureAllRecruits();buildAiRecruitingBoards(true);window.renderAll();autosave('Recruiting model initialized');return result};
const originalBeginYear=window.beginYear;window.beginYear=function(...args){const result=originalBeginYear.apply(this,args);if(window.SDF_DEFER_RECRUITING_INIT){state.recruitingInitializationPending=true;return result}ensureAllRecruits();buildAiRecruitingBoards(true);return result};

function resetPageOnFilters(){window.SDF_RECRUIT_UI??={page:1};window.SDF_RECRUIT_UI.page=1}
['positionFilter','starFilter','recruitRegionFilter','statusFilter','sortFilter'].forEach(id=>{const el=$(id);if(el)el.addEventListener('change',()=>{resetPageOnFilters();setTimeout(renderRecruitingV2,0)})});$('recruitSearch')?.addEventListener('input',()=>{resetPageOnFilters();setTimeout(renderRecruitingV2,0)});

window.migrateDynastyCore?.();ensureAllRecruits();if(state.school)buildAiRecruitingBoards(false);if(state.school&&document.getElementById('recruitingTab')&&!document.getElementById('recruitingTab').classList.contains('hidden'))renderRecruitingV2();
window.SDF_RECRUITING_V2={
 nilReaction,weeklyContactHours,canUseAction,CONTACT_CAP,ACTIONS,ensureRecruit,race,weightedFit,schoolGrade,
 performAction,MOTIVATIONS,lateOpportunity,maybeImmediateCommit,makeCuts,statusFor,boardCount,
 RECRUIT_BOARD_LIMIT,CLASS_SIGNING_LIMIT,buildAiRecruitingBoards,initializeRecruitingModelAsync,
 aiClassCount,renderRecruitingV2,dealbreakerMet,
 openRecruit:(id)=>window.openRecruit(id),
 openNilNegotiation:(id)=>window.offerNil(id),
 autoBoard:()=>window.autoBoard()
};
})();

(()=>{
'use strict';
const FACILITIES={
 training:{name:'Training Center',icon:'🏋️',benefit:'Improves player development and raises your Athletic Facilities grade for recruits.',impact:'Facilities-focused recruits · offseason progression',rating:'facilities'},
 recruiting:{name:'Recruiting Department',icon:'📋',benefit:'Adds weekly recruiting capacity, improves evaluations and strengthens the school’s facilities pitch.',impact:'Scouting · recruiting hours · Athletic Facilities',rating:'facilities'},
 medical:{name:'Sports Medicine',icon:'🩺',benefit:'Reduces injuries and improves player recovery throughout the season.',impact:'Injury prevention · recovery',rating:null},
 stadium:{name:'Stadium & Atmosphere',icon:'🏟️',benefit:'Raises attendance, home atmosphere, fan approval and game-day recruiting value.',impact:'Visits · attendance · revenue',rating:null},
 academics:{name:'Academic Support',icon:'🎓',benefit:'Raises the academic grade recruits see and lowers eligibility risk.',impact:'Academic-focused recruits · eligibility',rating:'academics'},
 nilCollective:{name:'NIL Collective',icon:'💵',benefit:'Raises your NIL reputation and adds more money to the recruiting NIL pool.',impact:'NIL-focused recruits · NIL budget',rating:'nil'}
};
const subviews={};let queuedRecap=null,suppressGameModal=false;
const $v=id=>document.getElementById(id);
function money(n){return '$'+Math.round(Number(n||0)/1000)+'k'}
function teamLogo(id){return (typeof TEAM_BRANDING!=='undefined'&&TEAM_BRANDING?.[Number(id)]?.logo)||'icon.svg'}
function escapeText(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function ensureV103(){
 state.facilities??={training:1,recruiting:1,medical:1,stadium:1,academics:1};
 if(state.facilities.nilCollective==null)state.facilities.nilCollective=1;
 state.facilityProject??=null;state._facilityWeeklyBonusApplied??=null;
}
function level(key){return Math.max(1,Math.min(5,Math.floor(Number(state.facilities[key]||1))))}
function facilityCost103(key){let next=level(key)+1;return Math.round((155000+next*95000)*Math.pow(next,1.22))}
function projectWeeks(key){let next=level(key)+1;return next>=5?3:next>=3?2:1}
function nextFacilityEffect(key){let next=Math.min(5,level(key)+1);if(key==='training')return `Athletic Facilities ${state.school.facilities} → ${Math.min(99,state.school.facilities+4)}`;if(key==='recruiting')return `+${2*(next-1)} weekly recruiting hours and better scouting`;if(key==='medical')return `${Math.round((next-1)*8)}% facility injury reduction`;if(key==='stadium')return `Larger crowds, +${5+next} atmosphere`;if(key==='academics')return `Academic rating ${state.school.academics} → ${Math.min(99,state.school.academics+4)}`;if(key==='nilCollective')return `NIL rating ${state.school.nil} → ${Math.min(99,state.school.nil+5)} · +${money(next*50000)} pool`;return ''}
function completeFacilityProject(){
 let p=state.facilityProject;if(!p)return;let key=p.key,target=Math.min(5,p.targetLevel);state.facilities[key]=target;
 if(key==='training'){state.school.facilities=clamp(state.school.facilities+4,0,99);state.roster.forEach(x=>{if(x.year<=2&&x.ovr<x.pot&&Math.random()<.35)x.ovr++})}
 if(key==='recruiting'){state.school.facilities=clamp(state.school.facilities+2,0,99);state.school.hours=(state.school.hours||430)+12;if(state.headCoach?.baseRatings)state.headCoach.baseRatings.recruiting=clamp(Number(state.headCoach.baseRatings.recruiting||state.staff.head.recruiting)+1,0,99);else state.staff.head.recruiting=clamp(state.staff.head.recruiting+1,0,99);window.syncHeadCoachRatings?.()}
 if(key==='medical'){state.roster.filter(x=>x.injury).forEach(x=>x.injury.weeks=Math.max(1,x.injury.weeks-1))}
 if(key==='stadium'){state.stadium.capacity=Math.round((state.stadium.capacity||45000)+5000+target*1500);state.stadium.atmosphere=clamp((state.stadium.atmosphere||55)+5+target,0,99);state.fanApproval=clamp(state.fanApproval+4,0,100)}
 if(key==='academics')state.school.academics=clamp(state.school.academics+4,0,99);
 if(key==='nilCollective'){state.school.nil=clamp(state.school.nil+5,0,99);state.nilBudget+=(target*50000)}
 state.facilityProject=null;state.recruitingNeedsRecalcAll=true;(state.recruits||[]).forEach(r=>r.recruitingNeedsRecalc=true);state.achievementStats.facilityMax+=(target>=5?1:0);state.news.push(`${FACILITIES[key].name} reached Level ${target}. Recruiting and program benefits are now active.`);saveNow103('Facility completed');
}
function progressFacilityProject(){ensureV103();if(!state.facilityProject)return;state.facilityProject.remainingWeeks--;if(state.facilityProject.remainingWeeks<=0)completeFacilityProject();else state.news.push(`${FACILITIES[state.facilityProject.key].name} construction: ${state.facilityProject.remainingWeeks} week(s) remaining.`)}
function applyWeeklyFacilityBenefits(){ensureV103();if(state.phase!=='REGULAR'||state.week>12)return;let key=`${state.year}-${state.week}`;if(state._facilityWeeklyBonusApplied===key)return;state._facilityWeeklyBonusApplied=key;state.weeklyHours+=Math.max(0,(level('recruiting')-1)*2);state.nilBudget+=Math.max(0,(level('nilCollective')-1)*6000)}
function saveNow103(reason){try{window.SDF_RELEASE_TEST?.saveNow?.(reason,false,false)}catch{}}
window.upgradeFacility=function(key){ensureV103();if(!FACILITIES[key])return;if(state.facilityProject){alert(`Finish the current ${FACILITIES[state.facilityProject.key].name} project first.`);return}let current=level(key);if(current>=5)return;let cost=facilityCost103(key);if(state.budget<cost){alert(`You need ${money(cost)}. Current program funds: ${money(state.budget)}.`);return}state.budget-=cost;state.facilityProject={key,targetLevel:current+1,remainingWeeks:projectWeeks(key),cost,startedYear:state.year,startedWeek:state.week};state.news.push(`Construction started on ${FACILITIES[key].name} Level ${current+1}.`);window.renderAll();saveNow103('Facility project started')};
function renderFacilities103(){ensureV103();let grid=$v('facilityGrid');if(!grid)return;let project=state.facilityProject;let banner=project?`<div class="facility-project-banner"><b>${FACILITIES[project.key].icon} ${FACILITIES[project.key].name} upgrade underway</b><span>Level ${project.targetLevel} · ${project.remainingWeeks} week(s) remaining. Facility benefits apply when construction finishes.</span></div>`:'';
 grid.innerHTML=banner+`<div class="facility-summary">${Object.entries(FACILITIES).map(([key,d])=>{let lv=level(key),cost=lv<5?facilityCost103(key):0,busy=!!project,active=project?.key===key;return`<article class="facility-card-v103 ${active?'active-project':''}"><div class="facility-level-row"><h3>${d.icon} ${d.name}</h3><b>Level ${lv}/5</b></div><div class="facility-level-dots">${[1,2,3,4,5].map(n=>`<span class="${n<=lv?'on':''}"></span>`).join('')}</div><div class="facility-benefit">${d.benefit}</div><div class="facility-recruit-impact"><b>Recruiting/program impact</b><br>${d.impact}<br><strong>Next: ${nextFacilityEffect(key)}</strong></div><span class="sub">${lv>=5?'Maximum level':`${money(cost)} · ${projectWeeks(key)} week construction`}</span><button class="btn primary full" onclick="upgradeFacility('${key}')" ${lv>=5||busy||state.budget<cost?'disabled':''}>${active?'Construction Active':lv>=5?'Fully Upgraded':`Build Level ${lv+1}`}</button></article>`}).join('')}</div>`;
}
const oldRenderProgram=window.renderProgram;window.renderProgram=function(){ensureV103();oldRenderProgram?.();renderFacilities103();let exp=$v('tierExplanation');if(exp)exp.innerHTML=`Your program is <b>${schoolTier(state.school).label}</b>. Recruit interest grades update when facility construction finishes. Athletic Facilities, Academics and NIL are direct recruit priorities; training, medical and stadium projects improve development, availability and game-day results.<div class="program-path"><div class="program-path-card"><b>Want better recruits?</b><span>Upgrade Training, Recruiting, Academics or NIL based on the priorities shown in each prospect profile.</span></div><div class="program-path-card"><b>Want more wins?</b><span>Training, Medical and Stadium upgrades improve development, availability and home-field strength.</span></div><div class="program-path-card"><b>Budget strategy</b><span>Only one construction project can run at a time, so choose the weakness hurting your current class.</span></div></div>`};
function goProgram(section='facilities'){closeAnyModal();window.showTab('program');setSubview('programTab',section)}
window.goProgram=goProgram;
const oldOpenRecruit=window.openRecruit;window.openRecruit=function(id){oldOpenRecruit(id);let r=findR(id);if(!r)return;let keys=(r.motivations||[]).map(m=>m.key),relevant=[];if(keys.includes('FACILITIES'))relevant.push('Athletic Facilities');if(keys.includes('ACADEMICS'))relevant.push('Academic Support');if(keys.includes('NIL'))relevant.push('NIL Collective');if(relevant.length){$v('modalBody').insertAdjacentHTML('beforeend',`<div class="recruit-program-link"><b>Program investment can change this race</b><span>${escapeText(r.name)} highly values ${relevant.join(', ')}. Finished upgrades immediately improve the school grades used in his decision.</span><button class="btn primary" onclick="goProgram('facilities')">Open Facility Upgrades</button></div>`)}};
function closeAnyModal(){$v('modal')?.classList.add('hidden');$v('gameResultModal')?.classList.add('hidden')}
function seededQuarters(total,seed){let vals=[0,0,0,0],remain=Number(total)||0;for(let i=0;i<3;i++){let max=Math.max(0,Math.min(remain,14)),v=((seed>>>(i*4))%(max+1));v=Math.round(v/3)*3;if(v>remain)v=remain;vals[i]=v;remain-=v}vals[3]=remain;return vals}
function hash(v){let h=2166136261;for(let c of String(v)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function conferencePosition(){let sorted=(state.standings||[]).slice().sort((a,b)=>b.w-a.w||a.l-b.l),idx=sorted.findIndex(x=>x.id===state.school.id);return idx>=0?`#${idx+1}`:'—'}
function showGameResultModal(recap,playedWeek){if(!recap)return;let modal=$v('gameResultModal'),body=$v('gameResultBody'),opp=schools.find(s=>s.name===recap.opponent),seed=hash(`${state.year}-${playedWeek}-${recap.opponent}-${recap.us}-${recap.them}`),uq=seededQuarters(recap.us,seed),oq=seededQuarters(recap.them,seed>>1),next=state.phase==='REGULAR'?state.schedule[state.week-1]:null,ranking=state.rankings?.find(x=>x.id===state.school.id)?.rank;
 body.innerHTML=`<span class="eyebrow">WEEK ${playedWeek} FINAL · ${recap.win?'VICTORY':'DEFEAT'}</span><h2 id="gameResultTitle">${escapeText(recap.headline)}</h2><div class="game-final-head"><div class="game-final-team"><img src="${teamLogo(state.school.id)}" alt=""><b>${escapeText(state.school.name)}</b></div><div class="game-final-score"><strong>${recap.us}–${recap.them}</strong><span>${recap.win?'FINAL · WIN':'FINAL · LOSS'}</span></div><div class="game-final-team"><img src="${teamLogo(opp?.id)}" alt=""><b>${escapeText(recap.opponent)}</b></div></div><div class="table-wrap"><table class="quarter-table"><thead><tr><th>Team</th><th>1</th><th>2</th><th>3</th><th>4</th><th>F</th></tr></thead><tbody><tr><td>${escapeText(state.school.name)}</td>${uq.map(v=>`<td>${v}</td>`).join('')}<td><b>${recap.us}</b></td></tr><tr><td>${escapeText(recap.opponent)}</td>${oq.map(v=>`<td>${v}</td>`).join('')}<td><b>${recap.them}</b></td></tr></tbody></table></div><div class="result-summary-grid"><div><small>RECORD</small><b>${state.record.w}-${state.record.l}</b></div><div><small>CONFERENCE PLACE</small><b>${conferencePosition()}</b></div><div><small>NATIONAL RANK</small><b>${ranking?'#'+ranking:'NR'}</b></div></div><div class="box-score-grid">${Object.entries(recap.boxScore||{}).map(([k,v])=>`<div class="box-stat"><small>${k.replace(/([A-Z])/g,' $1')}</small><b>${v}</b></div>`).join('')}</div><h3>Standout Players</h3><div class="postgame-stars">${(recap.stars||[]).map(s=>`<div class="postgame-star">${escapeText(s)}</div>`).join('')||'<span class="muted">No standout data recorded.</span>'}</div>${next?`<div class="app-week-card"><img src="${teamLogo(next.oppId)}" alt=""><div><small class="eyebrow">NEXT: WEEK ${next.week}</small><strong>${next.home?'vs':'at'} ${escapeText(next.opponent)}</strong><span class="sub">${next.weather||'Clear'} · Power ${next.oppPower}</span></div></div>`:'<div class="postseason-empty">The regular season is complete. Open the Postseason tab for what comes next.</div>'}<div class="postgame-actions"><button class="btn primary" onclick="closeGameResult()">Continue</button><button class="btn neutral" onclick="closeGameResult();showTab('season')">View Schedule</button>${next?`<button class="btn neutral" onclick="closeGameResult();showTab('gameplan')">Prepare Next Game</button><button class="btn neutral" onclick="closeGameResult();showTab('recruiting')">Recruiting</button>`:`<button class="btn warning" onclick="closeGameResult();showTab('postseason')">Open Postseason Hub</button>`}</div>`;
 modal.classList.remove('hidden');body.scrollTop=0}
window.closeGameResult=function(){$v('gameResultModal').classList.add('hidden')};$v('closeGameResult').onclick=window.closeGameResult;$v('gameResultModal').addEventListener('click',e=>{if(e.target===$v('gameResultModal'))window.closeGameResult()});
const baseAdvance=window.advanceWeek;window.advanceWeek=function(...args){let oldRecap=state.lastGameRecap,played=state.week;let result=baseAdvance.apply(this,args);progressFacilityProject();applyWeeklyFacilityBenefits();window.renderAll();if(state.lastGameRecap&&state.lastGameRecap!==oldRecap&&!suppressGameModal){if(state.pendingEvent||!$v('modal').classList.contains('hidden'))queuedRecap={recap:state.lastGameRecap,played};else setTimeout(()=>showGameResultModal(state.lastGameRecap,played),40)}return result};
const baseChoose=window.chooseDecision;window.chooseDecision=function(...args){let out=baseChoose.apply(this,args);if(queuedRecap){let q=queuedRecap;queuedRecap=null;setTimeout(()=>showGameResultModal(q.recap,q.played),40)}return out};
const baseSimEnd=window.simEnd;window.simEnd=function(...args){suppressGameModal=true;let out=baseSimEnd.apply(this,args);suppressGameModal=false;if(state.lastGameRecap)setTimeout(()=>showGameResultModal(state.lastGameRecap,12),40);return out};$v('simToEndBtn').onclick=()=>window.simEnd();
const baseChamp=window.playChampionshipWeek;window.playChampionshipWeek=function(...args){let out=baseChamp.apply(this,args);progressFacilityProject();window.showTab('postseason');window.renderAll();return out};
const basePlayPost=window.playPostseason;window.playPostseason=function(...args){let out=basePlayPost.apply(this,args);progressFacilityProject();window.showTab('postseason');window.renderAll();return out};
const baseResolve=window.resolveSigningDay;window.resolveSigningDay=function(...args){let out=baseResolve.apply(this,args);window.showTab('postseason');window.renderAll();return out};
const baseCoachInjury=window.coachInjuryMult;window.coachInjuryMult=function(){let base=typeof baseCoachInjury==='function'?baseCoachInjury():1;return base*Math.max(.62,1-(level('medical')-1)*.08)};
const baseWeeklyPlanMod=window.weeklyGamePlanModifier;window.weeklyGamePlanModifier=function(g){let base=typeof baseWeeklyPlanMod==='function'?baseWeeklyPlanMod(g):0;return base+(g?.home?Math.max(0,level('stadium')-1):0)};
window.updateEligibility=function(){state.roster.forEach(p=>{let base=state.academicPolicy==='Strict'?.015:state.academicPolicy==='Balanced'?.035:.07,facilityReduction=(level('academics')-1)*.006,academicRisk=Math.random()<Math.max(.005,base-facilityReduction);state.playerEligibility[p.id]=!academicRisk;if(academicRisk)p.injury={weeks:1,type:'Academically ineligible'}})};
const baseBegin=window.beginYear;window.beginYear=function(...args){let out=baseBegin.apply(this,args);ensureV103();state.nilBudget+=Math.max(0,(level('nilCollective')-1)*35000);applyWeeklyFacilityBenefits();return out};
function renderNextSteps(){let el=$v('nextStepsPanel');if(!el)return;ensureV103();let next=currentOpponent?.(),board=(state.recruits||[]).filter(r=>r.onBoard&&!r.committedTo).length,injured=(state.roster||[]).filter(p=>p.injury).length,affordable=Object.keys(FACILITIES).some(k=>level(k)<5&&state.budget>=facilityCost103(k)),phase=state.phase;let items=[];
 if(phase==='REGULAR'){items.push({icon:'⭐',title:'Recruiting',text:`${state.weeklyHours} hours available · ${board} prospects on your board.`,tab:'recruiting',label:state.weeklyHours?'Use Recruiting Hours':'Review Your Board',attention:state.weeklyHours>0});items.push({icon:'📋',title:'Prepare for Week '+state.week,text:next?`${next.home?'Home vs':'Road at'} ${next.opponent}. Practice focus: ${state.weeklyPractice}.`:'No regular-season game remains.',tab:'gameplan',label:'Open Game Plan',attention:!!next});items.push({icon:'☷',title:'Roster Check',text:injured?`${injured} player(s) currently injured. Confirm replacements and snap shares.`:'Depth chart is available for manual rotations and snap shares.',tab:'roster',label:'Manage Roster',attention:injured>0});items.push({icon:'🏗️',title:'Build the Program',text:state.facilityProject?`${FACILITIES[state.facilityProject.key].name}: ${state.facilityProject.remainingWeeks} week(s) left.`:affordable?'Your budget can fund a facility upgrade that affects recruits and team performance.':'Review facility benefits and save toward the next project.',tab:'program',sub:'facilities',label:state.facilityProject?'View Construction':'Upgrade Facilities',attention:affordable&&!state.facilityProject})}
 else items.push({icon:'🏆',title:'Season Phase',text:`Current phase: ${phase}. Your postseason and offseason actions have their own dedicated hub.`,tab:phase==='CHAMP'||phase==='BOWLS'||phase==='POST'?'postseason':'season',label:'Continue Season',attention:true});
 el.innerHTML=`<div class="section-head"><div><span class="eyebrow">WHAT TO DO NEXT</span><h3>Coach’s Checklist</h3></div></div>${items.map(i=>`<article class="checklist-card ${i.attention?'attention':'done'}"><span class="check-icon">${i.icon}</span><h4>${i.title}</h4><p>${i.text}</p><button class="btn neutral" onclick="navigateCoachTask('${i.tab}','${i.sub||''}')">${i.label}</button></article>`).join('')}`}
window.navigateCoachTask=function(tab,sub){window.showTab(tab);if(sub)setSubview(tab+'Tab',sub)};
function movePostseasonPanels(){let host=$v('postseasonStageHost');['championshipPanel','bowlsPanel','postseasonPanel'].forEach(id=>{let el=$v(id);if(el&&el.parentElement!==host)host.appendChild(el)})}
function renderPostseason(){movePostseasonPanels();let ranking=state.rankings?.find(x=>x.id===state.school.id),seed=state.playoff?.findIndex(x=>x.id===state.school.id)+1,phase=state.phase,steps=[['Regular Season',phase!=='REGULAR'],['Conference Championship',['BOWLS','POST','PORTAL'].includes(phase)],['Bowls / CFP',['POST','PORTAL'].includes(phase)],['Offseason',phase==='PORTAL']];$v('postseasonStatusCards').innerHTML=metric('Record',`${state.record.w}-${state.record.l}`)+metric('National Rank',ranking?'#'+ranking.rank:'Unranked')+metric('Projected Seed',seed?`#${seed}`:'Outside field')+metric('Current Phase',phase);$v('postseasonGuide').innerHTML=steps.map(([label,done],i)=>`<div class="postseason-step ${done?'complete':(!done&&steps.slice(0,i).every(x=>x[1]))?'active':''}"><b>${done?'✓ ':''}${label}</b><span>${i===0?'Build the résumé':i===1?'Win the league':i===2?'Bowls and 12-team bracket':'Portal and program building'}</span></div>`).join('');let field=(state.playoff||[]).slice(0,12);$v('postseasonProjectionGrid').innerHTML=field.length?field.map((t,i)=>`<div class="playoff-card"><span class="eyebrow">${phase==='REGULAR'?'PROJECTED ':''}SEED ${i+1}</span><div class="team-mini"><img src="${teamLogo(t.id)}" alt=""><div><h3>${escapeText(t.name)}</h3><span class="sub">${t.record?.w||0}-${t.record?.l||0} · ${t.conference}</span></div></div></div>`).join(''):'<div class="postseason-empty">Playoff projections appear after rankings are generated. Continue the season to build your résumé.</div>'}
function setupSubview(tabId,entries,defaultKey){let tab=$v(tabId);if(!tab||tab.querySelector(':scope > .tab-section-nav'))return;let nav=document.createElement('div');nav.className='tab-section-nav';let help=document.createElement('p');help.className='tab-section-help';help.textContent='Choose a section instead of scrolling through the entire page.';tab.prepend(help);tab.prepend(nav);subviews[tabId]={entries,active:defaultKey};entries.forEach(e=>{let target=typeof e.target==='string'?document.querySelector(e.target):e.target;if(!target)return;target.dataset.subview=e.key;let b=document.createElement('button');b.className='tab-section-btn';b.textContent=e.label;b.onclick=()=>setSubview(tabId,e.key);b.dataset.key=e.key;nav.appendChild(b)});setSubview(tabId,defaultKey)}
window.setSubview=setSubview;function setSubview(tabId,key){let cfg=subviews[tabId];if(!cfg)return;cfg.active=key;let tab=$v(tabId);tab.querySelectorAll(':scope > section[data-subview]').forEach(s=>s.classList.toggle('subview-hidden',s.dataset.subview!==key));tab.querySelectorAll(':scope > .tab-section-nav .tab-section-btn').forEach(b=>b.classList.toggle('active',b.dataset.key===key));window.scrollTo({top:0,behavior:'smooth'})}
function installSubviewNavigation(){setupSubview('rosterTab',[{key:'depth',label:'Depth Chart',target:'#rosterTab > section:nth-of-type(1)'},{key:'injuries',label:'Injury Report',target:'#rosterTab > section:nth-of-type(2)'},{key:'players',label:'Full Roster',target:'#rosterTab > section:nth-of-type(3)'}],'depth');setupSubview('gameplanTab',[{key:'scout',label:'Opponent',target:'#gameplanTab > section:nth-of-type(1)'},{key:'practice',label:'Practice',target:'#gameplanTab > section:nth-of-type(2)'},{key:'plan',label:'Tendencies',target:'#gameplanTab > section:nth-of-type(3)'}],'scout');setupSubview('coachTab',[{key:'skills',label:'Skill Tree',target:'#coachTab > section:nth-of-type(1)'},{key:'leadership',label:'Leadership',target:'#coachTab > section:nth-of-type(2)'}],'skills');setupSubview('statsTab',[{key:'team',label:'Team Stats',target:'#statsTab > section:nth-of-type(1)'},{key:'logs',label:'Game Logs',target:'#statsTab > section:nth-of-type(2)'},{key:'awards',label:'Awards',target:'#statsTab > section:nth-of-type(3)'},{key:'archive',label:'Archive',target:'#statsTab > section:nth-of-type(4)'},{key:'national',label:'National',target:'#statsTab > section:nth-of-type(5)'},{key:'classes',label:'Classes',target:'#statsTab > section:nth-of-type(6)'}],'team');setupSubview('teamTab',[{key:'schemes',label:'Schemes',target:'#teamTab > section:nth-of-type(1)'},{key:'ratings',label:'Ratings',target:'#teamTab > section:nth-of-type(2)'},{key:'leaders',label:'Leaders',target:'#teamTab > section:nth-of-type(3)'}],'schemes');setupSubview('seasonTab',[{key:'schedule',label:'Schedule',target:'#seasonTab > section:nth-of-type(2)'},{key:'standings',label:'Standings',target:'#seasonTab > section:nth-of-type(1)'}],'schedule');setupSubview('programTab',[{key:'overview',label:'Overview',target:'#programTab > section:nth-of-type(1)'},{key:'facilities',label:'Facilities',target:'#programTab > section:nth-of-type(2)'},{key:'staff',label:'Staff',target:'#programTab > section:nth-of-type(3)'},{key:'promises',label:'Promises',target:'#programTab > section:nth-of-type(4)'}],'overview');setupSubview('dynastyTab',[{key:'achievements',label:'Achievements',target:'#dynastyTab > section:nth-of-type(1)'},{key:'career',label:'Career & Saves',target:'#dynastyTab > section:nth-of-type(2)'},{key:'sponsors',label:'Sponsor Rewards',target:'#sponsorCenter'},{key:'rivalries',label:'Rivalries',target:'#dynastyTab > section:nth-of-type(4)'},{key:'draft',label:'Draft',target:'#dynastyTab > section:nth-of-type(5)'}],'achievements');setupSubview('historyTab',[{key:'history',label:'Seasons',target:'#historyTab > section:nth-of-type(1)'},{key:'trophies',label:'Trophies',target:'#historyTab > section:nth-of-type(2)'},{key:'records',label:'Records',target:'#historyTab > section:nth-of-type(3)'}],'history')}
const releaseRenderAll=window.renderAll;window.renderAll=function(...args){ensureV103();let out=releaseRenderAll.apply(this,args);renderNextSteps();if(!$v('programTab').classList.contains('hidden'))renderFacilities103();if(!$v('postseasonTab').classList.contains('hidden'))renderPostseason();return out};
const releaseShowTab=window.showTab;window.showTab=function(n){if(n==='postseason'){window.SDF_RELEASE_TEST.ui.activeTab='postseason';document.querySelectorAll('.nav-tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===n));document.querySelectorAll('.tab-page').forEach(p=>p.classList.add('hidden'));$v('postseasonTab').classList.remove('hidden');releaseRenderAll();renderPostseason();window.scrollTo({top:0,behavior:'smooth'});return}let out=releaseShowTab(n);if(subviews[n+'Tab'])setSubview(n+'Tab',subviews[n+'Tab'].active);return out};
function wireNavigation(){document.querySelectorAll('.nav-tab').forEach(b=>b.onclick=()=>window.showTab(b.dataset.tab));document.querySelectorAll('[data-mobile-target]').forEach(b=>b.onclick=()=>{window.showTab(b.dataset.mobileTarget);$v('mobileMoreMenu')?.classList.add('hidden')})}
ensureV103();movePostseasonPanels();installSubviewNavigation();wireNavigation();applyWeeklyFacilityBenefits();window.renderAll();
window.SDF_V103_TEST={FACILITIES,facilityCost103,projectWeeks,nextFacilityEffect,progressFacilityProject,renderPostseason,showGameResultModal};
})();

(()=>{
'use strict';
const $5=id=>document.getElementById(id);
function saveV105(reason){try{window.SDF_RELEASE_TEST?.saveNow?.(reason,false,false)}catch{}}
function money5(value){return '$'+Math.round(Number(value||0)/1000)+'k'}
const CLASS_NAMES={1:'Freshman',2:'Sophomore',3:'Junior',4:'Senior'};
function baseClassName(year){return CLASS_NAMES[Number(year)]||`Year ${year}`}
function classLabel(p){
 const base=baseClassName(p.year);let label;
 if(p.redshirt)label=`${base} · Redshirting`;
 else label=p.redshirtUsed?`Redshirt ${base}`:base;
 return p.walkOn?`${label} · Walk-on`:label
}
window.classLabel=classLabel;
function ensurePlayerFields(p){
 p.redshirtUsed??=false;p.redshirtSeason??=null;p.progressionHistory??=[];p.walkOn??=false;p.scholarship??=!p.walkOn;
 p.seasonStats??=typeof emptySeasonStats==='function'?emptySeasonStats():{games:0};
 p.statHistory??=[];p.gameLog??=[];
 return p
}
function ensureRosterFields(){(state.roster||[]).forEach(ensurePlayerFields)}
function currentGames(p){return Number(p.seasonStats?.games||0)}
function redshirtStatus(p){
 ensurePlayerFields(p);const games=currentGames(p);
 if(p.redshirt)return{can:true,active:true,label:'Remove Redshirt',detail:`Currently preserving this season. ${games}/4 games played.`};
 if(p.redshirtUsed)return{can:false,active:false,label:'Redshirt Already Used',detail:`Redshirt season used${p.redshirtSeason?` in Dynasty Year ${p.redshirtSeason}`:''}.`};
 if(state.phase!=='REGULAR')return{can:false,active:false,label:'Redshirt Unavailable',detail:'Redshirt decisions are available during the regular season.'};
 if(games>4)return{can:false,active:false,label:'Redshirt Burned',detail:`Played ${games} games. The four-game limit has been exceeded.`};
 return{can:true,active:false,label:'Redshirt Player',detail:`Eligible under the game’s classic four-game rule: ${games}/4 games played.`}
}
function removeFromDepthChart(p){
 if(!state.depthChart?.[p.pos]?.slots)return;
 state.depthChart[p.pos].slots=state.depthChart[p.pos].slots.filter(slot=>slot.playerId!==p.id)
}
window.togglePlayerRedshirt=id=>{
 const p=state.roster.find(x=>x.id===id);if(!p)return;ensurePlayerFields(p);const status=redshirtStatus(p);
 if(p.redshirt){
  p.redshirt=false;autoDepth();state.depthChart[p.pos]=undefined;initializeDepthChart();state.news.push(`${p.name} was removed from redshirt status.`)
 }else{
  if(!status.can){alert(status.detail);return}
  p.redshirt=true;p.starter=false;removeFromDepthChart(p);state.captains=(state.captains||[]).filter(x=>x!==p.id);autoDepth();state.depthChart[p.pos]=undefined;initializeDepthChart();state.news.push(`${p.name} will redshirt this season. He may appear in up to four games without using the season in this classic-rule simulation.`)
 }
 window.renderAll();saveV105('Redshirt decision')
};
function progressionHtml(p){
 ensurePlayerFields(p);const list=p.progressionHistory||[];
 if(!list.length)return'<p class="muted">His first offseason development result will appear here.</p>';
 return`<div class="progression-list">${list.slice().reverse().map(x=>`<div class="progression-row"><span>${x.classBefore||'Previous class'} → ${x.classAfter||'Next class'}</span><b>${x.from} → ${x.to} OVR <em class="${x.gain>0?'gain':''}">${x.gain>=0?'+':''}${x.gain}</em></b></div>`).join('')}</div>`
}
window.openPlayerProfile=id=>{
 const p=state.roster.find(x=>x.id===id);if(!p)return;ensurePlayerFields(p);const rs=redshirtStatus(p),last=p.progressionHistory?.at(-1);
 $5('modalBody').innerHTML=`<span class="eyebrow">PLAYER PROFILE</span><h2>${p.name}</h2><p class="muted">${p.pos} · ${p.arch} · ${p.hometown}</p><div class="metric-grid">${metric('OVR',p.ovr)}${metric('Potential',p.pot)}${metric('Class',classLabel(p))}${metric('Roster Status',p.walkOn?'Walk-on':'Scholarship')}${metric('Morale',p.morale)}${metric('Development',p.dev)}${metric('Status',p.injury?p.injury.type:p.redshirt?'Redshirting':p.starter?'Starter':'Backup')}${metric('Games This Season',currentGames(p))}${metric('Last Progression',last?`${last.gain>=0?'+':''}${last.gain} OVR`:'—')}</div><section class="player-management-card"><div><span class="eyebrow">ELIGIBILITY</span><h3>Redshirt Decision</h3><p>${rs.detail}</p></div><button class="btn ${rs.active?'warning':'primary'}" onclick="togglePlayerRedshirt('${p.id}')" ${!rs.can?'disabled':''}>${rs.label}</button></section><section class="player-profile-stats"><span class="eyebrow">PLAYER DEVELOPMENT</span><h3>OVR Progression</h3>${progressionHtml(p)}</section>${playerProfileStatsHtml(p)}`;
 $5('modal').classList.remove('hidden');const card=$5('modal').querySelector('.modal-card');if(card)card.scrollTop=0
};
function renderRoster105(){
 ensureRosterFields();let n=needs(),q=(window.SDF_RELEASE_TEST?.ui?.rosterQuery||'').trim().toLowerCase(),players=state.roster.slice().sort((a,b)=>POSITIONS.indexOf(a.pos)-POSITIONS.indexOf(b.pos)||b.ovr-a.ovr).filter(p=>!q||`${p.name} ${p.pos} ${p.hometown}`.toLowerCase().includes(q));
 $5('depthChart').innerHTML=POSITIONS.map(pos=>{let a=state.roster.filter(x=>x.pos===pos).sort((x,y)=>y.starter-x.starter||y.ovr-x.ovr).slice(0,Math.max(STARTERS[pos]+3,4));return`<div class="depth-card"><strong>${pos} · ${n[pos].label}</strong>${a.map((x,i)=>`<div class="depth-line"><span>${i+1}</span><button class="link-button" onclick="openPlayerProfile('${x.id}')">${x.name}<small class="sub">${x.arch} · ${classLabel(x)}${x.starter?' · Starter':''}${x.redshirt?' · RS':''}${x.injury?` · ${x.injury.type}`:''}</small></button><b>${x.ovr}</b></div>`).join('')}</div>`}).join('');
 $5('rosterSummary').innerHTML=metric('Players',state.roster.length)+metric('Average OVR',Math.round(avg(state.roster.map(p=>p.ovr))))+metric('Seniors',state.roster.filter(p=>p.year===4).length)+metric('Active Redshirts',state.roster.filter(p=>p.redshirt).length)+metric('Walk-ons',state.roster.filter(p=>p.walkOn).length)+metric('Injured',state.roster.filter(p=>p.injury).length)+metric('Portal Risk',state.roster.filter(p=>!p.starter&&p.morale<62).length);
 $5('rosterTable').innerHTML=players.map(p=>{const last=p.progressionHistory?.at(-1);return`<tr><td><button class="link-button" onclick="openPlayerProfile('${p.id}')">${p.name}</button><span class="sub">${playerStatLine(p)}</span></td><td>${p.pos}</td><td>${p.arch}</td><td>${p.hometown}</td><td>${classLabel(p)}</td><td>${p.ovr}${last?` <small class="progress-badge">+${Math.max(0,last.gain)}</small>`:''}</td><td>${p.pot}</td><td>${p.dev}</td><td>${p.morale}</td><td>${p.injury?p.injury.type:p.redshirt?'Redshirting':p.starter?'Starter':'Backup'}</td><td>${!p.starter&&p.morale<62?'High':!p.starter&&p.morale<72?'Medium':'Low'}</td></tr>`}).join('');
 $5('rosterCardList').innerHTML=players.map(p=>{const last=p.progressionHistory?.at(-1);return`<article class="mobile-data-card"><div class="mobile-data-head"><div><h3>${p.name}</h3><span class="sub">${p.pos} · ${p.arch} · ${classLabel(p)}</span></div><b>${p.ovr}</b></div><div class="mobile-data-grid"><div><small>POT</small><b>${p.pot}</b></div><div><small>MORALE</small><b>${p.morale}</b></div><div><small>STATUS</small><b>${p.redshirt?'RS':p.starter?'Starter':'Backup'}</b></div><div><small>LAST GAIN</small><b>${last?`${last.gain>=0?'+':''}${last.gain}`:'—'}</b></div></div><span class="sub">${playerStatLine(p)}</span><button class="btn primary full" onclick="openPlayerProfile('${p.id}')">Player Profile & Redshirt</button></article>`}).join('')
}
window.renderRoster=renderRoster105;
window.renderDepthManager=function(){
 ensureRosterFields();initializeDepthChart();if(!$5('depthChartManager'))return;
 $5('depthChartManager').innerHTML=POSITIONS.map(pos=>{let players=state.roster.filter(p=>p.pos===pos&&!p.redshirt),slots=state.depthChart[pos]?.slots||[];return`<div class="depth-position"><div class="depth-position-head"><b>${pos}</b><span class="sub">${players.length} available</span></div><div class="depth-slots">${[0,1,2].map(i=>`<div class="depth-slot"><small>${i===0?'Starter':i===1?'Rotation':'Reserve'}</small><select onchange="setDepthPlayer('${pos}',${i},this.value)"><option value="">Unassigned</option>${players.map(p=>`<option value="${p.id}" ${slots[i]?.playerId===p.id?'selected':''}>${p.name} · ${classLabel(p)} · ${p.ovr}</option>`).join('')}</select><input type="range" min="0" max="100" value="${slots[i]?.snapShare||0}" onchange="setSnapShare('${pos}',${i},this.value)"><span class="sub">${slots[i]?.snapShare||0}% snaps</span></div>`).join('')}</div></div>`}).join('')
};
window.autoRedshirt=function(){
 ensureRosterFields();let selected=[];
 POSITIONS.forEach(pos=>{const depth=state.roster.filter(p=>p.pos===pos&&!p.injury).sort((a,b)=>b.ovr-a.ovr),safeCount=Math.max(STARTERS[pos]+1,2);depth.slice(safeCount).filter(p=>p.year===1&&!p.redshirtUsed&&currentGames(p)<=4).slice(0,2).forEach(p=>selected.push(p))});
 selected.slice(0,15).forEach(p=>{p.redshirt=true;p.starter=false;removeFromDepthChart(p)});
 autoDepth();initializeDepthChart();state.news.push(`Auto-redshirted ${Math.min(15,selected.length)} eligible freshmen behind established depth.`);window.renderAll();saveV105('Auto redshirt')
};
if($5('autoRedshirtBtn'))$5('autoRedshirtBtn').onclick=()=>window.autoRedshirt();

const priorOffseason=window.offseason;
window.offseason=function(...args){
 ensureRosterFields();const before=new Map(state.roster.map(p=>[p.id,{ovr:p.ovr,year:p.year,redshirt:p.redshirt,classBefore:classLabel(p)}]));
 const result=priorOffseason.apply(this,args);
 ensureRosterFields();const report=[];
 state.roster.forEach(p=>{const b=before.get(p.id);if(!b)return;if(b.redshirt){p.redshirtUsed=true;p.redshirtSeason=state.year}const gain=p.ovr-b.ovr,entry={dynastyYear:state.year,from:b.ovr,to:p.ovr,gain,classBefore:b.classBefore,classAfter:classLabel(p)};p.progressionHistory.push(entry);p.lastProgression=entry;report.push({id:p.id,name:p.name,pos:p.pos,...entry})});
 state.lastProgressionReport=report.sort((a,b)=>b.gain-a.gain).slice(0,25);window.renderAll();saveV105('Player progression recorded');return result
};

function annualNilAllocation(){
 const collective=Math.max(1,Number(state.facilities?.nilCollective||1)),rating=Number(state.school?.nil||50);
 return Math.round(50000+rating*2400+collective*30000)
}
const priorStart=window.start;
window.start=function(...args){
 const result=priorStart.apply(this,args);ensureRosterFields();state.nilBudget=annualNilAllocation();state._nilAllocationYear=state.year;window.renderAll();saveV105('Separate budgets initialized');return result
};
const priorBegin=window.beginYear;
window.beginYear=function(...args){
 const priorYear=state._nilAllocationYear,result=priorBegin.apply(this,args);ensureRosterFields();
 if(state.school&&priorYear!==state.year){const allocation=annualNilAllocation(),carry=Math.min(Number(state.nilBudget||0),Math.round(allocation*.5));state.nilBudget=allocation+carry;state._nilAllocationYear=state.year;state.news.push(`The NIL collective allocated ${money5(allocation)} for this recruiting cycle. Program funds remain separate.`)}
 return result
};

function renderResourceGuide(){
 const el=$5('recruitingResourceGuide');if(!el||!state.school)return;
 el.innerHTML=`<article><span>⏱️</span><div><b>Recruiting Hours</b><strong>${state.weeklyHours}</strong><small>Staff time that refreshes every week. Rebuild programs begin near 350 hours; national powers can approach 1,000. Each prospect is capped at 50 contact hours per week.</small></div></article><article><span>💵</span><div><b>Recruiting NIL Pool</b><strong>${money5(state.nilBudget)}</strong><small>Used only for prospect NIL offers. It cannot pay coaches or build facilities.</small></div></article><article><span>🏫</span><div><b>Program Funds</b><strong>${money5(state.budget)}</strong><small>Used for facilities, staff changes and program operations—not recruit NIL offers.</small></div></article>`
}
const priorRecruitRender=window.renderRecruiting;
window.renderRecruiting=function(...args){let out=priorRecruitRender.apply(this,args);renderResourceGuide();return out};
const priorProgramRender=window.renderProgram;
window.renderProgram=function(...args){let out=priorProgramRender.apply(this,args);if($5('programManagementCards'))$5('programManagementCards').innerHTML=$5('programManagementCards').innerHTML.replace(/>Budget</g,'>Program Funds<');return out};

ensureRosterFields();
if(state.school){renderResourceGuide();saveV105('V1.0.5 roster migration')}
window.SDF_V105_TEST={classLabel,redshirtStatus,annualNilAllocation,ensurePlayerFields};
})();

(()=>{
'use strict';
const WALK_ON_TARGETS={QB:2,RB:3,WR:6,TE:2,OT:4,IOL:5,EDGE:4,DL:4,LB:5,CB:5,S:4,K:1,P:1};
function save106(reason){try{window.SDF_RELEASE_TEST?.saveNow?.(reason,false,false)}catch{}}
function weeklyHoursFor(s=state.school){
 if(!s)return 350;
 const prestige=Number(s.prestige||50),tier=schoolTier(s),base=prestige<=44?350:prestige<=54?400:prestige<=64?500:prestige<=74?650:prestige<=84?800:1000;
 const facilityBonus=Math.max(0,(Number(state.facilities?.recruiting||1)-1)*35),staffRating=Number(state.staff?.head?.recruiting||55),staffBonus=clamp(Math.round((staffRating-55)*2),-25,100),last=state.history?.at(-1),performance=last?clamp((Number(last.wins||0)-Number(s.expectation||6))*15,-45,75):0,mult=Number(difficultyConfig?.().hours||1),bounds={REBUILD:[350,500],REGIONAL:[400,650],RISING:[500,800],POWER:[650,1000],ELITE:[850,1150]}[tier.key]||[350,1150];
 return clamp(Math.round((base+facilityBonus+staffBonus+performance)*mult),bounds[0],bounds[1])
}
window.weeklyHoursFor=window.calculateRecruitingHours||weeklyHoursFor;
function nearbyHome(){const same=(LOC||[]).filter(x=>x[1]===state.school?.state);return choice(same.length?same:LOC)}
function walkOnOverall(){return clamp(Math.round(45+Number(state.school?.prestige||50)*.15)+rand(-4,4),45,68)}
function createWalkOn(pos){
 const h=nearbyHome(),ovr=walkOnOverall(),devRoll=Math.random(),dev=devRoll<.03?'Elite':devRoll<.12?'Star':devRoll<.34?'Impact':'Normal';
 return{id:crypto.randomUUID(),name:pname(),pos,arch:choice(ARCH[pos]),hometown:`${h[0]}, ${h[1]}`,year:1,ovr,pot:clamp(ovr+rand(3,9),ovr,78),dev,morale:rand(68,84),personality:choice(['Team-first','Loyal','Academic','Competitive']),starter:false,redshirt:false,redshirtUsed:false,redshirtSeason:null,progressionHistory:[],walkOn:true,scholarship:false,rosterOrigin:'Walk-on tryout',injury:null,seasonStats:emptySeasonStats(),statHistory:[],gameLog:[],stats:{games:0,yards:0,td:0,tackles:0,sacks:0,int:0},attrs:attrsFor(pos,ovr)}
}
function fillWalkOnNeeds({silent=false}={}){
 const added=[];for(const pos of POSITIONS){let count=state.roster.filter(p=>p.pos===pos).length,needed=Math.max(0,Number(WALK_ON_TARGETS[pos]||STARTERS[pos])-count);for(let i=0;i<needed;i++){const p=createWalkOn(pos);state.roster.push(p);added.push(p)}}
 if(added.length&&!silent){state.news.push(`Walk-on tryouts added ${added.length} players to cover thin positions.`);autoDepth();state.depthChart={};initializeDepthChart()}
 return added
}
window.holdWalkOnTryouts=()=>{const added=fillWalkOnNeeds();window.renderAll();save106('Walk-on tryouts');if(!added.length)alert('Every position already has minimum playable depth.')};
const priorFinish=window.finishOffseason;
window.finishOffseason=function(...args){
 const beforeYear=state.year,added=fillWalkOnNeeds({silent:true}),ids=new Set(added.map(p=>p.id)),result=priorFinish.apply(this,args);
 if(state.year===beforeYear){state.roster=state.roster.filter(p=>!ids.has(p.id));return result}
 if(added.length){state.lastWalkOnClass=added.map(p=>({name:p.name,pos:p.pos,ovr:p.ovr}));state.news.push(`Walk-on tryouts filled ${added.length} roster openings: ${added.map(p=>p.pos).join(', ')}.`);window.renderAll();save106('Walk-on class added')}
 return result
};
function appendWalkOnControl(){const host=document.getElementById('rosterSummary');if(!host||document.getElementById('walkOnTryoutBtn'))return;host.insertAdjacentHTML('afterend',`<div class="walkon-control"><div><b>Walk-on Tryouts</b><span class="sub">After the portal, walk-ons automatically fill positions below minimum playable depth. You can also check for shortages now.</span></div><button id="walkOnTryoutBtn" class="btn neutral" onclick="holdWalkOnTryouts()">Check Roster Depth</button></div>`)}
const priorRoster=window.renderRoster;window.renderRoster=function(...args){const out=priorRoster.apply(this,args);appendWalkOnControl();return out};
if(state.school){const cap=weeklyHoursFor();if(Number(state.recruitingHoursCapacity||0)<200){state.weeklyHours=cap;state.recruitingHoursCapacity=cap;state._recruitingHoursWeekKey=`${state.year}-${state.week}`}(state.roster||[]).forEach(p=>{p.walkOn??=false;p.scholarship??=!p.walkOn})}
window.SDF_V106_TEST={weeklyHoursFor,WALK_ON_TARGETS,createWalkOn,fillWalkOnNeeds};
})();

(()=>{
'use strict';
const $11=id=>document.getElementById(id);const money11=n=>'$'+Math.round(Number(n||0)/1000)+'k';
const ROLE_DEFS=[
 {key:'QB1',label:'QB1',pos:'QB',side:'Offense',weight:1.2},{key:'RB1',label:'RB1',pos:'RB',side:'Offense',weight:1},{key:'RB2',label:'RB2 / Third Down',pos:'RB',side:'Offense',weight:.45},
 {key:'WR1',label:'WR1 / X',pos:'WR',side:'Offense',weight:1},{key:'WR2',label:'WR2 / Z',pos:'WR',side:'Offense',weight:.95},{key:'SLOT',label:'Slot WR',pos:'WR',side:'Offense',weight:.8},{key:'TE1',label:'TE1',pos:'TE',side:'Offense',weight:.75},
 {key:'LT',label:'Left Tackle',pos:'OT',side:'Offense',weight:.8},{key:'RT',label:'Right Tackle',pos:'OT',side:'Offense',weight:.8},{key:'LG',label:'Left Guard',pos:'IOL',side:'Offense',weight:.65},{key:'C',label:'Center',pos:'IOL',side:'Offense',weight:.7},{key:'RG',label:'Right Guard',pos:'IOL',side:'Offense',weight:.65},
 {key:'LE',label:'Left Edge',pos:'EDGE',side:'Defense',weight:.8},{key:'RE',label:'Right Edge',pos:'EDGE',side:'Defense',weight:.8},{key:'DT1',label:'Defensive Tackle 1',pos:'DL',side:'Defense',weight:.75},{key:'DT2',label:'Defensive Tackle 2',pos:'DL',side:'Defense',weight:.7},
 {key:'MLB',label:'Middle Linebacker',pos:'LB',side:'Defense',weight:.8},{key:'WLB',label:'Weakside Linebacker',pos:'LB',side:'Defense',weight:.7},{key:'SLB',label:'Strongside Linebacker',pos:'LB',side:'Defense',weight:.55},
 {key:'CB1',label:'Cornerback 1',pos:'CB',side:'Defense',weight:.85},{key:'CB2',label:'Cornerback 2',pos:'CB',side:'Defense',weight:.85},{key:'NCB',label:'Nickel Corner',pos:'CB',side:'Defense',weight:.65},{key:'FS',label:'Free Safety',pos:'S',side:'Defense',weight:.75},{key:'SS',label:'Strong Safety',pos:'S',side:'Defense',weight:.75},
 {key:'K',label:'Kicker',pos:'K',side:'Special Teams',weight:1},{key:'P',label:'Punter',pos:'P',side:'Special Teams',weight:1}
];
let audioCtx=null,lastCommitCount=0,replayTimer=null,replayIndex=0,replaySpeed=800,replayScores={us:0,them:0};
function save11(reason){try{window.SDF_RELEASE_TEST?.saveNow?.(reason,false,false)}catch{}}
function grade11(n){n=Number(n||0);return n>=93?'A+':n>=90?'A':n>=87?'A-':n>=83?'B+':n>=80?'B':n>=77?'B-':n>=73?'C+':n>=70?'C':n>=67?'C-':n>=63?'D+':n>=60?'D':'F'}

function annualProgramAllocation(){
 if(!state.school)return 0;
 return Math.round((2400000+Number(state.school.prestige||50)*40000+Number(state.school.recent||50)*15000+Number(state.school.facilities||50)*10000+Number(state.boosterSupport||55)*8000)/10000)*10000
}
function scaledHeadCoachSalary(){return Math.round((650000+Number(state.school?.prestige||50)*20000)/10000)*10000}
function auditProgramFinances(){
 if(!state.school)return;
 state.coachCareer??={name:'Coach',salary:scaledHeadCoachSalary(),contractYears:4,buyout:500000,reputation:50,careerWins:0,careerLosses:0,jobs:[]};
 if(!state._salaryScaleV144){const target=scaledHeadCoachSalary();if(Number(state.coachCareer.salary||0)>target*1.35)state.coachCareer.salary=target;state._salaryScaleV144=true}
 if(Number(state.budget||0)<0){const recovery=Math.max(500000,Math.round(annualProgramAllocation()*.32/10000)*10000);state.budget=recovery;state._budgetAuditV144=true;state.news??=[];state.news.push(`A program-finance audit corrected the negative balance and restored ${money11(recovery)} in operating reserves.`)}
}
function ensure11(){
 if(!state.school)return;window.migrateDynastyCore?.();auditProgramFinances();state.staffContracts??={};state.staffMarket??={};state.realDepthChart??={};state.portalWeek??=1;state.portalHours??=40;state.portalDepartures??=[];state.soundEnabled??=true;state._staffPayrollYear??=null;
 ['oc','dc'].forEach(role=>{let c=state.staff?.[role];if(!c)return;state.staffContracts[role]??={salary:staffSalary(c,role),years:3,buyoutRate:.2}});ensureStaffMarket();ensureRealDepth();
}
function staffSalary(c,role){let avg=(Number(c.recruiting)+Number(c.development)+Number(c.game))/3,base=role==='oc'||role==='dc'?240000:1500000;return Math.round((base+avg*9000)/10000)*10000}
function staffBuyout(role){let x=state.staffContracts?.[role];return x?Math.round(x.salary*Math.max(1,x.years)*x.buyoutRate):0}
function candidate(role,i){let base=clamp(Math.round((state.school.prestige+state.school.recent)/2)+((i%4)-1)*5,48,94),c=makeCoach(role==='oc'?'Offensive Coordinator':'Defensive Coordinator',base),salary=staffSalary(c,role);return{id:crypto.randomUUID(),...c,salary,years:rand(2,4),signingBonus:Math.round(salary*(.18+i*.035)/10000)*10000,scheme:role==='oc'?choice(['Pro Style','Spread','Air Raid','Power Run','Option','Tempo Spread']):choice(['4-3','3-4','4-2-5','3-3-5','Multiple'])}}
function ensureStaffMarket(){['oc','dc'].forEach(role=>{if(!Array.isArray(state.staffMarket[role])||!state.staffMarket[role].length)state.staffMarket[role]=Array.from({length:5},(_,i)=>candidate(role,i))})}
function hireCost(role,c){return staffBuyout(role)+Number(c.signingBonus||0)}
window.hireStaffCandidate=(role,id)=>{ensure11();let c=state.staffMarket[role]?.find(x=>x.id===id);if(!c)return;let cost=hireCost(role,c);if(state.budget<cost){alert(`You need ${money11(cost)} in program funds.`);return}if(!confirm(`Hire ${c.name} for ${money11(c.salary)} per year? Buyout and signing costs total ${money11(cost)}.`))return;state.budget-=cost;state.staff[role]={name:c.name,role:c.role,recruiting:c.recruiting,development:c.development,game:c.game};state.staffContracts[role]={salary:c.salary,years:c.years,buyoutRate:.2};if(role==='oc')state.offense=c.scheme;else state.defense=c.scheme;state.staffMarket[role]=Array.from({length:5},(_,i)=>candidate(role,i));state.news.push(`${c.name} hired as ${c.role}. Immediate cost: ${money11(cost)}; annual salary: ${money11(c.salary)}.`);window.renderAll();save11('Staff hired')};
function coachSkillGrid(c){return`<div class="coach-ratings"><div><small>Recruit</small><b>${c.recruiting}</b></div><div><small>Develop</small><b>${c.development}</b></div><div><small>Game</small><b>${c.game}</b></div></div>`}
function openStaffCandidates(role){ensure11();const current=state.staff[role],contract=state.staffContracts[role],candidates=state.staffMarket[role]||[],title=role==='oc'?'Replace Offensive Coordinator':'Replace Defensive Coordinator';$11('modalBody').innerHTML=`<span class="eyebrow">COACHING SEARCH</span><h2>${title}</h2><article class="current-coach-modal"><b>Current: ${current.name}</b><span>${current.role} · ${money11(contract.salary)}/yr · ${contract.years} years remaining</span>${coachSkillGrid(current)}<small>Replacing him triggers a ${money11(staffBuyout(role))} contract buyout.</small></article><div class="staff-candidate-popup">${candidates.map(c=>{const cost=hireCost(role,c);return`<article class="staff-candidate-card"><div><span class="eyebrow">${c.scheme}</span><h3>${c.name}</h3><span class="sub">${c.years}-year contract</span></div>${coachSkillGrid(c)}<div class="cost-line"><small>Annual salary</small><b>${money11(c.salary)}</b></div><div class="cost-line"><small>Signing bonus</small><b>${money11(c.signingBonus)}</b></div><div class="cost-line"><small>Current coach buyout</small><b>${money11(staffBuyout(role))}</b></div><div class="cost-line total"><small>Total due today</small><b>${money11(cost)}</b></div><button class="btn primary full" onclick="hireStaffCandidate('${role}','${c.id}')" ${state.budget<cost?'disabled':''}>Hire ${c.name}</button></article>`}).join('')}</div>`;$11('modal').classList.remove('hidden');$11('modalBody').scrollTop=0}
window.openStaffCandidates=openStaffCandidates;
function renderStaff11(){ensure11();const cards=[['head',state.staff.head],['oc',state.staff.oc],['dc',state.staff.dc]];let grid=$11('staffGrid');if(grid)grid.innerHTML=cards.map(([role,c])=>{const head=role==='head',x=head?{salary:state.coachCareer?.salary||scaledHeadCoachSalary(),years:state.coachCareer?.contractYears||0}:state.staffContracts[role];return`<article class="coach-card current-staff-card"><div class="staff-card-head"><div><span class="eyebrow">${head?'HEAD COACH':role==='oc'?'OFFENSE':'DEFENSE'}</span><h3>${c.name}</h3><span class="sub">${c.role}${head?' · You':` · ${role==='oc'?state.offense:state.defense}`}</span></div><span class="coach-contract-chip">${money11(x.salary)}/yr</span></div>${coachSkillGrid(c)}<div class="staff-contract-line"><span>${x.years} years remaining</span>${head?'':`<span>${money11(staffBuyout(role))} buyout</span>`}</div>${head?'<span class="sub">Your Head Coach skills improve through the Coach skill tree.</span>':`<button class="btn warning full" onclick="openStaffCandidates('${role}')">Replace</button>`}</article>`}).join('');
 let host=$11('staffManagement');if(!host)return;const payroll=(state.coachCareer?.salary||0)+['oc','dc'].reduce((n,r)=>n+(state.staffContracts[r]?.salary||0),0);host.innerHTML=`<div class="metric-grid">${metric('Program Funds',money11(state.budget))}${metric('Annual Staff Payroll',money11(payroll))}${metric('Coordinator Buyouts',money11(staffBuyout('oc')+staffBuyout('dc')))}</div><div class="staff-direction"><b>Current Staff</b><span>Review each coach’s Recruiting, Development, and Game ratings. Press Replace to open the candidate market with all immediate and annual costs shown before hiring.</span></div>`+cards.map(([role,c])=>{const head=role==='head',x=head?{salary:state.coachCareer?.salary||scaledHeadCoachSalary(),years:state.coachCareer?.contractYears||0}:state.staffContracts[role];return`<article class="staff-current-row"><div><span class="eyebrow">${head?'HEAD COACH':role==='oc'?'OFFENSIVE COORDINATOR':'DEFENSIVE COORDINATOR'}</span><h3>${c.name}</h3><span class="sub">${head?'Program leader':role==='oc'?state.offense:state.defense} · ${money11(x.salary)}/year · ${x.years} years</span></div>${coachSkillGrid(c)}${head?'<button class="btn neutral" onclick="showTab(\'coach\')">Coach Skill Tree</button>':`<button class="btn warning" onclick="openStaffCandidates('${role}')">Replace</button>`}</article>`}).join('')}
function payrollCharge(){ensure11();if(state._staffPayrollYear===state.year)return;let total=(state.coachCareer?.salary||0)+['oc','dc'].reduce((n,r)=>n+(state.staffContracts[r]?.salary||0),0),allocation=annualProgramAllocation();state.budget=Math.max(0,Number(state.budget||0))+allocation-total;state.budget=Math.max(0,state.budget);state._staffPayrollYear=state.year;state._programAllocationYear=state.year;['oc','dc'].forEach(r=>state.staffContracts[r].years=Math.max(1,state.staffContracts[r].years-1));state.news.push(`Athletics allocated ${money11(allocation)} for Year ${state.year}; ${money11(total)} was charged for coaching payroll. Remaining Program Funds: ${money11(state.budget)}.`)}
function renderSchoolGrades(){let host=$11('schoolRecruitingGrades');if(!host||!state.school)return;let s=state.school,rows=[['Program Prestige',s.prestige,'Tradition and national brand'],['Recent Success',s.recent,'Winning and championship contention'],['Pro Development',s.pro,'Draft and professional pipeline'],['Athletic Facilities',s.facilities,'Training and recruiting facilities'],['Academics',s.academics,'Academic reputation and support'],['NIL Opportunity',s.nil,'Collective strength and recruit resources'],['Playing Time',Math.round(avg(POSITIONS.map(p=>{let n=needs()[p];return clamp(52+n.sev*7,25,98)}))),'Average opportunity across the roster'],['Stadium Atmosphere',state.stadium?.atmosphere||55,'Visits and home-field environment']];host.innerHTML=rows.map(([label,v,desc])=>`<article class="school-grade-card"><small>${label}</small><b>${grade11(v)} · ${Math.round(v)}</b><span class="sub">${desc}</span></article>`).join('')}
function ensureRealDepth(){
 state.realDepthChart??={};
 const usedStarters={};
 for(const role of ROLE_DEFS){
  const rostered=state.roster.filter(p=>p.pos===role.pos&&!p.redshirt).sort((a,b)=>(a.injury?1:0)-(b.injury?1:0)||b.ovr-a.ovr);
  const available=rostered.filter(p=>!p.injury);
  let current=state.realDepthChart[role.key];
  if(!current||!Array.isArray(current.slots))current={slots:[]};
  const localUsed=new Set();
  for(let i=0;i<3;i++){
   let slot=current.slots[i];
   const assigned=slot&&state.roster.find(p=>p.id===slot.playerId);
   // Injuries are temporary and must never erase the user's saved depth chart.
   // Only permanent eligibility changes (departed player, wrong position or
   // redshirt) invalidate an assignment.
   const valid=!!assigned&&assigned.pos===role.pos&&!assigned.redshirt&&!localUsed.has(assigned.id)&&(i>0||!usedStarters[assigned.id]);
   if(!valid){
    const pool=available.length?available:rostered;
    const pick=pool.find(p=>!localUsed.has(p.id)&&(i>0||!usedStarters[p.id]))||pool.find(p=>!localUsed.has(p.id))||null;
    slot={playerId:pick?.id||'',snapShare:Number(slot?.snapShare ?? (i===0?70:i===1?25:5))};
   }else{
    slot={playerId:assigned.id,snapShare:Number(slot.snapShare ?? (i===0?70:i===1?25:5))};
   }
   current.slots[i]=slot;
   if(slot.playerId)localUsed.add(slot.playerId);
   if(i===0&&slot.playerId)usedStarters[slot.playerId]=true;
  }
  state.realDepthChart[role.key]=current;
  normalizeRole(role.key);
 }
 applyRealDepth();
}

function normalizeRole(key){let slots=state.realDepthChart[key]?.slots||[],total=slots.reduce((n,s)=>n+Number(s.snapShare||0),0);if(!total){slots.forEach((s,i)=>s.snapShare=i===0?70:i===1?25:5);return}let rounded=0;slots.forEach((s,i)=>{s.snapShare=i===slots.length-1?100-rounded:Math.round(Number(s.snapShare||0)/total*100);rounded+=s.snapShare})}
function applyRealDepth(){
 state.roster.forEach(p=>p.starter=false);
 const activeStarters=new Set();
 ROLE_DEFS.forEach(role=>{
  const slots=state.realDepthChart[role.key]?.slots||[];
  const player=slots.map(s=>state.roster.find(p=>p.id===s.playerId)).find(p=>p&&!p.injury&&!p.redshirt&&!activeStarters.has(p.id));
  if(player){player.starter=true;activeStarters.add(player.id)}
 });
}
window.setRealDepthPlayer=(role,index,id)=>{ensureRealDepth();let def=ROLE_DEFS.find(r=>r.key===role);if(id&&def){ROLE_DEFS.filter(r=>r.pos===def.pos).forEach(r=>(state.realDepthChart[r.key]?.slots||[]).forEach((slot,i)=>{if(!(r.key===role&&i===index)&&slot.playerId===id)slot.playerId=''}))}state.realDepthChart[role].slots[index].playerId=id;applyRealDepth();renderDepth11();save11('Depth chart')};
window.setRealSnapShare=(role,index,value)=>{ensureRealDepth();state.realDepthChart[role].slots[index].snapShare=Number(value);normalizeRole(role);applyRealDepth();renderDepth11();save11('Snap share')};
function roleRating(role){let d=state.realDepthChart[role.key],weighted=0,total=0;(d?.slots||[]).forEach(s=>{let p=state.roster.find(x=>x.id===s.playerId);if(p&&!p.injury&&!p.redshirt){weighted+=p.ovr*Number(s.snapShare||0);total+=Number(s.snapShare||0)}});return total?weighted/total:45}
function renderDepth11(){let host=$11('depthChartManager');if(!host)return;ensureRealDepth();host.innerHTML=['Offense','Defense','Special Teams'].map(side=>`<section class="depth-side"><h3>${side}</h3><div class="real-depth-grid">${ROLE_DEFS.filter(r=>r.side===side).map(role=>{let players=state.roster.filter(p=>p.pos===role.pos&&!p.redshirt).sort((a,b)=>(a.injury?1:0)-(b.injury?1:0)||b.ovr-a.ovr),slots=state.realDepthChart[role.key].slots,total=slots.reduce((n,s)=>n+Number(s.snapShare||0),0);return`<article class="real-depth-role"><div class="depth-position-head"><h4>${role.label}</h4><b>${Math.round(roleRating(role))} OVR</b></div>${slots.map((s,i)=>`<div class="role-slot"><label>${i===0?'Starter':i===1?'Rotation':'Reserve'}<select onchange="setRealDepthPlayer('${role.key}',${i},this.value)"><option value="">Unassigned</option>${players.map(p=>`<option value="${p.id}" ${p.id===s.playerId?'selected':''} ${p.injury&&p.id!==s.playerId?'disabled':''}>${p.name} · ${classLabel(p)} · ${p.ovr}${p.injury?' · OUT':''}</option>`).join('')}</select></label><label>Snaps<input type="number" min="0" max="100" value="${s.snapShare}" onchange="setRealSnapShare('${role.key}',${i},this.value)"></label></div>`).join('')}<div class="snap-total">Total ${total}% · Snap shares directly control touches, targets and defensive statistics.</div></article>`}).join('')}</div></section>`).join('')}
window.teamRatings=function(){ensureRealDepth();let off=ROLE_DEFS.filter(r=>r.side==='Offense'),def=ROLE_DEFS.filter(r=>r.side==='Defense'),weighted=arr=>Math.round(arr.reduce((n,r)=>n+roleRating(r)*r.weight,0)/arr.reduce((n,r)=>n+r.weight,0)),special=Math.round(roleRating(ROLE_DEFS.find(r=>r.key==='K')));return{offense:weighted(off),defense:weighted(def),special,overall:Math.round((weighted(off)+weighted(def)+special*.25)/2.25)}};
function participants(keys){let map=new Map();ROLE_DEFS.filter(r=>keys.includes(r.key)).forEach(r=>(state.realDepthChart[r.key]?.slots||[]).forEach(s=>{let p=state.roster.find(x=>x.id===s.playerId);if(p&&!p.injury&&!p.redshirt)map.set(p.id,{p,weight:(map.get(p.id)?.weight||0)+Number(s.snapShare||0)*r.weight})}));return [...map.values()].sort((a,b)=>b.weight-a.weight)}
function distribute(total,list,field,min=0){let weight=list.reduce((n,x)=>n+x.weight,0)||1,remaining=total;list.forEach((x,i)=>{let v=i===list.length-1?remaining:Math.max(min,Math.round(total*x.weight/weight));remaining-=v;x.p.seasonStats[field]=(x.p.seasonStats[field]||0)+Math.max(0,v)});return list}
window.simDetailedPlayerStats=function(g,win,us,them){ensureRealDepth();state.roster.forEach(ensurePlayerStats);let qbs=participants(['QB1']),rbs=participants(['RB1','RB2']),rec=participants(['WR1','WR2','SLOT','TE1']),defs=participants(['LE','RE','DT1','DT2','MLB','WLB','SLB','CB1','CB2','NCB','FS','SS']),k=participants(['K'])[0]?.p,passYds=clamp(rand(150,365)+Math.round((teamRatings().offense-g.oppPower)*3),70,520),rushYds=clamp(rand(65,210)+Math.round((teamRatings().offense-g.oppPower)*2),25,330),passTD=Math.max(0,Math.round(us/14)+rand(-1,1)),rushTD=Math.max(0,Math.round((us-passTD*7)/14));qbs.forEach(({p,weight},i)=>{let share=weight/qbs.reduce((n,x)=>n+x.weight,0),att=Math.max(1,Math.round(rand(24,39)*share)),comp=Math.round(att*(.54+(p.ovr-65)/180));p.seasonStats.games++;p.seasonStats.passAtt+=att;p.seasonStats.passComp+=comp;p.seasonStats.passYds+=Math.round(passYds*share);p.seasonStats.passTD+=i?0:passTD;p.seasonStats.passINT+=i?0:rand(0,2);recordPlayerGame(p,state.week,g.opponent,win?'W':'L',{passYds:Math.round(passYds*share),passTD:i?0:passTD})});distribute(rand(22,39),rbs,'rushAtt');distribute(rushYds,rbs,'rushYds');if(rbs[0])rbs[0].p.seasonStats.rushTD+=rushTD;rbs.forEach(x=>{x.p.seasonStats.games++;recordPlayerGame(x.p,state.week,g.opponent,win?'W':'L',{rushYds:Math.round(rushYds*x.weight/(rbs.reduce((n,y)=>n+y.weight,0)||1))})});distribute(rand(16,31),rec,'rec');distribute(passYds,rec,'recYds');for(let i=0;i<passTD&&rec.length;i++)rec[i%rec.length].p.seasonStats.recTD++;rec.forEach(x=>{x.p.seasonStats.games++;recordPlayerGame(x.p,state.week,g.opponent,win?'W':'L',{recYds:Math.round(passYds*x.weight/(rec.reduce((n,y)=>n+y.weight,0)||1))})});defs.forEach(({p,weight})=>{let share=weight/(defs.reduce((n,x)=>n+x.weight,0)||1),t=Math.max(1,Math.round(rand(52,78)*share));p.seasonStats.games++;p.seasonStats.tackles+=t;if(Math.random()<.35)p.seasonStats.tfl+=rand(0,2);if(['EDGE','DL','LB'].includes(p.pos)&&Math.random()<.24)p.seasonStats.sacks+=1;if(['CB','S','LB'].includes(p.pos)&&Math.random()<.09)p.seasonStats.defINT+=1;recordPlayerGame(p,state.week,g.opponent,win?'W':'L',{tackles:t})});if(k){let fga=rand(0,3),fgm=Math.max(0,fga-(Math.random()<.25?1:0)),xpa=Math.floor(us/7);k.seasonStats.games++;k.seasonStats.fga+=fga;k.seasonStats.fgm+=fgm;k.seasonStats.xpa+=xpa;k.seasonStats.xpm+=xpa;k.seasonStats.points+=fgm*3+xpa}}
function portalClass(p){return classLabel?classLabel(p):`Year ${p.year}`}
function portalFit(p){let need=needs()[p.pos],pt=clamp(50+need.sev*8+(p.ovr-(need.q||68))*1.3,20,99),win=state.school.recent,scheme=window.SDF_RECRUITING_V2?.schoolGrade?window.SDF_RECRUITING_V2.schoolGrade({pos:p.pos,arch:p.arch,motivations:[],id:p.id},state.school,'SCHEME'):70,homeState=(p.hometown||'').split(', ').pop(),home=state.school.state===homeState?95:state.school.pipelines?.includes(homeState)?80:55;return{pt,win,scheme,home,overall:Math.round(pt*.38+win*.24+scheme*.2+home*.18)}}
function portalSeed(text){let h=2166136261;for(let ch of String(text)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)}return Math.abs(h>>>0)}
function ensurePortal(){if(!Array.isArray(state.portal))state.portal=[];state.portal.forEach((p,i)=>{p.portalInterest??=clamp(24+portalFit(p).overall*.45+rand(-8,8),20,78);p.portalNIL??=Math.round((10000+Math.max(0,p.ovr-68)*3500+rand(0,15000))/5000)*5000;p.portalRivals??=[choice(schools.filter(s=>s.id!==state.school.id)).name,choice(schools.filter(s=>s.id!==state.school.id)).name];p.portalRivals=[...new Set(p.portalRivals)].filter(n=>n&&n!==state.school.name);while(p.portalRivals.length<2){let n=choice(schools.filter(s=>s.id!==state.school.id&&!p.portalRivals.includes(s.name))).name;p.portalRivals.push(n)}p.portalRivalScores??={};p.portalRivals.forEach((name,j)=>{if(p.portalRivalScores[name]==null){let offset=(portalSeed(`${p.id}-${name}`)%19)-7+(j===0?3:0);p.portalRivalScores[name]=clamp(Math.round(p.portalInterest+offset),20,92)}});p.portalCommitted??=false;p.portalLost??=null;p.portalContact??=0})}
function portalRank(p){ensurePortal();let rivals=p.portalRivals.map(name=>({name,score:Math.round(p.portalRivalScores?.[name]||20)})),all=[{name:state.school.name,score:Math.round(p.portalInterest),user:true},...rivals].sort((a,b)=>b.score-a.score);return{all,userRank:all.findIndex(x=>x.user)+1,leader:all[0]}}
window.portalContact=(id,type)=>{ensurePortal();let p=state.portal.find(x=>x.id===id);if(!p||p.portalCommitted||p.portalLost)return;let cost=type==='VISIT'?15:5,gain=type==='VISIT'?rand(9,15):rand(3,7);if(state.portalHours<cost)return;state.portalHours-=cost;p.portalInterest=clamp(p.portalInterest+gain,0,100);p.portalContact+=cost;if(p.portalInterest>=100)signPortal(p);renderPortal11();save11('Portal contact')};
window.portalNil=(id)=>{ensurePortal();let p=state.portal.find(x=>x.id===id);if(!p||p.portalCommitted||p.portalLost||state.nilBudget<p.portalNIL)return;state.nilBudget-=p.portalNIL;p.portalInterest=clamp(p.portalInterest+rand(8,14),0,100);p.portalNILOffered=p.portalNIL;if(p.portalInterest>=100)signPortal(p);renderPortal11();save11('Portal NIL')};
function signPortal(p){if(p.portalCommitted||p.portalLost)return;p.portalCommitted=true;p.taken=true;state.roster.push({...p,id:crypto.randomUUID(),morale:80,starter:false,walkOn:false,scholarship:true,seasonStats:emptySeasonStats(),statHistory:p.statHistory||[],gameLog:[],stats:{games:0,yards:0,td:0,tackles:0,sacks:0,int:0}});state.achievementStats.portalAdds++;state.news.push(`${p.name} committed from the transfer portal.`);playSound('commit')}
window.retainTransfer=(id)=>{let d=state.portalDepartures.find(x=>x.player.id===id);if(!d||d.retained)return;let cost=d.nilAsk;if(state.nilBudget<cost)return;state.nilBudget-=cost;d.retained=true;let p={...d.player,year:Math.min(5,(Number(d.player.year)||1)+1),morale:72,injury:null,starter:false};state.roster.push(p);state.news.push(`${p.name} withdrew from the portal after a ${money11(cost)} retention package and returns as a ${portalClass(p)}.`);ensureRealDepth();renderPortal11();save11('Retained transfer')};
function renderPortal11(){let o=$11('portalOverviewV11'),list=$11('portalListV11'),depart=$11('portalDepartureListV11'),dir=$11('portalDirectionV11'),btn=$11('portalAdvanceWeekBtn');if(!o)return;ensurePortal();let open=state.phase==='PORTAL';o.innerHTML=metric('Portal Status',open?`Week ${state.portalWeek}/4`:'Closed')+metric('Portal Hours',open?state.portalHours:'—')+metric('NIL Pool',money11(state.nilBudget))+metric('Signed Transfers',state.portal.filter(p=>p.portalCommitted).length);dir.innerHTML=open?`<b>The portal is open.</b> Contact players with a 5-hour call, host a 15-hour visit, or make a recruit-only NIL offer. Playing time, scheme, winning and location determine your starting position.`:`<b>The portal opens after the season.</b> You can always find this tab here. During the season it shows how the system works; after the season it becomes fully interactive.`;btn.disabled=!open;btn.textContent=open&&state.portalWeek>=4?'Finish Portal Window':'Advance Portal Week';depart.innerHTML=(state.portalDepartures||[]).map(d=>`<article class="portal-card ${d.retained?'signed':''}"><h4>${d.player.name}</h4><span class="sub">${d.player.pos} · ${portalClass(d.player)} · ${d.player.ovr} OVR</span><p>${d.reason}</p><b>Retention ask: ${money11(d.nilAsk)}</b><button class="btn warning full" onclick="retainTransfer('${d.player.id}')" ${!open||d.retained||state.nilBudget<d.nilAsk?'disabled':''}>${d.retained?'Returning to Team':'Try to Retain'}</button></article>`).join('')||'<p class="muted">No outgoing transfers recorded.</p>';list.innerHTML=(state.portal||[]).map(p=>{let f=portalFit(p),race=portalRank(p);return`<article class="portal-card ${p.portalCommitted?'signed':p.portalLost?'lost':''}"><h4>${p.name}</h4><span class="sub">${p.pos} · ${p.arch} · ${portalClass(p)} · ${p.ovr} OVR / ${p.pot} POT</span><p>${p.reason||'Seeking a better opportunity'}</p><div class="portal-fit-row"><div><small>PLAYING TIME</small><b>${grade11(f.pt)}</b></div><div><small>SCHEME</small><b>${grade11(f.scheme)}</b></div><div><small>OVERALL FIT</small><b>${grade11(f.overall)}</b></div></div><b>${p.portalCommitted?'SIGNED TO YOU':p.portalLost?`SIGNED: ${p.portalLost}`:`#${race.userRank} · ${Math.round(p.portalInterest)} interest`}</b><span class="sub">Leader: ${race.leader.name} · NIL ask ${money11(p.portalNIL)}</span><div class="actions"><button class="btn neutral" onclick="portalContact('${p.id}','CALL')" ${!open||p.portalCommitted||p.portalLost||state.portalHours<5?'disabled':''}>Call · 5 hrs</button><button class="btn warning" onclick="portalContact('${p.id}','VISIT')" ${!open||p.portalCommitted||p.portalLost||state.portalHours<15?'disabled':''}>Visit · 15 hrs</button><button class="btn primary" onclick="portalNil('${p.id}')" ${!open||p.portalCommitted||p.portalLost||p.portalNILOffered||state.nilBudget<p.portalNIL?'disabled':''}>${p.portalNILOffered?'NIL Offered':'NIL '+money11(p.portalNIL)}</button></div></article>`}).join('')||'<p class="muted">Portal prospects will appear when the offseason begins.</p>'}
window.setRecruitingMode=mode=>{let portal=mode==='portal';$11('highSchoolRecruitingBoard').classList.toggle('hidden',portal);$11('highSchoolCommitSection').classList.toggle('hidden',portal);$11('portalRecruitingSection').classList.toggle('hidden',!portal);$11('highSchoolRecruitingBtn').className=`btn ${portal?'neutral':'primary'}`;$11('transferPortalRecruitingBtn').className=`btn ${portal?'primary':'neutral'}`;state.recruitingView=portal?'portal':'highschool';if(portal)renderPortal11();window.scrollTo({top:0,behavior:'smooth'})};
function advancePortalWeek(){if(state.phase!=='PORTAL')return;if(state.portalWeek>=4){window.finishOffseason();return}ensurePortal();state.portal.forEach(p=>{if(p.portalCommitted||p.portalLost)return;p.portalRivals.forEach(name=>{let school=schools.find(s=>s.name===name),push=rand(2,6)+Math.round(((school?.prestige||65)-60)/18);p.portalRivalScores[name]=clamp((p.portalRivalScores[name]||20)+push,0,100)});let race=portalRank(p);if(race.leader.name!==state.school.name&&race.leader.score>=100){p.portalLost=race.leader.name;p.taken=true;state.news.push(`${p.name} committed to ${p.portalLost} from the transfer portal.`)}else if(p.portalInterest>=100)signPortal(p)});state.portalWeek++;state.portalHours=40;renderPortal11();showInfoPopup('Portal Week Advanced',`The transfer window moved to Week ${state.portalWeek}. Your portal interest did not decrease, but rival programs gained influence and may have moved ahead.`);save11('Portal week')}
function showInfoPopup(title,body,extra=''){let m=$11('modalBody');m.innerHTML=`<span class="eyebrow">SATURDAY DYNASTY FOOTBALL</span><h2>${title}</h2><p>${body}</p>${extra}<button class="btn primary full" onclick="document.getElementById('modal').classList.add('hidden')">Continue</button>`;$11('modal').classList.remove('hidden');playSound('popup')}
function meaningfulWeeklyEvent(){if(Math.random()>.24)return;let active=state.roster.filter(p=>!p.injury&&!p.redshirt),p=choice(active),backup=choice(state.roster.filter(x=>x.pos===p.pos&&x.id!==p.id));let events=[{title:'Team Rules Violation',text:`${p.name}, your ${p.starter?'starting':'reserve'} ${p.pos}, missed a required team meeting.`,choices:[['Suspend one game',()=>{p.injury={weeks:1,type:'Team suspension'};p.starter=false;state.fanApproval=clamp(state.fanApproval+3,0,100)}],['Internal discipline',()=>{p.morale=clamp(p.morale-8,0,99);state.boosterSupport=clamp(state.boosterSupport+1,0,100)}],['Let him play',()=>{state.fanApproval=clamp(state.fanApproval-6,0,100);state.jobSecurity=clamp(state.jobSecurity-3,0,100)}]]},{title:'Playing-Time Complaint',text:`${p.name} wants a clearer role. He currently has ${p.starter?'a starting job':'a backup role'}.`,choices:[['Promise more snaps',()=>{p.morale=clamp(p.morale+10,0,99);state.promises.push({id:crypto.randomUUID(),targetId:p.id,target:p.name,type:'More playing time',year:state.year,resolved:false,kept:null})}],['Hold an open competition',()=>{p.morale=clamp(p.morale+5,0,99);if(backup)backup.morale=clamp(backup.morale+3,0,99)}],['Refuse',()=>{p.morale=clamp(p.morale-12,0,99)}]]},{title:'Academic Warning',text:`${p.name} is falling behind academically and may miss next week.`,choices:[['Mandatory tutoring',()=>{state.budget=Math.max(0,Number(state.budget||0)-20000);p.morale=clamp(p.morale-2,0,99);state.playerEligibility[p.id]=true}],['Reduce practice load',()=>{p.morale=clamp(p.morale+4,0,99);p.ovr=Math.max(45,p.ovr-1)}],['Take the risk',()=>{if(Math.random()<.55)p.injury={weeks:1,type:'Academically ineligible'}}]]}];state.pendingEvent=choice(events);window.showDecisionEvent();playSound('event')}
window.weeklyEvent=meaningfulWeeklyEvent;
window.showDecisionEvent=function(){let e=state.pendingEvent;if(!e)return;$11('modalBody').innerHTML=`<span class="eyebrow">PROGRAM EVENT</span><h2>${e.title}</h2><p>${e.text}</p><div class="event-impact"><b>This decision changes actual player status, morale, finances, eligibility or job support.</b></div><div>${e.choices.map((c,i)=>`<button class="btn primary full" onclick="chooseDecision(${i})">${c[0]}</button>`).join('')}</div>`;$11('modal').classList.remove('hidden')};
window.maybeInjury=function(){let chance=.20*difficultyConfig().injury*coachInjuryMult()*(state.weeklyPractice==='Injury Prevention'?.65:1);if(Math.random()>=chance)return;ensureRealDepth();let pool=state.roster.filter(p=>p.starter&&!p.injury&&!p.redshirt);if(!pool.length)return;let p=choice(pool),severity=choice([{type:'Ankle sprain',weeks:1},{type:'Shoulder strain',weeks:2},{type:'Hamstring injury',weeks:3},{type:'Concussion',weeks:2},{type:'Knee injury',weeks:4}]);p.injury={weeks:severity.weeks,type:severity.type};p.starter=false;state.lastInjuryAlert={player:p.name,pos:p.pos,type:severity.type,weeks:severity.weeks};state.news.push(`${p.name} (${p.pos}) suffered a ${severity.type} and will miss approximately ${severity.weeks} week(s).`);ensureRealDepth();playSound('injury')};
function playSound(type){if(!state?.soundEnabled)return;try{audioCtx??=new (window.AudioContext||window.webkitAudioContext)();let seq=type==='commit'?[[660,.08],[880,.12],[1040,.18]]:type==='injury'?[[220,.12],[160,.22]]:type==='event'?[[420,.08],[360,.12]]:[[520,.08]];let t=audioCtx.currentTime;seq.forEach(([f,d])=>{let o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=f;o.type='sine';g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.09,t+.01);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(audioCtx.destination);o.start(t);o.stop(t+d+.02);t+=d})}catch{}}
function updateSoundSetting(){state.soundEnabled=!!$11('soundSetting')?.checked;save11('Sound setting')}
function parseDrive(line){let parts=String(line).replace(/^Drive \d+: /,'').split('; '),a=parts[0]||'',b=parts[1]||'',pts=x=>x.includes('Touchdown')?7:x.includes('Field Goal')?3:0;return{text:line,us:pts(a),them:pts(b)}}
window.watchLastGame=(speed=1)=>{let recap=state.lastGameRecap;if(!recap)return;clearInterval(replayTimer);replayIndex=0;replayScores={us:0,them:0};replaySpeed=speed===4?180:speed===2?350:speed===.5?1300:700;$11('gameResultModal').classList.add('hidden');$11('gameSimModal').classList.remove('hidden');renderReplay();replayTimer=setInterval(stepReplay,replaySpeed);playSound('popup')};
function renderReplay(){let r=state.lastGameRecap,opp=schools.find(s=>s.name===r.opponent),drives=r.drives||[];$11('gameSimBody').innerHTML=`<span class="eyebrow">GAME REPLAY</span><h2 id="gameSimTitle">${state.school.name} ${r.home?'vs':'at'} ${r.opponent}</h2><div class="sim-scoreboard"><div><img src="${TEAM_BRANDING?.[state.school.id]?.logo||'icon.svg'}"><b>${state.school.name}</b></div><div class="sim-score">${replayScores.us}–${replayScores.them}</div><div><img src="${TEAM_BRANDING?.[opp?.id]?.logo||'icon.svg'}"><b>${r.opponent}</b></div></div><div class="sim-controls"><button class="btn neutral" onclick="watchLastGame(.5)">0.5×</button><button class="btn neutral" onclick="watchLastGame(1)">1×</button><button class="btn neutral" onclick="watchLastGame(2)">2×</button><button class="btn neutral" onclick="watchLastGame(4)">4×</button><button class="btn primary" onclick="finishReplay()">Final</button></div><div class="sim-feed" id="simFeed">${drives.slice(0,replayIndex).map((d,i)=>`<div class="sim-play ${i===replayIndex-1?'current':''}">${d}</div>`).join('')||'<div class="muted">Kickoff is next…</div>'}</div>`;let feed=$11('simFeed');if(feed)feed.scrollTop=feed.scrollHeight}
function stepReplay(){let r=state.lastGameRecap,drives=r.drives||[];if(replayIndex>=drives.length){finishReplay();return}let p=parseDrive(drives[replayIndex]);replayScores.us+=p.us;replayScores.them+=p.them;replayIndex++;renderReplay()}
window.finishReplay=()=>{clearInterval(replayTimer);let r=state.lastGameRecap;replayIndex=(r.drives||[]).length;replayScores={us:r.us,them:r.them};renderReplay();$11('gameSimBody').insertAdjacentHTML('beforeend',`<button class="btn success full" onclick="closeGameSimulation()">Final: ${state.school.name} ${r.us}, ${r.opponent} ${r.them}</button>`)};
window.closeGameSimulation=()=>{clearInterval(replayTimer);$11('gameSimModal').classList.add('hidden')};
function decorateGameResult(){let body=$11('gameResultBody');if(!body||$11('watchReplayBtn'))return;if(state.lastInjuryAlert){body.insertAdjacentHTML('beforeend',`<div class="injury-alert"><b>Injury Report</b><span>${state.lastInjuryAlert.player} (${state.lastInjuryAlert.pos}) suffered a ${state.lastInjuryAlert.type} and is expected to miss ${state.lastInjuryAlert.weeks} week(s). The depth chart was adjusted.</span></div>`);state.lastInjuryAlert=null}body.insertAdjacentHTML('beforeend',`<button id="watchReplayBtn" class="btn primary full" onclick="watchLastGame(1)">Watch Game Simulation</button>`)}
function postseasonBidPopup(){let d=state.postseasonData;if(!d)return;let field=d.playoffField||[],user=field.find(t=>t.id===state.school.id),bowl=(d.bowls||[]).find(b=>b.a.id===state.school.id||b.b.id===state.school.id);if(user)showInfoPopup('College Football Playoff Bid',`${state.school.name} earned the #${user.seed} seed in the 12-team playoff.`,`<div class="postseason-bid"><b>Opponent and bracket are available in the Postseason tab.</b></div><button class="btn warning full" onclick="document.getElementById('modal').classList.add('hidden');showTab('postseason')">Open Postseason Hub</button>`);else if(bowl)showInfoPopup('Bowl Invitation',`${state.school.name} accepted a bid to the ${bowl.name} against ${(bowl.a.id===state.school.id?bowl.b:bowl.a).name}.`,`<button class="btn warning full" onclick="document.getElementById('modal').classList.add('hidden');showTab('postseason')">View Bowl Matchup</button>`);else showInfoPopup('Season Ends Without a Bowl',`${state.school.name} did not receive a postseason invitation this season.`)}
function phaseLabel(){if(state.phase==='REGULAR')return`Advance Week ${state.week}`;if(state.phase==='SIGNING')return'Resolve Signing Day';if(state.phase==='CHAMP')return'Play Championship Week';if(state.phase==='BOWLS')return'Play Bowl / Playoff';if(state.phase==='AWARDS')return'View Awards Week';if(state.phase==='POST')return'Enter Offseason';if(state.phase==='PORTAL')return state.portalWeek>=4?'Finish Portal Window':`Advance Portal Week ${state.portalWeek}`;return'Advance'}
const priorAdvance=window.advanceWeek;window.advanceWeek=function(){if(state.phase==='REGULAR'&&!state.seasonDone){state.lastInjuryAlert=null;let out=priorAdvance();setTimeout(decorateGameResult,100);setTimeout(decorateGameResult,350);return out}if(state.phase==='SIGNING')return window.resolveSigningDay();if(state.phase==='CHAMP')return window.playChampionshipWeek();if(state.phase==='BOWLS')return window.playPostseason();if(state.phase==='AWARDS')return window.completeAwardsWeek?.();if(state.phase==='POST')return window.offseason();if(state.phase==='PORTAL')return advancePortalWeek()};
const priorChamp=window.playChampionshipWeek;window.playChampionshipWeek=function(...args){let out=priorChamp.apply(this,args);setTimeout(postseasonBidPopup,80);return out};
const priorOff=window.offseason;window.offseason=function(...args){let before=new Map(state.roster.map(p=>[p.id,JSON.parse(JSON.stringify(p))])),out=priorOff.apply(this,args),after=new Set(state.roster.map(p=>p.id));state.portalDepartures=[...before.values()].filter(p=>!after.has(p.id)&&p.year<=4).map(p=>({player:p,reason:p.morale<60?'Unhappy with role and morale':'Seeking a different opportunity',nilAsk:Math.round((12000+Math.max(0,p.ovr-65)*2500)/5000)*5000,retained:false}));state.portalWeek=1;state.portalHours=40;ensurePortal();$11('portalPanel')?.classList.add('hidden');window.showTab('recruiting');window.setRecruitingMode('portal');save11('Portal opened');return out};
const priorFinishOff=window.finishOffseason;window.finishOffseason=function(...args){let out=priorFinishOff.apply(this,args);if(state.phase==='REGULAR'){state.portalWeek=1;state.portalHours=40;state.portalDepartures=[];state.realDepthChart={};ensureRealDepth();payrollCharge()}return out};
const priorBegin=window.beginYear;window.beginYear=function(...args){let out=priorBegin.apply(this,args);ensure11();payrollCharge();return out};
const priorStart=window.start;window.start=function(...args){let out=priorStart.apply(this,args);ensure11();lastCommitCount=state.commits.length;window.scrollTo({top:0,behavior:'auto'});return out};
const priorRenderRecruit=window.renderRecruiting;window.renderRecruiting=function(...args){let out=priorRenderRecruit.apply(this,args);renderSchoolGrades();if(state.recruitingView==='portal')window.setRecruitingMode('portal');return out};
window.renderDepthManager=renderDepth11;const priorRenderProgram=window.renderProgram;window.renderProgram=function(...args){let out=priorRenderProgram.apply(this,args);renderStaff11();return out};window.renderStaff=renderStaff11;
const priorRenderAll=window.renderAll;window.renderAll=function(...args){let out=priorRenderAll.apply(this,args);if(!state.school)return out;ensure11();let label=phaseLabel();['advanceWeekBtn','recruitAdvanceBtn','mobileAdvance'].forEach(id=>{let b=$11(id);if(b){b.disabled=false;b.textContent=id==='mobileAdvance'?'Advance':label}});renderSchoolGrades();if(!$11('rosterTab').classList.contains('hidden'))renderDepth11();if(!$11('programTab').classList.contains('hidden'))renderStaff11();if(state.recruitingView==='portal')renderPortal11();let count=state.commits?.length||0;if(count>lastCommitCount)playSound('commit');lastCommitCount=count;$11('soundSetting').checked=state.soundEnabled;return out};
$11('highSchoolRecruitingBtn').onclick=()=>window.setRecruitingMode('highschool');$11('transferPortalRecruitingBtn').onclick=()=>window.setRecruitingMode('portal');$11('portalAdvanceWeekBtn').onclick=()=>window.advanceWeek();$11('soundSetting').onchange=updateSoundSetting;$11('closeGameSim').onclick=window.closeGameSimulation;$11('gameSimModal').addEventListener('click',e=>{if(e.target===$11('gameSimModal'))window.closeGameSimulation()});
ensure11();lastCommitCount=state.commits?.length||0;if(state.recruitingView==='portal')window.setRecruitingMode('portal');window.SDF_V11_TEST={ROLE_DEFS,grade11,staffBuyout,portalFit,phaseLabel,ensureRealDepth,annualProgramAllocation,scaledHeadCoachSalary,auditProgramFinances,depthSnapshot:()=>JSON.parse(JSON.stringify(state.realDepthChart||{})),participantWeights:keys=>participants(keys).map(x=>({id:x.p.id,name:x.p.name,pos:x.p.pos,weight:x.weight}))};
})();
(()=>{
'use strict';
const VERSION='1.7.5',INITIAL_POOL=3000,RECRUIT_BOARD_LIMIT=35,CLASS_SIGNING_LIMIT=25,AI_ROSTER_LIMIT=85,DRAFT_ROUNDS=7,DRAFT_PICKS_PER_ROUND=32,DRAFT_FIRST_ROUND_SCHOOL_CAP=6,DRAFT_TOTAL_SCHOOL_CAP=15;
const $111=id=>document.getElementById(id);
let rosterUi={section:'top25',query:'',conference:'ALL',position:'ALL',page:1,pageSize:24,teamId:null},aiEnsureCache={rosters:null,userId:null,count:0};
function save111(reason){try{window.SDF_RELEASE_TEST?.saveNow?.(reason,false,false)}catch{}}
function userId(){return Number(state.school?.id)}
function rerankRecruits(){state.recruits.sort((a,b)=>b.stars-a.stars||(b.trueOvr||b.ovr)-(a.trueOvr||a.ovr)||a.name.localeCompare(b.name));state.recruits.forEach((r,i)=>r.rank=i+1)}
function ensureFixedRecruitClass(){
 if(!state.school||state.phase!=='REGULAR')return 0;
 (state.recruits||[]).forEach(r=>{r.entryWeek=1;r.lateEvaluation=false});
 if(state.week!==1||state.recruits.length>=INITIAL_POOL)return 0;
 const needed=INITIAL_POOL-state.recruits.length,batch=window.genRecruits(needed);
 batch.forEach(r=>{r.entryWeek=1;r.lateEvaluation=false});state.recruits.push(...batch);rerankRecruits();
 state.news.push(`The full ${INITIAL_POOL}-prospect national recruiting class is available from opening week.`);save111('Completed opening recruiting class');return needed
}
const priorStart=window.start;window.start=function(...args){let out=priorStart.apply(this,args);ensureFixedRecruitClass();ensureAiRosters();return out};
const priorBegin=window.beginYear;window.beginYear=function(...args){let out=priorBegin.apply(this,args);ensureFixedRecruitClass();ensureAiRosters();return out};
const priorResolve=window.resolveRecruiting;window.resolveRecruiting=function(...args){const before=new Set((state.recruits||[]).filter(r=>r.committedTo).map(r=>r.id)),out=priorResolve.apply(this,args);(state.recruits||[]).forEach(r=>{if(r.committedTo&&!before.has(r.id))r.committedWeek=state.week});return out};
function hash111(v){let h=2166136261;for(const ch of String(v)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function rng111(seed){let x=hash111(seed)||1;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296}}
function seededFloat111(seed){return(hash111(seed)%100000)/100000}
function seededInt111(seed,min,max){return min+(hash111(seed)%((max-min)+1))}
function pick111(arr,rng){return arr[Math.floor(rng()*arr.length)]}
function worldTeam111(id){return(state.world||[]).find(t=>Number(t.id)===Number(id))}
function program111(schoolOrId){
 const school=typeof schoolOrId==='object'?schoolOrId:schools.find(s=>Number(s.id)===Number(schoolOrId));if(!school)return null;
 if(Number(school.id)===userId())return{...school,...state.school,coach:Number(state.staff?.head?.development||state.staff?.head?.game||70)};
 const w=worldTeam111(school.id);return{...school,prestige:Number(w?.prestige??school.prestige??50),recent:Number(w?.recent??school.recent??50),facilities:Number(w?.facilities??school.facilities??50),pro:Number(w?.pro??school.pro??50),coach:Number(w?.coach??70),conference:w?.conference||school.conference}
}
function aiAttrs111(pos,ovr,rng){return{speed:clamp(ovr+Math.floor(rng()*17)-8,40,99),strength:clamp(ovr+Math.floor(rng()*17)-8,40,99),skill:clamp(ovr+Math.floor(rng()*15)-7,40,99),awareness:clamp(ovr+Math.floor(rng()*17)-9,40,99)}}
function initialAiPlayer111(school,pos,i,rng){
 const p=program111(school),year=1+Math.floor(rng()*4),classBonus=[-5,-2,1,4][year-1],count=Number(DEPTH[pos]||3),depthBonus=i===0?5:i===1?2:i>=count-2?-4:0,noise=Math.floor(rng()*15)-7;
 const teamBase=Math.round(p.prestige*.38+p.recent*.24+p.facilities*.15+p.pro*.13+p.coach*.10),ovr=clamp(teamBase+classBonus+depthBonus+noise,45,96),pot=clamp(ovr+2+Math.floor(rng()*11),ovr,99),devRoll=rng(),dev=devRoll>.985?'Elite':devRoll>.90?'Star':devRoll>.62?'Impact':'Normal',loc=pick111(LOC,rng),first=pick111(FIRST,rng),last=pick111(LAST,rng),redshirtUsed=year>1&&rng()<.28;
 return{id:`ai-${school.id}-${state.year}-${pos}-${i}-${Math.floor(rng()*1e8)}`,name:`${first} ${last}`,pos,arch:pick111(ARCH[pos],rng),hometown:`${loc[0]}, ${loc[1]}`,year,ovr,pot,dev,morale:60+Math.floor(rng()*36),redshirt:false,redshirtUsed,starter:false,walkOn:i===count-1&&rng()<.25,depthIndex:i,attrs:aiAttrs111(pos,ovr,rng),signedYear:Math.max(1,state.year-year+1),stars:null}
}
function assignAiDepth111(roster){
 for(const p of roster){p.starter=false;p.depthIndex=99}
 for(const pos of POSITIONS){const group=roster.filter(p=>p.pos===pos).sort((a,b)=>Number(b.ovr)-Number(a.ovr)||Number(b.pot)-Number(a.pot));group.forEach((p,i)=>{p.depthIndex=i;p.starter=i<Number(STARTERS[pos]||1)})}
 return roster
}
function trimAiRoster111(roster){
 if(roster.length<=AI_ROSTER_LIMIT)return roster;
 const keep=roster.slice();keep.sort((a,b)=>{const aw=a.walkOn?0:1,bw=b.walkOn?0:1;if(aw!==bw)return aw-bw;if(!!a.starter!==!!b.starter)return a.starter?1:-1;return Number(a.ovr)-Number(b.ovr)});
 while(keep.length>AI_ROSTER_LIMIT)keep.shift();return keep
}
function fillAiWalkons111(school,roster){
 const p=program111(school),rng=rng111(`walkons-${state.year}-${school.id}-${roster.length}`);
 for(const pos of POSITIONS){const min=Math.max(Number(STARTERS[pos]||1)+1,Math.ceil(Number(DEPTH[pos]||3)*.55));let count=roster.filter(x=>x.pos===pos).length;while(count<min){const loc=pick111(LOC,rng),ovr=clamp(Math.round((p.prestige+p.recent)/2)-14+Math.floor(rng()*10),45,76);roster.push({id:`ai-walkon-${school.id}-${state.year}-${pos}-${count}-${Math.floor(rng()*1e8)}`,name:`${pick111(FIRST,rng)} ${pick111(LAST,rng)}`,pos,arch:pick111(ARCH[pos],rng),hometown:`${loc[0]}, ${loc[1]}`,year:1,ovr,pot:clamp(ovr+2+Math.floor(rng()*6),ovr,84),dev:'Normal',morale:72,redshirt:false,redshirtUsed:false,starter:false,walkOn:true,depthIndex:99,attrs:aiAttrs111(pos,ovr,rng),signedYear:state.year,stars:0});count++}}
 return roster
}
function createAiRoster111(school){const rng=rng111(`persistent-ai-roster-${state.year}-${school.id}`),roster=[];for(const pos of POSITIONS)for(let i=0;i<Number(DEPTH[pos]||3);i++)roster.push(initialAiPlayer111(school,pos,i,rng));return assignAiDepth111(roster)}
function ensureAiRosters(force=false){
 if(!state.school||!state.world?.length)return{};state.aiRosters??={};state.aiRosterVersion=2;const currentUser=userId(),expected=Math.max(0,schools.length-1),count=schools.filter(s=>Number(s.id)!==currentUser&&Array.isArray(state.aiRosters[Number(s.id)])&&state.aiRosters[Number(s.id)].length).length;
 if(!force&&aiEnsureCache.rosters===state.aiRosters&&aiEnsureCache.userId===currentUser&&count>=expected)return state.aiRosters;
 for(const school of schools){const id=Number(school.id);if(id===currentUser)continue;const program=program111(school);let roster=state.aiRosters[id];if(!Array.isArray(roster)||!roster.length){roster=createAiRoster111(school);state.aiRosters[id]=roster}else{for(const p of roster){p.ovr=Number.isFinite(Number(p.ovr))?Number(p.ovr):clamp(Math.round((program.prestige+program.recent)/2),45,92);p.pot=Number.isFinite(Number(p.pot))?Math.max(Number(p.ovr),Number(p.pot)):clamp(Number(p.ovr)+6,Number(p.ovr),96);p.year=clamp(Math.round(Number(p.year||1)),1,4);p.dev=p.dev||'Normal';p.morale=clamp(Number(p.morale||75),0,99);p.arch=p.arch||choice(ARCH[p.pos]||['Balanced']);p.hometown=p.hometown||'Unknown';p.redshirt=!!p.redshirt;p.redshirtUsed=!!p.redshirtUsed;p.walkOn=!!p.walkOn;p.attrs??=aiAttrs111(p.pos,p.ovr,rng111(`migrate-${id}-${p.id}`))}assignAiDepth111(roster)}const w=worldTeam111(id),ratings=teamRatings111(roster);if(w){w.rosterPower=ratings.overall;w.aiRosterSize=roster.length;w.pro=Number(w.pro??school.pro??50)}}
 aiEnsureCache={rosters:state.aiRosters,userId:currentUser,count:expected};return state.aiRosters
}
function getAiRoster111(teamId){teamId=Number(teamId);if(teamId===userId())return state.roster;ensureAiRosters();return state.aiRosters?.[teamId]||[]}
function cachedAiRoster111(teamId){teamId=Number(teamId);return teamId===userId()?state.roster:(state.aiRosters?.[teamId]||[])}
function setAiRoster111(teamId,roster){state.aiRosters??={};state.aiRosters[Number(teamId)]=assignAiDepth111(trimAiRoster111(roster||[]));return state.aiRosters[Number(teamId)]}
function storeUserProgram111(teamId,roster){const id=Number(teamId);if(!Number.isFinite(id))return;state.aiRosters??={};const school=schools.find(s=>Number(s.id)===id);const copy=JSON.parse(JSON.stringify(roster||[]));for(const p of copy){if(!p.attrs)p.attrs=aiAttrs111(p.pos,Number(p.ovr||60),rng111(`stored-${id}-${p.id}`))}state.aiRosters[id]=assignAiDepth111(copy);const w=worldTeam111(id);if(w&&school){const rt=teamRatings111(copy);w.rosterPower=rt.overall;w.aiRosterSize=copy.length}}
function takeProgramForUser111(teamId){ensureAiRosters();const id=Number(teamId),school=schools.find(s=>Number(s.id)===id),roster=state.aiRosters?.[id]?.length?JSON.parse(JSON.stringify(state.aiRosters[id])):createAiRoster111(school);for(const p of roster){if(!p.attrs)p.attrs=aiAttrs111(p.pos,Number(p.ovr||60),rng111(`take-${id}-${p.id}`))}delete state.aiRosters[id];return assignAiDepth111(roster)}
function removePlayersFromProgram111(teamId,ids){const remove=new Set(ids||[]);if(Number(teamId)===userId())state.roster=(state.roster||[]).filter(p=>!remove.has(p.id));else if(state.aiRosters?.[Number(teamId)])state.aiRosters[Number(teamId)]=state.aiRosters[Number(teamId)].filter(p=>!remove.has(p.id));const roster=Number(teamId)===userId()?state.roster:state.aiRosters?.[Number(teamId)];if(roster)assignAiDepth111(roster)}
function recruitToAiPlayer111(r,schoolId){const ovr=Number(r.trueOvr||r.ovr||65),pot=Math.max(ovr,Number(r.truePot||r.pot||ovr+7)),loc=`${r.city||'Unknown'}, ${r.home||''}`.trim().replace(/,\s*$/,'');return{id:r.id,name:r.name,pos:r.pos,arch:r.arch||choice(ARCH[r.pos]),hometown:loc,year:1,ovr,pot,dev:r.dev||'Normal',morale:82,redshirt:false,redshirtUsed:false,starter:false,walkOn:false,depthIndex:99,attrs:r.attrs||aiAttrs111(r.pos,ovr,rng111(`signed-${schoolId}-${r.id}`)),signedYear:state.year,stars:Number(r.stars||0),recruitRank:Number(r.rank||0)}}
function productionBonus111(p){const s=p.seasonStats||p.stats||{};let v=0;if(p.pos==='QB')v=Number(s.passYds||s.yards||0)/700+Number(s.passTD||s.td||0)*.18-Number(s.passINT||0)*.10;else if(p.pos==='RB')v=Number(s.rushYds||s.yards||0)/300+Number(s.rushTD||s.td||0)*.30+Number(s.recYds||0)/650;else if(['WR','TE'].includes(p.pos))v=Number(s.recYds||s.yards||0)/270+Number(s.recTD||s.td||0)*.32;else if(['EDGE','DL','LB'].includes(p.pos))v=Number(s.tackles||0)/34+Number(s.sacks||0)*.65+Number(s.defINT||s.int||0)*.65;else if(['CB','S'].includes(p.pos))v=Number(s.tackles||0)/48+Number(s.defINT||s.int||0)*1.05+Number(s.sacks||0)*.30;else if(['OT','IOL'].includes(p.pos))v=p.starter?2.2:.4;else if(p.pos==='K')v=Number(s.fgm||0)*.10;else if(p.pos==='P')v=Number(s.inside20||0)*.08;return clamp(v,-2,9)}
function evaluateDraftProspect111(p,context={}){
 const wins=Number(context.wins??context.record?.w??0),losses=Number(context.losses??context.record?.l??0),pro=Number(context.pro??50),allAmerican=!!context.allAmericanNames?.includes?.(p.name),awardWinner=!!context.awardNames?.includes?.(p.name),starterBonus=p.starter?1.2:0,teamSuccess=losses===0&&wins>=12?3.2:wins>=11?2.4:wins>=9?1.4:wins>=7?.6:0,pipeline=clamp((pro-50)*.06,-1.5,3),positionAdj=['K','P'].includes(p.pos)?-8:p.pos==='TE'?-1:0,random=seededInt111(`draft-${context.year||state.year}-${p.id}`,-4,4),score=Number(p.ovr||0)+productionBonus111(p)+starterBonus+teamSuccess+pipeline+(allAmerican?2.2:0)+(awardWinner?1.4:0)+positionAdj+random;
 let round=null;if(score>=104)round=1;else if(score>=100)round=2;else if(score>=96)round=3;else if(score>=92)round=4;else if(score>=88)round=5;else if(score>=84)round=6;else if(score>=81)round=7;
 return{score,round,pick:null,production:productionBonus111(p),teamSuccess,pipeline}
}
function juniorDeclare111(p,evaluation,context={}){if(Number(p.year)!==3||!evaluation?.round)return false;const s=evaluation.score,chance=s>=104?.985:s>=100?.94:s>=96?.80:s>=92?.58:s>=88?.30:s>=84?.12:.03;return seededFloat111(`declare-${context.year||state.year}-${p.id}`)<chance}
function draftContext111(school,year){const id=Number(school.id);if(id===userId()){const c=state.draftContext||{};return{year,wins:Number(c.wins??state.record?.w??0),losses:Number(c.losses??state.record?.l??0),pro:Number(c.pro??state.school?.pro??school.pro??50),allAmericanNames:c.allAmericanNames||[],awardNames:c.awardNames||[]}}const p=program111(school),w=worldTeam111(id),record=w?.record||{w:0,l:0};return{year,wins:Number(record.w||0),losses:Number(record.l||0),pro:Number(p?.pro??50),allAmericanNames:[],awardNames:[]}}
function buildNationalDraftBoard111(year=Number(state.year),force=false){
 year=Number(year);ensureAiRosters();
 if(!force&&Number(state.nationalDraftBoardYear)===year&&Array.isArray(state.nationalDraftClass)){return{year,rows:state.nationalDraftClass.filter(x=>Number(x.year)===year),earlyEntries:(state.nationalDraftEarlyEntries||[]).filter(x=>Number(x.year)===year),meta:state.nationalDraftBoardMeta||null}}
 const candidates=[],earlyEntries=[];
 for(const school of schools){const id=Number(school.id),ctx=draftContext111(school,year);let roster;if(id===userId())roster=(state.draftEligibleClass?.length?state.draftEligibleClass:(state.roster||[]).filter(p=>Number(p.year)>=3&&!p.redshirt));else roster=cachedAiRoster111(id);
  for(const p of roster||[]){if(p.redshirt||Number(p.year)<3)continue;const evaluation=evaluateDraftProspect111(p,ctx),senior=Number(p.year)>=4,junior=Number(p.year)===3,early=junior&&juniorDeclare111(p,evaluation,ctx);if(early)earlyEntries.push({year,schoolId:id,school:school.name,playerId:p.id,player:p.name,pos:p.pos,ovr:Number(p.ovr||0),classYear:3,score:Math.round(evaluation.score*10)/10});if(!senior&&!early)continue;if(!evaluation.round)continue;candidates.push({year,schoolId:id,school:school.name,playerId:p.id,player:p.name,pos:p.pos,ovr:Number(p.ovr||0),classYear:Number(p.year),earlyEntry:early,score:Math.round(evaluation.score*10)/10,projectedRound:evaluation.round,tie:hash111(`draft-order-${year}-${id}-${p.id}`)})}
 }
 candidates.sort((a,b)=>b.score-a.score||a.projectedRound-b.projectedRound||a.tie-b.tie||String(a.playerId).localeCompare(String(b.playerId)));
 const roundCounts=Array(DRAFT_ROUNDS+1).fill(0),schoolFirst={},schoolTotal={},rows=[];
 for(const c of candidates){const sid=Number(c.schoolId);if(Number(schoolTotal[sid]||0)>=DRAFT_TOTAL_SCHOOL_CAP)continue;for(let round=Math.max(1,Number(c.projectedRound||7));round<=DRAFT_ROUNDS;round++){if(roundCounts[round]>=DRAFT_PICKS_PER_ROUND)continue;if(round===1&&Number(schoolFirst[sid]||0)>=DRAFT_FIRST_ROUND_SCHOOL_CAP)continue;const pick=++roundCounts[round];schoolTotal[sid]=Number(schoolTotal[sid]||0)+1;if(round===1)schoolFirst[sid]=Number(schoolFirst[sid]||0)+1;rows.push({...c,round,pick,overallPick:(round-1)*DRAFT_PICKS_PER_ROUND+pick});break}}
 const keepRows=(state.nationalDraftClass||[]).filter(x=>Number(x.year)!==year&&Number(x.year)>=year-3),keepEarly=(state.nationalDraftEarlyEntries||[]).filter(x=>Number(x.year)!==year&&Number(x.year)>=year-3);state.nationalDraftClass=keepRows.concat(rows);state.nationalDraftEarlyEntries=keepEarly.concat(earlyEntries);state.nationalDraftBoardYear=year;state.nationalDraftBoardMeta={year,totalDrafted:rows.length,roundCounts:roundCounts.slice(1),firstRoundSchoolCap:DRAFT_FIRST_ROUND_SCHOOL_CAP,totalSchoolCap:DRAFT_TOTAL_SCHOOL_CAP};return{year,rows,earlyEntries,meta:state.nationalDraftBoardMeta}
}
function aiProgressGain111(p,program){const dev=p.dev==='Elite'?3:p.dev==='Star'?2:p.dev==='Impact'?1:0,coach=Number(program.coach||65)>=82?1:Number(program.coach||65)>=68&&seededFloat111(`coachgrow-${state.year}-${p.id}`)<.55?1:0,facility=Number(program.facilities||50)>=82?1:Number(program.facilities||50)>=65&&seededFloat111(`facgrow-${state.year}-${p.id}`)<.4?1:0,young=Number(p.year)<=2&&seededFloat111(`younggrow-${state.year}-${p.id}`)<.35?1:0,speed=Number(state.realismSettings?.progression||1);return Math.max(1,Math.round((seededInt111(`basegrow-${state.year}-${p.id}`,1,2)+dev+coach+facility+young)*speed))}
function processAiOffseason111(){
 if(!state.school||!state.world?.length)return null;if(Number(state.aiRosterOffseasonYear)===Number(state.year))return state.aiRosterOffseasonSummary||null;ensureAiRosters();const year=Number(state.year),summary=[],board=buildNationalDraftBoard111(year),draftRows=board.rows||[],earlyEntries=board.earlyEntries||[];
 for(const school of schools){const id=Number(school.id);if(id===userId())continue;const program=program111(school),world=worldTeam111(id),schoolDraftRows=draftRows.filter(d=>Number(d.schoolId)===id),earlyIds=new Set(earlyEntries.filter(d=>Number(d.schoolId)===id).map(d=>d.playerId));let roster=cachedAiRoster111(id).map(p=>({...p})),graduates=0,earlyEntrants=0;
  const returning=[];for(const p of roster){window.SDF_V175?.archiveAiPlayerSeason?.(p,id,school.name,year);const senior=Number(p.year)>=4,junior=Number(p.year)===3&&earlyIds.has(p.id);if(senior||junior){if(senior)graduates++;if(junior)earlyEntrants++;continue}const old=Number(p.ovr),gain=aiProgressGain111(p,program),ceiling=Math.max(old,Number(p.pot||old));p.ovr=clamp(Math.min(ceiling,old+gain),45,99);if(p.attrs)for(const k of Object.keys(p.attrs))p.attrs[k]=clamp(Number(p.attrs[k]||old)+Math.max(0,p.ovr-old+seededInt111(`attr-${year}-${p.id}-${k}`,-1,1)),40,99);p.year=clamp(Number(p.year||1)+1,1,4);p.morale=clamp(Number(p.morale||75)+seededInt111(`morale-${year}-${p.id}`,-3,4),45,99);returning.push(p)}
  const signees=(state.recruits||[]).filter(r=>Number(r.committedTo)===id).map(r=>recruitToAiPlayer111(r,id));roster=returning.concat(signees);fillAiWalkons111(school,roster);roster=trimAiRoster111(roster);assignAiDepth111(roster);state.aiRosters[id]=roster;const ratings=teamRatings111(roster),drafted=schoolDraftRows.length,firstRounders=schoolDraftRows.filter(d=>Number(d.round)===1).length,proBoost=Math.min(4,drafted*.35+firstRounders*.2),newPro=clamp(Number(program.pro||school.pro||50)+proBoost,20,99);if(world){world.rosterPower=ratings.overall;world.pro=newPro;world.aiRosterSize=roster.length;world.aiDraftedLastYear=drafted;world.aiFirstRoundersLastYear=firstRounders;world.aiSignedLastYear=signees.length}summary.push({schoolId:id,school:school.name,graduates,earlyEntrants,drafted,firstRounders,signed:signees.length,rosterSize:roster.length,overall:ratings.overall,pro:newPro})
 }
 state.aiRosterOffseasonYear=year;state.aiRosterOffseasonSummary=summary;state.aiDraftSummaries=(state.aiDraftSummaries||[]).filter(x=>Number(x.year)!==year).concat(summary.map(x=>({...x,year}))).filter(x=>Number(x.year)>=year-5);return summary
}
function aiDraftSummary111(teamId,year=state.year){return(state.aiDraftSummaries||[]).find(x=>Number(x.schoolId)===Number(teamId)&&Number(x.year)===Number(year))||null}
function generateNationalRoster(school){if(Number(school.id)===userId())return state.roster;ensureAiRosters();return cachedAiRoster111(school.id)}
function teamRatings111(roster){const offense=new Set(['QB','RB','WR','TE','OT','IOL']),defense=new Set(['EDGE','DL','LB','CB','S']),top=(arr,n)=>arr.slice().sort((a,b)=>Number(b.ovr)-Number(a.ovr)).slice(0,n),avg111=a=>a.length?Math.round(a.reduce((n,x)=>n+Number(x.ovr||0),0)/a.length):0;return{overall:avg111(top(roster,44)),offense:avg111(top(roster.filter(p=>offense.has(p.pos)),22)),defense:avg111(top(roster.filter(p=>defense.has(p.pos)),22))}}
function role111(p){if(p.starter)return'Starter';if(Number(p.depthIndex)<=2)return'Rotation';return p.walkOn?'Walk-on':'Reserve'}
function filteredTeams(){const q=rosterUi.query.toLowerCase();return schools.filter(s=>{const p=program111(s);return(rosterUi.conference==='ALL'||p.conference===rosterUi.conference)&&(!q||`${s.name} ${s.city} ${s.state} ${p.conference}`.toLowerCase().includes(q))}).sort((a,b)=>program111(a).conference.localeCompare(program111(b).conference)||a.name.localeCompare(b.name))}
function setNationalSection(section){rosterUi.section=section;document.querySelectorAll('[data-national-panel]').forEach(el=>el.classList.toggle('hidden',el.dataset.nationalPanel!==section));document.querySelectorAll('[data-national-section]').forEach(b=>b.classList.toggle('active',b.dataset.nationalSection===section));if(section==='rosters')renderNationalRosterBrowser();window.scrollTo({top:0,behavior:'smooth'})}
window.setNationalSection=setNationalSection;
function renderNationalTeamGrid(){const list=filteredTeams(),pages=Math.max(1,Math.ceil(list.length/rosterUi.pageSize));rosterUi.page=clamp(rosterUi.page,1,pages);const rows=list.slice((rosterUi.page-1)*rosterUi.pageSize,rosterUi.page*rosterUi.pageSize);$111('nationalTeamPager').innerHTML=`<div class="pager-info">Showing ${(rosterUi.page-1)*rosterUi.pageSize+1}-${Math.min(rosterUi.page*rosterUi.pageSize,list.length)} of ${list.length} programs</div><div class="pager-actions"><button class="btn neutral" onclick="changeNationalTeamPage(-1)" ${rosterUi.page<=1?'disabled':''}>Previous</button><span>${rosterUi.page}/${pages}</span><button class="btn neutral" onclick="changeNationalTeamPage(1)" ${rosterUi.page>=pages?'disabled':''}>Next</button></div>`;$111('nationalTeamGrid').innerHTML=rows.map(s=>{const p=program111(s),b=TEAM_BRANDING?.[s.id],active=Number(rosterUi.teamId)===Number(s.id),ratings=Number(s.id)===userId()?teamRatings():teamRatings111(cachedAiRoster111(s.id));return`<button class="national-team-card ${active?'active':''}" onclick="selectNationalTeam(${s.id})"><img src="${b?.logo||'icon.svg'}" alt=""><div><h3>${s.name}</h3><span class="sub">${p.conference} · ${s.city}, ${s.state}</span><span class="sub">OVR ${ratings.overall} · Prestige ${Math.round(p.prestige)} · Recent ${Math.round(p.recent)}</span></div></button>`}).join('')||'<p class="muted">No programs match this search.</p>'}
window.changeNationalTeamPage=delta=>{rosterUi.page+=delta;renderNationalTeamGrid();$111('nationalTeamGrid')?.scrollIntoView({block:'start',behavior:'smooth'})};
window.selectNationalTeam=id=>{rosterUi.teamId=Number(id);renderNationalTeamGrid();renderSelectedNationalRoster();$111('selectedNationalRoster')?.scrollIntoView({block:'start',behavior:'smooth'})};
function renderSelectedNationalRoster(){let school=schools.find(s=>s.id===Number(rosterUi.teamId))||state.school;if(!school)return;const program=program111(school),roster=generateNationalRoster(school),pos=rosterUi.position,players=roster.filter(p=>pos==='ALL'||p.pos===pos).sort((a,b)=>POSITIONS.indexOf(a.pos)-POSITIONS.indexOf(b.pos)||Number(b.starter)-Number(a.starter)||Number(b.ovr)-Number(a.ovr)),ratings=Number(school.id)===userId()?teamRatings():teamRatings111(roster),b=TEAM_BRANDING?.[school.id],draft=Number(school.id)===userId()?null:aiDraftSummary111(school.id,state.year-1);$111('nationalTeamSummary').innerHTML=`<div class="selected-roster-head"><img src="${b?.logo||'icon.svg'}" alt=""><div><span class="eyebrow">${program.conference}</span><h2>${school.name}</h2><span class="sub">${school.city}, ${school.state} · ${Number(school.id)===userId()?'Your live dynasty roster':'Persistent dynasty roster'}</span></div></div>`+metric('Players',roster.length)+metric('Overall',ratings.overall)+metric('Offense',ratings.offense)+metric('Defense',ratings.defense)+metric('Prestige',Math.round(program.prestige))+metric('Recent Success',Math.round(program.recent))+metric('Seniors',roster.filter(p=>Number(p.year)===4).length)+metric('Freshmen',roster.filter(p=>Number(p.year)===1).length)+(draft?metric('Last Draft',draft.drafted):'');$111('nationalRosterTable').innerHTML=players.map(p=>`<tr><td><button class="link-button" onclick="openNationalPlayerProfile(${school.id},'${p.id}')">${p.name}</button></td><td>${p.pos}</td><td><span class="roster-role-badge">${role111(p)}</span></td><td>${classLabel(p)}</td><td>${p.ovr}</td><td>${p.pot}</td><td>${p.dev}</td><td>${p.hometown}</td></tr>`).join('');$111('nationalRosterCards').innerHTML=players.map(p=>`<article class="mobile-data-card"><div class="mobile-data-head"><div><h3>${p.name}</h3><span class="sub">${p.pos} · ${p.arch} · ${classLabel(p)}</span></div><b>${p.ovr}</b></div><div class="mobile-data-grid"><div><small>ROLE</small><b>${role111(p)}</b></div><div><small>POT</small><b>${p.pot}</b></div><div><small>DEV</small><b>${p.dev}</b></div><div><small>MORALE</small><b>${p.morale}</b></div></div><button class="btn primary full" onclick="openNationalPlayerProfile(${school.id},'${p.id}')">Player Profile</button></article>`).join('')}
window.openNationalPlayerProfile=(teamId,playerId)=>{if(Number(teamId)===userId())return openPlayerProfile(playerId);const school=schools.find(s=>s.id===Number(teamId)),p=generateNationalRoster(school).find(x=>x.id===playerId);if(!p)return;$111('modalBody').innerHTML=`<span class="eyebrow">NATIONAL ROSTER PROFILE</span><h2>${p.name}</h2><p class="muted">${school.name} · ${p.pos} · ${p.arch}</p><div class="metric-grid">${metric('Class',classLabel(p))}${metric('OVR',p.ovr)}${metric('Potential',p.pot)}${metric('Development',p.dev)}${metric('Depth Role',role111(p))}${metric('Morale',p.morale)}${metric('Hometown',p.hometown)}${metric('Roster Status',p.walkOn?'Walk-on':'Scholarship')}</div><div class="ai-player-note"><b>Persistent computer-team player</b><span class="sub">This player remains on ${school.name}'s roster from week to week, develops in the offseason, can be replaced by signed recruits, and leaves through graduation or the pro draft.</span></div>`;$111('modal').classList.remove('hidden');$111('modal').querySelector('.modal-card').scrollTop=0};
function renderNationalRosterBrowser(){if(!$111('nationalTeamGrid'))return;ensureAiRosters();if(rosterUi.teamId==null)rosterUi.teamId=userId();renderNationalTeamGrid();renderSelectedNationalRoster()}
function wire111(){document.querySelectorAll('[data-national-section]').forEach(b=>b.onclick=()=>setNationalSection(b.dataset.nationalSection));const conf=$111('nationalConferenceFilter');if(conf&&!conf.dataset.ready){[...new Set(schools.map(s=>program111(s).conference))].sort().forEach(c=>conf.insertAdjacentHTML('beforeend',`<option>${c}</option>`));conf.dataset.ready='1'}const pos=$111('nationalRosterPosition');if(pos&&!pos.dataset.ready){POSITIONS.forEach(p=>pos.insertAdjacentHTML('beforeend',`<option>${p}</option>`));pos.dataset.ready='1'}if($111('nationalTeamSearch'))$111('nationalTeamSearch').oninput=e=>{rosterUi.query=e.target.value;rosterUi.page=1;renderNationalTeamGrid()};if(conf)conf.onchange=e=>{rosterUi.conference=e.target.value;rosterUi.page=1;renderNationalTeamGrid()};if(pos)pos.onchange=e=>{rosterUi.position=e.target.value;renderSelectedNationalRoster()}}
const priorShowTab=window.showTab;window.showTab=function(name){let out=priorShowTab.apply(this,arguments);if(name==='rankings'){setNationalSection(rosterUi.section);renderNationalRosterBrowser()}return out};
const priorRenderAll=window.renderAll;window.renderAll=function(...args){let out=priorRenderAll.apply(this,args);if(state.school){ensureFixedRecruitClass();ensureAiRosters();if(!$111('rankingsTab')?.classList.contains('hidden'))renderNationalRosterBrowser()}return out};
wire111();if(state.school){ensureFixedRecruitClass();ensureAiRosters()}
window.SDF_AI_ROSTERS={version:VERSION,draftRules:{rounds:DRAFT_ROUNDS,picksPerRound:DRAFT_PICKS_PER_ROUND,firstRoundSchoolCap:DRAFT_FIRST_ROUND_SCHOOL_CAP,totalSchoolCap:DRAFT_TOTAL_SCHOOL_CAP},ensureAll:ensureAiRosters,get:getAiRoster111,set:setAiRoster111,storeUserProgram:storeUserProgram111,takeProgramForUser:takeProgramForUser111,removePlayersFromProgram:removePlayersFromProgram111,processOffseason:processAiOffseason111,buildNationalDraftBoard:buildNationalDraftBoard111,teamRatings:teamRatings111,program:program111,evaluateDraftProspect:evaluateDraftProspect111,juniorDeclares:juniorDeclare111,assignDepth:assignAiDepth111,recruitToPlayer:recruitToAiPlayer111,aiDraftSummary:aiDraftSummary111};
window.SDF_V111_TEST={INITIAL_POOL,RECRUIT_BOARD_LIMIT,CLASS_SIGNING_LIMIT,DRAFT_ROUNDS,DRAFT_PICKS_PER_ROUND,DRAFT_FIRST_ROUND_SCHOOL_CAP,DRAFT_TOTAL_SCHOOL_CAP,ensureFixedRecruitClass,generateNationalRoster,teamRatings111,ensureAiRosters,processAiOffseason111,buildNationalDraftBoard111,evaluateDraftProspect111,juniorDeclare111};
})();
(()=>{
'use strict';
const $13=id=>document.getElementById(id);
const R=window.SDF_RECRUITING_V2;
if(!R)return;
const USER=()=>Number(state.school?.id);
const FULL_TARGETS={QB:3,RB:4,WR:8,TE:3,OT:6,IOL:7,EDGE:6,DL:6,LB:8,CB:8,S:6,K:2,P:2};
const OFFENSE_PROFILES={
 'Pro Style':{poss:12,pass:52,runEff:1.02,passEff:1.02,explosive:0,turnover:0},
 Spread:{poss:13,pass:59,runEff:1.00,passEff:1.04,explosive:.02,turnover:.005},
 'Air Raid':{poss:14,pass:73,runEff:.88,passEff:1.10,explosive:.05,turnover:.02},
 'Power Run':{poss:11,pass:36,runEff:1.12,passEff:.94,explosive:-.01,turnover:-.01},
 Option:{poss:12,pass:29,runEff:1.10,passEff:.88,explosive:.03,turnover:.025},
 'Tempo Spread':{poss:15,pass:64,runEff:1.01,passEff:1.06,explosive:.04,turnover:.025}
};
const DEFENSE_PROFILES={
 '4-3':{run:4,pass:-2,pressure:1,bigRisk:0},'3-4':{run:2,pass:0,pressure:3,bigRisk:1},'4-2-5':{run:-3,pass:4,pressure:1,bigRisk:0},'3-3-5':{run:-4,pass:3,pressure:2,bigRisk:2},Multiple:{run:1,pass:1,pressure:1,bigRisk:0}
};
function save13(reason){try{window.SDF_RELEASE_TEST?.saveNow?.(reason,false,false)}catch{}}
function hash13(v){let h=2166136261;for(const ch of String(v)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function seeded13(v,min,max){return min+(hash13(v)%((max-min)+1))}
function ensure13(){if(!state.school)return;state.recruitVisitCalendar??={};state.gamePlanHistory??=[];state.gamePlan??={offenseAggression:50,tempo:50,runPass:50,blitz:35,manZone:50,fourthDown:35};(state.recruits||[]).forEach(r=>{r.visitScheduledWeek??=null;r.visitCompletedWeek??=null;r.offerCooldownUntil??=0})}
function letter(n){n=Number(n||0);return n>=93?'A+':n>=90?'A':n>=87?'A-':n>=83?'B+':n>=80?'B':n>=77?'B-':n>=73?'C+':n>=70?'C':n>=67?'C-':n>=63?'D+':n>=60?'D':'F'}
function forecast(pos){const players=(state.roster||[]).filter(p=>p.pos===pos),returning=players.filter(p=>p.year<4||p.redshirt).length,graduating=players.filter(p=>p.year>=4&&!p.redshirt).length,commits=(state.commits||[]).filter(r=>r.pos===pos).length,target=FULL_TARGETS[pos]||3,projected=returning+commits,shortage=Math.max(0,target-projected);return{pos,returning,graduating,commits,target,projected,shortage,label:shortage>=3?'Critical':shortage===2?'High':shortage===1?'Moderate':'Covered'}}
function forecastAll(){return POSITIONS.map(forecast).sort((a,b)=>b.shortage-a.shortage||b.graduating-a.graduating||POSITIONS.indexOf(a.pos)-POSITIONS.indexOf(b.pos))}
function urgency(r){const status=R.statusFor(r),rc=R.race(r),u=rc.user;if(r.committedTo)return{key:'commit',label:r.committedTo===USER()?'SIGNED':'COMMITTED',detail:schoolName(r.committedTo)};if(status.lockedOut||!status.access.allowed)return{key:'fading',label:'LOCKED OUT',detail:status.activeReason};if(!u)return{key:'fading',label:'LONG SHOT',detail:'Outside current school list'};const lead=u.rank===1?u.score-(rc.second?.score||0):0,gap=rc.gap||0,trend=Number(u.trend||0);if(r.offered&&u.score>=96)return{key:'commit',label:'COMMIT READY',detail:'Push to 100'};if(r.visitScheduledWeek)return{key:'visit',label:`VISIT W${r.visitScheduledWeek}`,detail:'Official visit scheduled'};if(u.rank===1&&lead>=10)return{key:'safe',label:'SAFE LEAD',detail:`Leading by ${Math.round(lead)}`};if(u.rank===1)return{key:'battle',label:'PROTECT LEAD',detail:`Leading by ${Math.round(lead)}`};if(u.rank<=3&&gap<=7)return{key:'battle',label:'TOSS-UP',detail:`${Math.round(gap)} behind`};if(state.week>=5&&u.rank<=5&&!r.visitCompletedWeek)return{key:'visit',label:'VISIT NEEDED',detail:'Schedule a home game'};if(trend<-1.5||u.rank>8)return{key:'fading',label:'FADING',detail:`#${u.rank} · trend ${trend.toFixed(1)}`};if(!r.offered&&state.week>=4)return{key:'high',label:'OFFER NEEDED',detail:'Scholarship can move the race'};if(r.stars===2&&state.week>=7)return{key:'safe',label:'LATE TARGET',detail:'Still available'};return{key:'high',label:'ACTIVE BATTLE',detail:`#${u.rank} · ${Math.round(gap)} behind`}}
function urgencyHtml(r){const u=urgency(r);return`<span class="urgency-badge urgency-${u.key}" title="${u.detail}">${u.label}</span>`}
function renderForecast(){const host=$13('recruitRosterForecast');if(!host)return;const rows=POSITIONS.map(forecast),open=rows.filter(x=>x.shortage>0).length;host.innerHTML=`<div class="section-head"><div><span class="eyebrow">NEXT-SEASON ROSTER FORECAST</span><h3>All Position Needs</h3><p class="muted">All ${rows.length} positions stay visible in a consistent order, with shortages highlighted for quick class balancing.</p></div><span class="forecast-count">${open} need${open===1?'':'s'} open</span></div><div class="forecast-grid forecast-grid-all">${rows.map(x=>`<article class="forecast-card ${x.shortage>=3?'critical':x.shortage>=2?'high':x.shortage===1?'moderate':'good'}"><small>${x.pos} · ${x.label}</small><b>${x.projected}/${x.target} projected</b><span class="sub">${x.returning} returning · ${x.commits} commits · ${x.graduating} leaving</span></article>`).join('')}</div>`}
function classBalance(){const commits=state.commits||[],position={},talent=commits.length?Math.round(commits.reduce((n,r)=>n+(r.trueOvr||r.ovr)*.72+r.stars*6,0)/commits.length):0;for(const p of POSITIONS)position[p]=commits.filter(r=>r.pos===p).length;let totalNeed=0,filledNeed=0,over=0;const needsByPos={};for(const p of POSITIONS){const returning=(state.roster||[]).filter(x=>x.pos===p&&(x.year<4||x.redshirt)).length,need=Math.max(0,(FULL_TARGETS[p]||3)-returning),signed=position[p]||0;needsByPos[p]=need;totalNeed+=need;filledNeed+=Math.min(need,signed);over+=Math.max(0,signed-(need+1))}const coverage=totalNeed?Math.round(filledNeed/totalNeed*100):100,balance=clamp(100-over*8-Math.max(0,totalNeed-filledNeed)*2,25,100),score=commits.length?clamp(Math.round(talent*.58+coverage*.24+balance*.18),0,100):0,grade=commits.length?letter(score):'—';return{commits,position,needsByPos,talent,coverage,balance,score,grade}}
function renderClassBalance(){const host=$13('classBalancePanel');if(!host)return;const c=classBalance(),rows=forecastAll().filter(x=>x.shortage>0||c.position[x.pos]).slice(0,12);host.innerHTML=`<div class="class-grade-head"><div><span class="eyebrow">CLASS CONSTRUCTION</span><h3>Position-Balanced Class Grade</h3><p class="muted">Talent matters, but ignoring major roster holes or oversigning one position lowers the grade.</p></div><div class="class-grade-letter">${c.grade}</div></div><div class="metric-grid">${metric('Talent',c.talent||'—')}${metric('Need Coverage',c.coverage+'%')}${metric('Position Balance',c.balance+'%')}${metric('Composite',c.score||'—')}</div><div class="class-position-grid">${rows.map(x=>`<article class="class-position-card"><small>${x.pos}</small><b>${c.position[x.pos]||0} signed</b><span class="sub">Pre-class need ${c.needsByPos[x.pos]||0} · ${x.projected}/${x.target} projected now</span></article>`).join('')}</div>`}
function withdrawOffer(id){const r=findR(id);if(!r||!r.offered||r.committedTo)return;const penalty=state.week>=9?9:state.week>=6?6:3,hasPromise=(state.promises||[]).some(p=>p.targetId===r.id&&!p.resolved),nil=Number(state.nilCommitments?.[r.id]||0),message=`Withdraw the scholarship from ${r.name}? You will recover the scholarship slot, but lose ${penalty}${hasPromise?' plus a broken-promise penalty':''} influence.${nil?` The NIL pledge is cancelled and 90% (${formatNilMoney(Math.round(nil*.9))}) returns to the collective.`:''}`;if(!confirm(message))return;r.offered=false;state.scholarships=Math.min(35,Number(state.scholarships||0)+1);r.weeklyPlan='NONE';r.offerCooldownUntil=state.week+1;const uid=USER();r.recruitInfluence??={};r.interest??={};r.interestTrend??={};r.recruitInfluence[uid]=Math.max(0,Number(r.recruitInfluence[uid]||0)-penalty-(hasPromise?3:0));r.interestTrend[uid]=-(penalty+5);r.interest[uid]=Math.max(2,Number(r.interest[uid]||0)-penalty-5-(hasPromise?3:0));if(nil){state.nilBudget+=Math.round(nil*.9);delete state.nilCommitments[r.id]}if(r.visitScheduledWeek){delete state.recruitVisitCalendar[`${state.year}-${r.visitScheduledWeek}-${r.id}`];r.visitScheduledWeek=null}for(const p of state.promises||[]){if(p.targetId===r.id&&!p.resolved){p.resolved=true;p.kept=false}}state.news.push(`${state.school.name} withdrew ${r.name}'s scholarship offer. The relationship took a hit.`);window.renderAll();save13('Scholarship withdrawn')}
window.withdrawRecruitOffer=withdrawOffer;
const priorOffer=window.offer;window.offer=function(id){const r=findR(id);if(r&&Number(r.offerCooldownUntil||0)>=state.week){alert(`${r.name} will not reconsider an offer until after Week ${r.offerCooldownUntil}.`);return}return priorOffer(id)};
function visitGames(r){return(state.schedule||[]).filter(g=>g.home&&!g.result&&g.week>=state.week&&g.week<=12).map(g=>{const count=(state.recruits||[]).filter(x=>Number(x.visitScheduledWeek)===Number(g.week)).length,quality=clamp(50+(g.rivalry?18:0)+(g.oppPower>=85?15:g.oppPower>=75?8:0)+(state.stadium?.atmosphere||55)/5,35,100);return{...g,count,quality}})}
function openVisitCalendar(id){const r=findR(id);if(!r)return;const status=R.statusFor(r);if(!status.canRecruit){alert(status.activeReason);return}if(!r.offered){alert('Offer a scholarship before scheduling an official visit.');return}if(r.visitCompletedWeek){alert(`${r.name} already completed an official visit in Week ${r.visitCompletedWeek}.`);return}if(r.visitScheduledWeek){alert(`${r.name} is already scheduled for Week ${r.visitScheduledWeek}.`);return}if(state.weeklyHours<20){alert('You need 20 recruiting hours to schedule an official visit.');return}const games=visitGames(r);$13('modalBody').innerHTML=`<span class="eyebrow">OFFICIAL VISIT CALENDAR</span><h2>${r.name}</h2><p class="muted">Choose a future home game. Wins, rivalries, ranked-quality opponents, stadium atmosphere and program fit affect the result. Maximum 10 visitors per game.</p><div class="visit-calendar">${games.map(g=>`<article class="visit-game"><div><b>Week ${g.week}: vs ${g.opponent}</b><span class="sub">${g.rivalry?'Rivalry · ':''}Opponent power ${g.oppPower} · ${g.weather||'Clear'} · ${g.count}/10 visitors</span><span class="visit-quality">Visit quality ${letter(g.quality)}</span></div><button class="btn primary" onclick="scheduleOfficialVisit('${r.id}',${g.week})" ${g.count>=10?'disabled':''}>Schedule · 20 hrs</button></article>`).join('')||'<p class="muted">No future home games remain. This recruit cannot take an official visit this season.</p>'}</div>`;$13('modal').classList.remove('hidden');$13('modal').querySelector('.modal-card').scrollTop=0}
window.visit=openVisitCalendar;
window.scheduleOfficialVisit=(id,week)=>{const r=findR(id),g=(state.schedule||[]).find(x=>x.week===Number(week));if(!r||!g||!g.home||g.result||state.weeklyHours<20)return;const count=(state.recruits||[]).filter(x=>Number(x.visitScheduledWeek)===Number(week)).length;if(count>=10){alert('That game already has 10 official visitors.');return}state.weeklyHours-=20;r.visit=false;r.visitScheduledWeek=Number(week);state.recruitVisitCalendar[`${state.year}-${week}-${id}`]=true;state.news.push(`${r.name} scheduled an official visit for Week ${week} against ${g.opponent}.`);$13('modal').classList.add('hidden');window.renderAll();save13('Official visit scheduled')};
function resolveVisits(g,win,margin){const results=[];for(const r of state.recruits||[]){if(Number(r.visitScheduledWeek)!==Number(g.week)||r.committedTo)continue;R.ensureRecruit(r);const fit=R.weightedFit(r,state.school),atmos=Number(state.stadium?.atmosphere||55),ranked=g.oppPower>=85,base=3+fit/24+atmos/28+(win?3:-1)+(g.rivalry?2:0)+(ranked?2:0)+(margin>=21?2:margin<=-21?-2:0),boost=clamp(Math.round(base),-3,14),uid=USER();r.visitBoostBySchool??={};r.recruitInfluence??={};r.interest??={};r.interestTrend??={};r.visitBoostBySchool[uid]=clamp(Number(r.visitBoostBySchool[uid]||0)+Math.max(0,boost),0,16);r.recruitInfluence[uid]=clamp(Number(r.recruitInfluence[uid]||0)+Math.max(0,boost*.35),0,36);const cap=R.statusFor(r).eligibility.cap;r.interest[uid]=clamp(Number(r.interest[uid]||0)+boost,2,cap);r.interestTrend[uid]=boost;r.visitCompletedWeek=g.week;r.visitScheduledWeek=null;delete state.recruitVisitCalendar[`${state.year}-${g.week}-${r.id}`];R.maybeImmediateCommit(r);results.push(`${r.name}: ${boost>=0?'+':''}${boost} interest`);state.news.push(`${r.name}'s Week ${g.week} visit ${boost>=8?'was outstanding':boost>=4?'went well':boost>=0?'was average':'hurt the relationship'} (${boost>=0?'+':''}${boost}).`)}return results}
function appendRecruitUI(){renderForecast();renderClassBalance();const links=document.querySelectorAll('#recruitTable [onclick^="openRecruit(\'"],#recruitCardList [onclick^="openRecruit(\'"]');for(const link of links){const m=link.getAttribute('onclick')?.match(/openRecruit\('([^']+)'\)/),r=m&&findR(m[1]);if(!r)continue;const host=link.closest('tr')?.querySelector('td:nth-child(2)')||link.closest('article')?.querySelector('.mobile-data-head>div');if(host&&!host.querySelector('.urgency-badge'))host.insertAdjacentHTML('beforeend',urgencyHtml(r));const actions=link.closest('tr')?.querySelector('.actions')||link.closest('article')?.querySelector('.mobile-actions');if(actions&&r.offered&&!r.committedTo&&!actions.querySelector('.withdraw-offer'))actions.insertAdjacentHTML('beforeend',`<button class="btn small danger withdraw-offer" onclick="withdrawRecruitOffer('${r.id}')">Withdraw Offer</button>`)} }
const priorRecruitRender=window.renderRecruiting;window.renderRecruiting=function(...args){const out=priorRecruitRender.apply(this,args);appendRecruitUI();return out};
function appendProfileExtras(id){const r=findR(id);if(!r)return;const body=$13('modalBody'),f=forecast(r.pos),u=urgency(r);body.insertAdjacentHTML('beforeend',`<section class="recruit-profile-section"><h3>Roster Forecast & Urgency</h3><div class="metric-grid">${metric('Urgency',u.label)}${metric('Projected '+r.pos,`${f.projected}/${f.target}`)}${metric('Returning',f.returning)}${metric('Current commits',f.commits)}${metric('Graduating',f.graduating)}${metric('Position need',f.label)}</div><p class="muted">${u.detail}</p>${r.visitScheduledWeek?`<div class="recruit-status-message warning"><b>Official Visit</b><span>Scheduled Week ${r.visitScheduledWeek}.</span></div>`:''}<div class="actions">${r.offered&&!r.committedTo?`<button class="btn danger" onclick="withdrawRecruitOffer('${r.id}')">Withdraw Scholarship</button>`:''}${r.offered&&!r.visitScheduledWeek&&!r.visitCompletedWeek?`<button class="btn warning" onclick="visit('${r.id}')">Choose Official Visit Game</button>`:''}</div></section>`);for(const btn of body.querySelectorAll('[onclick^="visit(\'"]')){btn.textContent=r.visitScheduledWeek?`Visit Scheduled W${r.visitScheduledWeek}`:r.visitCompletedWeek?`Visit Completed W${r.visitCompletedWeek}`:'Choose Official Visit Game';btn.disabled=!!r.visitScheduledWeek||!!r.visitCompletedWeek}}
const priorOpen=window.openRecruit;window.openRecruit=function(id){const out=priorOpen(id);appendProfileExtras(id);return out};const priorQuick=window.openRecruitQuickMenu;window.openRecruitQuickMenu=function(id){const out=priorQuick(id);appendProfileExtras(id);return out};

window.computeClassRankings=function(){const rows=schools.map(s=>{const user=Number(s.id)===USER(),list=user?(state.commits||[]):(state.recruits||[]).filter(r=>Number(r.committedTo)===Number(s.id)),count=list.length,five=list.filter(r=>r.stars===5).length,four=list.filter(r=>r.stars===4).length,avgRating=count?Math.round(avg(list.map(r=>r.trueOvr||r.ovr||65))):0,posCounts={};for(const r of list)posCounts[r.pos]=(posCounts[r.pos]||0)+1;const diversity=Object.keys(posCounts).length/POSITIONS.length*100,over=Object.values(posCounts).reduce((n,c)=>n+Math.max(0,c-4),0),balance=user?classBalance().balance:clamp(Math.round(diversity-over*6),30,100),score=count?avgRating*.75+five*15+four*7+count*1.2+balance*.18:0;return{id:s.id,name:s.name,commits:count,five,four,avgRating,balance,score}}).sort((a,b)=>b.score-a.score||b.avgRating-a.avgRating).map((x,i)=>({...x,rank:i+1}));state.classRankings=rows;return rows};
window.renderClassRankings=function(){const host=$13('classRankingGrid');if(!host)return;window.computeClassRankings();host.innerHTML=state.classRankings.slice(0,25).map(x=>`<div class="class-ranking-card"><b>#${x.rank} ${x.name}</b><span class="sub">${x.commits} commits · ${x.five} five-stars · ${x.four} four-stars · Avg ${x.avgRating||'—'} · Balance ${x.balance}%</span></div>`).join('')};
function stableOpponent(g){if(!g)return null;if(g.scoutingProfile)return g.scoutingProfile;const tendencies=['Pass Heavy','Balanced','Run Heavy','Tempo','Ball Control'],defenses=['4-3','3-4','4-2-5','3-3-5','Multiple'],weaknesses=['Pass protection','Run defense','Secondary depth','Turnover margin','Red-zone offense','Special teams'],stars=['Quarterback','Running back','Edge rusher','Cornerback','Wide receiver'];g.scoutingProfile={tendency:tendencies[hash13(`${state.year}-${g.oppId}-t`)%tendencies.length],defense:defenses[hash13(`${state.year}-${g.oppId}-d`)%defenses.length],weakness:weaknesses[hash13(`${state.year}-${g.oppId}-w`)%weaknesses.length],star:stars[hash13(`${state.year}-${g.oppId}-s`)%stars.length],form:['Hot','Steady','Inconsistent','Slumping'][hash13(`${state.year}-${g.oppId}-f`)%4]};return g.scoutingProfile}
function planEffects(g){
 const baseProfile=OFFENSE_PROFILES[state.offense]||OFFENSE_PROFILES['Pro Style'],opp=stableOpponent(g),runPass=Number(state.gamePlan.runPass||50),tempo=Number(state.gamePlan.tempo||50),agg=Number(state.gamePlan.offenseAggression||50),blitz=Number(state.gamePlan.blitz||35),zone=Number(state.gamePlan.manZone||50),fourth=Number(state.gamePlan.fourthDown||35),passRate=clamp(baseProfile.pass+(runPass-50)*.5,18,84),poss=clamp(Math.round(baseProfile.poss+(tempo-50)/15),9,18);
 const qb=roleParticipants(['QB1'])[0]?.p||state.roster.filter(p=>p.pos==='QB'&&!p.redshirt&&!p.injury).sort((a,b)=>b.ovr-a.ovr)[0],backs=roleParticipants(['RB1','RB2']),targets=roleParticipants(['WR1','WR2','SLOT','TE1']),line=roleParticipants(['LT','RT','LG','RG','C']);
 const qbGrade=playerSkill13(qb,['accuracy','decision','throwPower']),qbDecision=playerSkill13(qb,['decision','awareness','accuracy']),rbGrade=backs.length?avg(backs.map(x=>playerSkill13(x.p,['vision','elusiveness','power','speed']))):70,targetGrade=targets.length?avg(targets.map(x=>playerSkill13(x.p,['catch','route','speed']))):70,lineGrade=line.length?avg(line.map(x=>playerSkill13(x.p,['strength','awareness','skill']))):70;
 const passPersonnel=clamp(1+(qbGrade-72)/150+(targetGrade-72)/330+(lineGrade-72)/420,.78,1.27),runPersonnel=clamp(1+(rbGrade-72)/185+(lineGrade-72)/310,.78,1.25),op={...baseProfile,passEff:Number(baseProfile.passEff||1)*passPersonnel,runEff:Number(baseProfile.runEff||1)*runPersonnel};
 const turnoverRisk=clamp(7+baseProfile.turnover*100+(agg-50)*.055+Math.max(0,tempo-55)*.045+(72-qbDecision)*.078-(state.weeklyPractice==='Turnover Prevention'?2.5:0),2.2,18),explosive=clamp(10+baseProfile.explosive*100+(agg-50)*.09+(qbGrade-72)*.035+(targetGrade-72)*.02,4,27),pressure=clamp((DEFENSE_PROFILES[state.defense]?.pressure||1)+(blitz-35)/14,0,8),bigRisk=clamp((DEFENSE_PROFILES[state.defense]?.bigRisk||0)+(blitz-35)/20+Math.abs(zone-50)/35,0,9);return{op,opp,passRate,poss,turnoverRisk,explosive,pressure,bigRisk,fourth,tempo,agg,blitz,zone,qbGrade,qbDecision,rbGrade,targetGrade,lineGrade}
}
function practiceDescription13(f){return{Balanced:'Small preparation benefit on both sides of the ball.', 'Opponent Scouting':'Reduces variance and improves performance against the opponent’s main tendency.','Passing Offense':'Improves pass protection, completion rate and passing production.','Rushing Offense':'Improves yards per carry and short-yardage success.','Run Defense':'Reduces opponent rushing efficiency.','Pass Defense':'Improves coverage, sacks and interceptions.','Turnover Prevention':'Reduces interceptions and fumbles.','Young Player Development':'Young backups gain extra development, but weekly readiness drops slightly.','Injury Prevention':'Reduces injury risk, especially with high tempo.'}[f]||''}
function updatePlan13(k,v){state.gamePlan[k]=Number(v);window.renderGamePlan();save13('Game plan updated')}window.updateGamePlan=updatePlan13;window.choosePracticeFocus=f=>{state.weeklyPractice=f;window.renderGamePlan();save13('Practice focus')};
window.renderGamePlan=function(){if(!$13('opponentScoutPanel'))return;ensure13();const g=state.schedule?.[state.week-1],opp=stableOpponent(g);if(!g){$13('opponentScoutPanel').innerHTML='<p class="muted">No upcoming regular-season game.</p>';return}const e=planEffects(g);$13('opponentScoutPanel').innerHTML=`<div class="scout-report"><div><small>OPPONENT</small><b>${g.opponent}</b></div><div><small>POWER</small><b>${g.oppPower}</b></div><div><small>TENDENCY</small><b>${opp.tendency}</b></div><div><small>DEFENSIVE SCHEME</small><b>${opp.defense}</b></div><div><small>WEAKNESS</small><b>${hasCoachSkill('TACTICIAN_2')?opp.weakness:'Partially scouted'}</b></div><div><small>STAR UNIT</small><b>${opp.star}</b></div><div><small>FORM</small><b>${opp.form}</b></div><div><small>WEATHER</small><b>${g.weather||'Clear'}</b></div></div>`;const focuses=['Balanced','Opponent Scouting','Passing Offense','Rushing Offense','Run Defense','Pass Defense','Turnover Prevention','Young Player Development','Injury Prevention'];$13('practiceFocusGrid').innerHTML=focuses.map(f=>`<div class="choice-card ${state.weeklyPractice===f?'active':''}"><h4>${f}</h4><span class="sub">${practiceDescription13(f)}</span><button class="btn primary" onclick="choosePracticeFocus('${f}')">Select</button></div>`).join('');const controls=[['runPass','Run ←→ Pass',`${Math.round(100-e.passRate)}% run / ${Math.round(e.passRate)}% pass`],['tempo','Slow ←→ Fast',`${e.poss} expected possessions`],['offenseAggression','Conservative ←→ Aggressive',`${e.explosive.toFixed(0)}% explosive chance`],['blitz','Coverage ←→ Blitz',`Pressure +${e.pressure.toFixed(1)}`],['manZone','Man ←→ Zone',`${e.zone<40?'Mostly man':e.zone>60?'Mostly zone':'Mixed coverage'}`],['fourthDown','Punt ←→ Go For It',`${Math.round(e.fourth)} aggression`]];$13('gamePlanControls').innerHTML=controls.map(([k,l,d])=>`<div class="gameplan-card"><h4>${l}</h4><input type="range" min="0" max="100" value="${state.gamePlan[k]}" oninput="updateGamePlan('${k}',this.value)"><b>${state.gamePlan[k]}</b><span class="plan-value">${d}</span></div>`).join('');$13('gamePlanImpact').innerHTML=`<div class="playbook-truth"><b>${state.offense} offense + ${state.defense} defense</b><span class="sub">These settings now drive play selection, possessions, passing/rushing totals, sacks, turnovers, fourth-down attempts, explosive plays, fatigue and injury risk.</span></div><div class="gameplan-impact-grid"><article class="impact-card"><small>PASS RATE</small><b>${Math.round(e.passRate)}%</b><span class="sub">Playbook base plus Run/Pass slider.</span></article><article class="impact-card"><small>POSSESSIONS</small><b>${e.poss}</b><span class="sub">Tempo creates more chances but more fatigue.</span></article><article class="impact-card"><small>TURNOVER RISK</small><b>${e.turnoverRisk.toFixed(1)}%</b><span class="sub">Aggression and tempo raise it; prevention practice lowers it.</span></article><article class="impact-card"><small>DEFENSIVE PRESSURE</small><b>${e.pressure.toFixed(1)}</b><span class="sub">Blitzing creates sacks but increases big-play risk.</span></article><article class="impact-card"><small>BIG-PLAY RISK</small><b>${e.bigRisk.toFixed(1)}</b><span class="sub">Extreme coverage and blitz settings can be punished.</span></article><article class="impact-card"><small>PRACTICE</small><b>${state.weeklyPractice}</b><span class="sub">Applied to this week’s simulation and player output.</span></article></div>`}
function schemeMatchOff(stateScheme,oppDefense){const map={Air_Raid:{'4-3':3,'4-2-5':-3},Power_Run:{'3-3-5':4,'4-3':-2},Option:{'4-2-5':2,'3-4':-2},Spread:{'4-3':2,'4-2-5':-1},Tempo_Spread:{'4-3':2,'3-3-5':-1}};return map[String(stateScheme).replaceAll(' ','_')]?.[oppDefense]||0}
function schemeMatchDef(scheme,tendency){const d=DEFENSE_PROFILES[scheme]||DEFENSE_PROFILES.Multiple;if(tendency==='Run Heavy'||tendency==='Ball Control')return d.run;if(tendency==='Pass Heavy'||tendency==='Tempo')return d.pass;return Math.round((d.run+d.pass)/2)}
function driveSim(off,def,opt){const pass=opt.passRate/100,edge=clamp(off-def+rand(-(opt.variance||13),(opt.variance||13)),-30,30),turnChance=opt.turnoverRisk/100,sackChance=clamp(.10+(opt.sackPressure||0)*.01+(pass-.5)*.08,.055,.30),explosiveChance=opt.explosive/100,big=Math.random()<explosiveChance,turn=Math.random()<turnChance,sack=pass>.42&&Math.random()<sackChance?(Math.random()<.12?2:1):0,plays=rand(3,8);let baseYards=clamp(Math.round(8+plays*3.6+edge*.30+(big?17:0)-sack*6+rand(-5,5)),-5,88);if(turn)baseYards=Math.max(0,Math.round(baseYards*(.35+Math.random()*.55)));let passWeight=pass*(opt.passEff||1)*1.45,rushWeight=(1-pass)*(opt.runEff||1)*.88,effTotal=Math.max(.1,passWeight+rushWeight),passYds=Math.max(0,Math.round(baseYards*passWeight/effTotal)),rushYds=Math.max(0,baseYards-passYds),thirdAtt=rand(1,4),thirdConv=clamp(Math.round(thirdAtt*(.36+edge/150)),0,thirdAtt);if(turn)return{result:'Turnover',points:0,plays,yards:baseYards,passYds,rushYds,turnovers:1,sacks:sack,thirdAtt,thirdConv,fourthAtt:0,fourthConv:0,redAtt:0,redConv:0,touchdowns:0,fieldGoals:0,punts:0};let points=0,result='Punt',fourthAtt=0,fourthConv=0,tdChance=clamp(.23+edge*.0038+(big?.105:0),.07,.43),fgChance=clamp(.13+edge*.0012+(baseYards>=34?.03:0),.06,.20),roll=Math.random();if(roll<tdChance){points=7;result='Touchdown';baseYards=Math.max(baseYards,rand(28,62))}else if(roll<tdChance+fgChance){points=3;result='Field Goal';baseYards=Math.max(baseYards,rand(16,43))}else if(baseYards>=24&&Math.random()<opt.fourth/145){fourthAtt=1;const success=Math.random()<clamp(.40+edge/150+(opt.fourth<65?.04:0),.22,.72);if(success){fourthConv=1;points=Math.random()<.34?7:3;result=points===7?'Fourth-down Touchdown':'Fourth-down Field Goal'}else result='Turnover on Downs'}else if(edge<-10||baseYards<12)result='Three-and-out';passWeight=pass*(opt.passEff||1)*1.45;rushWeight=(1-pass)*(opt.runEff||1)*.88;effTotal=Math.max(.1,passWeight+rushWeight);passYds=Math.max(0,Math.round(baseYards*passWeight/effTotal));rushYds=Math.max(0,baseYards-passYds);const redAtt=points>0||baseYards>=45?1:0,redConv=points===7?1:0,touchdowns=points===7?1:0,fieldGoals=points===3?1:0,punts=['Punt','Three-and-out'].includes(result)?1:0;return{result,points,plays,yards:baseYards,passYds,rushYds,turnovers:0,sacks:sack,thirdAtt,thirdConv,fourthAtt,fourthConv,redAtt,redConv,touchdowns,fieldGoals,punts}}
function mergeStats(a,d){for(const k of ['plays','yards','passYds','rushYds','turnovers','sacks','thirdAtt','thirdConv','fourthAtt','fourthConv','redAtt','redConv','touchdowns','fieldGoals','punts'])a[k]=(a[k]||0)+(d[k]||0)}
function roleParticipants(keys){window.SDF_V11_TEST?.ensureRealDepth?.();const map=new Map();for(const key of keys){const role=window.SDF_V11_TEST?.ROLE_DEFS?.find(r=>r.key===key),slots=state.realDepthChart?.[key]?.slots||[];for(const slot of slots){const p=state.roster.find(x=>x.id===slot.playerId);if(!p||p.redshirt||p.injury)continue;const w=(Number(slot.snapShare||0)/100)*(role?.weight||1);map.set(p.id,{p,weight:(map.get(p.id)?.weight||0)+w})}}return[...map.values()].filter(x=>x.weight>0)}
function distribute(total,list,key){if(!list.length)return;const sum=list.reduce((n,x)=>n+x.weight,0)||1,vals=list.map(x=>Math.floor(total*x.weight/sum)),used=vals.reduce((a,b)=>a+b,0);for(let i=0;i<total-used;i++)vals[i%vals.length]++;list.forEach((x,i)=>x.p.seasonStats[key]+=vals[i]||0)}
function playerSkill13(p,keys){return clamp(Number(window.SDF_V144?.grade?.(p,keys)||p?.ovr||65),45,99)}
function mergeParticipants13(...groups){const map=new Map();for(const group of groups.flat()){if(!group?.p)continue;const old=map.get(group.p.id);map.set(group.p.id,{p:group.p,weight:(old?.weight||0)+Number(group.weight||0)})}return[...map.values()].filter(x=>x.weight>0)}
function allocate13(total,list,weightFn){total=Math.max(0,Math.round(Number(total)||0));const out=new Map();if(!list.length||!total)return out;const rows=list.map((x,i)=>{const w=Math.max(.001,Number(weightFn?.(x,i)??x.weight??1));return{x,i,w,raw:0,value:0}}),sum=rows.reduce((n,r)=>n+r.w,0)||1;let used=0;for(const r of rows){r.raw=total*r.w/sum;r.value=Math.floor(r.raw);used+=r.value}rows.sort((a,b)=>(b.raw-b.value)-(a.raw-a.value)||b.w-a.w);for(let i=0;i<total-used;i++)rows[i%rows.length].value++;for(const r of rows)out.set(r.x.p.id,r.value);return out}
function scoreBreakdown13(points){points=Math.max(0,Math.round(Number(points)||0));let best={td:0,fg:0,error:999,penalty:999};for(let td=0;td<=10;td++)for(let fg=0;fg<=10;fg++){const error=Math.abs(points-(td*7+fg*3)),penalty=error*100+Math.abs(td-points/7)+fg*.08;if(penalty<best.penalty)best={td,fg,error,penalty}}return best}
function addStat13(p,key,value){p.seasonStats[key]=(p.seasonStats[key]||0)+Math.max(0,Math.round(Number(value)||0))}
function applyPlayerStats(g,win,team,opp,plan){
 state.roster.forEach(p=>{window.SDF_V105_TEST?.ensurePlayerFields?.(p);ensurePlayerStats(p);p.stats??={games:0,yards:0,td:0,tackles:0,sacks:0,int:0}});
 const qbs=roleParticipants(['QB1']),rbs=roleParticipants(['RB1','RB2']),wide=roleParticipants(['WR1','WR2','SLOT','TE1']),backTargets=roleParticipants(['RB1','RB2']).map(x=>({p:x.p,weight:x.weight*.22})),receivers=mergeParticipants13(wide,backTargets),defs=roleParticipants(['LE','RE','DT1','DT2','MLB','WLB','SLB','CB1','CB2','NCB','FS','SS']),kickers=roleParticipants(['K']),punters=roleParticipants(['P']);
 const allParticipants=mergeParticipants13(qbs,rbs,receivers,defs,kickers,punters),appeared=new Set(allParticipants.map(x=>x.p.id));for(const id of appeared){const p=state.roster.find(x=>x.id===id);if(p){p.seasonStats.games++;p.stats.games++}}
 const qbMain=qbs[0]?.p,qbGrade=playerSkill13(qbMain,['accuracy','decision','throwPower']),passPlays=clamp(Math.round((team.plays||60)*plan.passRate/100),10,54),passAtt=clamp(passPlays-Math.max(0,team.sacks||0),10,52),teamYpa=(team.passYds||0)/Math.max(1,passAtt),completionPct=clamp(.59+(qbGrade-72)/285+(teamYpa-7.2)/90+(state.weeklyPractice==='Passing Offense'?.025:0),.43,.80),completions=clamp(Math.round(passAtt*completionPct),Math.min(6,passAtt),passAtt),fallbackScore=scoreBreakdown13(team.points),score={td:Number.isFinite(Number(team.touchdowns))?Number(team.touchdowns):fallbackScore.td,fg:Number.isFinite(Number(team.fieldGoals))?Number(team.fieldGoals):fallbackScore.fg},totalTD=score.td,passShare=clamp(plan.passRate/100+((team.passYds||0)-Number(team.rushYds||0))/Math.max(1,Number(team.yards||1))*0.12+(qbGrade-70)/350,.18,.82),passTD=clamp(Math.round(totalTD*passShare),0,totalTD),rushTD=totalTD-passTD,intShare=clamp(.58+(plan.passRate-50)/120+(72-qbGrade)/155,.28,.82),rawINT=(team.turnovers||0)*intShare,passINT=clamp(Math.floor(rawINT)+(Math.random()<rawINT%1?1:0),0,team.turnovers||0);
 const qbAtt=allocate13(passAtt,qbs,x=>x.weight*(.85+playerSkill13(x.p,['decision','accuracy'])/100)),qbComp=allocate13(completions,qbs,x=>(qbAtt.get(x.p.id)||0)*(.85+playerSkill13(x.p,['accuracy'])/100)),qbYds=allocate13(team.passYds||0,qbs,x=>(qbComp.get(x.p.id)||0)*(.75+playerSkill13(x.p,['throwPower','accuracy'])/100));for(const x of qbs){const p=x.p;addStat13(p,'passAtt',qbAtt.get(p.id));addStat13(p,'passComp',Math.min(qbAtt.get(p.id)||0,qbComp.get(p.id)||0));addStat13(p,'passYds',qbYds.get(p.id))}if(qbMain){addStat13(qbMain,'passTD',passTD);addStat13(qbMain,'passINT',passINT)}
 const qbRushBase=qbMain?(state.offense==='Option'?.26:['Scrambler','Improviser'].includes(qbMain.arch)?.11:['Spread','Tempo Spread'].includes(state.offense)?.07:.035):0,rushAtt=clamp(Math.max(0,(team.plays||60)-passAtt-Math.max(0,team.sacks||0)),8,58),qbCarries=qbMain?clamp(Math.round(rushAtt*qbRushBase),0,Math.min(14,rushAtt)):0,rbCarries=Math.max(0,rushAtt-qbCarries),rbAttMap=allocate13(rbCarries,rbs,x=>x.weight*Math.pow(.55+playerSkill13(x.p,['vision','elusiveness','power'])/100,1.75)),rushers=mergeParticipants13(rbs,qbs.map(x=>({p:x.p,weight:x.p.id===qbMain?.id?Math.max(.01,qbCarries):.001}))),carryMap=new Map(rbAttMap);if(qbMain)carryMap.set(qbMain.id,qbCarries);const rushYdMap=allocate13(team.rushYds||0,rushers,x=>Math.max(1,carryMap.get(x.p.id)||0)*(.65+playerSkill13(x.p,['speed','vision','elusiveness','power'])/100)*(x.p.pos==='QB'?.86:1));for(const x of rushers){const p=x.p;addStat13(p,'rushAtt',carryMap.get(p.id));addStat13(p,'rushYds',rushYdMap.get(p.id))}
 const catchMap=allocate13(completions,receivers,x=>x.weight*Math.pow(.52+playerSkill13(x.p,['catch','route','speed'])/100,1.7)),baseRecYds=[...catchMap.values()].reduce((n,c)=>n+c*4,0),extraYds=Math.max(0,(team.passYds||0)-baseRecYds),extraMap=allocate13(extraYds,receivers,x=>Math.max(1,catchMap.get(x.p.id)||0)*Math.pow(.52+playerSkill13(x.p,['route','speed','catch'])/100,1.55)),recYdMap=new Map();for(const x of receivers)recYdMap.set(x.p.id,Math.min(team.passYds||0,(catchMap.get(x.p.id)||0)*4+(extraMap.get(x.p.id)||0)));let recYdSum=[...recYdMap.values()].reduce((a,b)=>a+b,0),recDiff=(team.passYds||0)-recYdSum;if(receivers.length&&recDiff)recYdMap.set(receivers[0].p.id,Math.max(0,(recYdMap.get(receivers[0].p.id)||0)+recDiff));const recTdMap=allocate13(passTD,receivers,x=>Math.max(.2,catchMap.get(x.p.id)||0)*(.65+playerSkill13(x.p,['catch','route'])/100));for(const x of receivers){const p=x.p;addStat13(p,'rec',catchMap.get(p.id));addStat13(p,'recYds',recYdMap.get(p.id));addStat13(p,'recTD',recTdMap.get(p.id))}
 const rushTdMap=allocate13(rushTD,rushers,x=>Math.max(.2,carryMap.get(x.p.id)||0)*(.65+playerSkill13(x.p,['power','vision'])/100));for(const x of rushers)addStat13(x.p,'rushTD',rushTdMap.get(x.p.id));
 const tackleTotal=clamp(Math.round((opp.plays||62)*.84+rand(4,10)),48,88),positionTackle={LB:1.35,S:1.15,CB:.88,EDGE:.92,DL:.82},tackleMap=allocate13(tackleTotal,defs,x=>x.weight*(positionTackle[x.p.pos]||1)*(.65+playerSkill13(x.p,['tackle','awareness','strength'])/100)),front=defs.filter(x=>['EDGE','DL','LB'].includes(x.p.pos)),backs=defs.filter(x=>['CB','S','LB'].includes(x.p.pos)),sackTotal=clamp(Math.round(opp.sacks||0),0,7),sackMap=allocate13(sackTotal,front,x=>x.weight*(.55+playerSkill13(x.p,['passRush','strength','speed'])/100)),oppPassRate=stableOpponent(g)?.tendency==='Pass Heavy'?.67:stableOpponent(g)?.tendency==='Tempo'?.61:stableOpponent(g)?.tendency==='Run Heavy'?.39:stableOpponent(g)?.tendency==='Ball Control'?.43:.52,defInts=clamp(Math.round((opp.turnovers||0)*(.45+oppPassRate*.28)),0,opp.turnovers||0),intMap=allocate13(defInts,backs,x=>x.weight*(.55+playerSkill13(x.p,['coverage','awareness','speed'])/100)),forced=Math.max(0,(opp.turnovers||0)-defInts),ffMap=allocate13(forced,defs,x=>x.weight*(.55+playerSkill13(x.p,['tackle','strength'])/100)),tflTotal=clamp(Math.round((opp.plays||62)*.065+rand(0,3)),2,10),tflMap=allocate13(tflTotal,front,x=>x.weight*(.55+playerSkill13(x.p,['tackle','passRush','strength'])/100));for(const x of defs){const p=x.p;addStat13(p,'tackles',tackleMap.get(p.id));addStat13(p,'sacks',sackMap.get(p.id));addStat13(p,'defINT',intMap.get(p.id));addStat13(p,'ff',ffMap.get(p.id));addStat13(p,'tfl',tflMap.get(p.id))}
 if(kickers[0]){const p=kickers[0].p,fgm=score.fg,fga=fgm+(Math.random()<clamp(.34-(p.ovr-70)/180,.08,.42)?1:0),xpa=totalTD,xpm=xpa;addStat13(p,'fgm',fgm);addStat13(p,'fga',fga);addStat13(p,'xpm',xpm);addStat13(p,'xpa',xpa);addStat13(p,'points',fgm*3+xpm)}
 if(punters[0]){const p=punters[0].p,punts=clamp(Number.isFinite(Number(team.punts))?Number(team.punts):Math.round(((plan.poss||12)-totalTD-score.fg-(team.turnovers||0)-(team.fourthAtt||0)*.7)*.82),0,9),avgPunt=clamp(Math.round(40+(p.ovr-65)*.12+rand(-2,3)),34,49);addStat13(p,'punts',punts);addStat13(p,'puntYds',punts*avgPunt);p.seasonStats.puntLong=Math.max(p.seasonStats.puntLong||0,punts?avgPunt+rand(3,10):0);addStat13(p,'inside20',Math.round(punts*clamp(.28+(p.ovr-70)/180,.15,.48)))}
 for(const x of allParticipants){const p=x.p,s=p.seasonStats,last={};if(p.pos==='QB')Object.assign(last,{passAtt:qbAtt.get(p.id)||0,passComp:Math.min(qbAtt.get(p.id)||0,qbComp.get(p.id)||0),passYds:qbYds.get(p.id)||0,passTD:p.id===qbMain?.id?passTD:0,passINT:p.id===qbMain?.id?passINT:0,rushAtt:carryMap.get(p.id)||0,rushYds:rushYdMap.get(p.id)||0,rushTD:rushTdMap.get(p.id)||0});else if(['RB','WR','TE'].includes(p.pos))Object.assign(last,{rushAtt:carryMap.get(p.id)||0,rushYds:rushYdMap.get(p.id)||0,rushTD:rushTdMap.get(p.id)||0,rec:catchMap.get(p.id)||0,recYds:recYdMap.get(p.id)||0,recTD:recTdMap.get(p.id)||0});else if(['EDGE','DL','LB','CB','S'].includes(p.pos))Object.assign(last,{tackles:tackleMap.get(p.id)||0,tfl:tflMap.get(p.id)||0,sacks:sackMap.get(p.id)||0,defINT:intMap.get(p.id)||0,ff:ffMap.get(p.id)||0});if(Object.values(last).some(Number))recordPlayerGame(p,state.week,g.opponent,win?'W':'L',last);p.stats.yards+=(last.passYds||0)+(last.rushYds||0)+(last.recYds||0);p.stats.td+=(last.passTD||0)+(last.rushTD||0)+(last.recTD||0);p.stats.tackles+=last.tackles||0;p.stats.sacks+=last.sacks||0;p.stats.int+=last.defINT||0}
 const stars=[];if(qbMain)stars.push(`${qbMain.name}: ${qbComp.get(qbMain.id)||0}/${qbAtt.get(qbMain.id)||0}, ${qbYds.get(qbMain.id)||0} pass yds, ${passTD} TD`);const topRush=[...rushers].sort((a,b)=>(rushYdMap.get(b.p.id)||0)-(rushYdMap.get(a.p.id)||0))[0];if(topRush)stars.push(`${topRush.p.name}: ${carryMap.get(topRush.p.id)||0} carries, ${rushYdMap.get(topRush.p.id)||0} rush yds, ${rushTdMap.get(topRush.p.id)||0} TD`);const topRec=[...receivers].sort((a,b)=>(recYdMap.get(b.p.id)||0)-(recYdMap.get(a.p.id)||0))[0];if(topRec)stars.push(`${topRec.p.name}: ${catchMap.get(topRec.p.id)||0} rec, ${recYdMap.get(topRec.p.id)||0} yds, ${recTdMap.get(topRec.p.id)||0} TD`);const topDef=[...defs].sort((a,b)=>(tackleMap.get(b.p.id)||0)+5*(sackMap.get(b.p.id)||0)+7*(intMap.get(b.p.id)||0)-((tackleMap.get(a.p.id)||0)+5*(sackMap.get(a.p.id)||0)+7*(intMap.get(a.p.id)||0)))[0];if(topDef)stars.push(`${topDef.p.name}: ${tackleMap.get(topDef.p.id)||0} tackles, ${sackMap.get(topDef.p.id)||0} sacks, ${intMap.get(topDef.p.id)||0} INT`);return stars.slice(0,4)
}
function injuryAfterGame(plan){const tempo=Math.max(0,(plan.tempo-50)/50),agg=Math.max(0,(plan.agg-50)/50),practice=state.weeklyPractice==='Injury Prevention'?.55:1,medical=1-Math.max(0,Number(state.facilities?.medical||1)-1)*.07,chance=.12*difficultyConfig().injury*coachInjuryMult()*practice*medical*(1+tempo*.65+agg*.22);if(Math.random()>=chance)return;const pool=roleParticipants(window.SDF_V11_TEST?.ROLE_DEFS?.map(r=>r.key)||[]);if(!pool.length)return;const total=pool.reduce((n,x)=>n+x.weight,0),roll=Math.random()*total;let acc=0,p=pool[0].p;for(const x of pool){acc+=x.weight;if(roll<=acc){p=x.p;break}}const severity=choice([{type:'Ankle sprain',weeks:1},{type:'Shoulder strain',weeks:2},{type:'Hamstring injury',weeks:3},{type:'Concussion',weeks:2},{type:'Knee injury',weeks:4}]);p.injury={...severity};p.starter=false;state.lastInjuryAlert={player:p.name,pos:p.pos,...severity};state.news.push(`${p.name} (${p.pos}) suffered a ${severity.type} and will miss approximately ${severity.weeks} week(s).`);window.SDF_V11_TEST?.ensureRealDepth?.()}
window.simGame=function(w){ensure13();state.conferenceRecords??={};state.achievementStats??={};const g=state.schedule[w-1],t=teamRatings(),plan=planEffects(g),oppProfile=stableOpponent(g),matchups=window.SDF_V144?.matchupReport?.(g)||{userOffEdge:0,userDefEdge:0,userPassEff:1,userRunEff:1,oppPassEff:1,oppRunEff:1,userExplosiveBonus:0,oppExplosiveBonus:0,passEdge:0,runEdge:0,passDefEdge:0,runDefEdge:0},offMatch=schemeMatchOff(state.offense,oppProfile.defense),defMatch=schemeMatchDef(state.defense,oppProfile.tendency),practiceOff=(state.weeklyPractice==='Passing Offense'&&plan.passRate>=50)||(state.weeklyPractice==='Rushing Offense'&&plan.passRate<50)?3:state.weeklyPractice==='Opponent Scouting'?2:state.weeklyPractice==='Balanced'?1:state.weeklyPractice==='Young Player Development'?-2:0,practiceDef=['Run Defense','Pass Defense'].includes(state.weeklyPractice)?3:state.weeklyPractice==='Opponent Scouting'?2:state.weeklyPractice==='Balanced'?1:0,coverageMatch=(oppProfile.tendency==='Pass Heavy'||oppProfile.tendency==='Tempo')?(plan.zone-50)/20:(oppProfile.tendency==='Run Heavy'||oppProfile.tendency==='Ball Control')?(50-plan.zone)/28:-Math.abs(plan.zone-50)/45,weather=weatherModifier(g.weather,state.offense),ourOff=t.offense+offMatch+practiceOff+weather+(state.staff?.oc?.game||70)/30-2.3+matchups.userOffEdge*.28,ourDef=t.defense+defMatch+practiceDef+coverageMatch+(state.staff?.dc?.game||70)/32-2.2+matchups.userDefEdge*.26,oppOff=g.oppPower+seeded13(`${state.year}-${g.oppId}-off`,-4,5),oppDef=g.oppPower+seeded13(`${state.year}-${g.oppId}-def`,-4,5),oppPass=oppProfile.tendency==='Pass Heavy'?70:oppProfile.tendency==='Tempo'?62:oppProfile.tendency==='Run Heavy'?36:oppProfile.tendency==='Ball Control'?42:52,our={points:0},them={points:0},drives=[];for(let i=1;i<=plan.poss;i++){const a=driveSim(ourOff,oppDef,{passRate:plan.passRate,turnoverRisk:plan.turnoverRisk,explosive:clamp(plan.explosive+matchups.userExplosiveBonus,3,38),sackPressure:0,passEff:plan.op.passEff*matchups.userPassEff,runEff:plan.op.runEff*matchups.userRunEff,tempo:plan.tempo,fourth:plan.fourth,variance:state.weeklyPractice==='Opponent Scouting'?9:13}),b=driveSim(oppOff,ourDef,{passRate:oppPass,turnoverRisk:clamp(8+plan.pressure*.25,5,14),explosive:clamp(11+plan.bigRisk+matchups.oppExplosiveBonus,4,34),sackPressure:plan.pressure,passEff:matchups.oppPassEff,runEff:matchups.oppRunEff,tempo:oppProfile.tendency==='Tempo'?75:45,fourth:45,variance:13});our.points+=a.points;them.points+=b.points;mergeStats(our,a);mergeStats(them,b);drives.push(`Drive ${i}: ${state.school.name} ${a.result} (${a.yards} yds); ${g.opponent} ${b.result} (${b.yards} yds)`)}if(our.points===them.points){const ot=Math.random()>.5?7:3,winner=Math.random()>.5?our:them;winner.points+=ot;winner.touchdowns=(winner.touchdowns||0)+(ot===7?1:0);winner.fieldGoals=(winner.fieldGoals||0)+(ot===3?1:0);drives.push(`Overtime decided by ${ot} points.`)}const win=our.points>them.points,margin=our.points-them.points;g.result=win?'W':'L';g.score=`${our.points}-${them.points}`;win?state.record.w++:state.record.l++;state.conferenceRecords[state.school.id]??={w:0,l:0};if(g.conference){win?state.conferenceRecords[state.school.id].w++:state.conferenceRecords[state.school.id].l++}const me=state.standings.find(x=>x.id===state.school.id);if(me)win?me.w++:me.l++;state.standings.filter(x=>x.id!==state.school.id).forEach(x=>Math.random()>.5?x.w++:x.l++);const visitResults=resolveVisits(g,win,margin),stars=applyPlayerStats(g,win,our,them,plan),top=Math.max(1,our.plays+them.plays),ourMinutes=clamp(Math.round(30+(our.rushYds-them.rushYds)/35+(50-plan.tempo)/18),21,39);state.lastGameRecap={opponent:g.opponent,home:g.home,win,us:our.points,them:them.points,rivalry:g.rivalry,boxScore:{firstDowns:Math.round(our.yards/18),rushYds:our.rushYds,passYds:our.passYds,totalYds:our.yards,turnovers:our.turnovers,thirdDown:`${our.thirdConv}/${our.thirdAtt}`,fourthDown:`${our.fourthConv}/${our.fourthAtt}`,redZone:`${our.redConv}/${our.redAtt}`,sacksAllowed:our.sacks,timePossession:`${ourMinutes}:${String(rand(0,59)).padStart(2,'0')}`},headline:win?choice(['Game plan delivers a statement victory','Balanced execution powers the win','Fourth-quarter execution seals it']):choice(['Aggressive plan creates costly mistakes','Matchup problems decide the defeat','Late push falls short']),stars,drives,planReport:[`${state.offense}: ${Math.round(plan.passRate)}% pass, ${plan.poss} possessions`,`${state.weeklyPractice} practice applied`,`${state.defense}: pressure ${plan.pressure.toFixed(1)}, big-play risk ${plan.bigRisk.toFixed(1)}`,`Fourth downs: ${our.fourthConv}/${our.fourthAtt}`,`WR/QB vs coverage: ${matchups.passEdge>=0?'+':''}${matchups.passEdge.toFixed(1)} · Run game matchup: ${matchups.runEdge>=0?'+':''}${matchups.runEdge.toFixed(1)}`,`Pass defense matchup: ${matchups.passDefEdge>=0?'+':''}${matchups.passDefEdge.toFixed(1)} · Run defense: ${matchups.runDefEdge>=0?'+':''}${matchups.runDefEdge.toFixed(1)}`],visitResults};if(g.rivalry){state.fanApproval=clamp(state.fanApproval+(win?8:-8),0,100);state.boosterSupport=clamp(state.boosterSupport+(win?5:-5),0,100);const rh=state.rivalryHistory[state.rivalId];if(rh){win?rh.wins++:rh.losses++;rh.streak=win?Math.max(1,rh.streak+1):Math.min(-1,rh.streak-1);rh.bestMargin=Math.max(rh.bestMargin,win?margin:0);rh.last={year:state.year,win,score:g.score};if(win)state.achievementStats.rivalWins++}}updateAttendance(win,g.rivalry);state.coachCareer.careerWins+=win?1:0;state.coachCareer.careerLosses+=win?0:1;if(win&&margin>=35)state.achievementStats.bigWin=true;state.achievementStats.weatherConditions??={};if(win&&['Snow','Rain','Heavy Wind','Extreme Heat'].includes(g.weather))state.achievementStats.weatherConditions[g.weather]=true;addCoachXP(win?18:7);maybeCreateDynamicRivalry(g);state.news.push(`${g.result} ${g.score} ${g.home?'vs':'at'} ${g.opponent}. Game plan: ${state.offense}, ${Math.round(plan.passRate)}% pass, ${plan.poss} possessions.`);if(state.weeklyPractice==='Young Player Development'){const young=state.roster.filter(p=>p.year<=2&&!p.starter&&!p.redshirt&&p.ovr<p.pot).sort(()=>Math.random()-.5).slice(0,2);young.forEach(p=>{if(Math.random()<.45){p.ovr++;p.weeklyDevelopment=(p.weeklyDevelopment||0)+1;state.news.push(`${p.name} gained +1 OVR from the young-player practice focus.`)}})}injuryAfterGame(plan);state.roster.forEach(p=>p.morale=clamp(p.morale+(win?rand(0,3):rand(-3,1)),35,99));state.gamePlanHistory.push({year:state.year,week:state.week,opponent:g.opponent,offense:state.offense,defense:state.defense,practice:state.weeklyPractice,runPass:state.gamePlan.runPass,tempo:state.gamePlan.tempo,aggression:state.gamePlan.offenseAggression,blitz:state.gamePlan.blitz,zone:state.gamePlan.manZone,fourth:state.gamePlan.fourthDown,result:g.result,score:g.score})};

const offenseSelect=$13('offenseScheme'),defenseSelect=$13('defenseScheme');if(offenseSelect)offenseSelect.onchange=e=>{state.offense=e.target.value;window.renderAll();save13('Offensive playbook changed')};if(defenseSelect)defenseSelect.onchange=e=>{state.defense=e.target.value;window.renderAll();save13('Defensive playbook changed')};
function decoratePostgame(){const body=$13('gameResultBody'),r=state.lastGameRecap;if(!body||!r||body.querySelector('.postgame-plan-report'))return;body.insertAdjacentHTML('beforeend',`<section class="postgame-plan-report"><b>Game Plan Impact</b><ul>${(r.planReport||[]).map(x=>`<li>${x}</li>`).join('')}</ul></section>${r.visitResults?.length?`<section class="postgame-visit-results"><b>Official Visit Results</b><ul>${r.visitResults.map(x=>`<li>${x}</li>`).join('')}</ul></section>`:''}`)}
const priorAdvance=window.advanceWeek;window.advanceWeek=function(...args){const out=priorAdvance.apply(this,args);setTimeout(decoratePostgame,150);setTimeout(decoratePostgame,450);return out};
const priorRenderAll=window.renderAll;window.renderAll=function(...args){const out=priorRenderAll.apply(this,args);if(state.school){ensure13();if(!$13('recruitingTab')?.classList.contains('hidden'))appendRecruitUI();if(!$13('gameplanTab')?.classList.contains('hidden'))window.renderGamePlan()}return out};
ensure13();if(state.school){appendRecruitUI();window.renderGamePlan()}window.SDF_V113_TEST={forecast,forecastAll,classBalance,urgency,planEffects,stableOpponent,resolveVisits,schemeMatchOff,schemeMatchDef,driveSim,applyPlayerStats,scoreBreakdown13,OFFENSE_PROFILES,DEFENSE_PROFILES};
})();
(()=>{
'use strict';
const byId=id=>document.getElementById(id);let building=false;
function logoForSchool(id){return(typeof TEAM_BRANDING!=='undefined'?TEAM_BRANDING?.[Number(id)]?.logo:null)||'icon.svg'}
function setProgress(percent,message){const bar=byId('dynastyBuildProgressBar');if(bar)bar.style.width=`${Math.max(4,Math.min(100,Number(percent)||0))}%`;if(message)byId('dynastyBuildMessage').textContent=message}
function showLoader({title='Building Your Dynasty',message='Creating your roster, schedule and national recruiting class…',schoolId=null}={}){const modal=byId('dynastyBuildModal');if(!modal)return;byId('dynastyBuildTitle').textContent=title;byId('dynastyBuildMessage').textContent=message;byId('dynastyBuildLogo').src=schoolId?logoForSchool(schoolId):'icon-192.png';byId('dynastyBuildProgressBar').style.width='6%';byId('dynastyBuildError').classList.add('hidden');byId('dynastyBuildClose').classList.add('hidden');modal.classList.remove('hidden');document.body.classList.add('app-building')}
function hideLoader(){byId('dynastyBuildModal')?.classList.add('hidden');document.body.classList.remove('app-building');building=false}
function showFailure(error){console.error('Dynasty initialization failed',error);const message=error?.message||String(error||'Unknown startup error');byId('dynastyBuildMessage').textContent='The dynasty could not be created.';const box=byId('dynastyBuildError');box.textContent=`Startup error: ${message}`;box.classList.remove('hidden');byId('dynastyBuildClose').classList.remove('hidden');document.body.classList.remove('app-building');building=false}
function afterPaint(callback){requestAnimationFrame(()=>requestAnimationFrame(()=>setTimeout(callback,35)))}
function runHeavyStartup(task,options){if(building)return Promise.resolve(false);building=true;showLoader(options);return new Promise(resolve=>afterPaint(async()=>{const render=window.renderAll;window.renderAll=function(){};const started=performance.now();try{await task(setProgress);window.renderAll=render;if(state?.school)render();window.scrollTo({top:0,left:0,behavior:'auto'});setProgress(100,'Dynasty ready.');console.info(`Dynasty initialized in ${Math.round(performance.now()-started)} ms`);setTimeout(hideLoader,170);resolve(true)}catch(error){window.SDF_DEFER_RECRUITING_INIT=false;window.renderAll=render;showFailure(error);resolve(false)}}))}
async function initializeRecruiting(progress){if(!state?.school)return;const init=window.SDF_RECRUITING_V2?.initializeRecruitingModelAsync;if(typeof init==='function')await init(progress);window.SDF_RELEASE_TEST?.saveNow?.('Recruiting model initialized',false,false)}
const synchronousStart=window.start;
window.start=function(id){const school=schools?.find(s=>Number(s.id)===Number(id));return runHeavyStartup(async progress=>{window.SDF_DEFER_RECRUITING_INIT=true;try{synchronousStart.call(this,id)}finally{window.SDF_DEFER_RECRUITING_INIT=false}if(!state.school)return;setProgress(10,'Roster and schedule created. Preparing recruiting…');await initializeRecruiting(progress)},{schoolId:id,title:`Building ${school?.name||'Your Dynasty'}`,message:'Creating the roster, depth chart and 12-game schedule…'})};
const loadButton=byId('loadSelectedSaveBtn');if(loadButton)loadButton.onclick=()=>{const slot=byId('saveSlotPicker')?.value||'1';runHeavyStartup(async progress=>{window.SDF_RELEASE_TEST?.loadReleaseSave?.(slot);if(!state.school)return;setProgress(10,'Save restored. Rebuilding recruiting races…');await initializeRecruiting(progress)},{title:`Loading Dynasty Slot ${slot}`,message:'Restoring the roster, schedules, statistics and autosave data…'})};
const synchronousFinishOffseason=window.finishOffseason;window.finishOffseason=function(){return runHeavyStartup(async progress=>{window.SDF_DEFER_RECRUITING_INIT=true;try{synchronousFinishOffseason.call(this)}finally{window.SDF_DEFER_RECRUITING_INIT=false}if(state.phase==='REGULAR'&&state.week===1){setProgress(10,'New season created. Preparing the recruiting class…');await initializeRecruiting(progress)}},{schoolId:state.school?.id,title:`Preparing Dynasty Year ${Number(state.year||1)+1}`,message:'Graduating seniors, progressing players and creating the new schedule…'})};if(byId('finishOffseasonBtn'))byId('finishOffseasonBtn').onclick=()=>window.finishOffseason();
byId('dynastyBuildClose')?.addEventListener('click',()=>{hideLoader();state.school=null;byId('schoolScreen')?.classList.remove('hidden');byId('gameScreen')?.classList.add('hidden');window.renderSchools?.();window.scrollTo({top:0,left:0,behavior:'auto'})});window.SDF_V114_TEST={runHeavyStartup,showLoader,hideLoader,setProgress,synchronousStart};
})();
(()=>{
'use strict';
const $12=id=>document.getElementById(id);
const ROLE_KEYS={
 QB:['QB1'],RB:['RB1','RB2'],REC:['WR1','WR2','SLOT','TE1','RB1','RB2'],
 OL:['LT','RT','LG','C','RG'],FRONT:['LE','RE','DT1','DT2','MLB','WLB','SLB'],
 COVER:['CB1','CB2','NCB','FS','SS','MLB','WLB'],DEF:['LE','RE','DT1','DT2','MLB','WLB','SLB','CB1','CB2','NCB','FS','SS'],K:['K'],P:['P']
};
const SPEEDS={0:0,.5:1800,1:900,2:450,4:220};
let timer=null,currentSpeed=1,renderedFeedLength=0;
function n(v,d=0){v=Number(v);return Number.isFinite(v)?v:d}
function rnd(min,max){return Math.floor(Math.random()*(max-min+1))+min}
function pct(v){return Math.max(0,Math.min(100,n(v)))}
function safe(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function logo(id){return TEAM_BRANDING?.[Number(id)]?.logo||'icon.svg'}
function teamById(id){return schools.find(s=>Number(s.id)===Number(id))}
function currentGame(){if(state.liveGameContext?.game)return state.liveGameContext.game;return state.phase==='REGULAR'?state.schedule?.[Number(state.week||1)-1]:null}
function ensure12(){
 if(!state?.school)return;
 state.injuryHistory??=[];
 state.liveGame??=null;
 state.roster.forEach(p=>{if(p.injury)normalizeInjury(p)});
}
function normalizeInjury(p){
 if(!p?.injury)return null;
 const i=p.injury;
 i.type??='Undisclosed injury';
 i.weeks=Math.max(1,n(i.weeks,1));
 i.severity??=i.weeks>=6?'Severe':i.weeks>=3?'Moderate':'Minor';
 i.status??='Out';
 i.gamesMissed??=0;
 i.occurredYear??=Math.max(1,n(state.year,1));
 i.occurredWeek??=Math.max(0,n(state.week,0)-1);
 i.source??='Season';
 return i;
}
function expectedReturn(i){
 if(!i)return 'Available';
 const week=n(state.week,1)+n(i.weeks,1);
 if(state.phase!=='REGULAR')return 'Next season';
 if(week<=12)return `Around Week ${week}`;
 return 'Postseason / next season';
}
function injuryStatusClass(i){return n(i.weeks)>=5?'severe':n(i.weeks)>=3?'moderate':'minor'}
function recordInjury(player,diagnosis,weeks,source='Game',details={}){
 if(!player||player.injury)return null;
 const wasStarter=!!player.starter;
 const injury={
  id:crypto.randomUUID(),type:diagnosis,weeks,severity:weeks>=6?'Severe':weeks>=3?'Moderate':'Minor',status:'Out',gamesMissed:0,wasStarter,
  occurredYear:state.year,occurredWeek:state.week,source,quarter:details.quarter||null,clock:details.clock||null
 };
 player.injury=injury;player.starter=false;
 state.injuryHistory.push({id:injury.id,playerId:player.id,player:player.name,pos:player.pos,...injury});
 state.news.push(`${player.name} (${player.pos}) suffered a ${diagnosis} and is expected to miss ${weeks} week${weeks===1?'':'s'}.`);
 state.lastInjuryAlert={player:player.name,pos:player.pos,type:diagnosis,weeks};
 try{window.SDF_V11_TEST?.ensureRealDepth?.()}catch{}
 tone('injury');
 return injury;
}
function updateInjuryHistoryReturn(player){
 const id=player?.injury?.id;if(!id)return;
 const row=state.injuryHistory.find(x=>x.id===id);
 if(row){row.returnedYear=state.year;row.returnedWeek=state.week;row.gamesMissed=player.injury.gamesMissed||0}
}
function recoveryTick(){
 ensure12();
 state.roster.filter(p=>p.injury).forEach(p=>{
  const i=normalizeInjury(p);
  if(i.occurredYear===state.year&&i.occurredWeek===state.week)return;
  i.weeks--;
  if(i.weeks<=0){
   updateInjuryHistoryReturn(p);
   state.news.push(`${p.name} (${p.pos}) has been medically cleared and returned to the active roster.`);
   p.injury=null;
  }
 });
 try{window.SDF_V11_TEST?.ensureRealDepth?.()}catch{}
}
// Replace the old recovery function so injuries created in a game are not healed immediately after that same game.
window.healInjuries=recoveryTick;
function markGamesMissed(ids=null){
 const allowed=ids?new Set(ids):null;
 state.roster.filter(p=>p.injury&&(!allowed||allowed.has(p.id))).forEach(p=>{normalizeInjury(p).gamesMissed++});
}
function renderInjuries(){
 ensure12();if(!state.school)return;
 const active=state.roster.filter(p=>p.injury).sort((a,b)=>n(b.injury.weeks)-n(a.injury.weeks)||b.ovr-a.ovr);
 const starters=active.filter(p=>p.injury?.wasStarter).length;
 const summary=$12('injurySummary');
 if(summary)summary.innerHTML=metric('Unavailable',active.length)+metric('Projected starters out',starters)+metric('Games missed',active.reduce((t,p)=>t+n(p.injury.gamesMissed),0))+metric('Sports Medicine',`Level ${state.facilities?.medical||1}`);
 const list=$12('injuryReportList');
 if(list)list.innerHTML=active.length?active.map(p=>{
  const i=normalizeInjury(p);return `<article class="injury-row ${injuryStatusClass(i)}"><div class="injury-player"><b>${safe(p.name)}</b><span>${p.pos} · ${classLabel?.(p)||`Year ${p.year}`} · ${p.ovr} OVR</span></div><div><small>DIAGNOSIS</small><b>${safe(i.type)}</b><span>${safe(i.severity)} · ${safe(i.source)}</span></div><div><small>TIME OUT</small><b>${i.weeks} week${i.weeks===1?'':'s'}</b><span>${expectedReturn(i)}</span></div><div><small>SEASON IMPACT</small><b>${i.gamesMissed||0} game${i.gamesMissed===1?'':'s'} missed</b><span>Removed from active snap shares</span></div><button class="btn neutral" onclick="openPlayer('${p.id}')">Player Profile</button></article>`
 }).join(''):'<div class="injury-empty"><b>Full-strength roster</b><span>No players are currently unavailable.</span></div>';
 const history=$12('injuryHistoryList');
 if(history){const rows=(state.injuryHistory||[]).slice(-20).reverse();history.innerHTML=rows.length?rows.map(x=>`<div class="injury-history-row"><b>${safe(x.player)} · ${x.pos}</b><span>${safe(x.type)} · Year ${x.occurredYear}, Week ${x.occurredWeek}</span><span>${x.returnedYear?`Returned Year ${x.returnedYear}, Week ${x.returnedWeek}`:`Active · ${x.weeks} weeks initially`}</span></div>`).join(''):'<p class="muted">No recorded injuries yet.</p>'}
 const gd=$12('gameDayInjurySummary');
 if(gd)gd.innerHTML=active.length?`<div class="game-day-injury-list">${active.slice(0,5).map(p=>`<div><b>${safe(p.name)} · ${p.pos}</b><span>${safe(p.injury.type)} · ${p.injury.weeks} week${p.injury.weeks===1?'':'s'} remaining</span></div>`).join('')}</div>${active.length>5?`<p class="muted">Plus ${active.length-5} more unavailable player(s).</p>`:''}`:'<div class="injury-empty compact"><b>No active injuries</b><span>The current depth chart is at full availability.</span></div>';
}
window.autoAdjustForInjuries=()=>{state.realDepthChart={};try{autoDepth();window.SDF_V11_TEST?.ensureRealDepth?.()}catch{}window.renderAll();window.SDF_RELEASE_TEST?.saveNow?.('Depth adjusted for injuries',false,false)};
function roleParticipants(keys){
 try{window.SDF_V11_TEST?.ensureRealDepth?.()}catch{}
 const defs=window.SDF_V11_TEST?.ROLE_DEFS||[];
 const map=new Map();
 keys.forEach(key=>{
  const def=defs.find(r=>r.key===key),slots=state.realDepthChart?.[key]?.slots||[];
  slots.forEach(s=>{const p=state.roster.find(x=>x.id===s.playerId);if(!p||p.redshirt||p.injury)return;const weight=Math.max(.01,n(s.snapShare)/100*n(def?.weight,1));const old=map.get(p.id);map.set(p.id,{p,weight:(old?.weight||0)+weight})})
 });
 return [...map.values()];
}
function weighted(list){
 if(!list?.length)return null;const total=list.reduce((t,x)=>t+n(x.weight,1),0),roll=Math.random()*total;let acc=0;for(const x of list){acc+=n(x.weight,1);if(roll<=acc)return x.p||x}return list[list.length-1].p||list[list.length-1]
}
function skill12(p,keys){return Math.max(45,Math.min(99,n(window.SDF_V144?.grade?.(p,keys),n(p?.ovr,65))))}
function weightedSkill12(list,keys){return weighted((list||[]).map(x=>({p:x.p||x,weight:n(x.weight,1)*(.58+skill12(x.p||x,keys)/100)})))}
function randomDefender(front=false){return weighted(roleParticipants(front?ROLE_KEYS.FRONT:ROLE_KEYS.DEF))||state.roster.find(p=>['EDGE','DL','LB','CB','S'].includes(p.pos)&&!p.injury&&!p.redshirt)}
function makeOpponentRoster(g){
 const persistent=window.SDF_AI_ROSTERS?.get?.(g.oppId);
 if(Array.isArray(persistent)&&persistent.length){
  const active=persistent.filter(p=>!p.redshirt&&!p.injury).sort((a,b)=>Number(b.starter)-Number(a.starter)||n(a.depthIndex,99)-n(b.depthIndex,99)||n(b.ovr)-n(a.ovr));
  if(active.length)return active.map(p=>({...p,attrs:p.attrs?{...p.attrs}:undefined,stats:{}}));
 }
 const roles=['QB','RB','WR','WR','WR','TE','EDGE','EDGE','DL','LB','LB','CB','CB','S','S','K','P'];
 return roles.map((pos,i)=>({id:`opp-${g.oppId}-${i}`,name:pname(),pos,ovr:Math.max(48,Math.min(96,n(g.oppPower,65)+rnd(-8,8))),stats:{}}));
}
function oppPlayer(game,pos,index=0){const a=game.oppRoster.filter(p=>p.pos===pos);return a[index%Math.max(1,a.length)]||game.oppRoster[0]}
function stat(game,id,name,pos){game.playerStats[id]??={id,name,pos,passAtt:0,passComp:0,passYds:0,passTD:0,passINT:0,rushAtt:0,rushYds:0,rushTD:0,targets:0,rec:0,recYds:0,recTD:0,tackles:0,tfl:0,sacks:0,defINT:0,ff:0,fgm:0,fga:0,xpm:0,xpa:0,points:0,punts:0,puntYds:0,puntLong:0,inside20:0,touchbacks:0};return game.playerStats[id]}
function sideStats(game,side){return game.stats[side]}
function addFeed(game,text,type='play'){
 game.feed.push({id:game.feed.length+1,quarter:game.quarter,clock:game.clock,text,type,score:`${game.score.us}-${game.score.them}`});
 if(game.feed.length>180)game.feed=game.feed.slice(-180);
}
function clockText(seconds){seconds=Math.max(0,Math.round(seconds));return `${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`}
function quarterText(q){return q<=4?`${['1st','2nd','3rd','4th'][q-1]} Quarter`:`OT ${q-4}`}
function fieldText(game){
 const b=Math.round(game.ball),off=game.possession==='us';
 if(off)return b===50?'50 yard line':b<50?`${state.school.name} ${b}`:`${game.opponent} ${100-b}`;
 return b===50?'50 yard line':b>50?`${game.opponent} ${100-b}`:`${state.school.name} ${b}`;
}
function toGoal(game){return game.possession==='us'?100-game.ball:game.ball}
function direction(game){return game.possession==='us'?1:-1}
function situation(game){return `${ordinal(game.down)} & ${Math.max(1,Math.round(game.distance))} at ${fieldText(game)}`}
function ordinal(v){return v===1?'1st':v===2?'2nd':v===3?'3rd':'4th'}
function emergencyPlayer(kind){const pos=kind==='REC'?'WR':kind,name=kind==='P'?'Emergency Punter':kind==='K'?'Emergency Kicker':kind==='REC'?'Emergency Receiver':`Emergency ${kind}`;return{id:`emergency-${kind}`,name,pos,ovr:55,stats:{}}}
function selectUserSkill(kind){
 let player=null;if(kind==='QB')player=weightedSkill12(roleParticipants(ROLE_KEYS.QB),['decision','accuracy','throwPower']);else if(kind==='RB')player=weightedSkill12(roleParticipants(ROLE_KEYS.RB),['vision','elusiveness','power','speed']);else if(kind==='REC')player=weightedSkill12(roleParticipants(ROLE_KEYS.REC).map(x=>({p:x.p,weight:x.weight*(x.p.pos==='RB'?.24:x.p.pos==='TE'?.82:1)})),['route','catch','speed']);else if(kind==='K')player=weightedSkill12(roleParticipants(ROLE_KEYS.K),['accuracy','power']);else if(kind==='P')player=weightedSkill12(roleParticipants(ROLE_KEYS.P),['accuracy','power']);
 if(player)return player;const active=(state.roster||[]).filter(p=>!p.injury&&!p.redshirt),fallback=kind==='REC'?active.find(p=>['WR','TE','RB'].includes(p.pos)):kind==='P'?(active.find(p=>p.pos==='P')||active.find(p=>p.pos==='K')):active.find(p=>p.pos===kind);return fallback||emergencyPlayer(kind)
}
function gameConfig(g){
 const plan=window.SDF_V113_TEST?.planEffects?.(g)||{passRate:50,poss:12,turnoverRisk:8,explosive:12,pressure:5,bigRisk:8,tempo:50,agg:50,fourth:45,zone:50,op:{passEff:1,runEff:1}};
 const opp=window.SDF_V113_TEST?.stableOpponent?.(g)||{tendency:'Balanced',defense:'4-3'};
 const ratings=teamRatings(),matchups=window.SDF_V144?.matchupReport?.(g)||{userOffEdge:0,userDefEdge:0,passEdge:0,runEdge:0,passDefEdge:0,runDefEdge:0,userPassEff:1,userRunEff:1};
 const oppPass=opp.tendency==='Pass Heavy'?64:opp.tendency==='Tempo'?60:opp.tendency==='Run Heavy'?38:opp.tendency==='Ball Control'?42:51;
 const neutral=!!state.liveGameContext,siteEdge=neutral?0:(g.home?1.5:-1.5),oppPower=n(g.oppPower,65),qualityEdge=clamp(n(ratings.overall,65)-oppPower,-20,20),qualityBoost=qualityEdge*.20;
 return{
  plan,opp,ratings,matchups,oppPass,siteEdge,qualityEdge,qualityBoost,
  ourOff:ratings.offense+matchups.userOffEdge*.12+siteEdge+qualityBoost,
  ourDef:ratings.defense+matchups.userDefEdge*.12+siteEdge+qualityBoost,
  oppOff:oppPower+rnd(-2,2)-siteEdge,
  oppDef:oppPower+rnd(-2,2)-siteEdge
 }
}
function newLiveGame(){
 ensure12();const g=currentGame();if(!g||g.result)throw new Error('No unplayed regular-season game is available.');
 const cfg=gameConfig(g),coin=Math.random()<.5?'us':'them';
 return{
  version:2,year:state.year,week:state.week,scheduleIndex:state.liveGameContext?-1:state.week-1,contextType:state.liveGameContext?.type||'REGULAR',gameLabel:state.liveGameContext?.label||`Week ${state.week}`,contextMeta:state.liveGameContext?.meta||null,opponent:g.opponent,oppId:g.oppId,home:g.home,rivalry:g.rivalry,conference:g.conference,weather:g.weather||'Clear',
  quarter:1,clock:900,possession:coin,ball:coin==='us'?25:75,down:1,distance:10,score:{us:0,them:0},driveNo:1,complete:false,finalized:false,paused:false,
  cfg,oppRoster:makeOpponentRoster(g),feed:[],driveSummary:[],playerStats:{},stats:{us:emptyTeamStats(),them:emptyTeamStats()},injuries:[],lastPlay:'Kickoff is moments away.',plays:0,
  kickoffReceived:coin,secondHalfReceiver:coin==='us'?'them':'us',overtimePossessions:0,otFirst:null,startedAt:Date.now(),preGameInjuredIds:state.roster.filter(p=>p.injury).map(p=>p.id)
 };
}
function emptyTeamStats(){return{plays:0,firstDowns:0,rushAtt:0,rushYds:0,passAtt:0,passComp:0,passYds:0,totalYds:0,turnovers:0,sacks:0,thirdAtt:0,thirdConv:0,fourthAtt:0,fourthConv:0,redAtt:0,redConv:0,penalties:0,penaltyYds:0,timePossession:0}}

function offenseContext(game,side=game.possession){
 const other=side==='us'?'them':'us',diff=n(game.score?.[side])-n(game.score?.[other]),secondHalf=game.quarter>=3&&game.quarter<=4,late=game.quarter===4;
 let tempoAdjustment=0,passAdjustment=0,aggressionAdjustment=0,explosiveMultiplier=1,turnoverMultiplier=1;
 if(secondHalf&&diff>=21){tempoAdjustment-=14;passAdjustment-=9;aggressionAdjustment-=10;explosiveMultiplier*=.74}
 if(late&&diff>=35){tempoAdjustment-=10;passAdjustment-=8;aggressionAdjustment-=8;explosiveMultiplier*=.68}
 if(secondHalf&&diff<=-14){tempoAdjustment+=9;passAdjustment+=9;aggressionAdjustment+=7;explosiveMultiplier*=1.08;turnoverMultiplier*=1.10}
 const own=n(game.score?.[side]);
 if(own>=49){explosiveMultiplier*=.78;tempoAdjustment-=8;passAdjustment-=6;aggressionAdjustment-=7;turnoverMultiplier*=.94}
 if(own>=63){explosiveMultiplier*=.62;tempoAdjustment-=8;passAdjustment-=8;aggressionAdjustment-=6;turnoverMultiplier*=.92}
 return{diff,secondHalf,late,tempoAdjustment,passAdjustment,aggressionAdjustment,explosiveMultiplier,turnoverMultiplier}
}
function startOvertime(game,first=null){
 game.quarter=Math.max(5,n(game.quarter,4)+1);game.clock=0;game.overtimePossessions=0;game.otFirst=first||((Math.random()<.5)?'us':'them');
 resetSeries(game,game.otFirst,game.otFirst==='us'?75:25);
 addFeed(game,`Overtime ${game.quarter-4} begins. Each team starts at the 25.`,'quarter')
}
function completeOvertimePossession(game){
 game.overtimePossessions=n(game.overtimePossessions)+1;
 if(game.overtimePossessions===1){
  const next=game.possession==='us'?'them':'us';
  resetSeries(game,next,next==='us'?75:25);
  return
 }
 if(game.score.us!==game.score.them){game.complete=true;return}
 const nextFirst=game.otFirst==='us'?'them':'us';
 game.quarter++;game.clock=0;game.overtimePossessions=0;game.otFirst=nextFirst;
 resetSeries(game,nextFirst,nextFirst==='us'?75:25);
 addFeed(game,`Overtime ${game.quarter-4} begins. ${nextFirst==='us'?state.school.name:game.opponent} gets the first possession.`,'quarter')
}
function resetSeries(game,possession,ball){
 game.possession=possession;game.ball=ball;game.down=1;game.distance=Math.min(10,Math.max(1,toGoal(game)));game.driveNo++;
 if(toGoal(game)<=20)sideStats(game,possession).redAtt++
}
function flipPossession(game,spot=game.ball){
 if(game.quarter>4){completeOvertimePossession(game);return}
 const next=game.possession==='us'?'them':'us';resetSeries(game,next,Math.max(1,Math.min(99,spot)))
}
function scorePoints(game,side,points,label){
 game.score[side]+=points;
 if(points===7){const kicker=side==='us'?selectUserSkill('K'):oppPlayer(game,'K');if(kicker){const ks=stat(game,kicker.id,kicker.name,kicker.pos);ks.xpa++;ks.xpm++;ks.points++}}
 const line=`${label} ${side==='us'?state.school.name:game.opponent}.`;addFeed(game,line,points>=6?'score':'play');game.driveSummary.push(line);
 if(game.quarter>4){completeOvertimePossession(game);return}
 const receiver=side==='us'?'them':'us';resetSeries(game,receiver,receiver==='us'?25:75)
}
function addYards(game,yards){game.ball=Math.max(0,Math.min(100,game.ball+direction(game)*yards))}
function possessionTeam(game){return game.possession==='us'?state.school.name:game.opponent}
function snapClock(game,passIncomplete=false,scoringPlay=false){
 if(game.quarter>4)return;
 const ctx=offenseContext(game),baseTempo=game.possession==='us'?n(game.cfg.plan.tempo,50):(game.cfg.opp.tendency==='Tempo'?72:game.cfg.opp.tendency==='Ball Control'?34:50),tempo=baseTempo+ctx.tempoAdjustment;
 let runoff;
 if(scoringPlay)runoff=rnd(7,13);
 else if(passIncomplete)runoff=rnd(6,10);
 else runoff=Math.max(14,rnd(25,37)-Math.round((tempo-50)/4));
 if(ctx.secondHalf&&ctx.diff>=21&&!passIncomplete)runoff+=rnd(4,9);
 if(ctx.late&&ctx.diff>=35&&!passIncomplete)runoff+=rnd(3,7);
 runoff=Math.min(50,runoff);
 game.clock=Math.max(0,game.clock-runoff);sideStats(game,game.possession).timePossession+=runoff
}
function maybePenalty(game){
 if(Math.random()>.055)return false;const side=game.possession,offensive=Math.random()<.62,yds=choice([5,5,10,10,15]);const team=offensive?side:(side==='us'?'them':'us');sideStats(game,team).penalties++;sideStats(game,team).penaltyYds+=yds;
 if(offensive){addYards(game,-yds);game.distance+=yds;game.lastPlay=`Penalty on ${possessionTeam(game)}: ${yds} yards.`}
 else{addYards(game,yds);game.down=1;game.distance=Math.min(10,toGoal(game));sideStats(game,side).firstDowns++;game.lastPlay=`Defensive penalty: ${yds} yards and an automatic first down.`}
 addFeed(game,game.lastPlay,'penalty');snapClock(game,false);return true;
}
function maybeLiveInjury(game,participants){
 if(game.injuries.length>=3)return;
 const plan=game.cfg.plan,base=.0011*difficultyConfig().injury*n(state.realismSettings?.injuries,1)*coachInjuryMult()*(state.weeklyPractice==='Injury Prevention'?.6:1)*(1+Math.max(0,n(plan.tempo)-50)/90+Math.max(0,n(plan.agg)-50)/180);
 if(Math.random()>=base)return;
 const candidates=(participants||[]).filter(p=>p&&state.roster.some(x=>x.id===p.id)&&!p.injury);
 const player=choice(candidates.length?candidates:state.roster.filter(p=>!p.injury&&!p.redshirt&&p.starter));if(!player)return;
 const remaining=Math.max(1,13-state.week),roll=Math.random();let info;
 if(roll<.38)info=choice([{type:'Ankle sprain',weeks:1},{type:'Shoulder strain',weeks:1},{type:'Knee bruise',weeks:1}]);
 else if(roll<.78)info=choice([{type:'Hamstring strain',weeks:2},{type:'High ankle sprain',weeks:3},{type:'Concussion',weeks:2},{type:'Shoulder sprain',weeks:2}]);
 else if(roll<.96)info=choice([{type:'MCL sprain',weeks:4},{type:'Broken hand',weeks:5},{type:'Severe hamstring tear',weeks:4}]);
 else info=choice([{type:'ACL tear',weeks:Math.max(8,remaining)},{type:'Achilles tear',weeks:Math.max(8,remaining)}]);
 const injury=recordInjury(player,info.type,info.weeks,'Live game',{quarter:game.quarter,clock:clockText(game.clock)});if(!injury)return;
 game.injuries.push({playerId:player.id,player:player.name,pos:player.pos,...injury});
 const text=`INJURY: ${player.name} (${player.pos}) — ${info.type}. Out approximately ${info.weeks} week${info.weeks===1?'':'s'}.`;
 addFeed(game,text,'injury');game.lastPlay=text;
}
function passPlay(game){
 const us=game.possession==='us',cfg=game.cfg,off=us?cfg.ourOff:cfg.oppOff,def=us?cfg.oppDef:cfg.ourDef,side=us?'us':'them',st=sideStats(game,side),ctx=offenseContext(game,side);
 const qb=us?selectUserSkill('QB'):oppPlayer(game,'QB'),target=us?selectUserSkill('REC'):choice(game.oppRoster.filter(p=>['WR','TE','RB'].includes(p.pos))),defender=us?oppPlayer(game,choice(['CB','S','LB'])):randomDefender(false);
 const qs=stat(game,qb.id,qb.name,qb.pos),ts=stat(game,target.id,target.name,target.pos);st.plays++;st.passAtt++;qs.passAtt++;ts.targets++;
 const pressure=us?Math.max(0,(def-off)/100):n(cfg.plan.pressure,5)/18+Math.max(0,(def-off)/105),sackChance=Math.max(.025,Math.min(.115,.045+pressure*.014));
 if(Math.random()<sackChance){
  const loss=rnd(4,10),sacker=us?oppPlayer(game,choice(['EDGE','DL','LB'])):randomDefender(true);addYards(game,-loss);st.sacks++;
  if(sacker){const ds=stat(game,sacker.id,sacker.name,sacker.pos);ds.sacks++;ds.tackles++}
  game.lastPlay=`${qb.name} is sacked by ${sacker?.name||'the pass rush'} for a loss of ${loss}.`;addFeed(game,game.lastPlay);advanceDown(game,-loss);snapClock(game,false);maybeLiveInjury(game,[qb,sacker]);return
 }
 const aggression=(us?n(cfg.plan.agg,50):52)+ctx.aggressionAdjustment,oneOnOne=window.SDF_V144?.passMatchup?.(target,defender,cfg.plan.zone>=55?'zone':'man')||{edge:0};
 const risk=us?n(cfg.plan.turnoverRisk,8):8,qbDecision=skill12(qb,['decision','accuracy']),interceptChance=Math.max(.006,Math.min(.06,(.017+(def-off)/1600-oneOnOne.edge/2500+(72-qbDecision)/1450+Math.max(0,aggression-50)/2600+Math.max(0,risk-8)/2200)*ctx.turnoverMultiplier));
 if(Math.random()<interceptChance){
  const picker=us?oppPlayer(game,choice(['CB','S','LB'])):randomDefender(false);qs.passINT++;st.turnovers++;if(picker)stat(game,picker.id,picker.name,picker.pos).defINT++;
  game.lastPlay=`${qb.name}'s pass is intercepted by ${picker?.name||'a defender'}!`;addFeed(game,game.lastPlay,'turnover');snapClock(game,false);flipPossession(game,game.ball-direction(game)*rnd(0,12));maybeLiveInjury(game,[qb,target,picker]);return
 }
 const qbSkill=skill12(qb,['accuracy','decision','throwPower']),targetSkill=skill12(target,['catch','route','speed']),planEff=us?(n(cfg.plan.op?.passEff,1)-1)*.09:0;
 const redZoneBoost=toGoal(game)<=20?.035:0,comp=Math.max(.43,Math.min(.81,.61+redZoneBoost+(off-def)/1050+(qbSkill-70)/360+(targetSkill-70)/780+oneOnOne.edge/760+planEff));
 if(Math.random()>comp){
  game.lastPlay=`${qb.name}'s pass for ${target.name} falls incomplete.`;addFeed(game,game.lastPlay);advanceDown(game,0);snapClock(game,true);maybeLiveInjury(game,[qb,target,defender]);return
 }
 qs.passComp++;st.passComp++;ts.rec++;
 let yards=rnd(5,18)+Math.round((off-def)/62)+Math.round(oneOnOne.edge/48)+Math.round((qbSkill-70)/15)+Math.round((targetSkill-70)/18)+Math.round((n(cfg.scoring,1)-1)*8);
 let bigChance=(.028+(us?n(cfg.plan.explosive,12):10)/820+Math.max(-.012,Math.min(.045,oneOnOne.edge/1800)))*ctx.explosiveMultiplier*n(cfg.scoring,1);
 bigChance=Math.max(.015,Math.min(.105,bigChance));
 if(Math.random()<bigChance)yards+=rnd(12,28);
 yards=Math.max(-3,Math.min(yards,Math.min(75,toGoal(game))));
 qs.passYds+=yards;ts.recYds+=yards;st.passYds+=yards;st.totalYds+=yards;addYards(game,yards);
 if(defender&&toGoal(game)>0){const ds=stat(game,defender.id,defender.name,defender.pos);ds.tackles++;if(yards<=0)ds.tfl++}
 if(toGoal(game)<=0){
  qs.passTD++;ts.recTD++;ts.points+=6;st.redConv++;game.lastPlay=`TOUCHDOWN! ${qb.name} finds ${target.name} for ${Math.max(1,yards)} yards.`;snapClock(game,false,true);scorePoints(game,side,7,game.lastPlay);maybeLiveInjury(game,[qb,target,defender]);return
 }
 game.lastPlay=`${qb.name} completes to ${target.name} for ${yards} yard${yards===1?'':'s'}.`;addFeed(game,game.lastPlay);advanceDown(game,yards);snapClock(game,false);maybeLiveInjury(game,[qb,target,defender])
}
function runPlay(game){
 const us=game.possession==='us',cfg=game.cfg,off=us?cfg.ourOff:cfg.oppOff,def=us?cfg.oppDef:cfg.ourDef,side=us?'us':'them',st=sideStats(game,side),ctx=offenseContext(game,side),qb=us?selectUserSkill('QB'):oppPlayer(game,'QB'),rb=us?selectUserSkill('RB'):oppPlayer(game,'RB'),qbRunChance=us?clamp((state.offense==='Option'?.24:['Spread','Tempo Spread'].includes(state.offense)?.08:.035)+(['Scrambler','Improviser'].includes(qb?.arch)?.08:0),.02,.34):(cfg.opp.tendency==='Run Heavy'?.12:cfg.opp.tendency==='Tempo'?.10:.055),runner=Math.random()<qbRunChance?qb:rb,tackler=us?oppPlayer(game,choice(['LB','DL','S'])):randomDefender(false),rs=stat(game,runner.id,runner.name,runner.pos);
 st.plays++;st.rushAtt++;rs.rushAtt++;
 const runOne=window.SDF_V144?.runMatchup?.(runner,tackler)||{edge:0},runnerSkill=skill12(runner,['speed','vision','elusiveness','power']);
 let explosive=(.014+(us?n(cfg.plan.explosive,12):10)/940+Math.max(-.006,Math.min(.032,runOne.edge/1900)))*ctx.explosiveMultiplier*n(cfg.scoring,1);
 explosive=Math.max(.008,Math.min(.075,explosive));
 let yards=Math.round(rnd(-1,9)+(off-def)/68+runOne.edge/55+(runnerSkill-70)/13+(toGoal(game)<=20?.5:0)+(us?(n(cfg.plan.op?.runEff,1)-1)*3.2:0)+(n(cfg.scoring,1)-1)*5);
 if(Math.random()<explosive)yards+=rnd(11,25);
 yards=Math.max(-5,Math.min(yards,Math.min(70,toGoal(game))));rs.rushYds+=yards;st.rushYds+=yards;st.totalYds+=yards;
 const fumbleChance=(.0045+Math.max(0,(us?n(cfg.plan.agg,50):50)-50)/14000+Math.max(0,-runOne.edge)/15500+Math.max(0,70-runnerSkill)/6500)*ctx.turnoverMultiplier;
 if(Math.random()<fumbleChance){
  st.turnovers++;if(tackler){const ds=stat(game,tackler.id,tackler.name,tackler.pos);ds.ff++;ds.tackles++;if(yards<=0)ds.tfl++}addYards(game,yards);
  game.lastPlay=`${runner.name} gains ${yards} but fumbles! ${game.possession==='us'?game.opponent:state.school.name} recovers.`;addFeed(game,game.lastPlay,'turnover');snapClock(game,false);flipPossession(game);maybeLiveInjury(game,[runner,tackler]);return
 }
 addYards(game,yards);
 if(toGoal(game)<=0){
  rs.rushTD++;rs.points+=6;st.redConv++;game.lastPlay=`TOUCHDOWN! ${runner.name} breaks through for ${Math.max(1,yards)} yards.`;snapClock(game,false,true);scorePoints(game,side,7,game.lastPlay);maybeLiveInjury(game,[runner,tackler]);return
 }
 game.lastPlay=`${runner.name} runs for ${yards} yard${Math.abs(yards)===1?'':'s'}.`;addFeed(game,game.lastPlay);
 if(tackler){const ds=stat(game,tackler.id,tackler.name,tackler.pos);ds.tackles++;if(yards<=0)ds.tfl++}
 advanceDown(game,yards);snapClock(game,false);maybeLiveInjury(game,[runner,tackler])
}
function advanceDown(game,yards){
 const previousDown=game.down,st=sideStats(game,game.possession);
 if(previousDown===3)st.thirdAtt++;
 if(previousDown===4)st.fourthAtt++;
 if(yards>=game.distance){
  game.down=1;game.distance=Math.min(10,Math.max(1,toGoal(game)));st.firstDowns++;if(previousDown===3)st.thirdConv++;if(previousDown===4)st.fourthConv++;return
 }
 game.distance=Math.max(1,game.distance-yards);game.down++;
 if(game.down>4){game.lastPlay+=' Turnover on downs.';addFeed(game,'Turnover on downs.','turnover');flipPossession(game)}
}
function specialTeamsDecision(game){
 const side=game.possession,st=sideStats(game,side),goal=toGoal(game),us=side==='us',ctx=offenseContext(game,side),aggression=(us?n(game.cfg.plan.fourth,45):43)+ctx.aggressionAdjustment,needed=Math.max(1,game.distance),edge=us?game.cfg.ourOff-game.cfg.oppDef:game.cfg.oppOff-game.cfg.ourDef;
 if(game.down<4)return false;
 const goFor=(needed<=2&&goal>14&&aggression>=52)||(needed<=4&&goal<=12)||(ctx.late&&ctx.diff<0&&aggression>=48);
 if(goal<=35&&!goFor){
  const kicker=us?selectUserSkill('K'):oppPlayer(game,'K'),distance=Math.round(goal+17),rating=n(kicker?.ovr,65),chance=Math.max(.32,Math.min(.97,.965-Math.max(0,distance-25)*.015+(rating-70)*.006));
  snapClock(game,false,true);const ks=stat(game,kicker.id,kicker.name,kicker.pos);ks.fga++;
  if(Math.random()<chance){ks.fgm++;ks.points+=3;game.lastPlay=`${kicker.name} makes a ${distance}-yard field goal.`;scorePoints(game,side,3,game.lastPlay)}
  else{game.lastPlay=`${kicker.name} misses a ${distance}-yard field goal.`;addFeed(game,game.lastPlay,'turnover');flipPossession(game)}
  return true
 }
 if(goal>42&&!goFor){
  const punter=us?selectUserSkill('P'):oppPlayer(game,'P'),rating=n(punter?.ovr,65),punt=clamp(rnd(35,47)+Math.round((rating-65)/5),29,60),newBall=Math.max(5,Math.min(95,game.ball+direction(game)*punt)),ps=stat(game,punter.id,punter.name,punter.pos);
  ps.punts++;ps.puntYds+=punt;ps.puntLong=Math.max(ps.puntLong,punt);const landing=side==='us'?100-newBall:newBall;if(landing<=20)ps.inside20++;if(landing<=0)ps.touchbacks++;
  game.lastPlay=`${punter.name} punts ${punt} yards${landing<=20?' and pins the return team inside the 20':''}.`;addFeed(game,game.lastPlay);snapClock(game,false);flipPossession(game,newBall);return true
 }
 st.fourthAtt++;
 const chance=Math.max(.08,Math.min(.82,.69-(needed-1)*.055+edge/250+(aggression-50)/450));
 if(Math.random()<chance){
  const yards=needed+rnd(0,Math.min(6,Math.max(1,goal-needed)));addYards(game,yards);st.fourthConv++;st.firstDowns++;
  if(toGoal(game)<=0){game.lastPlay=`TOUCHDOWN! ${possessionTeam(game)} converts on fourth down.`;snapClock(game,false,true);scorePoints(game,side,7,game.lastPlay)}
  else{game.down=1;game.distance=Math.min(10,Math.max(1,toGoal(game)));game.lastPlay=`${possessionTeam(game)} converts on fourth down for ${yards} yards.`;addFeed(game,game.lastPlay);snapClock(game,false)}
 }else{game.lastPlay=`${possessionTeam(game)} is stopped on fourth down.`;addFeed(game,game.lastPlay,'turnover');snapClock(game,false);flipPossession(game)}
 return true
}
function quarterTransition(game){
 if(game.quarter>4)return false;
 if(game.clock>0)return false;
 if(game.quarter<4){
  game.quarter++;game.clock=900;
  if(game.quarter===3){resetSeries(game,game.secondHalfReceiver,game.secondHalfReceiver==='us'?25:75);addFeed(game,`Second-half kickoff to ${possessionTeam(game)}.`,'quarter')}
  else addFeed(game,`${quarterText(game.quarter)} begins.`,'quarter');
  return true
 }
 if(game.score.us!==game.score.them){game.complete=true;return true}
 game.quarter=4;startOvertime(game);return true
}
function overtimeCheck(game){return game.quarter>4&&game.complete}
function simulatePlay(game){
 if(game.complete)return;
 if(quarterTransition(game)){if(game.complete||game.quarter>4)return}
 if(game.quarter>4&&overtimeCheck(game))return;
 const beforePoss=game.possession;
 if(maybePenalty(game)){game.plays++;return}
 if(specialTeamsDecision(game)){game.plays++;return}
 const ctx=offenseContext(game),basePass=game.possession==='us'?n(game.cfg.plan.passRate,50):n(game.cfg.oppPass,51),passRate=Math.max(24,Math.min(78,basePass+ctx.passAdjustment));
 Math.random()*100<passRate?passPlay(game):runPlay(game);game.plays++;
 if(game.plays>205&&!game.complete){
  if(game.quarter<=4){game.clock=0;quarterTransition(game)}
  else if(game.possession===beforePoss)flipPossession(game)
 }
}
function topPlayers(game){
 const userIds=new Set((state.roster||[]).map(p=>String(p.id)));
 return Object.values(game.playerStats).filter(x=>userIds.has(String(x.id))).sort((a,b)=>playerValue(b)-playerValue(a)).slice(0,5)
}
function playerValue(s){return n(s.passYds)/15+n(s.passTD)*8-n(s.passINT)*5+n(s.rushYds)/10+n(s.rushTD)*8+n(s.recYds)/10+n(s.recTD)*8+n(s.tackles)+n(s.sacks)*5+n(s.defINT)*7+n(s.points)/3+n(s.puntYds)/55+n(s.inside20)*1.5}
function playerLine(s){if(s.pos==='QB')return `${s.passComp}/${s.passAtt}, ${s.passYds} YDS, ${s.passTD} TD, ${s.passINT} INT`;if(['RB'].includes(s.pos))return `${s.rushAtt} CAR, ${s.rushYds} YDS, ${s.rushTD} TD`;if(['WR','TE'].includes(s.pos))return `${s.rec} REC, ${s.recYds} YDS, ${s.recTD} TD`;if(['EDGE','DL','LB','CB','S'].includes(s.pos))return `${s.tackles} TKL, ${s.sacks} SACK, ${s.defINT} INT`;if(s.pos==='P')return `${s.punts} PUNTS, ${s.punts?(s.puntYds/s.punts).toFixed(1):'0.0'} AVG, ${s.inside20} IN 20`;return `${s.points} PTS`}
function applyPlayerStats(game,result){
 const userIds=new Set((state.roster||[]).map(p=>String(p.id)));
 Object.values(game.playerStats).filter(s=>userIds.has(String(s.id))).forEach(s=>{
  const p=state.roster.find(x=>String(x.id)===String(s.id));if(!p)return;ensurePlayerStats(p);const season=p.seasonStats;season.games++;season.passAtt+=s.passAtt;season.passComp+=s.passComp;season.passYds+=s.passYds;season.passTD+=s.passTD;season.passINT+=s.passINT;season.rushAtt+=s.rushAtt;season.rushYds+=s.rushYds;season.rushTD+=s.rushTD;season.rec+=s.rec;season.recYds+=s.recYds;season.recTD+=s.recTD;season.tackles+=s.tackles;season.tfl+=s.tfl;season.sacks+=s.sacks;season.defINT+=s.defINT;season.ff+=s.ff;season.fgm=(season.fgm||0)+s.fgm;season.fga=(season.fga||0)+s.fga;season.xpm=(season.xpm||0)+s.xpm;season.xpa=(season.xpa||0)+s.xpa;season.points+=s.points;season.punts+=s.punts;season.puntYds+=s.puntYds;season.puntLong=Math.max(season.puntLong,s.puntLong);season.inside20+=s.inside20;season.touchbacks+=s.touchbacks;
  p.stats??={games:0,yards:0,td:0,tackles:0,sacks:0,int:0};p.stats.games++;p.stats.yards+=s.passYds+s.rushYds+s.recYds;p.stats.td+=s.passTD+s.rushTD+s.recTD;p.stats.tackles+=s.tackles;p.stats.sacks+=s.sacks;p.stats.int+=s.defINT;
  recordPlayerGame(p,game.week,game.opponent,result,{passAtt:s.passAtt,passComp:s.passComp,passYds:s.passYds,passTD:s.passTD,passINT:s.passINT,rushAtt:s.rushAtt,rushYds:s.rushYds,rushTD:s.rushTD,rec:s.rec,recYds:s.recYds,recTD:s.recTD,tackles:s.tackles,tfl:s.tfl,sacks:s.sacks,defINT:s.defINT,ff:s.ff,fgm:s.fgm,fga:s.fga,xpm:s.xpm,xpa:s.xpa,points:s.points,punts:s.punts,puntYds:s.puntYds,puntLong:s.puntLong,inside20:s.inside20,touchbacks:s.touchbacks});
 });
}
function facilityWeeklyBonus(){
 const key=`${state.year}-${state.week}`;if(state._facilityWeeklyBonusApplied===key)return;state._facilityWeeklyBonusApplied=key;state.weeklyHours+=Math.max(0,(n(state.facilities?.recruiting,1)-1)*2);state.nilBudget+=Math.max(0,(n(state.facilities?.nilCollective,1)-1)*6000)
}
function finalizeLiveGame(game){
 if(game.finalized)return;game.finalized=true;stopTimer();const postseason=game.contextType!=='REGULAR',g=postseason?state.liveGameContext?.game:state.schedule[game.scheduleIndex],win=game.score.us>game.score.them,margin=game.score.us-game.score.them,result=win?'W':'L';if(!g)return;g.result=result;g.score=`${game.score.us}-${game.score.them}`;
 if(postseason){applyPlayerStats(game,result);try{window.SDF_V175?.recordLiveGame?.(game)}catch(err){console.warn('National live-game stats recovery',err)}win?state.record.w++:state.record.l++;state.coachCareer.careerWins+=win?1:0;state.coachCareer.careerLosses+=win?0:1;state.roster.forEach(p=>p.morale=clamp(p.morale+(win?rnd(0,3):rnd(-3,1)),35,99));const us=game.stats.us,them=game.stats.them,stars=topPlayers(game).map(x=>`${x.name}: ${playerLine(x)}`);state.lastGameRecap={opponent:g.opponent,home:false,win,us:game.score.us,them:game.score.them,rivalry:false,headline:`${game.gameLabel} · ${win?'Victory':'Defeat'}`,boxScore:{firstDowns:us.firstDowns,rushYds:us.rushYds,passYds:us.passYds,totalYds:us.totalYds,turnovers:us.turnovers,thirdDown:`${us.thirdConv}/${us.thirdAtt}`,fourthDown:`${us.fourthConv}/${us.fourthAtt}`,sacksAllowed:us.sacks,timePossession:clockText(us.timePossession)},opponentBoxScore:{firstDowns:them.firstDowns,rushYds:them.rushYds,passYds:them.passYds,totalYds:them.totalYds,turnovers:them.turnovers},stars,drives:game.driveSummary,planReport:[game.gameLabel,`${game.plays} live plays simulated`],liveGame:true,postseason:true,injuries:game.injuries};state.news.push(`${result} ${g.score} vs ${g.opponent} in ${game.gameLabel}. Watched live in Game Center.`);markGamesMissed(game.preGameInjuredIds||[]);recoveryTick();state.liveGame=null;const context=state.liveGameContext;state.liveGameContext=null;window.SDF_V16?.completePostseasonGame?.(context,game,{win,margin,result});window.renderAll();window.SDF_RELEASE_TEST?.saveNow?.('Postseason live game completed',false,true);renderFinal(game);return}

 win?state.record.w++:state.record.l++;state.conferenceRecords??={};state.conferenceRecords[state.school.id]??={w:0,l:0};if(g.conference)win?state.conferenceRecords[state.school.id].w++:state.conferenceRecords[state.school.id].l++;
 const me=state.standings?.find(x=>x.id===state.school.id);if(me)win?me.w++:me.l++;(state.standings||[]).filter(x=>x.id!==state.school.id).forEach(x=>Math.random()>.5?x.w++:x.l++);
 applyPlayerStats(game,result);try{window.SDF_V175?.recordLiveGame?.(game)}catch(err){console.warn('National live-game stats recovery',err)}const visitResults=window.SDF_V113_TEST?.resolveVisits?.(g,win,margin)||[];
 if(g.rivalry){state.fanApproval=clamp(state.fanApproval+(win?8:-8),0,100);state.boosterSupport=clamp(state.boosterSupport+(win?5:-5),0,100);const rh=state.rivalryHistory?.[state.rivalId];if(rh){win?rh.wins++:rh.losses++;rh.streak=win?Math.max(1,n(rh.streak)+1):Math.min(-1,n(rh.streak)-1);rh.bestMargin=Math.max(n(rh.bestMargin),win?margin:0);rh.last={year:state.year,win,score:g.score}}}
 try{updateAttendance(win,g.rivalry)}catch{};state.coachCareer.careerWins+=win?1:0;state.coachCareer.careerLosses+=win?0:1;try{addCoachXP(win?18:7)}catch{};try{maybeCreateDynamicRivalry(g)}catch{};
 state.roster.forEach(p=>p.morale=clamp(p.morale+(win?rnd(0,3):rnd(-3,1)),35,99));
 const us=game.stats.us,them=game.stats.them,stars=topPlayers(game).map(s=>`${s.name}: ${playerLine(s)}`);
 state.lastGameRecap={opponent:g.opponent,home:g.home,win,us:game.score.us,them:game.score.them,rivalry:g.rivalry,headline:win?'Live game plan delivers the victory':'Live comeback falls short',boxScore:{firstDowns:us.firstDowns,rushYds:us.rushYds,passYds:us.passYds,totalYds:us.totalYds,turnovers:us.turnovers,thirdDown:`${us.thirdConv}/${us.thirdAtt}`,fourthDown:`${us.fourthConv}/${us.fourthAtt}`,sacksAllowed:us.sacks,timePossession:clockText(us.timePossession)},opponentBoxScore:{firstDowns:them.firstDowns,rushYds:them.rushYds,passYds:them.passYds,totalYds:them.totalYds,turnovers:them.turnovers},stars,drives:game.driveSummary.length?game.driveSummary:game.feed.filter(x=>['score','turnover'].includes(x.type)).map(x=>x.text),planReport:[`${state.offense}: ${Math.round(game.cfg.plan.passRate)}% planned passing`,`${state.weeklyPractice} practice applied`,`${game.plays} live plays simulated`,`${game.injuries.length} game injury${game.injuries.length===1?'':'ies'}`],visitResults,liveGame:true,injuries:game.injuries};
 state.gamePlanHistory??=[];state.gamePlanHistory.push({year:state.year,week:state.week,opponent:g.opponent,offense:state.offense,defense:state.defense,practice:state.weeklyPractice,runPass:state.gamePlan?.runPass,tempo:state.gamePlan?.tempo,aggression:state.gamePlan?.offenseAggression,blitz:state.gamePlan?.blitz,zone:state.gamePlan?.manZone,fourth:state.gamePlan?.fourthDown,result,score:g.score,live:true});
 state.news.push(`${result} ${g.score} ${g.home?'vs':'at'} ${g.opponent}. Watched live in Game Center.`);
 try{resolveRecruiting()}catch{};try{simulateWorldWeek()}catch{};markGamesMissed(game.preGameInjuredIds||[]);recoveryTick();try{window.SDF_V103_TEST?.progressFacilityProject?.()}catch{};try{weeklyEvent()}catch{};
 state.week++;if(state.week>12)prepareSigningDay();else{resetHours();facilityWeeklyBonus()}
 state.liveGame=null;window.renderAll();window.SDF_RELEASE_TEST?.saveNow?.('Live game completed',false,true);renderFinal(game);
}
function renderField(game){const pos=pct(game.ball);return `<div class="live-field"><div class="endzone left">${safe(state.school.name)}</div><div class="field-lines"></div><div class="first-down-line" style="left:${pct(game.ball+direction(game)*game.distance)}%"></div><div class="ball-marker" style="left:${pos}%">🏈</div><div class="endzone right">${safe(game.opponent)}</div></div>`}
function renderTeamStats(game){const a=game.stats.us,b=game.stats.them;const rows=[['Total yards',a.totalYds,b.totalYds],['Passing',a.passYds,b.passYds],['Rushing',a.rushYds,b.rushYds],['First downs',a.firstDowns,b.firstDowns],['Turnovers',a.turnovers,b.turnovers],['3rd down',`${a.thirdConv}/${a.thirdAtt}`,`${b.thirdConv}/${b.thirdAtt}`],['4th down',`${a.fourthConv}/${a.fourthAtt}`,`${b.fourthConv}/${b.fourthAtt}`]];return `<div class="live-stat-table"><div class="stat-head"><b>${safe(state.school.name)}</b><span></span><b>${safe(game.opponent)}</b></div>${rows.map(r=>`<div><b>${r[1]}</b><span>${r[0]}</span><b>${r[2]}</b></div>`).join('')}</div>`}
function renderPlayerStats(game){const top=topPlayers(game);return `<div class="live-player-list">${top.length?top.map(s=>`<div><b>${safe(s.name)} · ${s.pos}</b><span>${playerLine(s)}</span></div>`).join(''):'<p class="muted">Player statistics appear after the opening drive.</p>'}</div>`}
function renderGameCenter(){
 const game=state.liveGame;if(!game)return;const body=$12('gameSimBody');if(!body)return;const opp=teamById(game.oppId),feed=game.feed.slice(-16).reverse();
 body.innerHTML=`<div class="live-center"><div class="live-topbar"><div><span class="live-badge">LIVE SIMULATION</span><b>Year ${game.year} · ${safe(game.gameLabel||`Week ${game.week}`)}</b><span>${game.home?'Home vs':'Road at'} ${safe(game.opponent)}</span></div><div class="live-controls"><button class="btn neutral" id="livePauseBtn">${game.paused?'Resume':'Pause'}</button><button class="btn primary" id="liveFinalBtn" ${game.simulatingToFinal?'disabled':''}>${game.simulatingToFinal?'Simulating…':'Sim to Final'}</button><button class="btn neutral" id="liveExitBtn">Save & Exit</button></div></div><div class="live-scoreboard"><div class="live-team"><img src="${logo(state.school.id)}" alt=""><b>${safe(state.school.name)}</b><span>${state.record.w}-${state.record.l}</span></div><div class="live-score"><b>${game.score.us}</b><div><span>${quarterText(game.quarter)}</span><strong>${game.quarter<=4?clockText(game.clock):'OT'}</strong><small>${safe(situation(game))}</small></div><b>${game.score.them}</b></div><div class="live-team"><img src="${logo(opp?.id)}" alt=""><b>${safe(game.opponent)}</b><span>${safe(game.cfg.opp.tendency||'Balanced')}</span></div></div>${renderField(game)}<div class="live-last-play"><small>LAST PLAY</small><b>${safe(game.lastPlay)}</b><span>${game.possession==='us'?state.school.name:game.opponent} ball · ${safe(situation(game))}</span></div><div class="speed-controls"><span>Speed</span>${[.5,1,2,4].map(v=>`<button class="speed-btn ${currentSpeed===v?'active':''}" data-speed="${v}">${v}×</button>`).join('')}</div><div class="live-grid"><section><div class="live-section-head"><b>Play by play</b><span>${game.plays} plays</span></div><div class="live-feed">${feed.length?feed.map((x,i)=>`<div class="live-feed-row ${x.type}"><span>${quarterText(x.quarter).replace(' Quarter','')} ${clockText(x.clock)}</span><p>${safe(x.text)}</p><b>${x.score}</b></div>`).join(''):'<div class="muted">Kickoff is next…</div>'}</div></section><section><div class="live-section-head"><b>Team stats</b></div>${renderTeamStats(game)}<div class="live-section-head"><b>Top performers</b></div>${renderPlayerStats(game)}${game.injuries.length?`<div class="live-injury-box"><b>Game injuries</b>${game.injuries.map(i=>`<span>${safe(i.player)} · ${safe(i.type)} · ${i.weeks} weeks</span>`).join('')}</div>`:''}</section></div></div>`;
 $12('livePauseBtn').onclick=()=>{game.paused=!game.paused;game.paused?stopTimer():startTimer();renderGameCenter()};
 $12('liveFinalBtn').onclick=()=>simToFinal();
 $12('liveExitBtn').onclick=()=>exitGameCenter();
 body.querySelectorAll('[data-speed]').forEach(b=>b.onclick=()=>setLiveSpeed(Number(b.dataset.speed)));
 renderedFeedLength=game.feed.length;
}
function renderFinal(game){
 const body=$12('gameSimBody');if(!body)return;const win=game.score.us>game.score.them,top=topPlayers(game);body.innerHTML=`<div class="live-final"><span class="eyebrow">FINAL</span><h2>${win?'Victory':'Defeat'} · ${safe(state.school.name)} ${game.score.us}, ${safe(game.opponent)} ${game.score.them}</h2><div class="final-score-row"><div><img src="${logo(state.school.id)}"><b>${game.score.us}</b><span>${safe(state.school.name)}</span></div><div class="final-divider">FINAL</div><div><img src="${logo(game.oppId)}"><b>${game.score.them}</b><span>${safe(game.opponent)}</span></div></div><div class="live-final-grid"><section><h3>Box score</h3>${renderTeamStats(game)}</section><section><h3>Top performers</h3>${renderPlayerStats(game)}</section></div>${game.injuries.length?`<div class="postgame-injuries"><h3>Persistent Injury Report</h3>${game.injuries.map(i=>`<div><b>${safe(i.player)} (${i.pos})</b><span>${safe(i.type)} · ${i.weeks} week${i.weeks===1?'':'s'} · ${expectedReturn(i)}</span></div>`).join('')}</div>`:''}<div class="live-final-actions"><button id="liveContinueBtn" class="btn success">Continue Dynasty</button><button id="liveInjuryBtn" class="btn neutral">Open Injury Report</button></div></div>`;
 $12('liveContinueBtn').onclick=()=>{$12('gameSimModal').classList.add('hidden');window.showTab('dashboard')};
 $12('liveInjuryBtn').onclick=()=>{$12('gameSimModal').classList.add('hidden');window.showTab('roster');setTimeout(()=>{document.querySelector('#rosterTab .tab-section-btn[data-key="injuries"]')?.click()},60)};
 tone(win?'win':'loss');
}
function gameTick(){
 const game=state.liveGame;if(!game||game.complete||game.paused){stopTimer();return}simulatePlay(game);if(game.complete){finalizeLiveGame(game);return}renderGameCenter();scheduleTick()
}
function scheduleTick(){stopTimer();if(!state.liveGame||state.liveGame.paused||currentSpeed===0)return;timer=setTimeout(gameTick,SPEEDS[currentSpeed]||900)}
function startTimer(){if(!state.liveGame)return;state.liveGame.paused=false;scheduleTick()}
function stopTimer(){if(timer){clearTimeout(timer);timer=null}}
function setLiveSpeed(v){currentSpeed=[.5,1,2,4].includes(v)?v:1;if(state.liveGame&&!state.liveGame.paused)scheduleTick();renderGameCenter()}
function simToFinal(){
 const game=state.liveGame;if(!game||game.finalized||game.simulatingToFinal)return;stopTimer();game.paused=true;game.simulatingToFinal=true;renderGameCenter();let safety=0;
 const finishSafely=()=>{if(game.finalized)return;game.simulatingToFinal=false;if(!game.complete){if(game.score.us===game.score.them)game.score.us+=3;game.complete=true;addFeed(game,'The remaining game clock was completed by the fast-sim safety engine.','quarter')}setTimeout(()=>finalizeLiveGame(game),0)};
 const runBatch=()=>{if(state.liveGame!==game||game.finalized)return;try{let count=0;while(!game.complete&&count++<18&&safety++<500)simulatePlay(game);if(game.complete||safety>=500){finishSafely();return}renderGameCenter();setTimeout(runBatch,0)}catch(error){console.error('Sim to Final recovered from an error',error);game.lastPlay='Fast simulation recovered and completed the game.';finishSafely()}};
 setTimeout(runBatch,0)
}
function exitGameCenter(){if(!state.liveGame)return;$12('gameSimModal').classList.add('hidden');state.liveGame.paused=true;stopTimer();window.SDF_RELEASE_TEST?.saveNow?.('Live game paused',false,false);window.renderAll()}
window.openLiveGameCenter=()=>{
 ensure12();if(state.phase!=='REGULAR'&&!state.liveGameContext){alert('There is no live matchup ready.');return}const g=currentGame();if(!g||g.result){alert('There is no unplayed game this week.');return}if(!state.liveGame||state.liveGame.year!==state.year||state.liveGame.week!==state.week)state.liveGame=newLiveGame();
 $12('gameResultModal')?.classList.add('hidden');$12('gameSimModal').classList.remove('hidden');$12('closeGameSim').classList.add('hidden');renderGameCenter();startTimer();tone('kickoff');window.SDF_RELEASE_TEST?.saveNow?.('Live game started',false,false)
};
function tone(type){if(!state?.soundEnabled)return;try{const ctx=new(window.AudioContext||window.webkitAudioContext)(),seq=type==='injury'?[[190,.16],[135,.28]]:type==='win'?[[523,.08],[659,.08],[784,.18]]:type==='loss'?[[260,.14],[196,.24]]:type==='kickoff'?[[440,.05],[660,.09]]:[[420,.07]];let t=ctx.currentTime;seq.forEach(([f,d])=>{const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=f;o.type='sine';g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.07,t+.01);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(ctx.destination);o.start(t);o.stop(t+d+.03);t+=d})}catch{}}
function renderGameDay(){
 const host=$12('gameDayMatchup');if(!host||!state.school)return;const g=currentGame(),opp=g?teamById(g.oppId):null,resume=state.liveGame&&!state.liveGame.finalized&&state.liveGame.year===state.year&&state.liveGame.week===state.week;
 if(!g){host.innerHTML='<div class="postseason-empty">No regular-season matchup is currently scheduled.</div>';return}
 host.innerHTML=`<div class="game-day-matchup"><div><img src="${logo(state.school.id)}"><b>${safe(state.school.name)}</b><span>${state.record.w}-${state.record.l} · ${teamRatings().overall} OVR</span></div><div class="game-day-middle"><span>WEEK ${state.week}</span><b>${g.home?'VS':'AT'}</b><small>${safe(g.weather||'Clear')} · ${g.conference?'Conference game':'Non-conference'}${g.rivalry?' · Rivalry':''}</small></div><div><img src="${logo(opp?.id)}"><b>${safe(g.opponent)}</b><span>${g.oppPower} projected power</span></div></div>${resume?`<div class="resume-live-banner"><b>Live game in progress</b><span>${quarterText(state.liveGame.quarter)} · ${clockText(state.liveGame.clock)} · ${state.liveGame.score.us}-${state.liveGame.score.them}</span><button class="btn success" onclick="openLiveGameCenter()">Resume Game Center</button></div>`:''}`;
 ['watchLiveGameBtn','watchLiveDashboardBtn'].forEach(id=>{const b=$12(id);if(b){b.disabled=!!g.result||state.phase!=='REGULAR';b.textContent=resume?'Resume Live Game':'Watch Game Live'}});
 const q=$12('quickSimGameBtn');if(q){q.disabled=!!resume||!!g.result||state.phase!=='REGULAR';q.textContent=resume?'Resume Game Center':'Open This Week’s Game'}
}
function repairQuickSimInjuries(){
 const base=window.simGame;if(typeof base!=='function'||base._v12Wrapped)return;
 const wrapped=function(...args){const before=new Map(state.roster.map(p=>[p.id,!!p.injury]));markGamesMissed();const out=base.apply(this,args);state.roster.forEach(p=>{if(!before.get(p.id)&&p.injury){normalizeInjury(p);p.injury.occurredYear=state.year;p.injury.occurredWeek=state.week;const exists=state.injuryHistory.some(x=>x.id===p.injury.id);if(!p.injury.id)p.injury.id=crypto.randomUUID();if(!exists)state.injuryHistory.push({id:p.injury.id,playerId:p.id,player:p.name,pos:p.pos,...p.injury})}});return out};wrapped._v12Wrapped=true;window.simGame=wrapped;
}
function wire12(){
 $12('watchLiveGameBtn')?.addEventListener('click',window.openLiveGameCenter);$12('watchLiveDashboardBtn')?.addEventListener('click',window.openLiveGameCenter);$12('quickSimGameBtn')?.addEventListener('click',()=>window.advanceWeek());$12('openFullInjuryReportBtn')?.addEventListener('click',()=>{window.showTab('roster');setTimeout(()=>document.querySelector('#rosterTab .tab-section-btn[data-key="injuries"]')?.click(),60)});$12('autoAdjustInjuriesBtn')?.addEventListener('click',window.autoAdjustForInjuries);
 $12('closeGameSim').onclick=exitGameCenter;$12('gameSimModal')?.addEventListener('click',e=>{if(e.target===$12('gameSimModal')&&state.liveGame)exitGameCenter()});
}
const previousRenderAll=window.renderAll;window.renderAll=function(...args){ensure12();const out=previousRenderAll.apply(this,args);if(!state.school)return out;renderInjuries();renderGameDay();if(state.liveGame&&!state.liveGame.finalized){['advanceWeekBtn','recruitAdvanceBtn','mobileAdvance','quickSimGameBtn'].forEach(id=>{const b=$12(id);if(b){b.disabled=true;if(id!=='quickSimGameBtn')b.textContent='Live Game In Progress'}})}return out};
const previousShowTab=window.showTab;window.showTab=function(name){const out=previousShowTab.call(this,name);if(name==='gameday')renderGameDay();if(name==='roster')renderInjuries();return out};

const phaseAdvance=window.advanceWeek;
window.advanceWeek=function(...args){
 if(state?.phase==='REGULAR'&&!state.seasonDone){
  const g=currentGame();
  if(g&&!g.result){window.openLiveGameCenter();return{openedGameCenter:true,week:state.week}}
 }
 return phaseAdvance?.apply(this,args)
};
window.simEnd=function(){return window.advanceWeek()};
function enforceGameCenterLabels(){
 if(!state?.school)return;
 const g=currentGame(),available=state.phase==='REGULAR'&&!state.seasonDone&&g&&!g.result;
 const resume=available&&state.liveGame&&!state.liveGame.finalized&&state.liveGame.year===state.year&&state.liveGame.week===state.week;
 [['advanceWeekBtn',resume?'Resume This Week’s Game →':`Watch Week ${state.week} Game →`],
  ['recruitAdvanceBtn',resume?'Resume This Week’s Game →':`Watch Week ${state.week} Game →`],
  ['mobileAdvance',resume?'Resume Game':'Watch Game'],
  ['quickSimGameBtn',resume?'Resume Game Center':'Open This Week’s Game'],
  ['simToEndBtn',resume?'Resume Current Game':'Open Next Game']].forEach(([id,label])=>{
   const b=$12(id);if(b&&available){b.disabled=false;b.textContent=label;b.onclick=()=>window.advanceWeek()}
  })
}
const renderBeforeRequired=window.renderAll;
window.renderAll=function(...args){const out=renderBeforeRequired?.apply(this,args);enforceGameCenterLabels();return out};

repairQuickSimInjuries();ensure12();wire12();if(state.school)window.renderAll();window.SDF_V12_TEST={newLiveGame,simulatePlay,renderInjuries,recoveryTick,recordInjury,finalizeLiveGame,gameConfig,emptyTeamStats,topPlayers,playerLine,skill12,requiredGameCenter:true};
})();
(()=>{
'use strict';
const TITLES={
 dashboard:['PROGRAM HQ','Dynasty Overview'],recruiting:['ROSTER BUILDING','Recruiting Central'],roster:['TEAM MANAGEMENT','Roster & Depth Chart'],
 team:['PROGRAM IDENTITY','Team Management'],gameplan:['SATURDAY PREP','Game Plan'],gameday:['LIVE FOOTBALL','Game Day'],coach:['STAFF ROOM','Coaching Staff'],
 stats:['PERFORMANCE','Statistics'],season:['SCHEDULE','Season Hub'],postseason:['CHAMPIONSHIP ROAD','Postseason'],program:['PROGRAM BUILDING','Facilities & Resources'],
 rankings:['NATIONAL PICTURE','Rankings'],dynasty:['DYNASTY CONTROL','Save & League Tools'],history:['LEGACY','Program History']
};
function activeTab(){return document.querySelector('.nav-tab.active')?.dataset.tab||'dashboard'}
function updateContext(tab=activeTab()){
 const [kicker,title]=TITLES[tab]||['SATURDAY DYNASTY FOOTBALL','Dynasty'];
 const k=document.getElementById('activeSectionKicker'),t=document.getElementById('activeSectionTitle');
 if(k)k.textContent=state?.school?`${state.school.conference||kicker} · ${kicker}`:kicker;
 if(t)t.textContent=state?.school?`${state.school.name} · ${title}`:'Select a Program';
 document.body.dataset.section=tab;
 document.querySelectorAll('.nav-tab').forEach(b=>b.setAttribute('aria-current',b.dataset.tab===tab?'page':'false'));
 document.querySelectorAll('[data-mobile-target]').forEach(b=>b.classList.toggle('active',b.dataset.mobileTarget===tab));
}
document.body.classList.add('broadcast-ui');
const oldShowTab=window.showTab;
if(oldShowTab)window.showTab=function(tab){const out=oldShowTab.apply(this,arguments);updateContext(tab);return out};
const oldRenderAll=window.renderAll;
if(oldRenderAll)window.renderAll=function(){const out=oldRenderAll.apply(this,arguments);updateContext();return out};
const oldApplyBrand=window.applyBrand;
if(oldApplyBrand)window.applyBrand=function(){const out=oldApplyBrand.apply(this,arguments);updateContext();return out};
window.addEventListener('DOMContentLoaded',()=>{
 updateContext();
 document.querySelectorAll('.nav-tab,[data-mobile-target]').forEach(btn=>btn.addEventListener('click',()=>setTimeout(()=>updateContext(btn.dataset.tab||btn.dataset.mobileTarget),0)));
});
window.SDF_V13_TEST={updateContext,TITLES};
})();
(()=>{
'use strict';
const $=id=>document.getElementById(id);
const roleDefs=()=>window.SDF_V11_TEST?.ROLE_DEFS||[];
const ensureDepth=()=>window.SDF_V11_TEST?.ensureRealDepth?.();
const save=(reason)=>window.SDF_RELEASE_TEST?.saveNow?.(reason,false,false);
const eligible=(def,p)=>p&&def&&p.pos===def.pos&&!p.redshirt&&!p.injury;

function starterAssignments(pos,exceptRole=''){
 const out=new Map();
 for(const def of roleDefs().filter(r=>r.pos===pos&&r.key!==exceptRole)){
  const id=state.realDepthChart?.[def.key]?.slots?.[0]?.playerId;
  if(id)out.set(id,def.key);
 }
 return out;
}
function bestAvailableStarter(pos,excluded=new Set()){
 return state.roster
  .filter(p=>p.pos===pos&&!p.redshirt&&!p.injury&&!excluded.has(p.id))
  .sort((a,b)=>b.ovr-a.ovr||a.name.localeCompare(b.name))[0]||null;
}
function repairStarterRoles(pos,preferredRole=''){
 const defs=roleDefs().filter(r=>r.pos===pos);
 const ordered=[...defs.filter(r=>r.key===preferredRole),...defs.filter(r=>r.key!==preferredRole)];
 const used=new Set();
 for(const def of ordered){
  const slot=state.realDepthChart?.[def.key]?.slots?.[0];
  if(!slot)continue;
  const current=state.roster.find(p=>p.id===slot.playerId);
  if(!eligible(def,current)||used.has(slot.playerId)){
   const pick=bestAvailableStarter(pos,used);
   slot.playerId=pick?.id||'';
  }
  if(slot.playerId)used.add(slot.playerId);
 }
}
function repairRoleDuplicates(role){
 const def=roleDefs().find(r=>r.key===role),slots=state.realDepthChart?.[role]?.slots||[];
 if(!def)return;
 const used=new Set();
 for(const slot of slots){
  if(!slot?.playerId)continue;
  if(used.has(slot.playerId)){
   const pick=state.roster.filter(p=>eligible(def,p)&&!used.has(p.id)).sort((a,b)=>b.ovr-a.ovr)[0];
   slot.playerId=pick?.id||'';
  }
  if(slot.playerId)used.add(slot.playerId);
 }
}
function smartSetDepthPlayer(role,index,id){
 ensureDepth();
 const def=roleDefs().find(r=>r.key===role);
 const chart=state.realDepthChart?.[role];
 if(!def||!chart)return;
 chart.slots[index]??={playerId:'',snapShare:index===0?70:index===1?25:5};
 const oldTarget=chart.slots[index].playerId||'';

 // Selecting a player already listed within this role performs a clean swap.
 const sameRoleIndex=chart.slots.findIndex((s,i)=>i!==index&&s.playerId===id);
 if(sameRoleIndex>=0)chart.slots[sameRoleIndex].playerId=oldTarget;

 if(index===0&&id){
  // A player cannot start at two roles for the same position. Move the displaced
  // starter into the old role when possible; otherwise promote the highest OVR
  // eligible player who is not already starting.
  const sourceDef=roleDefs().find(r=>r.pos===def.pos&&r.key!==role&&state.realDepthChart?.[r.key]?.slots?.[0]?.playerId===id);
  if(sourceDef){
   const sourceSlot=state.realDepthChart[sourceDef.key].slots[0];
   const otherStarters=starterAssignments(def.pos,sourceDef.key);
   let replacement=state.roster.find(p=>p.id===oldTarget&&eligible(sourceDef,p)&&!otherStarters.has(p.id)&&p.id!==id);
   if(!replacement){
    const excluded=new Set([...otherStarters.keys(),id]);
    replacement=bestAvailableStarter(def.pos,excluded);
   }
   sourceSlot.playerId=replacement?.id||'';
  }
 }

 chart.slots[index].playerId=id;
 repairRoleDuplicates(role);
 if(index===0)repairStarterRoles(def.pos,role);
 window.SDF_V11_TEST?.ensureRealDepth?.();
 try{state.roster.forEach(p=>p.starter=false);for(const r of roleDefs()){const pid=state.realDepthChart?.[r.key]?.slots?.[0]?.playerId,player=state.roster.find(p=>p.id===pid);if(player)player.starter=true}}catch{}
 window.renderDepthManager?.();
 save('Depth chart starter swap');
}
window.setRealDepthPlayer=smartSetDepthPlayer;

const STAT_FIELDS=['games','passAtt','passComp','passYds','passTD','passINT','rushAtt','rushYds','rushTD','rec','recYds','recTD','tackles','tfl','sacks','defINT','ff','fgm','fga','xpm','xpa','points','punts','puntYds','puntLong','inside20','touchbacks'];
function playerStats(p){
 let s=typeof ensurePlayerStats==='function'?ensurePlayerStats(p):(p.seasonStats??={});
 for(const key of STAT_FIELDS)s[key]=Number(s[key]||0);
 return s;
}
function categoryPlayers(category){
 const rows=(state.roster||[]).map(p=>({p,s:playerStats(p)}));
 const eligibleByCategory={
  PASSING:x=>x.p.pos==='QB'||x.s.passAtt>0,
  RUSHING:x=>['QB','RB','FB','WR'].includes(x.p.pos)||x.s.rushAtt>0,
  RECEIVING:x=>['WR','TE','RB','FB'].includes(x.p.pos)||x.s.rec>0,
  DEFENSE:x=>['EDGE','DL','LB','CB','S'].includes(x.p.pos)||x.s.tackles+x.s.sacks+x.s.defINT>0,
  KICKING:x=>x.p.pos==='K'||x.s.fga+x.s.xpa>0,
  PUNTING:x=>x.p.pos==='P'||x.s.punts>0,
  ALL:()=>true
 }[category]||(()=>true);
 const filtered=rows.filter(eligibleByCategory);
 const sorters={
  PASSING:(a,b)=>b.s.passYds-a.s.passYds||b.s.passTD-a.s.passTD||b.s.passAtt-a.s.passAtt,
  RUSHING:(a,b)=>b.s.rushYds-a.s.rushYds||b.s.rushTD-a.s.rushTD||b.s.rushAtt-a.s.rushAtt,
  RECEIVING:(a,b)=>b.s.recYds-a.s.recYds||b.s.recTD-a.s.recTD||b.s.rec-a.s.rec,
  DEFENSE:(a,b)=>b.s.tackles-a.s.tackles||b.s.sacks-a.s.sacks||b.s.defINT-a.s.defINT||b.s.tfl-a.s.tfl,
  KICKING:(a,b)=>b.s.points-a.s.points||b.s.fgm-a.s.fgm,
  PUNTING:(a,b)=>(b.s.puntYds/Math.max(1,b.s.punts))-(a.s.puntYds/Math.max(1,a.s.punts))||b.s.inside20-a.s.inside20,
  ALL:(a,b)=>b.s.games-a.s.games||b.p.ovr-a.p.ovr
 };
 return filtered.sort(sorters[category]);
}
function rating(s){return Math.max(0,Math.round((s.passYds/Math.max(1,s.passAtt))*8+s.passTD*6-s.passINT*5))}
function classText(p){try{return typeof classLabel==='function'?classLabel(p):`Year ${p.year}`}catch{return`Year ${p.year}`}}
function tableDefinition(category){
 return {
  PASSING:{headers:['Player','Pos','G','Cmp/Att','Cmp%','Yds','TD','INT','Rating'],cells:({p,s})=>[playerButton(p),p.pos,s.games,`${s.passComp}/${s.passAtt}`,`${s.passAtt?Math.round(s.passComp/s.passAtt*100):0}%`,s.passYds,s.passTD,s.passINT,rating(s)]},
  RUSHING:{headers:['Player','Pos','G','Car','Yds','Avg','TD'],cells:({p,s})=>[playerButton(p),p.pos,s.games,s.rushAtt,s.rushYds,s.rushAtt?(s.rushYds/s.rushAtt).toFixed(1):'0.0',s.rushTD]},
  RECEIVING:{headers:['Player','Pos','G','Rec','Yds','Avg','TD'],cells:({p,s})=>[playerButton(p),p.pos,s.games,s.rec,s.recYds,s.rec?(s.recYds/s.rec).toFixed(1):'0.0',s.recTD]},
  DEFENSE:{headers:['Player','Pos','G','Tackles','TFL','Sacks','INT','FF'],cells:({p,s})=>[playerButton(p),p.pos,s.games,s.tackles,s.tfl,s.sacks,s.defINT,s.ff]},
  KICKING:{headers:['Player','Pos','G','FG','FG%','XP','Pts'],cells:({p,s})=>[playerButton(p),p.pos,s.games,`${s.fgm}/${s.fga}`,`${s.fga?Math.round(s.fgm/s.fga*100):0}%`,`${s.xpm}/${s.xpa}`,s.points]},
  PUNTING:{headers:['Player','Pos','G','Punts','Yds','Avg','Long','Inside 20','TB'],cells:({p,s})=>[playerButton(p),p.pos,s.games,s.punts,s.puntYds,s.punts?(s.puntYds/s.punts).toFixed(1):'0.0',s.puntLong,s.inside20,s.touchbacks]},
  ALL:{headers:['Player','Pos','Class','G','Season Summary'],cells:({p,s})=>[playerButton(p),p.pos,classText(p),s.games,typeof playerStatLine==='function'?playerStatLine(p):'—']}
 }[category];
}
function playerButton(p){return`<button class="link-button" onclick="openPlayerProfile('${p.id}')">${p.name}</button>`}
function cardLine(category,{p,s}){
 const groups={
  PASSING:[['G',s.games],['CMP/ATT',`${s.passComp}/${s.passAtt}`],['YDS',s.passYds],['TD',s.passTD],['INT',s.passINT],['RTG',rating(s)]],
  RUSHING:[['G',s.games],['CAR',s.rushAtt],['YDS',s.rushYds],['AVG',s.rushAtt?(s.rushYds/s.rushAtt).toFixed(1):'0.0'],['TD',s.rushTD]],
  RECEIVING:[['G',s.games],['REC',s.rec],['YDS',s.recYds],['AVG',s.rec?(s.recYds/s.rec).toFixed(1):'0.0'],['TD',s.recTD]],
  DEFENSE:[['G',s.games],['TKL',s.tackles],['TFL',s.tfl],['SACK',s.sacks],['INT',s.defINT],['FF',s.ff]],
  KICKING:[['G',s.games],['FG',`${s.fgm}/${s.fga}`],['XP',`${s.xpm}/${s.xpa}`],['PTS',s.points]],
  PUNTING:[['G',s.games],['PUNTS',s.punts],['YDS',s.puntYds],['AVG',s.punts?(s.puntYds/s.punts).toFixed(1):'0.0'],['LONG',s.puntLong],['IN 20',s.inside20]],
  ALL:[['G',s.games],['OVR',p.ovr],['CLASS',classText(p)]]
 }[category];
 return`<article class="player-stat-card"><div class="player-stat-card-head"><div>${playerButton(p)}<span>${p.pos} · ${classText(p)}</span></div><b>${p.ovr} OVR</b></div><div class="player-stat-card-grid">${groups.map(([label,value])=>`<div><small>${label}</small><strong>${value}</strong></div>`).join('')}</div></article>`;
}
function renderStats131(){
 const table=$('playerStatsTable'),select=$('statsCategory');
 if(!table||!select)return;
 const category=select.value||'PASSING',rows=categoryPlayers(category),def=tableDefinition(category);
 table.innerHTML=`<thead><tr>${def.headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${def.cells(row).map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')}</tbody>`;
 let cards=$('playerStatsCards');
 if(!cards){cards=document.createElement('div');cards.id='playerStatsCards';cards.className='player-stats-cards';table.closest('.table-wrap')?.insertAdjacentElement('afterend',cards)}
 cards.innerHTML=rows.map(row=>cardLine(category,row)).join('')||'<p class="muted">No player statistics have been recorded in this category yet.</p>';
 const totals=rows.reduce((a,{s})=>{for(const k of STAT_FIELDS)a[k]=(a[k]||0)+s[k];return a},{});
 const summary=$('teamStatSummary');
 if(summary){
  const games=Math.max(0,...(state.roster||[]).map(p=>playerStats(p).games));
  const metricFn=typeof metric==='function'?metric:(label,value)=>`<div class="metric"><span>${label}</span><b>${value}</b></div>`;
  const summaries={
   PASSING:[['Passing Yards',totals.passYds],['Completions',totals.passComp],['Attempts',totals.passAtt],['Pass TD',totals.passTD],['Interceptions',totals.passINT],['Games',games]],
   RUSHING:[['Rushing Yards',totals.rushYds],['Carries',totals.rushAtt],['Yards/Carry',totals.rushAtt?(totals.rushYds/totals.rushAtt).toFixed(1):'0.0'],['Rush TD',totals.rushTD],['Players Used',rows.filter(x=>x.s.rushAtt>0).length],['Games',games]],
   RECEIVING:[['Receiving Yards',totals.recYds],['Receptions',totals.rec],['Yards/Rec',totals.rec?(totals.recYds/totals.rec).toFixed(1):'0.0'],['Receiving TD',totals.recTD],['Players Used',rows.filter(x=>x.s.rec>0).length],['Games',games]],
   DEFENSE:[['Tackles',totals.tackles],['Tackles for Loss',totals.tfl],['Sacks',totals.sacks],['Interceptions',totals.defINT],['Forced Fumbles',totals.ff],['Games',games]],
   KICKING:[['Field Goals',`${totals.fgm}/${totals.fga}`],['Extra Points',`${totals.xpm}/${totals.xpa}`],['Kicking Points',totals.points],['FG%',totals.fga?`${Math.round(totals.fgm/totals.fga*100)}%`:'0%'],['Games',games]],
   ALL:[['Passing',`${totals.passYds} yds`],['Rushing',`${totals.rushYds} yds`],['Receiving',`${totals.recYds} yds`],['Tackles',totals.tackles],['Sacks',totals.sacks],['Interceptions',totals.defINT]]
  }[category];
  summary.innerHTML=summaries.map(([l,v])=>metricFn(l,v)).join('');
 }
}
const priorRenderStats=window.renderStats;
window.renderStats=function(...args){try{priorRenderStats?.apply(this,args)}finally{renderStats131()}};
const statsSelect=$('statsCategory');if(statsSelect)statsSelect.onchange=window.renderStats;
const priorRenderAll=window.renderAll;window.renderAll=function(...args){const out=priorRenderAll?.apply(this,args);if(state.school&&!$('statsTab')?.classList.contains('hidden'))renderStats131();return out};

window.SDF_V131_TEST={smartSetDepthPlayer,repairStarterRoles,categoryPlayers,renderStats131};
if(state?.school){ensureDepth();renderStats131()}
})();
(()=>{
'use strict';
const $m=id=>document.getElementById(id);
const cfg=()=>window.SDF_AD_CONFIG||{};
const native=()=>!!(window.Capacitor?.isNativePlatform?.()||window.Capacitor?.getPlatform?.()==='android');
const plugin=()=>window.Capacitor?.Plugins?.AdMob||null;
let initialized=false,canRequestAds=false,busy=false,interstitialPrepared=false;
let rewardListenerInstalled=false,pendingRewardKind=null,rewardGrantedForPending=false;

function ensureState(){
 if(typeof state==='undefined')return;
 state.monetization??={};
 state.monetization.weeklyClaims??={};
 state.monetization.seasonInterstitialYears??=[];
 state.monetization.edition='ADS_READY';
}
function weekKey(kind){return `${state?.year||0}-${state?.week||0}-${kind}`}
function claimed(kind){ensureState();return !!state?.monetization?.weeklyClaims?.[weekKey(kind)]}
function markClaimed(kind){ensureState();state.monetization.weeklyClaims[weekKey(kind)]=Date.now()}
function saveReward(reason){window.renderAll?.();window.SDF_RELEASE_TEST?.saveNow?.(reason,false,true);window.save?.()}
function grantReward(kind,rewardMeta){
 if(!kind||claimed(kind))return false;
 if(kind==='HOURS'){
  const bonus=Number(cfg().rewardRecruitingHours||25);
  const baseCap=Number(state.recruitingHoursCapacity||window.calculateRecruitingHours?.()||state.weeklyHours||0);
  state.weeklyHours=Number(state.weeklyHours||0)+bonus;
  // Recruiting-hour rewards are EXTRA weekly capacity. Without raising the
  // temporary capacity, migrateDynastyCore() clamps the reward away on render.
  state.recruitingHoursCapacity=baseCap+bonus;
  state.news?.push(`A sponsor meeting added ${bonus} recruiting hours for Week ${state.week}.`);
  window.toast?.(`+${bonus} recruiting hours`);
 }else{
  const bonus=Number(cfg().rewardNilAmount||10000);
  state.nilBudget=Number(state.nilBudget||0)+bonus;
  state.news?.push(`A booster spotlight added $${bonus.toLocaleString()} to the recruit NIL pool.`);
  window.toast?.(`+$${bonus.toLocaleString()} recruit NIL`);
 }
 markClaimed(kind);
 rewardGrantedForPending=true;
 saveReward(`Sponsor reward: ${kind}`);
 console.info('Sponsor reward granted',kind,rewardMeta||{});
 return true;
}
async function installRewardListener(){
 const AdMob=plugin();
 if(!AdMob||rewardListenerInstalled||typeof AdMob.addListener!=='function')return;
 await AdMob.addListener('onRewardedVideoAdReward',reward=>{
  if(pendingRewardKind)grantReward(pendingRewardKind,reward);
 });
 rewardListenerInstalled=true;
}
function statusText(){
 if(!native())return 'Ads are available only inside the installed Android app. The browser preview remains ad-free.';
 if(!plugin())return 'AdMob plugin is not available. Run SYNC_ANDROID.bat and rebuild the native Android project.';
 if(!initialized)return 'Initializing sponsor services…';
 if(!canRequestAds)return 'Ads are unavailable until privacy consent is resolved or an ad can be served.';
 return cfg().useTestAds?'Google test ads are active. Test ads do not generate revenue.':'Production ad IDs are active.';
}
function render(){
 const panel=$m('adStatusPanel');if(!panel)return;ensureState();
 const c=cfg(),hoursClaimed=claimed('HOURS'),nilClaimed=claimed('NIL');
 panel.innerHTML=`<div><small>EDITION</small><b>${c.useTestAds?'Safe test mode':'Production ads'}</b></div><div><small>AD STATUS</small><b>${statusText()}</b></div><div><small>THIS WEEK</small><b>${hoursClaimed?'Hours claimed':'Hours available'} · ${nilClaimed?'NIL claimed':'NIL available'}</b></div>`;
 const badge=$m('adEditionBadge');if(badge)badge.textContent=c.useTestAds?'TEST ADS':'ADS ACTIVE';
 const h=$m('rewardHoursAdBtn'),n=$m('rewardNilAdBtn');
 if(h){h.disabled=busy||hoursClaimed||!canRequestAds;h.textContent=hoursClaimed?'Claimed This Week':busy?'Loading…':'Watch Sponsor Video'}
 if(n){n.disabled=busy||nilClaimed||!canRequestAds;n.textContent=nilClaimed?'Claimed This Week':busy?'Loading…':'Watch Sponsor Video'}
 const inlineHours=$m('recruitRewardHoursAdBtn'),inlineNil=$m('recruitRewardNilAdBtn');
 if(inlineHours){
  inlineHours.disabled=busy||hoursClaimed||!canRequestAds;
  inlineHours.innerHTML=hoursClaimed
   ?'<span aria-hidden="true">✓</span><span>Hours Claimed This Week</span>'
   :busy
    ?'<span aria-hidden="true">…</span><span>Loading Ad…</span>'
    :'<span aria-hidden="true">▶</span><span>Watch for +25 Recruiting Hrs</span>';
 }
 if(inlineNil){
  inlineNil.disabled=busy||nilClaimed||!canRequestAds;
  inlineNil.innerHTML=nilClaimed
   ?'<span aria-hidden="true">✓</span><span>NIL Claimed This Week</span>'
   :busy
    ?'<span aria-hidden="true">…</span><span>Loading Ad…</span>'
    :'<span aria-hidden="true">▶</span><span>Watch for +$10K NIL</span>';
 }
 const privacy=$m('adPrivacyOptionsBtn');if(privacy)privacy.disabled=!plugin();
}

function openSponsorCenter(){
 if(!state?.school){window.toast?.('Start or load a dynasty before opening Sponsor Rewards.','error');return}
 window.showTab?.('dynasty');
 setTimeout(()=>{
  if(window.setSubview)window.setSubview('dynastyTab','sponsors');
  else $m('sponsorCenter')?.scrollIntoView({behavior:'smooth',block:'start'});
  $m('mobileMoreMenu')?.classList.add('hidden');
 },40);
}

async function initializeAds(){
 ensureState();render();
 const AdMob=plugin();if(!native()||!AdMob){render();return}
 try{
  await AdMob.initialize({initializeForTesting:!!cfg().useTestAds,tagForChildDirectedTreatment:false,tagForUnderAgeOfConsent:false,maxAdContentRating:'Teen'});
  initialized=true;
  await installRewardListener();
  let info=await AdMob.requestConsentInfo({tagForUnderAgeOfConsent:false});
  if(!info.canRequestAds&&info.isConsentFormAvailable)info=await AdMob.showConsentForm();
  canRequestAds=info.canRequestAds!==false;
  render();
  if(canRequestAds)prepareSeasonInterstitial();
 }catch(err){console.error('AdMob initialization failed',err);initialized=true;canRequestAds=false;render()}
}
async function showReward(kind){
 if(busy||claimed(kind)||!canRequestAds)return;
 const AdMob=plugin();if(!AdMob)return;
 busy=true;pendingRewardKind=kind;rewardGrantedForPending=false;render();
 try{
  await installRewardListener();
  const id=kind==='HOURS'?cfg().rewardedRecruitingId:cfg().rewardedNilId;
  await AdMob.prepareRewardVideoAd({adId:id,isTesting:!!cfg().useTestAds,immersiveMode:false});
  const reward=await AdMob.showRewardVideoAd();
  // The plugin documents both a Rewarded event and a returned AdMobRewardItem.
  // Use either path, with claimed(kind) preventing a double grant.
  if(reward)grantReward(kind,reward);
  if(!rewardGrantedForPending&&!claimed(kind))throw new Error('Reward was not earned.');
 }catch(err){console.error('Rewarded ad failed',err);window.toast?.('The sponsor video was not completed or could not load. No reward was used.','error')}
 finally{pendingRewardKind=null;rewardGrantedForPending=false;busy=false;render()}
}
async function prepareSeasonInterstitial(){
 if(!canRequestAds||!cfg().seasonInterstitialEnabled||interstitialPrepared)return;
 try{await plugin().prepareInterstitial({adId:cfg().seasonInterstitialId,isTesting:!!cfg().useTestAds,immersiveMode:false});interstitialPrepared=true}catch(err){console.warn('Season interstitial preload failed',err)}
}
async function showSeasonInterstitial(){
 ensureState();const y=Number(state?.year||0);
 if(!canRequestAds||!cfg().seasonInterstitialEnabled||state.monetization.seasonInterstitialYears.includes(y))return;
 try{
  if(!interstitialPrepared)await prepareSeasonInterstitial();
  if(!interstitialPrepared)return;
  await plugin().showInterstitial();
  state.monetization.seasonInterstitialYears.push(y);interstitialPrepared=false;saveReward('Season sponsor shown');
  setTimeout(prepareSeasonInterstitial,1200);
 }catch(err){console.warn('Season interstitial unavailable',err);interstitialPrepared=false}
}
async function privacyOptions(){try{await plugin()?.showPrivacyOptionsForm?.()}catch(err){console.warn('Privacy options unavailable',err);window.toast?.('Privacy options are not required or unavailable right now.')}}

const baseRender=window.renderAll;
window.renderAll=function(...args){const out=baseRender?.apply(this,args);render();return out};
const baseFinish=window.finishSeason;
window.finishSeason=function(...args){const out=baseFinish?.apply(this,args);setTimeout(showSeasonInterstitial,700);return out};
window.openSponsorCenter=openSponsorCenter;window.SDF_MONETIZATION={initializeAds,showReward,showSeasonInterstitial,render,openSponsorCenter};

document.addEventListener('DOMContentLoaded',()=>{
 $m('rewardHoursAdBtn')?.addEventListener('click',()=>showReward('HOURS'));
 $m('rewardNilAdBtn')?.addEventListener('click',()=>showReward('NIL'));
 $m('recruitRewardHoursAdBtn')?.addEventListener('click',()=>showReward('HOURS'));
 $m('recruitRewardNilAdBtn')?.addEventListener('click',()=>showReward('NIL'));
 $m('adPrivacyOptionsBtn')?.addEventListener('click',privacyOptions);
 ['openSponsorDashboardBtn','openSponsorRecruitingBtn','openSponsorMobileBtn'].forEach(id=>$m(id)?.addEventListener('click',openSponsorCenter));
 render();setTimeout(initializeAds,350);
});
})();

(()=>{
'use strict';
const $v=id=>document.getElementById(id);
const c=(n,min=40,max=99)=>Math.max(min,Math.min(max,Math.round(Number(n)||0)));
function h(value){let x=2166136261;for(const ch of String(value)){x^=ch.charCodeAt(0);x=Math.imul(x,16777619)}return x>>>0}
function jitter(seed,span=6){return(h(seed)%(span*2+1))-span}
const LABELS={speed:'Speed',acceleration:'Acceleration',strength:'Strength',awareness:'Awareness',throwPower:'Throw Power',accuracy:'Accuracy',mobility:'Mobility',decision:'Decision Making',vision:'Vision',breakTackle:'Break Tackle',carrying:'Carrying',hands:'Hands',routeRunning:'Route Running',release:'Release',passBlock:'Pass Block',runBlock:'Run Block',blocking:'Blocking',passRush:'Pass Rush',powerRush:'Power Rush',runDefense:'Run Defense',blockShedding:'Block Shedding',tackling:'Tackling',pursuit:'Pursuit',coverage:'Coverage',manCoverage:'Man Coverage',zoneCoverage:'Zone Coverage',press:'Press',ballSkills:'Ball Skills',kickPower:'Kick Power',kickAccuracy:'Kick Accuracy',skill:'Technique'};
const KEYS={
 QB:['throwPower','accuracy','mobility','decision','awareness'],RB:['speed','acceleration','vision','breakTackle','carrying'],WR:['speed','acceleration','hands','routeRunning','release'],TE:['hands','routeRunning','blocking','strength','speed'],OT:['passBlock','runBlock','strength','awareness'],IOL:['passBlock','runBlock','strength','awareness'],EDGE:['passRush','runDefense','speed','strength','blockShedding'],DL:['powerRush','runDefense','blockShedding','strength','tackling'],LB:['tackling','pursuit','coverage','speed','blockShedding'],CB:['manCoverage','zoneCoverage','press','speed','ballSkills'],S:['zoneCoverage','tackling','speed','ballSkills','coverage'],K:['kickPower','kickAccuracy','awareness']
};
function buildAttrs(pos,ovr,seed=Math.random()){
 const b=Number(ovr||65),v=k=>c(b+jitter(`${seed}-${pos}-${k}`,9));let a={speed:v('speed'),strength:v('strength'),skill:v('skill'),awareness:v('awareness')};
 const set=(k,offset=0)=>a[k]=c(b+offset+jitter(`${seed}-${k}`,7));
 if(pos==='QB'){set('throwPower',2);set('accuracy');set('mobility',-1);set('decision');}
 else if(pos==='RB'){set('acceleration',2);set('vision');set('breakTackle');set('carrying',1);}
 else if(pos==='WR'){set('acceleration',2);set('hands');set('routeRunning');set('release');}
 else if(pos==='TE'){set('hands');set('routeRunning',-1);set('blocking');}
 else if(['OT','IOL'].includes(pos)){set('passBlock');set('runBlock');}
 else if(pos==='EDGE'){set('passRush',2);set('runDefense');set('blockShedding');}
 else if(pos==='DL'){set('powerRush',2);set('runDefense');set('blockShedding');set('tackling');}
 else if(pos==='LB'){set('tackling',2);set('pursuit');set('coverage',-2);set('blockShedding');}
 else if(pos==='CB'){set('manCoverage',2);set('zoneCoverage');set('press');set('ballSkills');}
 else if(pos==='S'){set('zoneCoverage',2);set('tackling');set('ballSkills');set('coverage');}
 else if(pos==='K'){set('kickPower',3);set('kickAccuracy');}
 return a
}
function ensureAttrs(p){if(!p)return{};const generated=buildAttrs(p.pos,p.trueOvr||p.ovr||65,p.id||p.name||Math.random());p.attrs??={};for(const [k,v] of Object.entries(generated))if(p.attrs[k]==null)p.attrs[k]=v;return p.attrs}
window.attrsFor=(pos,ovr)=>buildAttrs(pos,ovr,`${pos}-${ovr}-${Math.random()}`);
function avg(values){const a=values.filter(Number.isFinite);return a.length?a.reduce((n,v)=>n+v,0)/a.length:65}
function grade(p,keys){const a=ensureAttrs(p);return avg(keys.map(k=>Number(a[k]??p.ovr??65)))}
function best(pos,count=1){return(state.roster||[]).filter(p=>p.pos===pos&&!p.injury&&!p.redshirt).sort((a,b)=>b.ovr-a.ovr).slice(0,count)}
function rolePlayers(keys,pos,count=keys.length){const found=[],seen=new Set();for(const key of keys){const slots=state.realDepthChart?.[key]?.slots||[];for(const slot of slots.slice().sort((a,b)=>Number(b.snapShare||0)-Number(a.snapShare||0))){const p=(state.roster||[]).find(x=>x.id===slot.playerId&&!x.injury&&!x.redshirt);if(p&&(!pos||p.pos===pos)&&!seen.has(p.id)){found.push(p);seen.add(p.id);break}}}for(const p of best(pos,count)){if(!seen.has(p.id)){found.push(p);seen.add(p.id)}if(found.length>=count)break}return found.slice(0,count)}
function opponentGrade(g,unit,offset=0){return c(Number(g?.oppPower||65)+jitter(`${state.year}-${g?.oppId}-${unit}`,7)+offset)}
function matchupReport(g){
 const qb=rolePlayers(['QB1'],'QB',1)[0],rec=[...rolePlayers(['WR1','WR2','SLOT'],'WR',3),...rolePlayers(['TE1'],'TE',1)],rb=rolePlayers(['RB1','RB2'],'RB',2),ol=[...rolePlayers(['LT','RT'],'OT',2),...rolePlayers(['LG','C','RG'],'IOL',3)],front=[...rolePlayers(['LE','RE'],'EDGE',2),...rolePlayers(['DT1','DT2'],'DL',2),...rolePlayers(['MLB','WLB','SLB'],'LB',3)],db=[...rolePlayers(['CB1','CB2','NCB'],'CB',3),...rolePlayers(['FS','SS'],'S',2)];
 const userPass=avg([qb?grade(qb,['accuracy','throwPower','decision']):60,...rec.map(p=>grade(p,['routeRunning','hands','speed','release']))]),oppCoverage=opponentGrade(g,'coverage'),passEdge=userPass-oppCoverage;
 const userRun=avg([...rb.map(p=>grade(p,['vision','breakTackle','acceleration'])),...ol.map(p=>grade(p,['runBlock','strength']))]),oppRunDef=opponentGrade(g,'run-defense'),runEdge=userRun-oppRunDef;
 const userPassDef=avg(db.map(p=>grade(p,['manCoverage','zoneCoverage','speed','ballSkills'])).concat(front.map(p=>grade(p,['passRush','coverage'])))),oppPass=opponentGrade(g,'pass-offense'),passDefEdge=userPassDef-oppPass;
 const userRunDef=avg(front.map(p=>grade(p,['runDefense','tackling','blockShedding','pursuit']))),oppRun=opponentGrade(g,'run-offense'),runDefEdge=userRunDef-oppRun;
 return{userPass,oppCoverage,passEdge,userRun,oppRunDef,runEdge,userPassDef,oppPass,passDefEdge,userRunDef,oppRun,runDefEdge,userPassEff:Math.max(.62,Math.min(1.58,1+passEdge/78)),userRunEff:Math.max(.65,Math.min(1.5,1+runEdge/85)),oppPassEff:Math.max(.65,Math.min(1.45,1-passDefEdge/90)),oppRunEff:Math.max(.68,Math.min(1.42,1-runDefEdge/95)),userExplosiveBonus:Math.max(-8,Math.min(20,passEdge/3)),oppExplosiveBonus:Math.max(-8,Math.min(16,-passDefEdge/4)),userOffEdge:(passEdge+runEdge)/2,userDefEdge:(passDefEdge+runDefEdge)/2}
}
function passMatchup(receiver,defender,mode='balanced'){const rec=grade(receiver,['routeRunning','hands','speed','release']),cov=defender?grade(defender,mode==='zone'?['zoneCoverage','speed','ballSkills']:['manCoverage','press','speed','ballSkills']):65;return{receiver:rec,defender:cov,edge:rec-cov}}
function runMatchup(runner,defender){const run=grade(runner,['vision','breakTackle','acceleration','carrying']),stop=defender?grade(defender,['tackling','pursuit','runDefense','blockShedding']):65;return{runner:run,defender:stop,edge:run-stop}}
function attributeHtml(p){const a=ensureAttrs(p),keys=KEYS[p.pos]||['speed','strength','skill','awareness'];return`<div class="attribute-scout-grid">${keys.map(k=>`<article><small>${LABELS[k]||k}</small><b>${a[k]}</b><span class="attribute-bar"><i style="width:${a[k]}%"></i></span></article>`).join('')}</div>`}
const priorPlayer=window.openPlayerProfile;window.openPlayerProfile=function(id){const out=priorPlayer?.(id),p=(state.roster||[]).find(x=>x.id===id),body=$v('modalBody');if(p&&body&&!body.querySelector('.position-attributes'))body.insertAdjacentHTML('beforeend',`<section class="position-attributes"><span class="eyebrow">POSITION ATTRIBUTES</span><h3>${p.pos} Skill Profile</h3>${attributeHtml(p)}</section>`);return out};
function repairLoadedState(){if(!state?.school)return;window.migrateDynastyCore?.();(state.roster||[]).forEach(ensureAttrs);(state.recruits||[]).filter(r=>r.scouted).forEach(ensureAttrs);window.SDF_V11_TEST?.auditProgramFinances?.()}
const priorRender=window.renderAll;window.renderAll=function(...args){repairLoadedState();return priorRender.apply(this,args)};
repairLoadedState();
window.SDF_V144={buildAttrs,ensureAttrs,attributeHtml,grade,rolePlayers,matchupReport,passMatchup,runMatchup,repairLoadedState};
})();
(()=>{
'use strict';
const $16=id=>document.getElementById(id);const cash=n=>'$'+Math.round(Number(n||0)/1000)+'k';
function makeResult(pair,label,aScore=null,bScore=null){if(aScore==null)return simulateNeutralGame(pair[0],pair[1],label);const a=pair[0],b=pair[1],winner=aScore>bScore?a:b;return{label,a,b,aScore,bScore,winner,loser:winner.id===a.id?b:a}}
function liveResult(pair,label,game){const userFirst=Number(pair[0].id)===Number(state.school.id);return makeResult(pair,label,userFirst?game.score.us:game.score.them,userFirst?game.score.them:game.score.us)}
function setLive(type,label,pair,meta={}){const opp=pair.find(t=>Number(t.id)!==Number(state.school.id));state.liveGameContext={type,label,meta:{...meta,pair},game:{opponent:opp.name,oppId:opp.id,oppPower:opp.rosterPower||Math.round((Number(opp.prestige||70)+Number(opp.recent||70))/2),home:false,conference:false,rivalry:false,weather:'Clear',result:null,score:null}};window.showTab('gameday');setTimeout(()=>window.openLiveGameCenter(),30)}
function showBid(text){state.pendingPostseasonNotice=text;try{document.getElementById('modalBody').innerHTML=`<span class="eyebrow">POSTSEASON BID</span><h2>${text}</h2><p class="muted">This matchup must be played through Game Center. You can watch every snap or use Sim to Final inside the game.</p><button class="btn success full" onclick="document.getElementById('modal').classList.add('hidden');showTab('gameday')">Open Game Day</button>`;document.getElementById('modal').classList.remove('hidden')}catch{}}
function startChampionship(){if(state.phase!=='CHAMP')return;const games=state.postseasonData.conferenceGames||[],user=games.find(x=>[x.a.id,x.b.id].includes(state.school.id));state.postseasonData.conferenceResults=games.filter(x=>x!==user).map(x=>simulateNeutralGame(x.a,x.b,`${x.conference} Championship`));if(!user){state.postseasonData.champions=state.postseasonData.conferenceResults.map(x=>x.winner);prepareBowlsAndPlayoff();return}showBid(`${state.school.conference} Championship: ${state.school.name} vs ${(user.a.id===state.school.id?user.b:user.a).name}`);setLive('CONFERENCE',`${user.conference} Championship`,[user.a,user.b],{conference:user.conference})}
function completeConference(ctx,game){const pair=ctx.meta.pair,result=liveResult(pair,ctx.label,game);state.postseasonData.conferenceResults.push(result);state.postseasonData.champions=state.postseasonData.conferenceResults.map(x=>x.winner);if(result.winner.id===state.school.id){state.achievementStats.conferenceTitles++;state.conferenceChampions.push({year:state.year,conference:state.school.conference});state.trophies.push({year:state.year,type:`${state.school.conference} Champion`})}updateRankings();prepareBowlsAndPlayoff();showBid(state.postseasonData.playoffField?.some(t=>t.id===state.school.id)?`${state.school.name} earned a College Football Playoff bid.`:state.postseasonData.bowls?.some(b=>[b.a.id,b.b.id].includes(state.school.id))?`${state.school.name} earned a bowl bid.`:`${state.school.name}'s season will continue to Awards Week.`)}
function pairsFor(stage,prev=[]){const f=state.postseasonData.playoffField||[];if(stage===0)return[[f[4],f[11]],[f[5],f[10]],[f[6],f[9]],[f[7],f[8]]].filter(x=>x[0]&&x[1]);if(stage===1)return[[f[0],prev[3]],[f[3],prev[0]],[f[1],prev[2]],[f[2],prev[1]]].filter(x=>x[0]&&x[1]);if(stage===2)return[[prev[0],prev[1]],[prev[2],prev[3]]].filter(x=>x[0]&&x[1]);return prev.length>=2?[[prev[0],prev[1]]]:[]}
const roundNames=['CFP First Round','CFP Quarterfinal','CFP Semifinal','National Championship'];
function runPlayoffStage(stage,priorWinners=[]){const pairs=pairsFor(stage,priorWinners),results=[],userIndex=pairs.findIndex(pair=>pair.some(t=>t.id===state.school.id));for(let i=0;i<pairs.length;i++)if(i!==userIndex)results[i]=makeResult(pairs[i],roundNames[stage]);state.postseasonFlow={mode:'PLAYOFF',stage,priorWinners,pairs,results};if(userIndex>=0){const pair=pairs[userIndex];showBid(`${roundNames[stage]}: ${state.school.name} vs ${pair.find(t=>t.id!==state.school.id).name}`);setLive('PLAYOFF',roundNames[stage],pair,{stage,userIndex});return}finishStage(stage,results)}
function finishStage(stage,results){const clean=results.filter(Boolean),winners=results.map(x=>x?.winner).filter(Boolean);state.postseasonData.playoffRounds??=[];state.postseasonData.playoffRounds[stage]={name:roundNames[stage],games:clean};if(stage===3){const title=clean[0];state.postseasonData.nationalChampion=title?.winner;if(title?.winner.id===state.school.id){state.achievementStats.nationalTitles++;state.trophies.push({year:state.year,type:'National Championship'});state.school.prestige=clamp(state.school.prestige+5,25,99)}finishSeason();return}runPlayoffStage(stage+1,winners)}
function completePlayoff(ctx,game){const flow=state.postseasonFlow,idx=ctx.meta.userIndex,result=liveResult(ctx.meta.pair,ctx.label,game);flow.results[idx]=result;if(result.winner.id===state.school.id)state.achievementStats.playoffWins++;finishStage(flow.stage,flow.results)}
function startBowlOrPlayoff(){if(state.phase!=='BOWLS')return;const d=state.postseasonData,f=d.playoffField||[];d.bowlResults=(d.bowls||[]).filter(b=>![b.a.id,b.b.id].includes(state.school.id)).map(b=>simulateNeutralGame(b.a,b.b,b.name));if(f.some(t=>t.id===state.school.id)){if(schoolTier(state.school).key==='REBUILD')state.achievementStats.rebuildPlayoffs++;runPlayoffStage(0,[]);return}const bowl=(d.bowls||[]).find(b=>[b.a.id,b.b.id].includes(state.school.id));if(bowl){showBid(`${bowl.name}: ${state.school.name} vs ${(bowl.a.id===state.school.id?bowl.b:bowl.a).name}`);setLive('BOWL',bowl.name,[bowl.a,bowl.b],{bowlName:bowl.name});return}simulatePlayoffWithoutUser();finishSeason()}
function simulatePlayoffWithoutUser(){let winners=[];for(let stage=0;stage<4;stage++){const pairs=pairsFor(stage,winners),results=pairs.map(p=>makeResult(p,roundNames[stage]));state.postseasonData.playoffRounds??=[];state.postseasonData.playoffRounds[stage]={name:roundNames[stage],games:results};winners=results.map(r=>r.winner)}state.postseasonData.nationalChampion=winners[0]||null}
function completeBowl(ctx,game){const result=liveResult(ctx.meta.pair,ctx.label,game);state.postseasonData.bowlResults.push(result);if(result.winner.id===state.school.id){state.achievementStats.bowlWins++;state.trophies.push({year:state.year,type:ctx.label})}simulatePlayoffWithoutUser();finishSeason()}
function completePostseasonGame(ctx,game){if(!ctx)return;if(ctx.type==='CONFERENCE')completeConference(ctx,game);if(ctx.type==='BOWL')completeBowl(ctx,game);if(ctx.type==='PLAYOFF')completePlayoff(ctx,game)}
function awardValue(p){const s=p.seasonStats||{};return(s.passYds||0)/20+(s.passTD||0)*7-(s.passINT||0)*4+(s.rushYds||0)/12+(s.rushTD||0)*7+(s.recYds||0)/12+(s.recTD||0)*7+(s.tackles||0)+(s.tfl||0)*2+(s.sacks||0)*5+(s.defINT||0)*7+(s.points||0)/3+(s.inside20||0)*2+p.ovr/3}
function allAwards(){const existing=[...(state.awardsWeek?.awards||[])],defs=[['Quarterback Award','QB'],['Running Back Award','RB'],['Receiver Award','WR'],['Tight End Award','TE'],['Offensive Line Award',['OT','IOL']],['Defensive Line Award',['EDGE','DL']],['Linebacker Award','LB'],['Defensive Back Award',['CB','S']],['Kicker Award','K'],['Punter Award','P']];defs.forEach(([title,pos])=>{const positions=Array.isArray(pos)?pos:[pos],p=state.roster.filter(x=>positions.includes(x.pos)).sort((a,b)=>awardValue(b)-awardValue(a))[0];if(p&&!existing.some(x=>x.title===title))existing.push({title,player:p.name,pos:p.pos,detail:playerStatLine(p)})});return existing}
function renderAwards(){const panel=$16('awardsWeekPanel');if(!panel)return;const active=state.phase==='AWARDS';panel.classList.toggle('hidden',!active);if(!active)return;const awards=allAwards(),aa=state.awardsWeek?.allAmericans||[];$16('awardsWeekSummary').innerHTML=metric('Team Awards',awards.length)+metric('All-Americans',aa.length)+metric('Final Record',`${state.record.w}-${state.record.l}`)+metric('Trophies',state.trophies.filter(t=>t.year===state.year).length);$16('awardsWeekGrid').innerHTML=`<div class="award-week-section"><h3>Major Awards</h3><div class="award-week-cards">${awards.map(a=>`<article><span class="eyebrow">${a.title}</span><h3>${a.player}</h3><span>${a.pos||''}</span><small>${a.detail||''}</small></article>`).join('')}</div></div><div class="award-week-section"><h3>All-American Team</h3><div class="award-week-cards">${aa.map(a=>`<article><span class="eyebrow">ALL-AMERICAN</span><h3>${a.player}</h3><span>${a.pos} · ${a.ovr} OVR</span></article>`).join('')||'<p class="muted">No All-American selections this season.</p>'}</div></div>`;window.showTab('postseason')}
window.completeAwardsWeek=()=>{if(state.phase!=='AWARDS')return;state.phase='POST';state.awardsWeek.presented=true;$16('awardsWeekPanel').classList.add('hidden');$16('postseasonPanel').classList.remove('hidden');window.renderAll();window.SDF_RELEASE_TEST?.saveNow?.('Awards week completed',false,true)};
const baseFinish=window.finishSeason;window.finishSeason=function(...args){const out=baseFinish.apply(this,args);state.phase='AWARDS';renderAwards();window.SDF_RELEASE_TEST?.saveNow?.('Awards week opened',false,true);return out};
window.playChampionshipWeek=startChampionship;window.playPostseason=startBowlOrPlayoff;
const priorAdvance=window.advanceWeek;window.advanceWeek=function(...args){if(state.phase==='CHAMP')return startChampionship();if(state.phase==='BOWLS')return startBowlOrPlayoff();if(state.phase==='AWARDS')return renderAwards();return priorAdvance.apply(this,args)};
function renderFinanceNote(){const host=$16('programManagementCards');if(!host||$16('weeklyFinanceNote'))return;host.insertAdjacentHTML('afterend',`<div id="weeklyFinanceNote" class="finance-note"><b>Game-day net contribution</b><span>Home games now add roughly ${cash(state.lastGameRevenue||0)} after operations, security, travel, and stadium expenses. Annual athletics allocations—not weekly gate money—fund most major facility projects.</span></div>`)}
const priorRender=window.renderAll;window.renderAll=function(...args){const out=priorRender.apply(this,args);renderAwards();renderFinanceNote();if(state.phase==='CHAMP')$16('playChampionshipBtn').textContent='Open Conference Championship';if(state.phase==='BOWLS')$16('playPostseasonBtn').textContent='Open Bowl / Playoff Game';return out};
$16('continueAwardsBtn')?.addEventListener('click',window.completeAwardsWeek);$16('playChampionshipBtn').onclick=startChampionship;$16('playPostseasonBtn').onclick=startBowlOrPlayoff;
window.SDF_V16={completePostseasonGame,startChampionship,startBowlOrPlayoff,renderAwards,allAwards};
})();
(()=>{
'use strict';
const V='1.6.5';
const el=id=>document.getElementById(id);
const num=v=>Number(v||0);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Number(state.school?.id);
const confRecord=id=>state.conferenceRecords?.[Number(id)]||state.conferenceRecords?.[String(id)]||{w:0,l:0};
const rankFor=id=>state.rankings?.find(x=>Number(x.id)===Number(id))?.rank||null;
const worldTeam=id=>state.world?.find(x=>Number(x.id)===Number(id));
const validRosterIds=()=>new Set((state.roster||[]).map(p=>p.id));
const saveNow=(reason,manual=false,backup=false)=>window.SDF_RELEASE_TEST?.saveNow?.(reason,manual,backup);

function projectedUpside(r){
 if(!r)return'Unknown';
 if(Number(r.committedTo)===uid()&&state.signingDayResolved)return String(r.truePot||r.pot||'?');
 if(!r.scouted)return'Unknown';
 const pot=num(r.truePot||r.pot||r.ovr),confidence=clamp(num(r.scoutConfidence||55),20,100);
 let grade=pot>=93?'A+':pot>=90?'A':pot>=87?'A-':pot>=84?'B+':pot>=81?'B':pot>=78?'B-':pot>=75?'C+':pot>=72?'C':pot>=69?'C-':pot>=66?'D+':'D';
 if(confidence<65){const broad=grade[0];return broad==='A'?'A–B':broad==='B'?'B–C':broad==='C'?'C–D':'D–F'}
 if(confidence<90)return `${grade[0]} range`;
 return grade;
}
window.projectedRecruitUpside=projectedUpside;

function cleanRosterReferences(){
 if(!state.school)return;
 const ids=validRosterIds();
 state.captains=(state.captains||[]).filter(id=>ids.has(id)).slice(0,4);
 if(state.depthChart)for(const chart of Object.values(state.depthChart)){if(!chart?.slots)continue;chart.slots.forEach(s=>{if(s.playerId&&!ids.has(s.playerId))s.playerId=''})}
 if(state.realDepthChart)for(const chart of Object.values(state.realDepthChart)){if(!chart?.slots)continue;chart.slots.forEach(s=>{if(s.playerId&&!ids.has(s.playerId))s.playerId=''})}
 for(const key of Object.keys(state.playerEligibility||{}))if(!ids.has(key))delete state.playerEligibility[key];
 state.jobSecurity=clamp(Math.round(num(state.jobSecurity)),0,100);
 state.fanApproval=clamp(Math.round(num(state.fanApproval)),0,100);
 state.boosterSupport=clamp(Math.round(num(state.boosterSupport)),0,100);
}

function releaseLostScholarships(){
 if(!state.school)return 0;
 let released=0;
 for(const r of state.recruits||[]){
  if(!r.offered||!r.committedTo||Number(r.committedTo)===uid()||r._userOfferReleased)continue;
  r._userOfferReleased=true;r.offered=false;r.weeklyPlan='NONE';released++;
  if(r.visitScheduledWeek){delete state.recruitVisitCalendar?.[`${state.year}-${r.visitScheduledWeek}-${r.id}`];r.visitScheduledWeek=null}
  const nil=num(state.nilCommitments?.[r.id]);if(nil){state.nilBudget=num(state.nilBudget)+nil;delete state.nilCommitments[r.id]}
  state.news?.push(`Scholarship slot recovered after ${r.name} committed to ${schoolName(r.committedTo)}.`);
 }
 if(released)state.scholarships=clamp(num(state.scholarships)+released,0,35);
 return released;
}

function ensureRepairState(){
 if(!state.school)return;
 state.conferenceRecords??={};state.headToHeadResults??=[];state.programHistory??={};state.coachCareer??={name:'Coach',careerWins:0,careerLosses:0,jobs:[]};state.coachCareer.jobs??=[];state.coachCareer.schoolStints??=[];state.conferenceMoveHistory??=[];
 const baseSchool=schools.find(s=>Number(s.id)===uid());if(baseSchool&&state.school.conference)baseSchool.conference=state.school.conference;
 for(const t of state.world||[])state.conferenceRecords[t.id]??={w:0,l:0};
 state.conferenceRecords[uid()]??={w:0,l:0};
 cleanRosterReferences();releaseLostScholarships();
}

// Better AI schedule results: every simulated game updates both teams and conference records.
function simulateWorldWeek163(){
 ensureRepairState();
 const userOpponent=(state.schedule||[]).find(g=>Number(g.week)===Number(state.week))?.oppId;
 const teams=(state.world||[]).filter(t=>Number(t.id)!==uid()&&Number(t.id)!==Number(userOpponent));
 const seed=(state.year*97+state.week*31)%997;
 const ordered=teams.slice().sort((a,b)=>((Number(a.id)*37+seed)%1009)-((Number(b.id)*37+seed)%1009));
 const used=new Set();
 for(const a of ordered){
  if(used.has(a.id))continue;
  let pool=ordered.filter(b=>!used.has(b.id)&&b.id!==a.id);
  const same=pool.filter(b=>b.conference===a.conference);
  const preferConference=state.week>=3&&state.week<=10;
  const b=(preferConference&&same.length?same:pool)[0];if(!b)continue;
  used.add(a.id);used.add(b.id);
  const edge=num(a.rosterPower)-num(b.rosterPower)+(Math.random()*25-12.5),winner=edge>=0?a:b,loser=winner===a?b:a;
  winner.record??={w:0,l:0};loser.record??={w:0,l:0};winner.record.w++;loser.record.l++;
  if(a.conference===b.conference){state.conferenceRecords[a.id]??={w:0,l:0};state.conferenceRecords[b.id]??={w:0,l:0};state.conferenceRecords[winner.id].w++;state.conferenceRecords[loser.id].l++}
  state.headToHeadResults.push({year:state.year,week:state.week,winner:winner.id,loser:loser.id,conference:a.conference===b.conference});
  winner.recent=clamp(num(winner.recent)+.35,20,99);loser.recent=clamp(num(loser.recent)-.25,20,99);
 }
 state.headToHeadResults=state.headToHeadResults.slice(-700);window.updateRankings?.();
};

window.updateRankings=function(){
 if(!state.school)return;
 ensureRepairState();
 const user={id:uid(),name:state.school.name,conference:state.school.conference,prestige:state.school.prestige,recent:state.school.recent,record:{...state.record},rosterPower:teamRatings().overall};
 const all=(state.world||[]).filter(t=>Number(t.id)!==uid()).concat(user),old=Object.fromEntries((state.rankings||[]).map(t=>[t.id,t.rank]));
 const userResults=(state.schedule||[]).filter(g=>g.result).map(g=>({winner:g.result==='W'?uid():g.oppId,loser:g.result==='W'?g.oppId:uid()}));
 const h2h=[...(state.headToHeadResults||[]),...userResults];
 const rows=all.map(t=>{const cr=confRecord(t.id),games=num(t.record?.w)+num(t.record?.l),winPct=games?num(t.record.w)/games:0,confGames=cr.w+cr.l,confPct=confGames?cr.w/confGames:0,quality=(t.record?.w||0)*2.2+(t.rosterPower||70)*.35+(t.prestige||60)*.13+(t.recent||60)*.14;return{...t,conferenceRecord:{...cr},score:(t.record.w*20-t.record.l*10)+winPct*18+confPct*7+quality}});
 rows.sort((a,b)=>{const direct=h2h.slice().reverse().find(x=>(Number(x.winner)===Number(a.id)&&Number(x.loser)===Number(b.id))||(Number(x.winner)===Number(b.id)&&Number(x.loser)===Number(a.id))),similarRecord=Math.abs(num(a.record?.w)-num(b.record?.w))<=2&&Math.abs(num(a.record?.l)-num(b.record?.l))<=1;if(direct&&(similarRecord||Math.abs(a.score-b.score)<34))return Number(direct.winner)===Number(a.id)?-1:1;return b.score-a.score||b.record.w-a.record.w||a.record.l-b.record.l});
 state.rankings=rows.map((t,i)=>({...t,rank:i+1}));state.playoff=state.rankings.slice(0,12);state.rankingMovement=state.rankings.slice(0,25).map(t=>({id:t.id,name:t.name,from:old[t.id]||null,to:t.rank,change:old[t.id]?old[t.id]-t.rank:0}));
};

function recordUserOpponentResult(){
 const g=(state.schedule||[]).find(x=>x.week===state.week-1&&x.result);if(!g||g._worldRecorded)return;g._worldRecorded=true;
 const opp=worldTeam(g.oppId);if(opp){opp.record??={w:0,l:0};g.result==='W'?opp.record.l++:opp.record.w++}
 state.headToHeadResults??=[];state.headToHeadResults.push({year:state.year,week:g.week,winner:g.result==='W'?uid():g.oppId,loser:g.result==='W'?g.oppId:uid(),conference:!!g.conference});
 if(g.conference){state.conferenceRecords[g.oppId]??={w:0,l:0};g.result==='W'?state.conferenceRecords[g.oppId].l++:state.conferenceRecords[g.oppId].w++}
}

// Capture every draft-eligible upperclassman before offseason progression removes seniors.
// Seniors are always eligible; juniors may choose early entry when their draft grade is strong enough.
function beforeOffseason163(){
 const roster=(state.roster||[]),year=Number(state.year),allAmericanNames=(state.allAmericans||[]).filter(x=>Number(x.year)===year).map(x=>x.player),awardNames=(state.awardsWeek?.awards||[]).map(x=>x.player);
 state.draftContext={year,schoolId:uid(),schoolName:state.school?.name||'Program',pro:num(state.school?.pro),wins:num(state.record?.w),losses:num(state.record?.l),allAmericanNames,awardNames};
 state.draftEligibleClass=roster.filter(p=>num(p.year)>=3&&!p.redshirt).map(p=>JSON.parse(JSON.stringify(p)));
 state.departingClass=roster.filter(p=>num(p.year)>=4&&!p.redshirt).map(p=>JSON.parse(JSON.stringify(p)));
}
function afterOffseason163(out){
 cleanRosterReferences();state.realDepthChart={};window.SDF_V11_TEST?.ensureRealDepth?.();return out;
}
function fallbackDraftEvaluation163(p,ctx){
 const s=p.seasonStats||p.stats||{},production=num(s.passYds||s.rushYds||s.recYds||s.yards)/700+num(s.passTD||s.rushTD||s.recTD||s.td)*.2+num(s.sacks)*.6+num(s.defINT||s.int)*.8,team=ctx.losses===0&&ctx.wins>=12?3:ctx.wins>=10?2:ctx.wins>=8?1:0,score=num(p.ovr)+Math.min(8,production)+team+clamp((num(ctx.pro)-50)*.06,-1.5,3)+rand(-4,4);let round=null;if(score>=104)round=1;else if(score>=100)round=2;else if(score>=96)round=3;else if(score>=92)round=4;else if(score>=88)round=5;else if(score>=84)round=6;else if(score>=81)round=7;return{score,round,pick:null}
}
function renderDraftResults163(result){
 const host=el('offseasonResults');if(!host)return;
 const early=result.earlyEntrants||[],drafted=result.drafted||[];
 host.innerHTML=`<h3>Pro Draft & Departures</h3><p class="muted">${result.seniors} senior${result.seniors===1?'':'s'} completed their college career. ${early.length?`${early.length} junior${early.length===1?'':'s'} declared early for the pro draft.`:'No juniors declared early.'}</p><div class="draft-grid">${drafted.map(d=>`<div class="draft-card"><h4>${esc(d.player)}</h4><span>Round ${d.round}, Pick ${d.pick}</span><span class="sub">${d.pos} · ${d.earlyEntry?'JR Early Entry':'SR'} · OVR ${d.ovr}</span></div>`).join('')||'<p class="muted">No players were drafted.</p>'}</div>${early.filter(e=>!drafted.some(d=>d.playerId===e.playerId)).length?`<p class="muted">Undrafted early entrants: ${early.filter(e=>!drafted.some(d=>d.playerId===e.playerId)).map(e=>esc(e.player)).join(', ')}.</p>`:''}`;
}
window.runDraft=function(){
 const ctx=state.draftContext||{year:state.year,schoolId:uid(),schoolName:state.school?.name||'Program',pro:num(state.school?.pro),wins:num(state.record?.w),losses:num(state.record?.l),allAmericanNames:[],awardNames:[]};
 if(state.currentDraftResults&&Number(state.currentDraftResults.year)===Number(ctx.year)&&Number(state.currentDraftResults.schoolId)===Number(ctx.schoolId)&&state.offseasonTasks?.draft){renderDraftResults163(state.currentDraftResults);return}
 if(Number(state.nationalDraftBoardYear)!==Number(ctx.year))window.SDF_AI_ROSTERS?.buildNationalDraftBoard?.(ctx.year);
 const candidates=(state.draftEligibleClass||state.departingClass||[]).filter(p=>num(p.year)>=3),candidateById=new Map(candidates.map(p=>[String(p.id),p]));
 let drafted=(state.nationalDraftClass||[]).filter(d=>Number(d.year)===Number(ctx.year)&&Number(d.schoolId)===Number(ctx.schoolId)).map(d=>({playerId:d.playerId,player:d.player,pos:d.pos,round:num(d.round),pick:num(d.pick),overallPick:num(d.overallPick),year:num(d.year),schoolId:num(d.schoolId),school:d.school||ctx.schoolName,ovr:num(d.ovr),classYear:num(d.classYear),earlyEntry:!!d.earlyEntry,score:num(d.score)}));
 let earlyEntrants=(state.nationalDraftEarlyEntries||[]).filter(d=>Number(d.year)===Number(ctx.year)&&Number(d.schoolId)===Number(ctx.schoolId)).map(d=>({playerId:d.playerId,player:d.player,pos:d.pos,ovr:num(d.ovr),score:num(d.score)}));
 // Emergency compatibility for a save that reaches the draft before a national board exists.
 if(!drafted.length&&!earlyEntrants.length&&candidates.length){const rules=window.SDF_AI_ROSTERS?.draftRules||{rounds:7,picksPerRound:32,firstRoundSchoolCap:6,totalSchoolCap:15},occupied=new Set((state.nationalDraftClass||[]).filter(d=>Number(d.year)===Number(ctx.year)).map(d=>`${d.round}-${d.pick}`)),schoolRoundOne=(state.nationalDraftClass||[]).filter(d=>Number(d.year)===Number(ctx.year)&&Number(d.schoolId)===Number(ctx.schoolId)&&Number(d.round)===1).length,schoolTotal=(state.nationalDraftClass||[]).filter(d=>Number(d.year)===Number(ctx.year)&&Number(d.schoolId)===Number(ctx.schoolId)).length;let r1=schoolRoundOne,total=schoolTotal;const graded=[];for(const p of candidates){const evaluation=window.SDF_AI_ROSTERS?.evaluateDraftProspect?.(p,ctx)||fallbackDraftEvaluation163(p,ctx),senior=num(p.year)>=4,junior=num(p.year)===3,early=junior&&!!window.SDF_AI_ROSTERS?.juniorDeclares?.(p,evaluation,ctx);if(!senior&&!early)continue;if(early)earlyEntrants.push({playerId:p.id,player:p.name,pos:p.pos,ovr:num(p.ovr),score:num(evaluation.score)});if(evaluation.round)graded.push({p,evaluation,early})}graded.sort((a,b)=>b.evaluation.score-a.evaluation.score);for(const g of graded){if(total>=num(rules.totalSchoolCap,15))break;for(let round=num(g.evaluation.round);round<=num(rules.rounds,7);round++){if(round===1&&r1>=num(rules.firstRoundSchoolCap,6))continue;let pick=1;while(pick<=num(rules.picksPerRound,32)&&occupied.has(`${round}-${pick}`))pick++;if(pick>num(rules.picksPerRound,32))continue;occupied.add(`${round}-${pick}`);if(round===1)r1++;total++;drafted.push({playerId:g.p.id,player:g.p.name,pos:g.p.pos,round,pick,overallPick:(round-1)*num(rules.picksPerRound,32)+pick,year:ctx.year,schoolId:ctx.schoolId,school:ctx.schoolName,ovr:num(g.p.ovr),classYear:num(g.p.year),earlyEntry:g.early,score:Math.round(num(g.evaluation.score)*10)/10});break}}}
 const removeJuniorIds=earlyEntrants.map(e=>e.playerId).filter(id=>candidateById.has(String(id)));if(removeJuniorIds.length)window.SDF_AI_ROSTERS?.removePlayersFromProgram?.(ctx.schoolId,removeJuniorIds);
 drafted.sort((a,b)=>a.round-b.round||a.pick-b.pick);state.draftHistory??=[];state.draftHistory=state.draftHistory.filter(d=>!(Number(d.year)===Number(ctx.year)&&Number(d.schoolId||ctx.schoolId)===Number(ctx.schoolId)));state.draftHistory.push(...drafted);
 state.achievementStats.totalDrafted+=drafted.length;state.achievementStats.firstRounders+=drafted.filter(d=>d.round===1).length;
 const firstRounders=drafted.filter(d=>d.round===1).length,boost=Math.min(4,drafted.length*.35+firstRounders*.2),newPro=clamp(num(ctx.pro)+boost,20,99),wt=worldTeam(ctx.schoolId),baseSchool=schools.find(s=>Number(s.id)===Number(ctx.schoolId));if(Number(ctx.schoolId)===uid())state.school.pro=newPro;if(wt)wt.pro=newPro;if(baseSchool)baseSchool.pro=newPro;
 state.offseasonTasks.draft=true;state.currentDraftResults={year:ctx.year,schoolId:ctx.schoolId,school:ctx.schoolName,seniors:(state.departingClass||[]).length,earlyEntrants,drafted};renderDraftResults163(state.currentDraftResults);
 if(Number(ctx.schoolId)===uid()){cleanRosterReferences();state.realDepthChart={};window.SDF_V11_TEST?.ensureRealDepth?.()}
 window.renderAll?.();saveNow('Draft and graduation processed',false,true);
};

// Manual snap distribution: edits stay in a draft until the user explicitly
// saves an exact 100% distribution. Nothing else moves while typing.
const snapDrafts={};
function roleRating163(role){const slots=state.realDepthChart?.[role.key]?.slots||[],shares=snapDrafts[role.key]||slots.map(s=>num(s.snapShare));let weighted=0,total=0;for(let i=0;i<slots.length;i++){const p=state.roster.find(x=>x.id===slots[i].playerId);if(p&&!p.injury&&!p.redshirt){weighted+=num(p.ovr)*num(shares[i]);total+=num(shares[i])}}return total?Math.round(weighted/total):45}
function snapValues(role){const slots=state.realDepthChart?.[role]?.slots||[];return(snapDrafts[role]||slots.map(s=>num(s.snapShare))).slice()}
function ensureSnapDraft(role){if(!snapDrafts[role])snapDrafts[role]=snapValues(role);return snapDrafts[role]}
window.setRealDepthPlayer=function(role,index,id){window.SDF_V11_TEST?.ensureRealDepth?.();const defs=window.SDF_V11_TEST?.ROLE_DEFS||[],def=defs.find(r=>r.key===role),slots=state.realDepthChart?.[role]?.slots;if(!def||!slots?.[index])return;if(id){defs.filter(r=>r.pos===def.pos).forEach(r=>(state.realDepthChart?.[r.key]?.slots||[]).forEach((slot,i)=>{if(!(r.key===role&&i===index)&&slot.playerId===id)slot.playerId=''}))}slots[index].playerId=id;window.SDF_V11_TEST?.ensureRealDepth?.();window.renderDepthManager?.();saveNow('Depth chart updated')};
window.setRealSnapShare=function(role,index,value){window.SDF_V11_TEST?.ensureRealDepth?.();const draft=ensureSnapDraft(role);if(index<0||index>=draft.length)return;draft[index]=clamp(Math.round(num(value)),0,100);window.renderDepthManager?.()};
window.adjustRealSnapShare=function(role,index,delta){const draft=ensureSnapDraft(role);if(index<0||index>=draft.length)return;draft[index]=clamp(num(draft[index])+num(delta),0,100);window.renderDepthManager?.()};
window.autoBalanceRole=function(role){const slots=state.realDepthChart?.[role]?.slots||[],draft=ensureSnapDraft(role),active=slots.map((s,i)=>({s,i})).filter(x=>x.s.playerId);draft.fill(0);active.forEach((x,i)=>draft[x.i]=i===0?70:i===1?25:5);window.renderDepthManager?.()};
window.cancelRoleDistribution=function(role){delete snapDrafts[role];window.renderDepthManager?.()};
window.saveRoleDistribution=function(role){const slots=state.realDepthChart?.[role]?.slots||[],shares=snapValues(role),total=shares.reduce((n,v)=>n+num(v),0),ids=slots.map(s=>s.playerId).filter(Boolean);if(total!==100){alert(`Snap shares must total exactly 100%. Current total: ${total}%.`);return}if(new Set(ids).size!==ids.length){alert('The same player cannot fill more than one role in this position group.');return}slots.forEach((s,i)=>s.snapShare=num(shares[i]));delete snapDrafts[role];saveNow('Snap distribution saved',true,false);window.renderDepthManager?.()};
window.renderDepthManager=function(){
 const host=el('depthChartManager');if(!host)return;window.SDF_V11_TEST?.ensureRealDepth?.();const defs=window.SDF_V11_TEST?.ROLE_DEFS||[];
 host.innerHTML=['Offense','Defense','Special Teams'].map(side=>`<section class="depth-side"><h3>${side}</h3><div class="real-depth-grid">${defs.filter(r=>r.side===side).map(role=>{const players=state.roster.filter(p=>p.pos===role.pos&&!p.redshirt).sort((a,b)=>(a.injury?1:0)-(b.injury?1:0)||b.ovr-a.ovr),slots=state.realDepthChart[role.key].slots,shares=snapValues(role.key),total=shares.reduce((n,v)=>n+num(v),0),dupe=slots.map(s=>s.playerId).filter(Boolean).some((id,i,a)=>a.indexOf(id)!==i),dirty=!!snapDrafts[role.key];return`<article class="real-depth-role"><div class="depth-position-head"><h4>${role.label}</h4><b>${roleRating163(role)} Room OVR</b></div>${slots.map((s,i)=>`<div class="role-slot"><label>${i===0?'Starter':i===1?'Rotation':'Reserve'}<select onchange="setRealDepthPlayer('${role.key}',${i},this.value)"><option value="">Unassigned</option>${players.map(p=>`<option value="${p.id}" ${p.id===s.playerId?'selected':''} ${p.injury&&p.id!==s.playerId?'disabled':''}>${esc(p.name)} · ${classLabel(p)} · ${p.ovr}${p.injury?' · OUT':''}</option>`).join('')}</select></label><label>Snap share<div class="snap-stepper"><button type="button" class="btn small neutral" onclick="adjustRealSnapShare('${role.key}',${i},-5)">−5</button><input type="number" min="0" max="100" value="${num(shares[i])}" onchange="setRealSnapShare('${role.key}',${i},this.value)"><button type="button" class="btn small neutral" onclick="adjustRealSnapShare('${role.key}',${i},5)">+5</button></div></label></div>`).join('')}<div class="snap-total ${total===100&&!dupe?'valid':'invalid'}"><b>${total}/100%</b><span>${dupe?'A player is assigned twice.':total===100?(dirty?'Ready to save.':'Current saved distribution.'):'Adjust manually until the total equals 100%.'}</span></div><div class="actions"><button class="btn neutral small" onclick="autoBalanceRole('${role.key}')">Auto Balance</button>${dirty?`<button class="btn neutral small" onclick="cancelRoleDistribution('${role.key}')">Cancel Changes</button>`:''}<button class="btn primary small" onclick="saveRoleDistribution('${role.key}')" ${total!==100||dupe||!dirty?'disabled':''}>Save Distribution</button></div></article>`}).join('')}</div></section>`).join('');
};

// Clear duplicate/broken visit controls and keep one working schedule button.
function repairRecruitModal(){
 const body=el('modalBody');if(!body)return;const buttons=[...body.querySelectorAll('button')].filter(b=>/Official Visit|Choose Official Visit|Schedule Official Visit/.test(b.textContent));if(buttons.length>1)buttons.slice(0,-1).forEach(b=>b.remove());
 body.querySelectorAll('.recruit-profile-section').forEach(section=>{if(!section.textContent.trim()&&!section.children.length)section.remove()});
 const card=body.closest('.modal-card');if(card)card.style.paddingBottom='calc(110px + env(safe-area-inset-bottom))';
}
function afterRecruitOpen163(){setTimeout(repairRecruitModal,0)}

// Development screen now labels OVR/POT and explains the selected focus.
const focusText={Strength:'Raises strength and physical matchup ratings.',Speed:'Raises speed and athleticism.',Awareness:'Raises recognition and consistency.',Technique:'Raises position-specific skill ratings.',Leadership:'Improves morale and captain suitability.',PositionChange:'Moves the player to a related position with a possible OVR adjustment.'};
window.openDevelopmentPreview=function(id){const p=state.roster.find(x=>x.id===id);if(!p)return;p.attrs??=attrsFor(p.pos,p.ovr);const label=k=>String(k).replace(/([a-z])([A-Z])/g,'$1 $2').replace(/^./,c=>c.toUpperCase()),ranked=Object.entries(p.attrs||{}).filter(([,v])=>Number.isFinite(Number(v))).sort((a,b)=>Number(b[1])-Number(a[1])),strengths=ranked.slice(0,2),needs=ranked.slice(-2).reverse(),traitList=list=>list.length?list.map(([k,v])=>`<div class="event-card"><b>${esc(label(k))}</b><span class="sub">${Math.round(num(v))} rating</span></div>`).join(''):'<p class="muted">No attribute data available.</p>';el('modalBody').innerHTML=`<span class="eyebrow">PLAYER DEVELOPMENT PREVIEW</span><h2>${esc(p.name)}</h2><p>${p.pos} · ${p.arch} · ${classLabel(p)}</p><div class="metric-grid">${metric('OVR',p.ovr)}${metric('Potential',p.pot)}${metric('Development',p.dev)}${metric('Morale',p.morale)}${metric('Speed',p.attrs.speed)}${metric('Strength',p.attrs.strength)}${metric('Skill',p.attrs.skill)}${metric('Awareness',p.attrs.awareness)}</div><div class="two-col"><section><h3>Strengths</h3>${traitList(strengths)}</section><section><h3>Needs Work</h3>${traitList(needs)}</section></div><h3>Focus Effects</h3>${Object.entries(focusText).map(([k,v])=>`<div class="event-card"><b>${k==='PositionChange'?'Position Change':k}</b><span class="sub">${v}</span></div>`).join('')}`;el('modal').classList.remove('hidden')};
window.runPlayerProgression=function(){const top=state.roster.slice().sort((a,b)=>(b.pot-b.ovr)-(a.pot-a.ovr)).slice(0,18);el('modalBody').innerHTML=`<span class="eyebrow">PLAYER DEVELOPMENT</span><h2>Assign Individual Focus</h2><p class="muted"><b>OVR</b> is current ability. <b>Potential</b> is the player’s ceiling. Focuses improve specific attributes and do not replace normal offseason progression.</p>${top.map(p=>`<div class="event-card development-player-card"><div><b>${esc(p.name)} · ${p.pos}</b><span class="sub">OVR ${p.ovr} · Potential ${p.pot} · ${p.dev} development</span></div><button class="btn neutral small" onclick="openDevelopmentPreview('${p.id}')">Player Preview</button><select onchange="applyPlayerFocus('${p.id}',this.value)"><option value="">Choose focus</option>${Object.keys(focusText).map(f=>`<option value="${f==='PositionChange'?'Position Change':f}">${f==='PositionChange'?'Position Change':f} — ${focusText[f]}</option>`).join('')}</select></div>`).join('')}<button class="btn success full" onclick="finishProgression()">Finish Development</button>`;el('modal').classList.remove('hidden')};

// Coach identity and career follow the coach, while program history follows each school.
// Coach identity now comes from the Create Your Coach popup on the team screen.
function beforeStart163(){const pending=window.SDF_NEW_DYNASTY_PENDING;return{name:(pending?.coachName||state.coachCareer?.name||'Coach').trim()||'Coach'}}
function afterStart163(context,result){
 if(!state.school)return result;const name=context?.name||'Coach';state.coachCareer.name=name;state.staff?.head&&(state.staff.head.name=name);state.coachCareer.currentSchoolId=state.school.id;state.coachCareer.currentSchool=state.school.name;state.coachCareer.currentStintStart=state.year;ensureRepairState();captureProgramBaseline();saveNow('Coach career created',false,true);return result
}
function beforeAcceptJob163(){if(!state.school)return null;return{id:state.school.id,name:state.school.name,conference:state.school.conference,start:state.coachCareer.currentStintStart||1,end:state.year,record:`${state.coachCareer.careerWins}-${state.coachCareer.careerLosses}`}}
function afterAcceptJob163(old,result){if(old&&state.school&&Number(state.school.id)!==Number(old.id)){state.coachCareer.schoolStints??=[];state.coachCareer.schoolStints.push(old);state.coachCareer.currentSchoolId=state.school.id;state.coachCareer.currentSchool=state.school.name;state.coachCareer.currentStintStart=state.year;captureProgramBaseline();return{result,changed:true}}return{result,changed:false}}

function captureProgramBaseline(){if(!state.school)return;state.programHistory??={};const key=String(state.school.id);state.programHistory[key]??=[];if(!state.programHistory[key].length)state.programHistory[key].push({year:state.year-1,school:state.school.name,conference:state.school.conference,wins:0,losses:0,conferenceWins:0,conferenceLosses:0,rank:null,prestige:num(state.school.prestige),recent:num(state.school.recent),overall:teamRatings().overall,baseline:true})}
function captureSeasonTrend(){
 if(!state.school)return;captureProgramBaseline();const key=String(state.school.id),cr=confRecord(uid()),rank=rankFor(uid());const row={year:state.year,schoolId:state.school.id,school:state.school.name,conference:state.school.conference,wins:num(state.record.w),losses:num(state.record.l),conferenceWins:cr.w,conferenceLosses:cr.l,rank,prestige:Math.round(num(state.school.prestige)),recent:Math.round(num(state.school.recent)),overall:teamRatings().overall,postseason:state.history?.at(-1)?.post||'None'};
 const arr=state.programHistory[key];if(!arr.some(x=>x.year===row.year&&!x.baseline))arr.push(row);const h=state.history?.find(x=>x.year===state.year);if(h)Object.assign(h,row);
 state.coachCareer.seasonHistory??=[];if(!state.coachCareer.seasonHistory.some(x=>x.year===row.year&&x.schoolId===row.schoolId))state.coachCareer.seasonHistory.push({...row});
 evaluateConferenceInvite();
}
function afterFinishSeason163(out){captureSeasonTrend();saveNow('Season history captured',false,true);return out}

const tierMap={'Southeastern':4,'Great North':4,'Atlantic':4,'Heartland':4,'Western':4,'Metro':3,'Mountain':3,'Southern Coast':2,'Great Lakes':2,'National':2,'Independents':1};
function evaluateConferenceInvite(){
 if(state.pendingConferenceInvite||!state.school)return;const current=tierMap[state.school.conference]||1,history=(state.programHistory?.[String(uid())]||[]).filter(x=>!x.baseline).slice(-3);if(history.length<2)return;const sustained=history.slice(-2).every(x=>x.wins>=9),elite=history.some(x=>x.rank&&x.rank<=12)||history.some(x=>x.wins>=11);if(!sustained||!elite)return;
 const activity=Math.max(.5,Math.min(1.5,num(state.realismSettings?.realignment,1))),inviteChance=Math.max(.25,Math.min(.98,.72*activity));if(Math.random()>inviteChance)return;
 const candidates=Object.keys(tierMap).filter(c=>tierMap[c]===Math.min(4,current+1));if(!candidates.length)return;const target=candidates.sort((a,b)=>{const ar=(schools.filter(s=>s.conference===a&&s.region===state.school.region).length?1:0),br=(schools.filter(s=>s.conference===b&&s.region===state.school.region).length?1:0);return br-ar})[0];
 state.pendingConferenceInvite={conference:target,offeredYear:state.year,reason:`Back-to-back ${history.at(-2).wins}- and ${history.at(-1).wins}-win seasons`};state.news.push(`${target} invited ${state.school.name} to join after sustained success.`);
}
window.acceptConferenceInvite=function(){const offer=state.pendingConferenceInvite;if(!offer)return;const from=state.school.conference;state.school.conference=offer.conference;const baseSchool=schools.find(s=>Number(s.id)===uid());if(baseSchool)baseSchool.conference=offer.conference;const wt=worldTeam(uid());if(wt)wt.conference=offer.conference;state.conferenceMoveHistory.push({year:state.year,from:from,to:offer.conference});state.news.push(`${state.school.name} accepted an invitation from ${offer.conference}.`);state.pendingConferenceInvite=null;window.renderAll();saveNow('Conference invitation accepted',true,true)};
window.declineConferenceInvite=function(){if(!state.pendingConferenceInvite)return;state.news.push(`${state.school.name} declined the ${state.pendingConferenceInvite.conference} invitation.`);state.pendingConferenceInvite=null;window.renderAll();saveNow('Conference invitation declined')};

function renderCareerAndTrends(){
 if(!state.school)return;
 const coach=el('coachCareerPanel');if(coach){const stints=state.coachCareer.schoolStints||[],offer=state.pendingConferenceInvite;coach.innerHTML=`<div class="metric-grid">${metric('Coach',state.coachCareer.name||'Coach')}${metric('Current School',state.school.name)}${metric('Career Record',`${state.coachCareer.careerWins}-${state.coachCareer.careerLosses}`)}${metric('Reputation',Math.round(num(state.coachCareer.reputation)))}${metric('Salary','$'+Math.round(num(state.coachCareer.salary)/100000)/10+'M')}${metric('Contract',num(state.coachCareer.contractYears)+' years')}${metric('Schools Coached',stints.length+1)}${metric('National Titles',state.achievementStats.nationalTitles)}</div><p class="muted">The dynasty follows <b>${esc(state.coachCareer.name||'your coach')}</b>. Accepting a job moves the coach to a new school; each program keeps its own history and conference membership.</p>${stints.length?`<h3>Coaching Stops</h3>${stints.map(s=>`<div class="event-card"><b>${esc(s.name)}</b><span class="sub">Years ${s.start}–${s.end} · ${esc(s.conference)}</span></div>`).join('')}`:''}${offer?`<div class="viz-callout"><b>${esc(offer.conference)} Conference Invitation</b><span>${esc(offer.reason)}</span><div class="actions"><button class="btn success" onclick="acceptConferenceInvite()">Accept Invitation</button><button class="btn neutral" onclick="declineConferenceInvite()">Decline</button></div></div>`:''}`}
 let section=el('programTrendSection');if(!section){const historyTab=el('historyTab');if(historyTab){historyTab.insertAdjacentHTML('afterbegin','<section id="programTrendSection" class="surface"><div class="section-head"><div><span class="eyebrow">PROGRAM TREND</span><h2>Season-by-Season Growth</h2></div></div><div id="programTrendGrid"></div></section>');section=el('programTrendSection')}}
 const rows=(state.programHistory?.[String(uid())]||[]).slice().sort((a,b)=>a.year-b.year);const grid=el('programTrendGrid');if(grid)grid.innerHTML=rows.length?`<div class="table-wrap"><table><thead><tr><th>Year</th><th>School</th><th>Conference</th><th>Record</th><th>Conf.</th><th>Rank</th><th>OVR</th><th>Prestige</th><th>Recent</th><th>Postseason</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${r.baseline?'Start':r.year}</td><td>${esc(r.school)}</td><td>${esc(r.conference)}</td><td>${r.baseline?'—':`${r.wins}-${r.losses}`}</td><td>${r.baseline?'—':`${r.conferenceWins}-${r.conferenceLosses}`}</td><td>${r.rank?'#'+r.rank:'—'}</td><td>${r.overall}</td><td>${r.prestige}</td><td>${r.recent}</td><td>${esc(r.postseason||'—')}</td></tr>`).join('')}</tbody></table></div>`:'<p class="muted">Complete a season to begin trend tracking.</p>';
}

// Export using native share when available, with a browser download fallback.
window.onNativeExportResult=function(success,message){if(!success&&message&&!/canceled/i.test(message))alert(message)};
window.exportDynastySave=async function(){
 if(!state.school)return;const saved=saveNow('Export backup',false,true);if(!saved){alert('The dynasty could not be saved to its slot. Export will use the current in-memory dynasty instead.')}const data=window.SDF_RELEASE_TEST?.compactState?.()||state,json=JSON.stringify(data,null,2),name=`Saturday_Dynasty_${String(state.school.name).replace(/[^a-z0-9]+/gi,'_')}_Y${state.year}_W${state.week}.json`;
 // The Android app exposes a native document picker so exported saves are
 // actually written to Downloads/Drive instead of relying on WebView downloads.
 try{if(window.SDFNative&&typeof window.SDFNative.exportSave==='function'){window.SDFNative.exportSave(name,json);return}}catch(err){console.warn('Native Android export failed to open',err)}
 const file=new File([json],name,{type:'application/json'});
 try{if(navigator.canShare?.({files:[file]})){await navigator.share({title:'Saturday Dynasty Football Save',text:'Dynasty save backup',files:[file]});return}}
 catch(err){if(err?.name==='AbortError')return;console.warn('Native share failed',err)}
 try{const url=URL.createObjectURL(file),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);alert(`Backup created: ${name}`)}catch(err){el('modalBody').innerHTML=`<span class="eyebrow">EXPORT BACKUP</span><h2>Copy Your Save</h2><p class="muted">Android could not open a file destination. Select all of the text below and save it as <b>${esc(name)}</b>.</p><textarea style="width:100%;min-height:300px">${esc(json)}</textarea>`;el('modal').classList.remove('hidden')}
};
if(el('exportSaveBtn'))el('exportSaveBtn').onclick=()=>window.exportDynastySave();

// A native-style watchdog prevents a damaged save or unexpected play-engine error
// from leaving the Sim to Final button frozen forever. The normal batched engine
// still gets several seconds to finish first.
let liveFinalWatchdog=null;
document.addEventListener('click',event=>{
 const button=event.target.closest?.('#liveFinalBtn');if(!button)return;
 clearTimeout(liveFinalWatchdog);
 liveFinalWatchdog=setTimeout(()=>{
  const game=state.liveGame;if(!game||game.finalized||!game.simulatingToFinal)return;
  console.warn('V1.6.5 fast-sim watchdog completed a stalled game.');
  game.simulatingToFinal=false;game.paused=true;
  if(game.score?.us===game.score?.them)game.score.us+=3;
  game.complete=true;game.lastPlay='The fast-sim watchdog safely completed the remaining game clock.';
  try{window.SDF_V12_TEST?.finalizeLiveGame?.(game)}catch(error){console.error('Fast-sim watchdog finalize failed',error);game.finalized=true;window.renderAll?.()}
 },8000);
},true);

function decorateLiveScoreboard(){
 if(!state.liveGame)return;const teams=document.querySelectorAll('#gameSimBody .live-scoreboard .live-team');if(teams.length<2)return;const userCr=confRecord(uid()),opp=worldTeam(state.liveGame.oppId)||state.rankings?.find(x=>Number(x.id)===Number(state.liveGame.oppId)),oppCr=confRecord(state.liveGame.oppId),ur=rankFor(uid()),or=rankFor(state.liveGame.oppId),spans=[teams[0].querySelector('span'),teams[1].querySelector('span')],labels=[`${ur?'#'+ur+' · ':''}${state.record.w}-${state.record.l} (${userCr.w}-${userCr.l} conf) · ${teamRatings().overall} OVR`,`${or?'#'+or+' · ':''}${opp?.record?.w||0}-${opp?.record?.l||0} (${oppCr.w}-${oppCr.l} conf) · ${opp?.rosterPower||state.liveGame.oppPower} OVR`];spans.forEach((node,i)=>{if(node&&node.textContent!==labels[i])node.textContent=labels[i]});
}
new MutationObserver(()=>decorateLiveScoreboard()).observe(el('gameSimBody')||document.body,{subtree:true,childList:true});

function beforeRender163(){if(!state.school)return;ensureRepairState();recordUserOpponentResult();window.updateRankings?.()}
function afterRender163(out){if(!state.school)return out;cleanRosterReferences();releaseLostScholarships();renderCareerAndTrends();repairRecruitModal();decorateLiveScoreboard();return out}

// Rebind key controls after all cumulative wrappers.
if(el('exportSaveBtn'))el('exportSaveBtn').onclick=()=>window.exportDynastySave();
setTimeout(()=>{if(!state.school)return;ensureRepairState();captureProgramBaseline();window.renderAll?.()},0);
window.SDF_V163={version:V,projectedUpside,releaseLostScholarships,cleanRosterReferences,captureSeasonTrend,simulateWorldWeek163,lifecycle:{beforeOffseason:beforeOffseason163,afterOffseason:afterOffseason163,afterRecruitOpen:afterRecruitOpen163,beforeStart:beforeStart163,afterStart:afterStart163,beforeAcceptJob:beforeAcceptJob163,afterAcceptJob:afterAcceptJob163,afterFinishSeason:afterFinishSeason163,beforeRender:beforeRender163,afterRender:afterRender163}};
})();
(()=>{
'use strict';
const VERSION='1.6.5';
const LEGACY_TEAM_NAMES=new Map([
  ["Florida Atlantic State", "Orlando Atlantic"],
  ["Capital University", "Potomac Capital"],
  ["Mississippi Valley State", "Jackson Delta State"],
  ["New England College", "Boston Commonwealth"],
  ["San Diego State Coast", "San Diego Pacific"],
  ["Ann Arbor Wolverines", "Ann Arbor Ironclads"],
  ["Madison State", "Madison Lakes"],
  ["Lincoln Corn State", "Lincoln Prairie"],
  ["Athens Bulldogs", "Athens Black Bears"],
  ["Tuscaloosa Crimson", "Tuscaloosa Forge"],
  ["Knoxville Volunteers", "Knoxville Ridge"],
  ["Gainesville Gators", "Gainesville Swampcats"],
  ["Tallahassee Seminoles", "Tallahassee Firebirds"],
  ["Clemson Tigers", "Clemson Gold"],
  ["Coral Gables Hurricanes", "Coral Gables Storm"],
  ["Norman Sooners", "Norman Stampede"],
  ["Stillwater Cowboys", "Stillwater Outlaws"],
  ["Eugene Ducks", "Eugene Evergreens"],
  ["Seattle Huskies", "Seattle Orcas"],
  ["Los Angeles Trojans", "Los Angeles Centurions"],
  ["South Bend Irish", "South Bend Foundry"],
  ["Boise Broncos", "Boise High Desert"],
  ["Memphis Tigers", "Memphis Blues"],
  ["Boone Mountaineers", "Boone Summit"],
  ["Athens Bobcats", "Athens Riverhawks"],
  ["Minneapolis Northmen", "Minneapolis Northstar"],
  ["Iowa City Hawkeyes", "Iowa City Harvesters"],
  ["West Lafayette Engineers", "West Lafayette Riveters"],
  ["Bloomington Hoosiers", "Bloomington Torch"],
  ["College Park Terrapins", "College Park Guardians"],
  ["Piscataway Knights", "Piscataway Forge"],
  ["Ames Cyclones", "Ames Windriders"],
  ["Manhattan Wildcats", "Manhattan Flint"],
  ["Lawrence Jayhawks", "Lawrence Freeholders"],
  ["Waco Bears", "Waco Wranglers"],
  ["Fort Worth Horned Frogs", "Fort Worth Railmen"],
  ["Lubbock Red Raiders", "Lubbock Dust Devils"],
  ["Auburn Plainsmen", "Auburn Oaks"],
  ["Oxford Rebels", "Oxford Magnolias"],
  ["Starkville Bulldogs", "Starkville Iron"],
  ["Columbia Gamecocks", "Columbia Palmettos"],
  ["Lexington Wildcats", "Lexington Thoroughbreds"],
  ["Fayetteville Razorbacks", "Fayetteville Ozarks"],
  ["Columbia Tigers", "Columbia Trailblazers"],
  ["College Station Aggies", "College Station Rangers"],
  ["Chapel Hill Heels", "Chapel Hill Pines"],
  ["Raleigh Wolfpack", "Raleigh Redtails"],
  ["Durham Blue Devils", "Durham Scholars"],
  ["Blacksburg Hokies", "Blacksburg Foundry"],
  ["Charlottesville Cavaliers", "Charlottesville Summit"],
  ["Louisville Cardinals", "Louisville Riverhawks"],
  ["Syracuse Orange", "Syracuse Snowcats"],
  ["Chestnut Hill Eagles", "Chestnut Hill Scholars"],
  ["Tempe Sun Devils", "Tempe Scorch"],
  ["Tucson Wildcats", "Tucson Saguaros"],
  ["Berkeley Bears", "Berkeley Sequoias"],
  ["Palo Alto Cardinal", "Palo Alto Innovators"],
  ["Boulder Buffaloes", "Boulder Peaks"],
  ["Salt Lake Utes", "Salt Lake Sentinels"],
  ["Corvallis Beavers", "Corvallis Timber"],
  ["Pullman Cougars", "Pullman Palouse"],
  ["Provo Cougars", "Provo Peaks"],
  ["Houston Cougars", "Houston Apollos"],
  ["Cincinnati Bearcats", "Cincinnati Rivermen"],
  ["Orlando Knights", "Orlando Orbit"],
  ["Morgantown Mountaineers", "Morgantown Miners"],
  ["Tampa Bulls", "Tampa Tritons"],
  ["Ypsilanti Eagles", "Ypsilanti Flyers"],
  ["Kalamazoo Broncos", "Kalamazoo Kestrels"],
  ["Mount Pleasant Chips", "Mount Pleasant Lumber"],
  ["Akron Zips", "Akron Foundry"],
  ["Kent Flashes", "Kent Lightning"],
  ["Bowling Green Falcons", "Bowling Green Aviators"],
  ["Muncie Cardinals", "Muncie Forge"],
  ["DeKalb Huskies", "DeKalb Prairie"],
  ["Fort Collins Rams", "Fort Collins Frontiers"],
  ["Laramie Cowboys", "Laramie Range"],
  ["Albuquerque Lobos", "Albuquerque Sol"],
  ["Las Vegas Rebels", "Las Vegas Neon"],
  ["Reno Wolf Pack", "Reno Silver"],
  ["Fresno Bulldogs", "Fresno Gold"],
  ["San Jose Spartans", "San Jose Circuit"],
  ["Honolulu Warriors", "Honolulu Tides"],
  ["Tulane Wave", "New Orleans Crescent"],
  ["Tulsa Hurricane", "Tulsa Ember"],
  ["Philadelphia Owls", "Philadelphia Liberty"],
  ["Greenville Pirates", "Greenville Mariners"],
  ["Annapolis Midshipmen", "Annapolis Admirals"],
  ["West Point Cadets", "Hudson Valley Guard"],
  ["Birmingham Blazers", "Birmingham Ironworks"],
  ["San Antonio Roadrunners", "San Antonio Vaqueros"],
  ["Conway Chanticleers", "Conway Marsh"],
  ["Statesboro Eagles", "Statesboro Pines"],
  ["Atlanta Panthers", "Atlanta Phoenix"],
  ["Troy Trojans", "Troy Titans"],
  ["Mobile Jaguars", "Mobile Baycats"],
  ["Lafayette Cajuns", "Lafayette Cypress"],
  ["Monroe Warhawks", "Monroe Bayou"],
  ["Jonesboro Red Wolves", "Jonesboro Ridge"],
  ["Buffalo Bulls", "Buffalo Blizzard"],
  ["Amherst Minutemen", "Amherst Scholars"],
  ["Storrs Huskies", "Storrs Ice"],
  ["Philadelphia Wildcats", "Philadelphia Founders"],
  ["New York Lions", "New York Empire"],
  ["San Luis Obispo Mustangs", "San Luis Obispo Coast"],
  ["Davis Aggies", "Davis Harvest"],
  ["Missoula Grizzlies", "Missoula Peaks"],
  ["Bozeman Bobcats", "Bozeman Sky"],
  ["Sacramento Hornets", "Sacramento Gold"]
]);
const LEGACY_CONFERENCES=new Map([
  [['Big','Ten'].join(' '),'Great North'],
  [['S','EC'].join(''),'Southeastern'],
  [['A','CC'].join(''),'Atlantic'],
  [['Big','12'].join(' '),'Heartland'],
  [['Pac','12'].join('-'),'Western'],
  [['Amer','ican'].join(''),'Metro'],
  [['Mid','American'].join('-'),'Great Lakes'],
  [['Mountain','West'].join(' '),'Mountain'],
  [['Sun','Belt'].join(' '),'Southern Coast'],
  [['Conference','USA'].join(' '),'National']
]);
const legacyNames=[...LEGACY_TEAM_NAMES.keys()].sort((a,b)=>b.length-a.length);
const legacyConferences=[...LEGACY_CONFERENCES.entries()].sort((a,b)=>b[0].length-a[0].length);
const escapeRegex=value=>String(value).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const legacyPattern=legacyNames.length?new RegExp(legacyNames.map(escapeRegex).join('|'),'g'):null;
function canonicalConference(value){return typeof value==='string'?(LEGACY_CONFERENCES.get(value)||value):value}
function replaceLegacyText(value){
 if(typeof value!=='string')return value;
 let out=legacyPattern?value.replace(legacyPattern,match=>LEGACY_TEAM_NAMES.get(match)||match):value;
 for(const [oldName,newName] of legacyConferences)out=out.split(oldName).join(newName);
 return out
}
function canonicalSchool(id){const numeric=Number(id);return Number.isFinite(numeric)?(schools||[]).find(s=>Number(s.id)===numeric):null}
function syncSchoolObject(obj){
 if(!obj||typeof obj!=='object')return;
 const direct=canonicalSchool(obj.id);
 if(direct&&typeof obj.name==='string')obj.name=direct.name;
 if(obj.oppId!=null){const school=canonicalSchool(obj.oppId);if(school&&typeof obj.opponent==='string')obj.opponent=school.name}
 if(obj.schoolId!=null){const school=canonicalSchool(obj.schoolId);if(school){if(typeof obj.school==='string')obj.school=school.name;if(typeof obj.schoolName==='string')obj.schoolName=school.name}}
 if(obj.teamId!=null){const school=canonicalSchool(obj.teamId);if(school){if(typeof obj.team==='string')obj.team=school.name;if(typeof obj.teamName==='string')obj.teamName=school.name}}
 if(typeof obj.conference==='string')obj.conference=canonicalConference(obj.conference);
 if(typeof obj.from==='string')obj.from=canonicalConference(obj.from);
 if(typeof obj.to==='string')obj.to=canonicalConference(obj.to)
}
function migrateTree(value,seen=new WeakSet()){
 if(typeof value==='string')return replaceLegacyText(value);
 if(!value||typeof value!=='object')return value;
 if(seen.has(value))return value;seen.add(value);
 if(Array.isArray(value)){for(let i=0;i<value.length;i++)value[i]=migrateTree(value[i],seen);return value}
 for(const key of Object.keys(value))value[key]=migrateTree(value[key],seen);
 syncSchoolObject(value);return value
}
function migrateState(){
 if(!state||!state.school||state._v165BrandingMigration===1)return false;
 migrateTree(state);
 const current=canonicalSchool(state.school.id);if(current){state.school.name=current.name;state.school.conference=canonicalConference(state.school.conference||current.conference)}
 (state.world||[]).forEach(syncSchoolObject);(state.standings||[]).forEach(syncSchoolObject);(state.rankings||[]).forEach(syncSchoolObject);(state.schedule||[]).forEach(syncSchoolObject);
 for(const [schoolId,rows] of Object.entries(state.programHistory||{})){const school=canonicalSchool(schoolId);if(school)(rows||[]).forEach(row=>{row.schoolId=Number(schoolId);row.school=school.name;row.conference=canonicalConference(row.conference||school.conference)})}
 if(state.coachCareer){const currentSchool=canonicalSchool(state.coachCareer.currentSchoolId);if(currentSchool)state.coachCareer.currentSchool=currentSchool.name;(state.coachCareer.schoolStints||[]).forEach(syncSchoolObject);(state.coachCareer.seasonHistory||[]).forEach(syncSchoolObject)}
 state._v165BrandingMigration=1;state._simulationModelVersion=8;return true
}
window.SDF_V165={VERSION,migrateState,replaceLegacyText,canonicalConference};
if(state?.school)migrateState();
})();
(()=>{
'use strict';
const VERSION='1.6.6';
function migrate(){if(!state?.school||state._v166PlayerStatsNeeds===1)return false;state._simulationModelVersion=9;state._v166PlayerStatsNeeds=1;return true}
window.SDF_V166={VERSION,migrate,playerStatModel:'NCAA-calibrated',allPositionRecruitingNeeds:true};
if(state?.school)migrate();
})();
(()=>{
'use strict';
const V='1.7.5';
const el=id=>document.getElementById(id);
const n=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const userId=()=>Number(state.school?.id);
const saveNow=(reason,manual=false,backup=false)=>window.SDF_RELEASE_TEST?.saveNow?.(reason,manual,backup);
const normal=()=>{let u=0,v=0;while(!u)u=Math.random();while(!v)v=Math.random();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)};
const currentRank=()=>state.rankings?.find(x=>Number(x.id)===userId())?.rank||null;
const confRecord=()=>state.conferenceRecords?.[userId()]||state.conferenceRecords?.[String(userId())]||{w:0,l:0};
const currentGame=()=>state.schedule?.find(g=>Number(g.week)===Number(state.week));
const pct=v=>`${Math.round(v*100)}%`;

const ARCHETYPES={
 RECRUITER:{label:'Recruiter',description:'Builds pipelines, evaluates prospects and closes classes.',skill:'RECRUITER_1'},
 DEVELOPER:{label:'Developer',description:'Improves young players and gets more from the roster.',skill:'DEVELOPER_1'},
 STRATEGIST:{label:'Strategist',description:'Creates weekly matchup and game-plan advantages.',skill:'TACTICIAN_1'},
 BUILDER:{label:'Program Builder',description:'Raises culture, morale and long-term program stability.',skill:'CULTURE_1'}
};
const PRESETS={
 CASUAL:{upsetVariance:.82,scoring:1.02,injuries:.72,progression:1.16,transfers:.72,jobSecurity:.72,recruiting:.88,realignment:.80},
 STANDARD:{upsetVariance:1,scoring:1,injuries:1,progression:1,transfers:1,jobSecurity:1,recruiting:1,realignment:1},
 CHALLENGING:{upsetVariance:1.05,scoring:.98,injuries:1.08,progression:.94,transfers:1.12,jobSecurity:1.15,recruiting:1.12,realignment:.90},
 REALISTIC:{upsetVariance:1.12,scoring:.98,injuries:1.04,progression:.96,transfers:1.08,jobSecurity:1.08,recruiting:1.06,realignment:.85}
};
const OFF_SCHEME_FITS={
 'Pro Style':{QB:['Field General','Strong Arm'],RB:['Power Back','Receiving Back'],WR:['Route Runner','Possession'],TE:['Blocking','Possession'],OT:['Pass Protector','Balanced'],IOL:['Power','Balanced']},
 Spread:{QB:['Scrambler','Improviser'],RB:['Receiving Back','Elusive Back'],WR:['Deep Threat','Route Runner'],TE:['Receiving','Vertical'],OT:['Agile','Pass Protector'],IOL:['Agile','Balanced']},
 'Air Raid':{QB:['Strong Arm','Field General'],RB:['Receiving Back','Elusive Back'],WR:['Deep Threat','Route Runner'],TE:['Receiving','Vertical'],OT:['Pass Protector','Agile'],IOL:['Pass Protector','Agile']},
 'Power Run':{QB:['Field General','Strong Arm'],RB:['Power Back','One Cut'],WR:['Possession','Route Runner'],TE:['Blocking','Possession'],OT:['Power','Run Blocker'],IOL:['Power','Run Blocker']},
 Option:{QB:['Scrambler','Improviser'],RB:['Elusive Back','One Cut'],WR:['Deep Threat','Route Runner'],TE:['Blocking','Vertical'],OT:['Agile','Run Blocker'],IOL:['Agile','Run Blocker']},
 'Tempo Spread':{QB:['Improviser','Scrambler'],RB:['Receiving Back','Elusive Back'],WR:['Deep Threat','Route Runner'],TE:['Receiving','Vertical'],OT:['Agile','Pass Protector'],IOL:['Agile','Balanced']}
};
const DEF_SCHEME_FITS={
 '4-3':{EDGE:['Power Rusher','Run Stopper'],DL:['Run Stopper','Power'],LB:['Run Stopper','Field General'],CB:['Man','Zone'],S:['Run Support','Zone']},
 '3-4':{EDGE:['Speed Rusher','Power Rusher'],DL:['Run Stopper','Nose'],LB:['Pass Coverage','Field General'],CB:['Man','Zone'],S:['Zone','Run Support']},
 '4-2-5':{EDGE:['Speed Rusher','Power Rusher'],DL:['Pass Rusher','Power'],LB:['Pass Coverage','Field General'],CB:['Man','Slot'],S:['Zone','Hybrid']},
 '3-3-5':{EDGE:['Speed Rusher','Hybrid'],DL:['Run Stopper','Power'],LB:['Pass Coverage','Hybrid'],CB:['Zone','Slot'],S:['Zone','Hybrid']},
 Multiple:{EDGE:['Speed Rusher','Power Rusher'],DL:['Run Stopper','Pass Rusher'],LB:['Field General','Pass Coverage'],CB:['Man','Zone'],S:['Hybrid','Zone']}
};

function ensureState(){
 if(!state.school)return;
 state.realismSettings??={preset:'STANDARD',...PRESETS.STANDARD};
 state.realismSettings.preset??='STANDARD';
 for(const [k,v] of Object.entries(PRESETS.STANDARD))if(!Number.isFinite(Number(state.realismSettings[k])))state.realismSettings[k]=v;
 state.coachCareer??={name:'Coach',careerWins:0,careerLosses:0,jobs:[]};
 state.coachCareer.archetype??='BUILDER';
 state.coachCareer.seasonHistory??=[];
 state.weeklyRecaps??=[];
 state.playerRoles??={};
 state.seasonExpectations??={};
 state.programRecordsV170??={singleGame:{},season:{},career:{},milestones:{longestWinStreak:0,currentWinStreak:0,biggestWin:null,highestRank:null,bestPrestige:null,bestRecent:null,mostDrafted:null}};
 state.recoveryMeta??={backups:[],lastHealthCheck:null,lastAudit:null};
 state.rivalryMomentum??=0;
 state._v170ProcessedGames??={};
 state._v170RoleWeeks??={};
 ensureSeasonExpectations();
}

function probabilityFromEdge(edge,variance=1){
 const scale=7.8*Math.max(.72,variance);
 return clamp(1/(1+Math.exp(-edge/scale)),.04,.96);
}
function expectedGameWin(g){
 const ours=window.teamRatings?.().overall||n(state.school?.prestige,65);
 const home=g.home?1.8:-1.8;
 return probabilityFromEdge(ours-n(g.oppPower,65)+home,n(state.realismSettings?.upsetVariance,1));
}
function makeExpectations(){
 const probs=(state.schedule||[]).map(g=>expectedGameWin(g));
 const raw=probs.reduce((a,b)=>a+b,0);
 const expectedWins=clamp(Math.round(raw),3,11);
 const conferenceGames=(state.schedule||[]).filter(g=>g.conference).length;
 const expectedConferenceWins=clamp(Math.round(raw*((conferenceGames||8)/Math.max(1,(state.schedule||[]).length))),2,conferenceGames||8);
 const classTarget=state.school.prestige>=85?20:state.school.prestige>=72?35:state.school.prestige>=58?55:75;
 const postseason=expectedWins>=10?'Reach the playoff conversation':expectedWins>=8?'Compete for a conference title':expectedWins>=6?'Earn a bowl bid':'Show measurable improvement';
 return{year:state.year,expectedWins,expectedConferenceWins,classTarget,postseason,beatRival:true,createdAt:Date.now(),evaluated:false};
}
function ensureSeasonExpectations(){
 if(!state.school||!state.schedule?.length)return;
 if(!state.seasonExpectations||Number(state.seasonExpectations.year)!==Number(state.year))state.seasonExpectations=makeExpectations();
 state.school.expectation=state.seasonExpectations.expectedWins;
}
function expectationRows(){
 const e=state.seasonExpectations||makeExpectations(),cr=confRecord(),rivalGame=(state.schedule||[]).find(g=>g.rivalry),classRank=state.classRankings?.find(x=>Number(x.id)===userId())?.rank||null;
 return[
  {key:'wins',label:`Win at least ${e.expectedWins} games`,done:state.record.w>=e.expectedWins,current:`${state.record.w}-${state.record.l}`,weight:3},
  {key:'conference',label:`Win at least ${e.expectedConferenceWins} conference games`,done:cr.w>=e.expectedConferenceWins,current:`${cr.w}-${cr.l} conf.`,weight:2},
  {key:'postseason',label:e.postseason,done:e.expectedWins>=10?(currentRank()&&currentRank()<=12):e.expectedWins>=8?state.record.w>=8:state.record.w>=6,current:currentRank()?`Ranked #${currentRank()}`:`${state.record.w} wins`,weight:2},
  {key:'recruiting',label:`Sign a top-${e.classTarget} class`,done:classRank&&classRank<=e.classTarget,current:classRank?`Class #${classRank}`:'In progress',weight:1},
  {key:'rivalry',label:rivalGame?`Beat ${rivalGame.opponent}`:'Protect the program in rivalry games',done:rivalGame?rivalryResult(rivalGame):true,current:rivalGame?(rivalGame.result?`${rivalGame.result} ${rivalGame.score||''}`:'Not played'):'No scheduled rival',weight:1}
 ];
}
function rivalryResult(g){return g?.result==='W'}
function evaluateExpectations(){
 ensureState();const e=state.seasonExpectations;if(!e||e.evaluated)return e?.evaluation;
 const rows=expectationRows(),earned=rows.reduce((s,x)=>s+(x.done?x.weight:0),0),total=rows.reduce((s,x)=>s+x.weight,0),rate=earned/Math.max(1,total);
 const delta=rate>=.9?8:rate>=.72?4:rate>=.5?0:rate>=.32?-5:-9;
 state.jobSecurity=clamp(Math.round(n(state.jobSecurity)+delta*n(state.realismSettings.jobSecurity,1)),0,100);
 state.fanApproval=clamp(Math.round(n(state.fanApproval)+(rate>=.72?3:rate<.4?-3:0)),0,100);
 e.evaluated=true;e.evaluation={rows,earned,total,rate,jobSecurityDelta:delta};
 const h=state.history?.find(x=>Number(x.year)===Number(state.year));if(h)h.expectations=e.evaluation;
 state.news?.push(`Season goals: ${earned}/${total} weighted points achieved (${delta>=0?'+':''}${delta} job security).`);
 return e.evaluation;
}

function injectStartOptions(){/* Replaced by the Create Your Coach popup in release.js. */}
function applyArchetype(){
 const key=state.coachCareer?.archetype||window.SDF_NEW_DYNASTY_PENDING?.archetype||'BUILDER',def=ARCHETYPES[key]||ARCHETYPES.BUILDER;
 state.coachCareer.archetype=key;state.coachCareer.archetypeLabel=def.label;
 state.headCoach??={level:1,xp:0,skillPoints:1,skills:{}};state.headCoach.skills??={};
 if(!state.headCoach.skills[def.skill]){state.headCoach.skills[def.skill]=true;state.headCoach.skillPoints=Math.max(0,n(state.headCoach.skillPoints)-1)}window.syncHeadCoachRatings?.()
}

function injectSections(){
 if(!state.school)return;
 if(!el('weeklyRecapV170'))el('dashboardTab')?.querySelector('.stack')?.insertAdjacentHTML('afterbegin','<section id="weeklyRecapV170" class="surface v170-section"></section>');
 if(!el('seasonGoalsV170'))el('dashboardTab')?.querySelector('.stack')?.insertAdjacentHTML('afterbegin','<section id="seasonGoalsV170" class="surface v170-section"></section>');
 if(!el('playerRolesV170'))el('rosterTab')?.insertAdjacentHTML('beforeend','<section id="playerRolesV170" class="surface v170-section"></section>');
 if(!el('schemeFitV170'))el('gameplanTab')?.insertAdjacentHTML('beforeend','<section id="schemeFitV170" class="surface v170-section"></section>');
 if(!el('rivalryV170'))el('programTab')?.insertAdjacentHTML('beforeend','<section id="rivalryV170" class="surface v170-section"></section>');
 if(!el('realismSettingsV170'))el('dynastyTab')?.insertAdjacentHTML('beforeend','<section id="realismSettingsV170" class="surface v170-section"></section>');
 if(!el('recoveryToolsV170'))el('dynastyTab')?.insertAdjacentHTML('beforeend','<section id="recoveryToolsV170" class="surface v170-section"></section>');
 if(!el('enhancedRecordsV170'))el('historyTab')?.insertAdjacentHTML('beforeend','<section id="enhancedRecordsV170" class="surface v170-section"></section>');
}

function renderGoals(){
 const host=el('seasonGoalsV170');if(!host)return;const e=state.seasonExpectations,rows=expectationRows();
 host.innerHTML=`<div class="section-head"><div><span class="eyebrow">PRESEASON EXPECTATIONS</span><h2>Year ${state.year} Coach Goals</h2><p class="muted">Job security now shows exactly what ownership expects and how each goal is tracking.</p></div><span class="viz-badge">Expected ${e.expectedWins} wins</span></div><div class="v170-goal-grid">${rows.map(x=>`<article class="v170-goal ${x.done?'done':''}"><span>${x.done?'✓':'○'}</span><div><b>${esc(x.label)}</b><small>${esc(x.current)} · Weight ${x.weight}</small></div></article>`).join('')}</div>`;
}

function topWeekPlayers(week){
 return (state.roster||[]).map(p=>{const g=(p.gameLog||[]).find(x=>Number(x.year)===Number(state.year)&&Number(x.week)===Number(week));if(!g)return null;let score=n(g.passYds)/15+n(g.passTD)*8-n(g.passINT)*5+n(g.rushYds)/10+n(g.rushTD)*8+n(g.recYds)/10+n(g.recTD)*8+n(g.tackles)+n(g.sacks)*5+n(g.defINT)*7+n(g.points)/3;return{p,g,score}}).filter(Boolean).sort((a,b)=>b.score-a.score).slice(0,3);
}
function createWeeklyRecap(g){
 const key=`${state.year}-${g.week}`;if(state._v170ProcessedGames[key])return;
 state._v170ProcessedGames[key]=true;
 const tops=topWeekPlayers(g.week),rankMove=state.rankingMovement?.find(x=>Number(x.id)===userId()),recentNews=(state.news||[]).slice(-12).filter(x=>/committed|injur|improved|gained|visit|upset/i.test(String(x))).slice(-5);
 const aiUpsets=(state.lastWorldResults||[]).filter(x=>x.upset).slice(0,5);
 const recap={key,year:state.year,week:g.week,opponent:g.opponent,result:g.result,score:g.score,rank:currentRank(),rankChange:rankMove?.change||0,conference:!!g.conference,rivalry:!!g.rivalry,topPlayers:tops.map(x=>({name:x.p.name,pos:x.p.pos,line:statLineFromLog(x.p,x.g)})),news:recentNews,upsets:aiUpsets,createdAt:Date.now()};
 state.weeklyRecaps.push(recap);state.weeklyRecaps=state.weeklyRecaps.slice(-80);state.lastWeeklyRecap=recap;
 updateProgramRecords(g,recap);applyRoleConsequences(g);rotateRecoveryBackup('Postgame backup');
}
function statLineFromLog(p,g){
 if(p.pos==='QB')return `${n(g.passComp)}/${n(g.passAtt)}, ${n(g.passYds)} pass yds, ${n(g.passTD)} TD`;
 if(p.pos==='RB')return `${n(g.rushAtt)} carries, ${n(g.rushYds)} rush yds, ${n(g.rushTD)} TD`;
 if(['WR','TE'].includes(p.pos))return `${n(g.rec)} rec, ${n(g.recYds)} yds, ${n(g.recTD)} TD`;
 if(['EDGE','DL','LB','CB','S'].includes(p.pos))return `${n(g.tackles)} tackles, ${n(g.sacks)} sacks, ${n(g.defINT)} INT`;
 return `${n(g.points)} points`;
}
function detectCompletedGames(){for(const g of state.schedule||[])if(g.result)createWeeklyRecap(g)}
window.openWeeklyRecapV170=function(key){const r=(state.weeklyRecaps||[]).find(x=>x.key===key)||state.lastWeeklyRecap;if(!r)return;el('modalBody').innerHTML=`<span class="eyebrow">WEEK ${r.week} RECAP</span><h2>${r.result} ${esc(r.score)} ${esc(r.opponent)}</h2><div class="metric-grid">${metric('National Rank',r.rank?'#'+r.rank:'Unranked')}${metric('Rank Movement',r.rankChange?`${r.rankChange>0?'+':''}${r.rankChange}`:'—')}${metric('Conference Game',r.conference?'Yes':'No')}${metric('Rivalry',r.rivalry?'Yes':'No')}</div><h3>Top Performers</h3><div class="commit-grid">${r.topPlayers.map(p=>`<div class="commit-card"><b>${esc(p.name)} · ${p.pos}</b><span class="sub">${esc(p.line)}</span></div>`).join('')||'<p class="muted">No player lines available.</p>'}</div>${r.upsets?.length?`<h3>National Upsets</h3>${r.upsets.map(u=>`<div class="event-card"><b>${esc(u.winner)} over ${esc(u.loser)}</b><span class="sub">${u.winnerPower} OVR defeated ${u.loserPower} OVR</span></div>`).join('')}`:''}${r.news?.length?`<h3>Other Developments</h3>${r.news.map(x=>`<div class="event-card">${x}</div>`).join('')}`:''}`;el('modal').classList.remove('hidden')};
function renderWeeklyRecap(){
 const host=el('weeklyRecapV170');if(!host)return;const r=state.lastWeeklyRecap;
 if(!r){host.innerHTML='<div class="section-head"><div><span class="eyebrow">WEEKLY RECAP</span><h2>Your Season Story</h2></div></div><p class="muted">The recap will collect game results, top performers, injuries, commitments, rankings and national upsets after each week.</p>';return}
 host.innerHTML=`<div class="section-head"><div><span class="eyebrow">WEEK ${r.week} RECAP</span><h2>${r.result} ${esc(r.score)} vs ${esc(r.opponent)}</h2></div><button class="btn neutral" onclick="openWeeklyRecapV170('${r.key}')">Full Recap</button></div><div class="v170-recap-grid">${r.topPlayers.map(p=>`<article><b>${esc(p.name)} · ${p.pos}</b><span>${esc(p.line)}</span></article>`).join('')}${r.rank?`<article><b>National Rank</b><span>#${r.rank}${r.rankChange?` (${r.rankChange>0?'+':''}${r.rankChange})`:''}</span></article>`:''}${r.upsets?.length?`<article><b>Upsets This Week</b><span>${r.upsets.length} nationally</span></article>`:''}</div>`;
}

function recruitFactorRows(r){
 const api=window.SDF_RECRUITING_V2;if(!api||!r)return[];
 const keys=r.motivations?.length?r.motivations.map(m=>({key:m.key,label:m.label,weight:m.weight})):['PRESTIGE','RECENT','PLAYING_TIME','SCHEME','HOME','FACILITIES','PRO','ACADEMICS','NIL'].map(k=>({key:k,label:k.replaceAll('_',' '),weight:10}));
 return keys.map(m=>{const grade=n(api.schoolGrade?.(r,state.school,m.key),50);return{...m,grade,letter:grade>=93?'A+':grade>=90?'A':grade>=87?'A-':grade>=83?'B+':grade>=80?'B':grade>=77?'B-':grade>=73?'C+':grade>=70?'C':grade>=67?'C-':grade>=60?'D':'F',impact:Math.round((grade-70)*n(m.weight,10)/35)}}).sort((a,b)=>Math.abs(b.impact)-Math.abs(a.impact));
}
function appendRecruitExplanation(id){
 const r=state.recruits?.find(x=>String(x.id)===String(id));if(!r||!el('modalBody')||el('recruitFitExplanationV170'))return;
 const rows=recruitFactorRows(r),fit=Math.round(window.SDF_RECRUITING_V2?.weightedFit?.(r,state.school)||0),visit=r.visitCompletedWeek?`Completed in Week ${r.visitCompletedWeek}`:r.visitScheduledWeek?`Scheduled for Week ${r.visitScheduledWeek}`:'Not scheduled';
 el('modalBody').insertAdjacentHTML('beforeend',`<section id="recruitFitExplanationV170" class="recruit-profile-section v170-fit-breakdown"><h3>Why ${esc(r.name)} Likes—or Dislikes—Your Program</h3><p class="muted">This is the transparent fit breakdown. Exact potential stays hidden until the player signs.</p><div class="metric-grid">${metric('Overall Fit',fit)}${metric('Projected Upside',window.projectedRecruitUpside?.(r)||'Unknown')}${metric('Visit',visit)}</div>${rows.map(x=>`<div class="v170-factor"><div><b>${esc(x.label)}</b><small>${x.weight}% of decision</small></div><span class="grade-pill">${x.letter}</span><strong class="${x.impact>=0?'positive':'negative'}">${x.impact>=0?'+':''}${x.impact}</strong></div>`).join('')}</section>`);
}

function roleFor(p){return state.playerRoles?.[p.id]||(p.redshirt?'REDSHIRT':p.starter?'STARTER':n(p.morale)<60?'RESERVE':'ROTATION')}
window.setPlayerRoleV170=function(id,role){
 const p=state.roster.find(x=>String(x.id)===String(id));if(!p)return;
 if(role==='REDSHIRT'){
  const games=n(p.seasonStats?.games);if(p.redshirtUsed||games>4){alert(p.redshirtUsed?'This player has already used a redshirt season.':'A player cannot redshirt after appearing in more than four games.');window.renderAll();return}
  p.redshirt=true;p.starter=false;p.redshirtSeason=state.year;
 }else if(p.redshirt){p.redshirt=false;p.redshirtSeason=null}
 state.playerRoles[id]=role;
 if(role==='STARTER')p.morale=clamp(n(p.morale)+2,35,99);
 saveNow('Player role updated');window.renderAll();
};
function roleRisk(p,role){let risk=0;if(role==='RESERVE'&&p.ovr>=78)risk+=22;if(role==='ROTATION'&&p.ovr>=84)risk+=12;if(role==='REDSHIRT'&&p.year>=3)risk+=18;if(p.morale<65)risk+=Math.round((65-p.morale)*.8);return clamp(risk,0,95)}
function renderPlayerRoles(){
 const host=el('playerRolesV170');if(!host)return;
 const rows=(state.roster||[]).slice().sort((a,b)=>b.ovr-a.ovr).slice(0,40);
 host.innerHTML=`<div class="section-head"><div><span class="eyebrow">PLAYER MANAGEMENT</span><h2>Roles, Redshirts & Transfer Risk</h2><p class="muted">Roles communicate expectations. Highly rated players buried on the depth chart are more likely to become unhappy.</p></div></div><div class="v170-role-list">${rows.map(p=>{const role=roleFor(p),risk=roleRisk(p,role);return`<article class="v170-role-row"><div><b>${esc(p.name)} · ${p.pos} · ${p.ovr} OVR</b><small>${classLabel(p)} · Morale ${p.morale} · Transfer risk ${risk}%</small></div><select onchange="setPlayerRoleV170('${p.id}',this.value)">${[['STARTER','Starter'],['ROTATION','Rotation'],['RESERVE','Reserve'],['SPECIAL','Special Teams'],['REDSHIRT','Redshirt']].map(([v,l])=>`<option value="${v}" ${role===v?'selected':''}>${l}</option>`).join('')}</select></article>`}).join('')}</div>`;
}
function applyRoleConsequences(g){
 const key=`${state.year}-${g.week}`;if(state._v170RoleWeeks[key])return;state._v170RoleWeeks[key]=true;
 for(const p of state.roster||[]){const role=roleFor(p),risk=roleRisk(p,role);if(role==='STARTER')p.morale=clamp(n(p.morale)+1,35,99);else if(role==='RESERVE'&&p.ovr>=80)p.morale=clamp(n(p.morale)-1,35,99);if(risk>=55&&Math.random()<.12)state.news.push(`${p.name} is frustrated with a ${role.toLowerCase()} role and may consider the portal.`)}
}

function playerSchemeFit(p){
 const table=['QB','RB','WR','TE','OT','IOL'].includes(p.pos)?OFF_SCHEME_FITS[state.offense]||OFF_SCHEME_FITS.Spread:DEF_SCHEME_FITS[state.defense]||DEF_SCHEME_FITS.Multiple;
 const ideal=table?.[p.pos]||[],arch=String(p.arch||'');let score=70;if(ideal.some(x=>arch.toLowerCase().includes(String(x).toLowerCase())||String(x).toLowerCase().includes(arch.toLowerCase())))score=92;else if(ideal.length)score=76;
 score+=Math.round((n(p.attrs?.awareness,p.ovr)-70)/8);return clamp(score,45,99);
}
function schemeFitBonus(side){
 const positions=side==='offense'?['QB','RB','WR','TE','OT','IOL']:['EDGE','DL','LB','CB','S'];const active=(state.roster||[]).filter(p=>positions.includes(p.pos)&&p.starter&&!p.injury&&!p.redshirt);const fit=active.length?active.reduce((s,p)=>s+playerSchemeFit(p),0)/active.length:70;return clamp(Math.round((fit-72)/9),-2,3)
}
function renderSchemeFit(){
 const host=el('schemeFitV170');if(!host)return;const rows=(state.roster||[]).filter(p=>p.starter&&!p.injury&&!p.redshirt).map(p=>({p,fit:playerSchemeFit(p)})).sort((a,b)=>b.fit-a.fit),avgFit=rows.length?Math.round(rows.reduce((s,x)=>s+x.fit,0)/rows.length):70;
 host.innerHTML=`<div class="section-head"><div><span class="eyebrow">SCHEME FIT</span><h2>${esc(state.offense)} / ${esc(state.defense)}</h2><p class="muted">Ratings remain the biggest factor. Scheme fit adds only a small matchup bonus or penalty.</p></div><span class="viz-badge">${avgFit} average fit</span></div><div class="metric-grid">${metric('Offense Bonus',`${schemeFitBonus('offense')>=0?'+':''}${schemeFitBonus('offense')} OVR`)}${metric('Defense Bonus',`${schemeFitBonus('defense')>=0?'+':''}${schemeFitBonus('defense')} OVR`)}</div><div class="two-col"><div><h3>Best Fits</h3>${rows.slice(0,5).map(x=>`<div class="event-card"><b>${esc(x.p.name)} · ${x.p.pos}</b><span>${x.fit} fit</span></div>`).join('')}</div><div><h3>Needs Adjustment</h3>${rows.slice(-5).reverse().map(x=>`<div class="event-card"><b>${esc(x.p.name)} · ${x.p.pos}</b><span>${x.fit} fit</span></div>`).join('')}</div></div>`;
}

function renderRivalry(){
 const host=el('rivalryV170');if(!host)return;const game=(state.schedule||[]).find(g=>g.rivalry),hist=state.rivalryHistory?.[state.rivalId]||{},intensity=clamp(55+n(hist.wins)*2+n(hist.losses)*2+Math.abs(n(hist.streak))*3,50,99);
 host.innerHTML=`<div class="section-head"><div><span class="eyebrow">RIVALRY STAKES</span><h2>${game?esc(game.opponent):'Program Rivalries'}</h2><p class="muted">Rivalry results affect fan approval, boosters, recruiting momentum and coach reputation.</p></div><span class="viz-badge">${intensity} intensity</span></div><div class="metric-grid">${metric('Series Record',`${n(hist.wins)}-${n(hist.losses)}`)}${metric('Current Streak',n(hist.streak)===0?'Even':`${Math.abs(n(hist.streak))} ${n(hist.streak)>0?'wins':'losses'}`)}${metric('Best Margin',n(hist.bestMargin)||'—')}${metric('Recruiting Momentum',state.rivalryMomentum?`+${state.rivalryMomentum}`:'—')}</div>`;
}

function updateProgramRecords(g,recap){
 const r=state.programRecordsV170,m=r.milestones,score=String(g.score||'0-0').split('-').map(Number),margin=(score[0]||0)-(score[1]||0);
 if(g.result==='W'){m.currentWinStreak=n(m.currentWinStreak)+1;m.longestWinStreak=Math.max(n(m.longestWinStreak),m.currentWinStreak)}else m.currentWinStreak=0;
 if(g.result==='W'&&(!m.biggestWin||margin>m.biggestWin.margin))m.biggestWin={margin,opponent:g.opponent,score:g.score,year:state.year,week:g.week};
 const rank=currentRank();if(rank&&(!m.highestRank||rank<m.highestRank.rank))m.highestRank={rank,year:state.year,week:g.week};
 if(!m.bestPrestige||n(state.school.prestige)>m.bestPrestige.value)m.bestPrestige={value:Math.round(n(state.school.prestige)),year:state.year};
 if(!m.bestRecent||n(state.school.recent)>m.bestRecent.value)m.bestRecent={value:Math.round(n(state.school.recent)),year:state.year};
 for(const x of topWeekPlayers(g.week)){
  const p=x.p,l=x.g,tests=[['passingYards',n(l.passYds)],['rushingYards',n(l.rushYds)],['receivingYards',n(l.recYds)],['passingTD',n(l.passTD)],['rushingTD',n(l.rushTD)],['receivingTD',n(l.recTD)],['tackles',n(l.tackles)],['sacks',n(l.sacks)],['interceptions',n(l.defINT)]];
  for(const [key,value] of tests)if(value>0&&(!r.singleGame[key]||value>r.singleGame[key].value))r.singleGame[key]={value,player:p.name,opponent:g.opponent,year:state.year,week:g.week};
 }
}
function compileCareerRecords(){
 const out={};for(const p of state.roster||[]){const seasons=[...(p.statHistory||[]),p.seasonStats||{}],sum={passYds:0,rushYds:0,recYds:0,passTD:0,rushTD:0,recTD:0,tackles:0,sacks:0,defINT:0};for(const s of seasons)for(const k of Object.keys(sum))sum[k]+=n(s[k]);for(const [k,v] of Object.entries(sum))if(!out[k]||v>out[k].value)out[k]={value:v,player:p.name}}
 state.programRecordsV170.career=out;
}
function renderRecords(){
 const host=el('enhancedRecordsV170');if(!host)return;compileCareerRecords();const r=state.programRecordsV170,m=r.milestones,labels={passingYards:'Passing Yards',rushingYards:'Rushing Yards',receivingYards:'Receiving Yards',passingTD:'Passing TD',rushingTD:'Rushing TD',receivingTD:'Receiving TD',tackles:'Tackles',sacks:'Sacks',interceptions:'Interceptions',passYds:'Career Passing',rushYds:'Career Rushing',recYds:'Career Receiving',passTD:'Career Pass TD',rushTD:'Career Rush TD',recTD:'Career Rec TD',defINT:'Career INT'};
 const cards=(obj,prefix='')=>Object.entries(obj||{}).filter(([,x])=>x&&n(x.value)>0).map(([k,x])=>`<article class="record-card"><h4>${prefix}${labels[k]||k}</h4><b>${x.value}</b><span>${esc(x.player||'')}</span></article>`).join('');
 host.innerHTML=`<div class="section-head"><div><span class="eyebrow">PROGRAM RECORD BOOK</span><h2>Milestones & Player Records</h2></div></div><div class="metric-grid">${metric('Longest Win Streak',m.longestWinStreak||'—')}${metric('Biggest Win',m.biggestWin?`${m.biggestWin.margin} vs ${m.biggestWin.opponent}`:'—')}${metric('Highest Rank',m.highestRank?`#${m.highestRank.rank}`:'—')}${metric('Peak Prestige',m.bestPrestige?.value||state.school.prestige)}</div><h3>Single-Game Records</h3><div class="record-grid">${cards(r.singleGame)||'<p class="muted">Records appear as games are played.</p>'}</div><h3>Single-Season Records</h3><div class="record-grid">${cards(r.season)||'<p class="muted">Complete a season to create season records.</p>'}</div><h3>Active Career Leaders</h3><div class="record-grid">${cards(r.career)||'<p class="muted">Career totals appear after games are played.</p>'}</div>`;
}

function coachSummary(){
 const seasons=state.coachCareer.seasonHistory||[],cr=seasons.reduce((a,x)=>({w:a.w+n(x.conferenceWins),l:a.l+n(x.conferenceLosses)}),{w:0,l:0}),drafted=(state.draftHistory||[]).length,bowlWins=n(state.achievementStats?.bowlWins),playoffWins=n(state.achievementStats?.playoffWins),awards=(state.history||[]).reduce((s,h)=>s+(h.awards?.length||0),0),bestClass=(state.history||[]).reduce((best,h)=>Math.min(best,n(h.classRank,999)),999);
 return{seasons,cr,drafted,bowlWins,playoffWins,awards,bestClass:bestClass===999?null:bestClass};
}
function renderCoachCareer(){
 const host=el('coachCareerPanel');if(!host)return;const c=coachSummary(),arch=ARCHETYPES[state.coachCareer.archetype]||ARCHETYPES.BUILDER,stints=state.coachCareer.schoolStints||[],allStints=[...stints,{name:state.school.name,conference:state.school.conference,start:state.coachCareer.currentStintStart||state.year,end:'Current'}];
 host.innerHTML=`<div class="section-head"><div><span class="eyebrow">COACH CAREER</span><h2>${esc(state.coachCareer.name||'Coach')} · ${arch.label}</h2><p class="muted">${arch.description} The dynasty follows the coach, while each school keeps its own history.</p></div></div><div class="metric-grid">${metric('Career Record',`${n(state.coachCareer.careerWins)}-${n(state.coachCareer.careerLosses)}`)}${metric('Conference Record',`${c.cr.w}-${c.cr.l}`)}${metric('Bowl Record',`${c.bowlWins} wins`)}${metric('Playoff Wins',c.playoffWins)}${metric('National Titles',n(state.achievementStats?.nationalTitles))}${metric('Players Drafted',c.drafted)}${metric('Awards Won',c.awards)}${metric('Best Class',c.bestClass?'#'+c.bestClass:'—')}</div><h3>Coaching Stops</h3><div class="v170-stints">${allStints.map(s=>`<article><b>${esc(s.name)}</b><span>${esc(s.conference)} · Years ${s.start}–${s.end}</span></article>`).join('')}</div>${c.seasons.length?`<h3>Career Seasons</h3><div class="table-wrap"><table><thead><tr><th>Year</th><th>School</th><th>Record</th><th>Conf.</th><th>Rank</th><th>Postseason</th></tr></thead><tbody>${c.seasons.slice().reverse().map(s=>`<tr><td>${s.year}</td><td>${esc(s.school)}</td><td>${s.wins}-${s.losses}</td><td>${s.conferenceWins}-${s.conferenceLosses}</td><td>${s.rank?'#'+s.rank:'—'}</td><td>${esc(s.postseason||'None')}</td></tr>`).join('')}</tbody></table></div>`:''}`;
}

window.applyRealismPresetV170=function(name){const p=PRESETS[name]||PRESETS.STANDARD;state.realismSettings={preset:name,...p};saveNow('Realism preset changed');window.renderAll()};
window.updateRealismSettingV170=function(key,value){state.realismSettings[key]=Number(value);state.realismSettings.preset='CUSTOM';saveNow('Realism setting changed')};
function renderSettings(){
 const host=el('realismSettingsV170');if(!host)return;const s=state.realismSettings;
 host.innerHTML=`<div class="section-head"><div><span class="eyebrow">DIFFICULTY & REALISM</span><h2>Dynasty Simulation Settings</h2><p class="muted">Better teams remain favored, but college football upsets can happen. Adjust how volatile the world feels.</p></div></div><div class="v170-preset-grid">${Object.keys(PRESETS).map(k=>`<button class="btn ${s.preset===k?'primary':'neutral'}" onclick="applyRealismPresetV170('${k}')">${k[0]+k.slice(1).toLowerCase()}</button>`).join('')}</div><div class="v170-slider-grid">${[['recruiting','Recruiting difficulty',.8,1.3,.05],['upsetVariance','Upset / game-day variance',.7,1.35,.05],['scoring','Scoring environment',.85,1.15,.05],['injuries','Injury frequency',.5,1.5,.05],['progression','Progression speed',.75,1.3,.05],['transfers','Transfer activity',.6,1.5,.05],['jobSecurity','Coach firing strictness',.6,1.5,.05],['realignment','Conference realignment activity',.5,1.5,.05]].map(([k,l,min,max,step])=>`<label><span>${l}</span><input type="range" min="${min}" max="${max}" step="${step}" value="${s[k]}" oninput="this.nextElementSibling.textContent=Number(this.value).toFixed(2)" onchange="updateRealismSettingV170('${k}',this.value)"><b>${n(s[k],1).toFixed(2)}</b></label>`).join('')}</div>`;
}

function saveSnapshot(){return JSON.parse(JSON.stringify(window.SDF_RELEASE_TEST?.compactState?.()||state))}
function rotateRecoveryBackup(reason){
 try{const data=saveSnapshot(),item={id:`${Date.now()}`,reason,year:state.year,week:state.week,createdAt:new Date().toISOString(),data};const key=`sdf-v170-recovery-${state.saveSlot||1}`,list=JSON.parse(localStorage.getItem(key)||'[]');list.unshift(item);localStorage.setItem(key,JSON.stringify(list.slice(0,5)));state.recoveryMeta.backups=list.slice(0,5).map(({data,...x})=>x)}catch(err){console.warn('Recovery backup failed',err)}
}
window.createRecoveryBackupV170=function(){rotateRecoveryBackup('Manual recovery point');saveNow('Recovery point created',true,true);window.renderAll()};
window.restoreRecoveryBackupV170=function(){
 try{const key=`sdf-v170-recovery-${state.saveSlot||1}`,list=JSON.parse(localStorage.getItem(key)||'[]');if(!list.length){alert('No recovery points are available yet.');return}if(!confirm(`Restore the backup from ${new Date(list[0].createdAt).toLocaleString()}? Current unsaved progress will be replaced.`))return;Object.keys(state).forEach(k=>delete state[k]);Object.assign(state,JSON.parse(JSON.stringify(list[0].data)));ensureState();saveNow('Recovery backup restored',true,true);window.renderAll()}catch(err){alert(`Restore failed: ${err.message}`)}
};
window.runDynastyHealthCheckV170=function(){
 ensureState();window.SDF_AI_ROSTERS?.ensureAll?.();const issues=[],ids=new Set();for(const p of state.roster||[]){if(ids.has(p.id))issues.push(`Duplicate player ID: ${p.name}`);ids.add(p.id);if(n(p.ovr)<40||n(p.ovr)>99)issues.push(`Invalid OVR for ${p.name}`);if(n(p.pot)<n(p.ovr))issues.push(`Potential below OVR for ${p.name}`)}
 let aiPlayers=0;for(const [teamId,roster] of Object.entries(state.aiRosters||{})){const teamIds=new Set();for(const p of roster||[]){aiPlayers++;if(teamIds.has(p.id))issues.push(`AI team ${teamId} has duplicate player ID ${p.id}`);teamIds.add(p.id);if(n(p.ovr)<40||n(p.ovr)>99)issues.push(`AI team ${teamId} has invalid OVR for ${p.name}`);if(n(p.pot)<n(p.ovr))issues.push(`AI team ${teamId} has potential below OVR for ${p.name}`);if(n(p.year)<1||n(p.year)>4)issues.push(`AI team ${teamId} has invalid class year for ${p.name}`)}}
 const draftSlots=new Set();for(const d of state.nationalDraftClass||[]){const key=`${d.year}-${d.round}-${d.pick}`;if(draftSlots.has(key))issues.push(`Duplicate pro draft slot: Year ${d.year}, Round ${d.round}, Pick ${d.pick}`);draftSlots.add(key);if(n(d.round)<1||n(d.round)>7||n(d.pick)<1||n(d.pick)>32)issues.push(`Invalid pro draft slot for ${d.player||d.playerId}`)}
 if(n(state.scholarships)<0||n(state.scholarships)>35)issues.push(`Scholarship count is ${state.scholarships}`);if(!state.schedule?.length)issues.push('Schedule is missing.');if(!state.world?.length)issues.push('World teams are missing.');if((state.captains||[]).some(id=>!ids.has(id)))issues.push('A captain points to a departed player.');
 const result={checkedAt:new Date().toISOString(),issues,roster:state.roster.length,aiPlayers,recruits:state.recruits.length,draftRows:(state.nationalDraftClass||[]).length,saveSlot:state.saveSlot};state.recoveryMeta.lastHealthCheck=result;
 el('modalBody').innerHTML=`<span class="eyebrow">SAVE HEALTH CHECK</span><h2>${issues.length?'Issues Found':'Dynasty Looks Healthy'}</h2><div class="metric-grid">${metric('Your Roster',result.roster)}${metric('AI Players',result.aiPlayers)}${metric('Draft Rows',result.draftRows)}${metric('Issues',issues.length)}</div>${issues.map(x=>`<div class="event-card">${esc(x)}</div>`).join('')||'<p class="muted">No structural save problems were detected across user rosters, AI rosters, or draft slots.</p>'}`;el('modal').classList.remove('hidden');return result;
};
function auditOneGame(a,b,settings={}){
 const variance=n(settings.upsetVariance,1),formA=normal()*4.8*variance,formB=normal()*4.8*variance,edge=(a+formA)-(b+formB),win=Math.random()<probabilityFromEdge(edge,variance),base=24+(n(settings.scoring,1)-1)*24,margin=Math.max(1,Math.round(Math.abs(edge)*.65+Math.abs(normal())*7)),winner=Math.max(10,Math.round(base+margin/2+normal()*4)),loser=Math.max(3,Math.round(base-margin/2+normal()*4));return{favoriteWon:a>=b?win:!win,aScore:win?winner:loser,bScore:win?loser:winner,upset:a>b&&!win||b>a&&win}
}
window.runSimulationAuditV170=function(iterations=25000){
 const gaps=[0,5,10,15,20],results=[];for(const gap of gaps){let fav=0,upsets=0,total=0,max=0;for(let i=0;i<iterations/gaps.length;i++){const r=auditOneGame(80,80-gap,state.realismSettings);if(gap===0){if(r.aScore>r.bScore)fav++}else{if(r.favoriteWon)fav++;else upsets++}total+=r.aScore+r.bScore;max=Math.max(max,r.aScore,r.bScore)}results.push({gap,favoriteWinRate:fav/(iterations/gaps.length),upsetRate:upsets/(iterations/gaps.length),averageCombined:total/(iterations/gaps.length),maxScore:max})}
 const pass=results.every(r=>r.gap===0?Math.abs(r.favoriteWinRate-.5)<.04:r.gap===5?r.favoriteWinRate>.58&&r.favoriteWinRate<.78:r.gap===10?r.favoriteWinRate>.7&&r.favoriteWinRate<.9:r.gap===15?r.favoriteWinRate>.8&&r.favoriteWinRate<.96:r.favoriteWinRate>.88&&r.favoriteWinRate<.99)&&results.every(r=>r.averageCombined>39&&r.averageCombined<65);
 const report={runAt:new Date().toISOString(),iterations,pass,results};state.recoveryMeta.lastAudit=report;
 if(el('modalBody')){el('modalBody').innerHTML=`<span class="eyebrow">SIMULATION AUDIT</span><h2>${pass?'Passed':'Review Needed'}</h2><p class="muted">${iterations.toLocaleString()} neutral-site test games. Better teams are favored, but not guaranteed to win.</p><div class="table-wrap"><table><thead><tr><th>OVR Gap</th><th>Favorite Win%</th><th>Upset%</th><th>Avg Total</th><th>Max</th></tr></thead><tbody>${results.map(r=>`<tr><td>${r.gap}</td><td>${pct(r.favoriteWinRate)}</td><td>${r.gap?pct(r.upsetRate):'—'}</td><td>${r.averageCombined.toFixed(1)}</td><td>${r.maxScore}</td></tr>`).join('')}</tbody></table></div>`;el('modal').classList.remove('hidden')}
 return report;
};
window.exportBugReportV170=async function(){
 const report={appVersion:V,generatedAt:new Date().toISOString(),health:window.runDynastyHealthCheckV170(),audit:state.recoveryMeta.lastAudit||window.runSimulationAuditV170(5000),state:saveSnapshot()};const json=JSON.stringify(report,null,2),name=`Saturday_Dynasty_Bug_Report_Y${state.year}_W${state.week}.json`;
 try{if(window.SDFNative?.exportSave){window.SDFNative.exportSave(name,json);return}}catch(err){console.warn(err)}
 const blob=new Blob([json],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)
};
function renderRecovery(){
 const host=el('recoveryToolsV170');if(!host)return;let backups=[];try{backups=JSON.parse(localStorage.getItem(`sdf-v170-recovery-${state.saveSlot||1}`)||'[]')}catch{}
 host.innerHTML=`<div class="section-head"><div><span class="eyebrow">SAVE & TESTING TOOLS</span><h2>Recovery, Diagnostics & Long-Term Audit</h2><p class="muted">Rotating recovery points help protect a dynasty, while the audit checks upset rates and score distributions without changing your real save.</p></div></div><div class="actions wrap"><button class="btn primary" onclick="createRecoveryBackupV170()">Create Recovery Point</button><button class="btn neutral" onclick="restoreRecoveryBackupV170()" ${backups.length?'':'disabled'}>Restore Latest</button><button class="btn neutral" onclick="runDynastyHealthCheckV170()">Check Save Health</button><button class="btn neutral" onclick="runSimulationAuditV170()">Run 25K-Game Audit</button><button class="btn neutral" onclick="runTenSeasonAuditV170()">Run 10-Season Audit</button><button class="btn neutral" onclick="exportBugReportV170()">Export Bug Report</button></div><div class="v170-backup-list">${backups.slice(0,5).map(x=>`<article><b>${esc(x.reason)}</b><span>Year ${x.year}, Week ${x.week} · ${new Date(x.createdAt).toLocaleString()}</span></article>`).join('')||'<p class="muted">No recovery points yet. One is created automatically after each completed game.</p>'}</div>`;
}

function simulateWorldWeekV170(){
 ensureState();const userOpponent=(state.schedule||[]).find(g=>Number(g.week)===Number(state.week))?.oppId,teams=(state.world||[]).filter(t=>Number(t.id)!==userId()&&Number(t.id)!==Number(userOpponent)),seed=(state.year*97+state.week*31)%997,ordered=teams.slice().sort((a,b)=>((n(a.id)*37+seed)%1009)-((n(b.id)*37+seed)%1009)),used=new Set(),results=[];
 for(const a of ordered){if(used.has(a.id))continue;let pool=ordered.filter(b=>!used.has(b.id)&&b.id!==a.id),same=pool.filter(b=>b.conference===a.conference),b=((state.week>=3&&state.week<=10)&&same.length?same:pool)[0];if(!b)continue;used.add(a.id);used.add(b.id);
  const homeEdge=1.5,formA=normal()*4.6*n(state.realismSettings.upsetVariance,1),formB=normal()*4.6*n(state.realismSettings.upsetVariance,1),edge=n(a.rosterPower)-n(b.rosterPower)+homeEdge+formA-formB,p=probabilityFromEdge(edge,n(state.realismSettings.upsetVariance,1)),aWins=Math.random()<p,winner=aWins?a:b,loser=aWins?b:a,favorite=n(a.rosterPower)>=n(b.rosterPower)?a:b,upset=Number(winner.id)!==Number(favorite.id)&&Math.abs(n(a.rosterPower)-n(b.rosterPower))>=3;
  winner.record??={w:0,l:0};loser.record??={w:0,l:0};winner.record.w++;loser.record.l++;
  if(a.conference===b.conference){state.conferenceRecords[a.id]??={w:0,l:0};state.conferenceRecords[b.id]??={w:0,l:0};state.conferenceRecords[winner.id].w++;state.conferenceRecords[loser.id].l++}
  state.headToHeadResults??=[];state.headToHeadResults.push({year:state.year,week:state.week,winner:winner.id,loser:loser.id,conference:a.conference===b.conference});winner.recent=clamp(n(winner.recent)+.35,20,99);loser.recent=clamp(n(loser.recent)-.25,20,99);
  results.push({winner:winner.name,loser:loser.name,winnerId:winner.id,loserId:loser.id,winnerPower:n(winner.rosterPower),loserPower:n(loser.rosterPower),favoriteWin:Number(winner.id)===Number(favorite.id),upset,winProbability:Number(winner.id)===Number(a.id)?p:1-p});
 }
 state.lastWorldResults=results;state.headToHeadResults=state.headToHeadResults.slice(-700);window.updateRankings?.();
}

function applyGameDayForm(g,live=false){
 const variance=n(state.realismSettings?.upsetVariance,1),scouting=state.weeklyPractice==='Opponent Scouting'?.78:1,userForm=normal()*3.2*variance*scouting,oppForm=normal()*3.2*variance,home=g.home?1.2:-1.2;
 state._v170GameDay={userForm:userForm+home,oppForm:oppForm-home,live,year:state.year,week:state.week};return state._v170GameDay;
}
function clearGameDayForm(){delete state._v170GameDay}


function withDifficultyMultipliers(overrides,fn){
 const old=window.difficultyConfig;if(typeof old!=='function')return fn();
 window.difficultyConfig=function(){const base=old();return{...base,...Object.fromEntries(Object.entries(overrides).map(([k,v])=>[k,n(base[k],1)*n(v,1)]))}};
 try{return fn()}finally{window.difficultyConfig=old}
}
function captureSeasonRecords(){
 const r=state.programRecordsV170;const categories={passingYards:['passYds','Passing Yards'],rushingYards:['rushYds','Rushing Yards'],receivingYards:['recYds','Receiving Yards'],tackles:['tackles','Tackles'],sacks:['sacks','Sacks'],interceptions:['defINT','Interceptions']};
 for(const [key,[field]] of Object.entries(categories)){const leader=(state.roster||[]).map(p=>({p,value:n(p.seasonStats?.[field])})).sort((a,b)=>b.value-a.value)[0];if(leader?.value>0&&(!r.season[key]||leader.value>r.season[key].value))r.season[key]={value:leader.value,player:leader.p.name,year:state.year}}
}
window.runTenSeasonAuditV170=function(){
 const seasons=[];let power=window.teamRatings?.().overall||75,prestige=n(state.school?.prestige,60),recent=n(state.school?.recent,60),totalUpsets=0,totalGames=0,maxScore=0;
 for(let year=1;year<=10;year++){let wins=0,losses=0,points=0,allowed=0;for(let week=1;week<=12;week++){const opponent=clamp(Math.round(68+normal()*9+Math.min(12,year*.3)),48,96),r=auditOneGame(power,opponent,state.realismSettings);wins+=r.aScore>r.bScore?1:0;losses+=r.aScore<r.bScore?1:0;points+=r.aScore;allowed+=r.bScore;totalUpsets+=r.upset?1:0;totalGames++;maxScore=Math.max(maxScore,r.aScore,r.bScore)}recent=clamp(Math.round(recent+(wins-6)*1.2),20,99);prestige=clamp(Math.round(prestige+(wins>=10?2:wins<=3?-2:0)),25,99);power=clamp(Math.round(power+(wins>=9?1:wins<=4?-1:0)+normal()*1.2),50,96);seasons.push({year,wins,losses,power,prestige,recent,ppg:points/12,papg:allowed/12})}
 const report={runAt:new Date().toISOString(),seasons,upsetRate:totalUpsets/totalGames,maxScore,pass:maxScore<90&&seasons.every(x=>x.ppg>10&&x.ppg<50&&x.papg>8&&x.papg<50)};state.recoveryMeta.lastTenSeasonAudit=report;
 el('modalBody').innerHTML=`<span class="eyebrow">10-SEASON SANDBOX AUDIT</span><h2>${report.pass?'Passed':'Review Needed'}</h2><p class="muted">This audit simulates ten synthetic seasons without changing your actual dynasty.</p><div class="metric-grid">${metric('Upset Rate',pct(report.upsetRate))}${metric('Maximum Score',report.maxScore)}${metric('Final Team OVR',seasons.at(-1).power)}</div><div class="table-wrap"><table><thead><tr><th>Year</th><th>Record</th><th>OVR</th><th>Prestige</th><th>Recent</th><th>PF/G</th><th>PA/G</th></tr></thead><tbody>${seasons.map(x=>`<tr><td>${x.year}</td><td>${x.wins}-${x.losses}</td><td>${x.power}</td><td>${x.prestige}</td><td>${x.recent}</td><td>${x.ppg.toFixed(1)}</td><td>${x.papg.toFixed(1)}</td></tr>`).join('')}</tbody></table></div>`;el('modal').classList.remove('hidden');return report
};

function personnelGrade(pos,keys=[]){const list=(state.roster||[]).filter(p=>p.pos===pos&&!p.redshirt&&!p.injury).sort((a,b)=>(b.starter-a.starter)||b.ovr-a.ovr).slice(0,STARTERS?.[pos]||1);if(!list.length)return 65;return avg(list.map(p=>keys.length?avg(keys.map(k=>n(p.attrs?.[k],p.ovr))):n(p.ovr,65)))}
function enhanceTeamRatingsV170(base){
 state.realDepthChart??={};const day=n(state._v170GameDay?.userForm),offBonus=schemeFitBonus('offense'),defBonus=schemeFitBonus('defense'),qb=personnelGrade('QB',['accuracy','decision','throwPower','skill','awareness']),rb=personnelGrade('RB',['vision','elusiveness','power','speed','skill']),receivers=avg([personnelGrade('WR',['catch','route','speed','skill']),personnelGrade('TE',['catch','route','strength','skill'])]),line=avg([personnelGrade('OT',['strength','awareness','skill']),personnelGrade('IOL',['strength','awareness','skill'])]),front=avg([personnelGrade('EDGE',['passRush','strength','speed','skill']),personnelGrade('DL',['tackle','strength','skill'])]),linebackers=personnelGrade('LB',['tackle','coverage','awareness','speed','skill']),secondary=avg([personnelGrade('CB',['coverage','awareness','speed','skill']),personnelGrade('S',['coverage','awareness','tackle','speed','skill'])]);
 const offPersonnel=(qb-base.offense)*.22+(rb-base.offense)*.08+(receivers-base.offense)*.07+(line-base.offense)*.10,defPersonnel=(front-base.defense)*.11+(linebackers-base.defense)*.08+(secondary-base.defense)*.12,offense=clamp(Math.round(base.offense+offPersonnel+offBonus+day),40,99),defense=clamp(Math.round(base.defense+defPersonnel+defBonus+day),40,99),overall=clamp(Math.round(offense*.48+defense*.48+n(base.special,65)*.04),40,99);return{...base,offense,defense,overall,personnel:{qb:Math.round(qb),rb:Math.round(rb),receivers:Math.round(receivers),line:Math.round(line),front:Math.round(front),linebackers:Math.round(linebackers),secondary:Math.round(secondary)}}
}

function runSimGameV170(baseFn,context,args){
 ensureState();const w=args[0],g=state.schedule?.[w-1];if(!g)return baseFn?.apply(context,args);const original=g.oppPower,form=applyGameDayForm(g,false);g.oppPower=clamp(Math.round(n(original)+form.oppForm),40,99);
 try{const out=withDifficultyMultipliers({injury:state.realismSettings.injuries},()=>baseFn.apply(context,args));if(state.lastGameRecap){state.lastGameRecap.gameDayForm={user:Math.round(form.userForm),opponent:Math.round(form.oppForm)};state.lastGameRecap.planReport??=[];state.lastGameRecap.planReport.push(`Game-day form: ${form.userForm>=0?'+':''}${form.userForm.toFixed(1)} us, ${form.oppForm>=0?'+':''}${form.oppForm.toFixed(1)} opponent`);scaleQuickScoreEnvironment(g,state.lastGameRecap,n(state.realismSettings.scoring,1))}return out}finally{g.oppPower=original;clearGameDayForm()}
}
function scaleQuickScoreEnvironment(g,recap,mult){
 if(Math.abs(mult-1)<.01)return;let us=Math.max(0,Math.round(n(recap.us)*mult)),them=Math.max(0,Math.round(n(recap.them)*mult));if(us===them)us+=3;const oldWin=recap.win,newWin=us>them;if(oldWin!==newWin)return;recap.us=us;recap.them=them;g.score=`${us}-${them}`
}

function runOpenLiveV170(baseFn,context,args){
 ensureState();const g=currentGame();if(!g)return baseFn?.apply(context,args);const original=g.oppPower,form=applyGameDayForm(g,true);g.oppPower=clamp(Math.round(n(original)+form.oppForm),40,99);try{const out=baseFn.apply(context,args);if(state.liveGame){state.liveGame.gameDayForm={user:Math.round(form.userForm),opponent:Math.round(form.oppForm)};state.liveGame.cfg.scoring=n(state.realismSettings.scoring,1)}return out}finally{g.oppPower=original;clearGameDayForm()}
}

function renderAllV170(){
 if(!state.school)return;ensureState();injectSections();detectCompletedGames();renderGoals();renderWeeklyRecap();renderPlayerRoles();renderSchemeFit();renderRivalry();renderSettings();renderRecovery();renderRecords();renderCoachCareer();
}

function beforeStartV170(){injectStartOptions()}
function afterStartV170(result){if(state.school){ensureState();applyArchetype();state.seasonExpectations=makeExpectations();rotateRecoveryBackup('New dynasty')}return result}
function beforeFinishSeasonV170(){ensureState();captureSeasonRecords()}
function invokeFinishSeasonV170(baseFn,context,args){return withDifficultyMultipliers({job:state.realismSettings.jobSecurity},()=>baseFn.apply(context,args))}
function afterFinishSeasonV170(out){evaluateExpectations();const drafted=(state.draftHistory||[]).filter(x=>Number(x.year)===Number(state.year)).length,m=state.programRecordsV170.milestones;if(drafted&&(!m.mostDrafted||drafted>m.mostDrafted.value))m.mostDrafted={value:drafted,year:state.year};rotateRecoveryBackup('End of season');return out}
function beforeOffseasonV170(){ensureState();return new Map((state.roster||[]).map(p=>[p.id,{ovr:n(p.ovr),pot:n(p.pot,p.ovr),attrs:{...(p.attrs||{})}}]))}
function invokeOffseasonV170(baseFn,context,args){return withDifficultyMultipliers({portal:state.realismSettings.transfers},()=>baseFn.apply(context,args))}
function afterOffseasonV170(before,out){const speed=n(state.realismSettings.progression,1);for(const p of state.roster||[]){const old=before.get(p.id);if(!old)continue;const baseGain=Math.max(0,n(p.ovr)-old.ovr),targetGain=Math.max(0,Math.round(baseGain*speed)),target=clamp(Math.min(n(p.pot,p.ovr),old.ovr+targetGain),old.ovr,99),delta=target-n(p.ovr);if(delta){p.ovr=target;if(p.attrs)for(const k of Object.keys(p.attrs))p.attrs[k]=clamp(n(p.attrs[k])+delta,40,99)}}return out}
function afterFinishOffseasonV170(oldYear,out){if(state.year!==oldYear){ensureState();state.seasonExpectations=makeExpectations();rotateRecoveryBackup('Start of season')}return out}
function afterRecruitOpenV170(id){setTimeout(()=>appendRecruitExplanation(id),0)}

// Rivalry wins create a modest one-week recruiting momentum bonus, never a guarantee.
function applyRivalryMomentum(){const g=(state.schedule||[]).find(x=>x.rivalry&&x.result&&!x._v170Momentum);if(!g)return;g._v170Momentum=true;if(g.result==='W'){state.rivalryMomentum=clamp(n(state.rivalryMomentum)+2,0,8);for(const r of (state.recruits||[]).filter(x=>x.onBoard&&!x.committedTo).slice(0,20)){r.recruitInfluence??={};r.recruitInfluence[userId()]=clamp(n(r.recruitInfluence[userId()])+.5,0,36)}state.news.push('The rivalry win created a small recruiting momentum boost.')}else state.rivalryMomentum=Math.max(0,n(state.rivalryMomentum)-1)}
function beforeRenderV170(){if(state.school){ensureState();applyRivalryMomentum()}}
function afterRenderV170(out){renderAllV170();return out}

injectStartOptions();
setTimeout(()=>{if(state.school){ensureState();window.renderAll?.()}},0);
window.SDF_V170={version:V,probabilityFromEdge,expectedGameWin,playerSchemeFit,schemeFitBonus,runAudit:window.runSimulationAuditV170,healthCheck:window.runDynastyHealthCheckV170,makeExpectations,auditOneGame,simulateWorldWeek:simulateWorldWeekV170,enhanceTeamRatings:enhanceTeamRatingsV170,runSimGame:runSimGameV170,runOpenLive:runOpenLiveV170,lifecycle:{beforeStart:beforeStartV170,afterStart:afterStartV170,beforeFinishSeason:beforeFinishSeasonV170,invokeFinishSeason:invokeFinishSeasonV170,afterFinishSeason:afterFinishSeasonV170,beforeOffseason:beforeOffseasonV170,invokeOffseason:invokeOffseasonV170,afterOffseason:afterOffseasonV170,afterFinishOffseason:afterFinishOffseasonV170,afterRecruitOpen:afterRecruitOpenV170,beforeRender:beforeRenderV170,afterRender:afterRenderV170}};
})();
(()=>{
'use strict';
const VERSION='1.7.5';
const STAT_FIELDS=['games','passAtt','passComp','passYds','passTD','passINT','rushAtt','rushYds','rushTD','rec','recYds','recTD','tackles','tfl','sacks','defINT','ff','fgm','fga','xpm','xpa','points','punts','puntYds','puntLong','inside20','touchbacks'];
const PLAYER_CATEGORIES={
 PASS_EFF:{label:'Passing Efficiency',field:'passEff',positions:['QB'],min:'passAtt'},
 PASS_YDS:{label:'Passing Yards',field:'passYds',positions:['QB'],min:'passAtt'},
 PASS_YPG:{label:'Passing Yards / Game',field:'passYpg',positions:['QB'],min:'passAtt'},
 PASS_TD:{label:'Passing Touchdowns',field:'passTD',positions:['QB'],min:'passAtt'},
 PASS_INT:{label:'Interceptions Thrown',field:'passINT',positions:['QB'],min:'passAtt'},
 PASS_ATT:{label:'Pass Attempts',field:'passAtt',positions:['QB'],min:'passAtt'},
 PASS_CMP:{label:'Completions',field:'passComp',positions:['QB'],min:'passAtt'},
 PASS_PCT:{label:'Completion %',field:'passPct',positions:['QB'],min:'passAtt'},
 RUSH_YDS:{label:'Rushing Yards',field:'rushYds',positions:['QB','RB','FB','WR'],min:'rushAtt'},
 RUSH_YPG:{label:'Rushing Yards / Game',field:'rushYpg',positions:['QB','RB','FB','WR'],min:'rushAtt'},
 RUSH_TD:{label:'Rushing Touchdowns',field:'rushTD',positions:['QB','RB','FB','WR'],min:'rushAtt'},
 RUSH_ATT:{label:'Rushing Attempts',field:'rushAtt',positions:['QB','RB','FB','WR'],min:'rushAtt'},
 RUSH_AVG:{label:'Yards / Carry',field:'rushAvg',positions:['QB','RB','FB','WR'],min:'rushAtt'},
 REC_YDS:{label:'Receiving Yards',field:'recYds',positions:['WR','TE','RB','FB'],min:'rec'},
 REC_YPG:{label:'Receiving Yards / Game',field:'recYpg',positions:['WR','TE','RB','FB'],min:'rec'},
 RECEPTIONS:{label:'Receptions',field:'rec',positions:['WR','TE','RB','FB'],min:'rec'},
 REC_TD:{label:'Receiving Touchdowns',field:'recTD',positions:['WR','TE','RB','FB'],min:'rec'},
 REC_AVG:{label:'Yards / Reception',field:'recAvg',positions:['WR','TE','RB','FB'],min:'rec'},
 TACKLES:{label:'Tackles',field:'tackles',positions:['EDGE','DL','LB','CB','S'],min:'tackles'},
 TFL:{label:'Tackles for Loss',field:'tfl',positions:['EDGE','DL','LB','CB','S'],min:'tackles'},
 SACKS:{label:'Sacks',field:'sacks',positions:['EDGE','DL','LB'],min:'tackles'},
 DEF_INT:{label:'Interceptions',field:'defINT',positions:['LB','CB','S'],min:'tackles'},
 FF:{label:'Forced Fumbles',field:'ff',positions:['EDGE','DL','LB','CB','S'],min:'tackles'},
 POINTS:{label:'Points',field:'points',positions:['K'],min:'games'},
 FGM:{label:'Field Goals Made',field:'fgm',positions:['K'],min:'fga'},
 XPM:{label:'Extra Points Made',field:'xpm',positions:['K'],min:'xpa'},
 FG_PCT:{label:'Field Goal %',field:'fgPct',positions:['K'],min:'fga'},
 PUNT_AVG:{label:'Punting Average',field:'puntAvg',positions:['P'],min:'punts'},
 PUNTS:{label:'Punts',field:'punts',positions:['P'],min:'punts'},
 PUNT_LONG:{label:'Longest Punt',field:'puntLong',positions:['P'],min:'punts'},
 PUNTS_INSIDE20:{label:'Punts Inside 20',field:'inside20',positions:['P'],min:'punts'},
 PUNT_TOUCHBACKS:{label:'Punt Touchbacks',field:'touchbacks',positions:['P'],min:'punts'}
};
const TEAM_CATEGORIES={
 PPG:{label:'Scoring Offense / Game',field:'ppg'},
 OFF_YPG:{label:'Total Offense / Game',field:'offYpg'},
 PASS_YPG:{label:'Passing Offense / Game',field:'passYpg'},
 RUSH_YPG:{label:'Rushing Offense / Game',field:'rushYpg'},
 SCORING_DEF:{label:'Scoring Defense / Game',field:'paPg',ascending:true},
 YARDS_DEF:{label:'Total Defense / Game',field:'defYpg',ascending:true},
 PASS_DEF:{label:'Passing Defense / Game',field:'passDefYpg',ascending:true},
 RUSH_DEF:{label:'Rushing Defense / Game',field:'rushDefYpg',ascending:true},
 SACKS:{label:'Sacks',field:'sacks'},
 TAKEAWAYS:{label:'Takeaways',field:'takeaways'},
 TURNOVER_MARGIN:{label:'Turnover Margin',field:'turnoverMargin'},
 TURNOVERS:{label:'Fewest Turnovers',field:'turnovers',ascending:true}
};
const ui={view:'PLAYERS',category:'PASS_YDS',conference:'ALL',team:'ALL',limit:50};
function n(v,d=0){v=Number(v);return Number.isFinite(v)?v:d}
function c(v,min,max){return Math.max(min,Math.min(max,v))}
function esc(v){return String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]))}
function hash(v){let h=2166136261;for(const ch of String(v)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function rng(seed){let x=hash(seed)||1;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return(x>>>0)/4294967296}}
function rint(r,min,max){return min+Math.floor(r()*((max-min)+1))}
function normal(r){const u=Math.max(1e-9,r()),v=Math.max(1e-9,r());return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)}
function teamById(id){return (schools||[]).find(s=>Number(s.id)===Number(id))}
function worldById(id){return (state.world||[]).find(t=>Number(t.id)===Number(id))}
function userId(){return Number(state.school?.id)}
function teamName(id){return Number(id)===userId()?state.school?.name:(teamById(id)?.name||worldById(id)?.name||'Unknown')}
function conferenceOf(id){return Number(id)===userId()?state.school?.conference:(worldById(id)?.conference||teamById(id)?.conference||'Independent')}
function teamRoster(id){return Number(id)===userId()?(state.roster||[]):window.SDF_AI_ROSTERS?.get?.(id)||[]}
function emptyStats(){if(typeof emptySeasonStats==='function')return emptySeasonStats();const out={};for(const k of STAT_FIELDS)out[k]=0;return out}
function ensureStats(p){if(!p)return null;p.seasonStats??=emptyStats();p.statHistory??=[];p.gameLog??=[];p.stats??={games:0,yards:0,td:0,tackles:0,sacks:0,int:0};for(const k of STAT_FIELDS)p.seasonStats[k]=n(p.seasonStats[k]);return p.seasonStats}
function zeroCurrentAiStats(){for(const [id,roster] of Object.entries(state.aiRosters||{})){if(Number(id)===userId())continue;for(const p of roster||[]){p.seasonStats=emptyStats();p.gameLog=[];p.stats={games:0,yards:0,td:0,tackles:0,sacks:0,int:0}}}}
function programPower(id){if(Number(id)===userId())return n(window.teamRatings?.().overall,70);const roster=teamRoster(id),rt=roster.length?window.SDF_AI_ROSTERS?.teamRatings?.(roster):null;const w=worldById(id);return c(Math.round(n(rt?.overall,w?.rosterPower||70)),45,99)}
function active(roster,pos,count){return roster.filter(p=>p.pos===pos&&!p.redshirt&&!p.injury).sort((a,b)=>Number(b.starter)-Number(a.starter)||n(a.depthIndex,99)-n(b.depthIndex,99)||n(b.ovr)-n(a.ovr)).slice(0,count)}
function uniquePlayers(groups){const m=new Map();for(const p of groups.flat())if(p&&!m.has(p.id))m.set(p.id,p);return[...m.values()]}
function allocate(total,players,weightFn,r){total=Math.max(0,Math.round(n(total)));const out=new Map();if(!players.length||!total)return out;const rows=players.map((p,i)=>{const w=Math.max(.001,n(weightFn?.(p,i),1)*(0.94+r()*.12));return{p,w,raw:0,value:0}}),sum=rows.reduce((a,x)=>a+x.w,0)||1;let used=0;for(const row of rows){row.raw=total*row.w/sum;row.value=Math.floor(row.raw);used+=row.value}rows.sort((a,b)=>(b.raw-b.value)-(a.raw-a.value)||b.w-a.w);for(let i=0;i<total-used;i++)rows[i%rows.length].value++;for(const row of rows)out.set(row.p.id,row.value);return out}
function footballBreakdown(score){score=Math.max(0,Math.round(score));let best={td:0,fg:0,error:999,penalty:999};for(let td=0;td<=9;td++)for(let fg=0;fg<=7;fg++){const val=td*7+fg*3,error=Math.abs(score-val),penalty=error*100+Math.abs(td-score/7)+fg*.06;if(penalty<best.penalty)best={td,fg,error,penalty,value:val}}return best}
function footballScore(target,r){target=c(Math.round(target),3,63);let best=[],min=999;for(let td=0;td<=8;td++)for(let fg=0;fg<=6;fg++){const value=td*7+fg*3,err=Math.abs(value-target);if(err<min){min=err;best=[value]}else if(err===min)best.push(value)}return best[Math.floor(r()*best.length)]||target}
function offenseTendency(id,r){const roster=teamRoster(id),qb=active(roster,'QB',1)[0],rb=active(roster,'RB',2),wr=active(roster,'WR',4),te=active(roster,'TE',2);const passSkill=n(qb?.ovr,65)+((wr.reduce((a,p)=>a+n(p.ovr),0)+te.reduce((a,p)=>a+n(p.ovr),0))/Math.max(1,wr.length+te.length)-65)*.35,runSkill=(rb.reduce((a,p)=>a+n(p.ovr),0)/Math.max(1,rb.length)||65);return c(.50+(passSkill-runSkill)/180+(r()-.5)*.08,.36,.68)}
function buildTeamBox(id,oppId,score,oppScore,r){const power=programPower(id),oppPower=programPower(oppId),passRate=offenseTendency(id,r),plays=c(Math.round(66+(r()-.5)*14+(score-oppScore)*.08),54,84),sacksAllowed=c(Math.round(2.2+(oppPower-power)/18+normal(r)*1.15),0,7),passAtt=c(Math.round(plays*passRate)-sacksAllowed,15,56),rushAtt=Math.max(16,plays-passAtt-sacksAllowed),yardsBase=c(Math.round(255+score*5.0+(power-70)*2.0+(r()-.5)*75),165,610),passShare=c(passRate+.04+(r()-.5)*.08,.38,.74),passYds=c(Math.round(yardsBase*passShare),75,510),rushYds=Math.max(35,yardsBase-passYds),passComp=c(Math.round(passAtt*c(.59+(power-oppPower)/450+(r()-.5)*.08,.46,.75)),8,passAtt),scoreParts=footballBreakdown(score),passTD=c(Math.round(scoreParts.td*c(passRate+(r()-.5)*.16,.20,.86)),0,scoreParts.td),rushTD=Math.max(0,scoreParts.td-passTD),turnovers=c(Math.round(1.35+(oppPower-power)/30+normal(r)*.8),0,5),passINT=c(Math.round(turnovers*(.55+r()*.25)),0,turnovers),fumbles=Math.max(0,turnovers-passINT),punts=c(Math.round(5-score/12+(r()-.5)*2),1,8),firstDowns=c(Math.round((passYds+rushYds)/18.5),10,36);return{plays,firstDowns,passAtt,passComp,passYds,passTD,passINT,rushAtt,rushYds,rushTD,totalYds:passYds+rushYds,turnovers,fumbles,sacksAllowed,fgm:scoreParts.fg,fga:scoreParts.fg+(r()<.32?1:0),xpm:scoreParts.td,xpa:scoreParts.td,punts,points:score}}
function makeScorePair(aId,bId,r,forcedWinner=null,knownScores=null){if(knownScores)return{aScore:n(knownScores.a),bScore:n(knownScores.b)};const ap=programPower(aId),bp=programPower(bId),edge=ap-bp,prob=window.SDF_V170?.probabilityFromEdge?.(edge,n(state.realismSettings?.upsetVariance,1))??(1/(1+Math.exp(-edge/8.5))),aWins=forcedWinner!=null?Number(forcedWinner)===Number(aId):r()<prob;let aTarget=26+edge*.42+normal(r)*6.5,bTarget=26-edge*.42+normal(r)*6.5,aScore=footballScore(aTarget,r),bScore=footballScore(bTarget,r);if(aScore===bScore){aWins?aScore+=3:bScore+=3}if((aScore>bScore)!==aWins){const hi=Math.max(aScore,bScore),lo=Math.min(aScore,bScore);if(aWins){aScore=hi;bScore=Math.max(3,lo)}else{bScore=hi;aScore=Math.max(3,lo)}if(aScore===bScore){aWins?aScore+=3:bScore+=3}}return{aScore,bScore}}
function lineObject(p){const out={id:p.id,name:p.name,pos:p.pos};for(const k of STAT_FIELDS)out[k]=0;return out}
function addLine(map,p,key,value){if(!p)return;const row=map.get(p.id)||lineObject(p);row[key]=n(row[key])+n(value);map.set(p.id,row)}
function buildPlayerLines(teamId,oppId,box,r){const roster=teamRoster(teamId);if(!roster.length)return[];roster.forEach(ensureStats);const qbs=active(roster,'QB',2),rbs=active(roster,'RB',3),wrs=active(roster,'WR',5),tes=active(roster,'TE',2),receivers=uniquePlayers([wrs,tes,rbs.slice(0,2)]),rushers=uniquePlayers([rbs,qbs.slice(0,1),wrs.slice(0,1)]),defs=uniquePlayers([active(roster,'EDGE',4),active(roster,'DL',4),active(roster,'LB',5),active(roster,'CB',5),active(roster,'S',4)]),kicker=active(roster,'K',1)[0],punter=active(roster,'P',1)[0],lines=new Map();
 const qbAtt=allocate(box.passAtt,qbs,(p,i)=>(i===0?8:1)*(n(p.ovr,65)/70),r),qbComp=allocate(box.passComp,qbs,(p,i)=>n(qbAtt.get(p.id))+.2,r),qbYds=allocate(box.passYds,qbs,(p,i)=>n(qbComp.get(p.id))*Math.max(1,n(p.ovr,65)/65),r),qbTd=allocate(box.passTD,qbs,p=>n(qbAtt.get(p.id))+1,r),qbInt=allocate(box.passINT,qbs,p=>n(qbAtt.get(p.id))+1,r);
 for(const p of qbs){addLine(lines,p,'passAtt',qbAtt.get(p.id));addLine(lines,p,'passComp',qbComp.get(p.id));addLine(lines,p,'passYds',qbYds.get(p.id));addLine(lines,p,'passTD',qbTd.get(p.id));addLine(lines,p,'passINT',qbInt.get(p.id))}
 const recCount=allocate(box.passComp,receivers,(p,i)=>(p.pos==='WR'?(i===0?4.2:i===1?3.5:2.6):p.pos==='TE'?2.2:1.2)*(n(p.ovr,65)/70),r),recYds=allocate(box.passYds,receivers,p=>(n(recCount.get(p.id))+.7)*(p.pos==='WR'?1.2:p.pos==='TE'?.95:.72)*(n(p.ovr,65)/70),r),recTd=allocate(box.passTD,receivers,p=>n(recYds.get(p.id))+25,r);
 for(const p of receivers){addLine(lines,p,'rec',recCount.get(p.id));addLine(lines,p,'recYds',recYds.get(p.id));addLine(lines,p,'recTD',recTd.get(p.id))}
 const rushAtt=allocate(box.rushAtt,rushers,(p,i)=>(p.pos==='RB'?(i===0?5.6:i===1?2.5:1.2):p.pos==='QB'?.75:.25)*(n(p.ovr,65)/70),r),rushYds=allocate(box.rushYds,rushers,p=>(n(rushAtt.get(p.id))+.5)*(n(p.ovr,65)/70),r),rushTd=allocate(box.rushTD,rushers,p=>n(rushAtt.get(p.id))+4,r);
 for(const p of rushers){addLine(lines,p,'rushAtt',rushAtt.get(p.id));addLine(lines,p,'rushYds',rushYds.get(p.id));addLine(lines,p,'rushTD',rushTd.get(p.id))}
 const oppBoxGuess=state._v175CurrentOppBox||null,oppPlays=n(oppBoxGuess?.plays,66),tackleTotal=c(Math.round(oppPlays*.92),46,88),tackles=allocate(tackleTotal,defs,(p,i)=>(p.pos==='LB'?3.4:['S','CB'].includes(p.pos)?2.35:2.1)*(p.starter?1.25:1)*(n(p.ovr,65)/70),r),tflTotal=c(Math.round(5+(programPower(teamId)-programPower(oppId))/12+r()*5),2,14),tfl=allocate(tflTotal,defs,p=>['EDGE','DL','LB'].includes(p.pos)?3:1,r),sackTotal=c(n(oppBoxGuess?.sacksAllowed,Math.round(2+r()*3)),0,8),sacks=allocate(sackTotal,defs,p=>['EDGE','DL'].includes(p.pos)?4:p.pos==='LB'?1.6:.1,r),intTotal=c(n(oppBoxGuess?.passINT,Math.round(r()*2)),0,5),ints=allocate(intTotal,defs,p=>['CB','S'].includes(p.pos)?3:p.pos==='LB'?1.2:.05,r),ffTotal=c(n(oppBoxGuess?.fumbles,Math.round(r()*2)),0,4),ffs=allocate(ffTotal,defs,p=>['EDGE','LB','DL'].includes(p.pos)?2.5:1,r);
 for(const p of defs){addLine(lines,p,'tackles',tackles.get(p.id));addLine(lines,p,'tfl',tfl.get(p.id));addLine(lines,p,'sacks',sacks.get(p.id));addLine(lines,p,'defINT',ints.get(p.id));addLine(lines,p,'ff',ffs.get(p.id))}
 if(kicker){addLine(lines,kicker,'fgm',box.fgm);addLine(lines,kicker,'fga',box.fga);addLine(lines,kicker,'xpm',box.xpm);addLine(lines,kicker,'xpa',box.xpa);addLine(lines,kicker,'points',box.fgm*3+box.xpm)}
 if(punter){const puntYds=box.punts*c(Math.round(42+(n(punter.ovr,65)-65)*.12+(r()-.5)*5),32,52);addLine(lines,punter,'punts',box.punts);addLine(lines,punter,'puntYds',puntYds);addLine(lines,punter,'puntLong',c(Math.round((box.punts?puntYds/box.punts:42)+rint(r,6,16)),35,68));addLine(lines,punter,'inside20',c(Math.round(box.punts*(.3+r()*.25)),0,box.punts));addLine(lines,punter,'touchbacks',c(Math.round(box.punts*(.05+r()*.12)),0,box.punts))}
 const participants=uniquePlayers([qbs,rushers,receivers,defs,kicker?[kicker]:[],punter?[punter]:[]]);for(const p of participants)addLine(lines,p,'games',1);return[...lines.values()]
}
function applyLines(teamId,oppId,week,result,lines,phase='REGULAR'){if(Number(teamId)===userId())return;const roster=teamRoster(teamId),byId=new Map(roster.map(p=>[String(p.id),p])),opp=teamName(oppId);for(const row of lines||[]){const p=byId.get(String(row.id));if(!p)continue;const s=ensureStats(p);for(const k of STAT_FIELDS){if(k==='puntLong')s[k]=Math.max(n(s[k]),n(row[k]));else s[k]=n(s[k])+n(row[k])}p.stats.games=n(p.stats.games)+n(row.games);p.stats.yards=n(p.stats.yards)+n(row.passYds)+n(row.rushYds)+n(row.recYds);p.stats.td=n(p.stats.td)+n(row.passTD)+n(row.rushTD)+n(row.recTD);p.stats.tackles=n(p.stats.tackles)+n(row.tackles);p.stats.sacks=n(p.stats.sacks)+n(row.sacks);p.stats.int=n(p.stats.int)+n(row.defINT);const gameLine={year:state.year,week,opponent:opp,result,phase};for(const k of STAT_FIELDS)if(k!=='games'&&n(row[k]))gameLine[k]=n(row[k]);p.gameLog.push(gameLine)}}
function emptyTeamSeason(id){return{year:state.year,teamId:Number(id),games:0,w:0,l:0,pointsFor:0,pointsAgainst:0,passYds:0,rushYds:0,totalYds:0,yardsAllowed:0,passYdsAllowed:0,rushYdsAllowed:0,passTD:0,rushTD:0,turnovers:0,sacks:0,takeaways:0}}
function teamSeason(id){state.teamSeasonStats??={};const key=String(id),row=state.teamSeasonStats[key];if(!row||Number(row.year)!==Number(state.year))state.teamSeasonStats[key]=emptyTeamSeason(id);return state.teamSeasonStats[key]}
function applyTeamBox(teamId,box,oppBox,score,oppScore,won){const s=teamSeason(teamId);s.games++;won?s.w++:s.l++;s.pointsFor+=n(score);s.pointsAgainst+=n(oppScore);s.passYds+=n(box.passYds);s.rushYds+=n(box.rushYds);s.totalYds+=n(box.totalYds);s.yardsAllowed+=n(oppBox.totalYds);s.passYdsAllowed+=n(oppBox.passYds);s.rushYdsAllowed+=n(oppBox.rushYds);s.passTD+=n(box.passTD);s.rushTD+=n(box.rushTD);s.turnovers+=n(box.turnovers);s.sacks+=n(oppBox.sacksAllowed);s.takeaways+=n(oppBox.turnovers)}
function resultKey(year,week,aId,bId,phase='REGULAR',label=''){const lo=Math.min(Number(aId),Number(bId)),hi=Math.max(Number(aId),Number(bId));return`${year}-${phase}-${week}-${lo}-${hi}-${hash(label)%10007}`}
function hasResult(key){return(state.nationalGameResults||[]).some(g=>g.key===key)}
function recordGame({year=state.year,week=state.week,phase='REGULAR',label='',aId,bId,aScore,bScore,aBox=null,bBox=null,conference=false,forcedWinner=null,exactLines={}}={}){aId=Number(aId);bId=Number(bId);if(!Number.isFinite(aId)||!Number.isFinite(bId)||aId===bId)return null;state.nationalGameResults??=[];const key=resultKey(year,week,aId,bId,phase,label);const existing=state.nationalGameResults.find(g=>g.key===key);if(existing)return existing;const scoreR=rng(`${key}-score-v175`),scores=makeScorePair(aId,bId,scoreR,forcedWinner,aScore!=null&&bScore!=null?{a:aScore,b:bScore}:null);aScore=scores.aScore;bScore=scores.bScore;aBox=aBox||buildTeamBox(aId,bId,aScore,bScore,rng(`${key}-abox-v175`));bBox=bBox||buildTeamBox(bId,aId,bScore,aScore,rng(`${key}-bbox-v175`));state._v175CurrentOppBox=bBox;const aLines=exactLines[aId]||buildPlayerLines(aId,bId,aBox,rng(`${key}-aline-v175`));state._v175CurrentOppBox=aBox;const bLines=exactLines[bId]||buildPlayerLines(bId,aId,bBox,rng(`${key}-bline-v175`));delete state._v175CurrentOppBox;const aWon=aScore>bScore,bWon=bScore>aScore;applyLines(aId,bId,week,aWon?'W':'L',aLines,phase);applyLines(bId,aId,week,bWon?'W':'L',bLines,phase);applyTeamBox(aId,aBox,bBox,aScore,bScore,aWon);applyTeamBox(bId,bBox,aBox,bScore,aScore,bWon);const compactExact={};if(exactLines[aId])compactExact[aId]=aLines;if(exactLines[bId])compactExact[bId]=bLines;const row={key,year:Number(year),week:Number(week),phase,label,aId,bId,aScore,bScore,conference:!!conference,aBox,bBox,exactLines:compactExact};state.nationalGameResults.push(row);state.nationalGameResults=state.nationalGameResults.filter(x=>Number(x.year)===Number(state.year)).slice(-950);state.nationalStats=[];return row}
function rebuildCurrentSeason(){if(!state.school)return;window.SDF_AI_ROSTERS?.ensureAll?.();zeroCurrentAiStats();state.teamSeasonStats={};const rows=(state.nationalGameResults||[]).filter(x=>Number(x.year)===Number(state.year));for(const g of rows){state._v175CurrentOppBox=g.bBox;const aLines=g.exactLines?.[g.aId]||buildPlayerLines(g.aId,g.bId,g.aBox,rng(`${g.key}-aline-v175`));state._v175CurrentOppBox=g.aBox;const bLines=g.exactLines?.[g.bId]||buildPlayerLines(g.bId,g.aId,g.bBox,rng(`${g.key}-bline-v175`));delete state._v175CurrentOppBox;applyLines(g.aId,g.bId,g.week,g.aScore>g.bScore?'W':'L',aLines,g.phase);applyLines(g.bId,g.aId,g.week,g.bScore>g.aScore?'W':'L',bLines,g.phase);applyTeamBox(g.aId,g.aBox,g.bBox,g.aScore,g.bScore,g.aScore>g.bScore);applyTeamBox(g.bId,g.bBox,g.aBox,g.bScore,g.aScore,g.bScore>g.aScore)}refreshUserTeamFromRoster();state._v175StatsReady=1;return rows.length}
function refreshUserTeamFromRoster(){if(!state.school)return;const id=userId(),s=teamSeason(id),played=(state.schedule||[]).filter(g=>g.result&&g.score),post=(state.nationalGameResults||[]).filter(g=>Number(g.year)===Number(state.year)&&(Number(g.aId)===id||Number(g.bId)===id));if(post.length)return;const totals=(state.roster||[]).reduce((a,p)=>{const x=ensureStats(p);a.passYds+=n(x.passYds);a.rushYds+=n(x.rushYds);a.passTD+=n(x.passTD);a.rushTD+=n(x.rushTD);a.turnovers+=n(x.passINT);a.sacks+=n(x.sacks);a.takeaways+=n(x.defINT);return a},{passYds:0,rushYds:0,passTD:0,rushTD:0,turnovers:0,sacks:0,takeaways:0});s.games=played.length;s.w=n(state.record?.w);s.l=n(state.record?.l);s.pointsFor=played.reduce((a,g)=>a+n(String(g.score).split('-')[0]),0);s.pointsAgainst=played.reduce((a,g)=>a+n(String(g.score).split('-')[1]),0);s.passYds=totals.passYds;s.rushYds=totals.rushYds;s.totalYds=totals.passYds+totals.rushYds;s.passTD=totals.passTD;s.rushTD=totals.rushTD;s.turnovers=totals.turnovers;s.sacks=totals.sacks;s.takeaways=totals.takeaways}
function backfillLegacySeason(){if(!state.school||!(state.aiRosters&&Object.keys(state.aiRosters).length))return 0;state.nationalGameResults??=[];let added=0;const known=new Set(state.nationalGameResults.map(x=>x.key));for(const h of state.headToHeadResults||[]){if(Number(h.year)!==Number(state.year))continue;const aId=Number(h.winner),bId=Number(h.loser),key=resultKey(state.year,h.week,aId,bId,'REGULAR','Legacy backfill');if(known.has(key)||aId===userId()||bId===userId())continue;recordGame({year:state.year,week:h.week,phase:'REGULAR',label:'Legacy backfill',aId,bId,conference:!!h.conference,forcedWinner:aId});known.add(key);added++}
 for(const g of state.schedule||[]){if(!g.result||!g.score)continue;const oppId=Number(g.oppId),key=resultKey(state.year,g.week,userId(),oppId,'REGULAR','User legacy backfill');if(known.has(key))continue;const parts=String(g.score).split('-').map(Number);recordGame({year:state.year,week:g.week,phase:'REGULAR',label:'User legacy backfill',aId:userId(),bId:oppId,aScore:n(parts[0]),bScore:n(parts[1]),conference:!!g.conference});known.add(key);added++}
 return added}
function simulateWorldWeek175(){if(!state.school)return;ensureNationalState();const week=Number(state.week),year=Number(state.year),worldKey=`${year}-${week}`;state.nationalWorldWeeks??=[];if(state.nationalWorldWeeks.includes(worldKey)){window.updateRankings?.();return state.lastWorldResults||[]}
 const userOpponent=(state.schedule||[]).find(g=>Number(g.week)===week)?.oppId,teams=(state.world||[]).filter(t=>Number(t.id)!==userId()&&Number(t.id)!==Number(userOpponent)),seed=(year*97+week*31)%997,ordered=teams.slice().sort((a,b)=>((n(a.id)*37+seed)%1009)-((n(b.id)*37+seed)%1009)),used=new Set(),results=[];
 for(const a of ordered){if(used.has(a.id))continue;let pool=ordered.filter(b=>!used.has(b.id)&&Number(b.id)!==Number(a.id)),same=pool.filter(b=>b.conference===a.conference),b=((week>=3&&week<=10)&&same.length?same:pool)[0];if(!b)continue;used.add(a.id);used.add(b.id);const aId=Number(a.id),bId=Number(b.id),r=rng(`world-${year}-${week}-${aId}-${bId}`),ap=programPower(aId),bp=programPower(bId),homeEdge=1.5,formA=normal(r)*4.6*n(state.realismSettings?.upsetVariance,1),formB=normal(r)*4.6*n(state.realismSettings?.upsetVariance,1),edge=ap-bp+homeEdge+formA-formB,p=window.SDF_V170?.probabilityFromEdge?.(edge,n(state.realismSettings?.upsetVariance,1))??(1/(1+Math.exp(-edge/8.5))),aWins=r()<p,winner=aWins?a:b,loser=aWins?b:a,row=recordGame({year,week,phase:'REGULAR',label:'National schedule',aId,bId,conference:a.conference===b.conference,forcedWinner:winner.id});winner.record??={w:0,l:0};loser.record??={w:0,l:0};winner.record.w++;loser.record.l++;if(a.conference===b.conference){state.conferenceRecords??={};state.conferenceRecords[aId]??={w:0,l:0};state.conferenceRecords[bId]??={w:0,l:0};state.conferenceRecords[Number(winner.id)].w++;state.conferenceRecords[Number(loser.id)].l++}state.headToHeadResults??=[];state.headToHeadResults.push({year,week,winner:Number(winner.id),loser:Number(loser.id),conference:a.conference===b.conference});winner.recent=c(n(winner.recent)+.35,20,99);loser.recent=c(n(loser.recent)-.25,20,99);results.push({winner:winner.name,loser:loser.name,winnerId:Number(winner.id),loserId:Number(loser.id),winnerPower:programPower(winner.id),loserPower:programPower(loser.id),favoriteWin:(ap>=bp?winner.id===a.id:winner.id===b.id),upset:(ap>=bp?winner.id!==a.id:winner.id!==b.id)&&Math.abs(ap-bp)>=3,winProbability:winner.id===a.id?p:1-p,score:row?`${row.aScore}-${row.bScore}`:''})}
 state.nationalWorldWeeks.push(worldKey);state.nationalWorldWeeks=state.nationalWorldWeeks.filter(k=>String(k).startsWith(`${year}-`));state.lastWorldResults=results;state.headToHeadResults=state.headToHeadResults.slice(-700);window.updateRankings?.();return results
}
function exactLiveLines(game,teamId){const ids=new Set(teamRoster(teamId).map(p=>String(p.id))),rows=[];for(const s of Object.values(game.playerStats||{})){if(!ids.has(String(s.id)))continue;const row={id:s.id,name:s.name,pos:s.pos};for(const k of STAT_FIELDS)row[k]=n(s[k]);row.games=1;rows.push(row)}return rows}
function liveTeamBox(game,side,lines=[]){const t=game.stats?.[side]||{},score=n(game.score?.[side]),parts=footballBreakdown(score),sum=k=>lines.reduce((a,x)=>a+n(x[k]),0),passINT=sum('passINT'),fgm=sum('fgm'),fga=sum('fga'),xpm=sum('xpm'),xpa=sum('xpa');return{plays:n(t.plays),firstDowns:n(t.firstDowns),passAtt:n(t.passAtt),passComp:n(t.passComp),passYds:n(t.passYds),passTD:sum('passTD'),passINT,rushAtt:n(t.rushAtt),rushYds:n(t.rushYds),rushTD:sum('rushTD'),totalYds:n(t.totalYds),turnovers:n(t.turnovers),fumbles:Math.max(0,n(t.turnovers)-passINT),sacksAllowed:n(t.sacks),fgm:fgm||parts.fg,fga:fga||fgm||parts.fg,xpm:xpm||parts.td,xpa:xpa||xpm||parts.td,punts:sum('punts'),points:score}}
function recordLiveGame(game){if(!game||!state.school)return null;const aId=userId(),bId=Number(game.oppId),userLines=exactLiveLines(game,aId),oppLines=exactLiveLines(game,bId),exact={};exact[bId]=oppLines;const aBox=liveTeamBox(game,'us',userLines),bBox=liveTeamBox(game,'them',oppLines);return recordGame({year:game.year||state.year,week:game.week||state.week,phase:game.contextType||'REGULAR',label:game.gameLabel||`Week ${game.week}`,aId,bId,aScore:n(game.score.us),bScore:n(game.score.them),aBox,bBox,conference:!!game.conference,exactLines:exact})}
function afterQuickSim(w){const g=state.schedule?.[Number(w)-1];if(!g?.result||!g.score)return;const key=resultKey(state.year,g.week,userId(),g.oppId,'REGULAR',`Week ${g.week}`);if(hasResult(key))return;const [us,them]=String(g.score).split('-').map(Number),recap=state.lastGameRecap||{},u=recap.boxScore||{},r=rng(`quick-user-${state.year}-${g.week}-${g.oppId}`),aBox={plays:c(Math.round((n(u.passYds)+n(u.rushYds))/5.8),50,85),firstDowns:n(u.firstDowns),passAtt:0,passComp:0,passYds:n(u.passYds),passTD:0,passINT:n(u.turnovers),rushAtt:0,rushYds:n(u.rushYds),rushTD:0,totalYds:n(u.totalYds,n(u.passYds)+n(u.rushYds)),turnovers:n(u.turnovers),fumbles:0,sacksAllowed:n(u.sacksAllowed),fgm:footballBreakdown(us).fg,fga:footballBreakdown(us).fg,xpm:footballBreakdown(us).td,xpa:footballBreakdown(us).td,punts:0,points:us},bBox=buildTeamBox(g.oppId,userId(),them,us,r);recordGame({year:state.year,week:g.week,phase:'REGULAR',label:`Week ${g.week}`,aId:userId(),bId:g.oppId,aScore:us,bScore:them,aBox,bBox,conference:!!g.conference})}
function archiveAiPlayerSeason(p,teamId,name,year=state.year){const s=ensureStats(p);if(n(s.games)>0){const h={year:Number(year),team:name||teamName(teamId),ovr:n(p.ovr),games:n(s.games)};const fields=p.pos==='QB'?['passAtt','passComp','passYds','passTD','passINT','rushAtt','rushYds','rushTD']:['RB','FB'].includes(p.pos)?['rushAtt','rushYds','rushTD','rec','recYds','recTD']:['WR','TE'].includes(p.pos)?['rec','recYds','recTD']:['EDGE','DL','LB','CB','S'].includes(p.pos)?['tackles','tfl','sacks','defINT','ff']:p.pos==='K'?['fgm','fga','xpm','xpa','points']:p.pos==='P'?['punts','puntYds','puntLong','inside20','touchbacks']:[];for(const k of fields)if(n(s[k]))h[k]=n(s[k]);p.statHistory=(p.statHistory||[]).filter(x=>Number(x.year)!==Number(year)).concat(h).slice(-4)}p.seasonStats=emptyStats();p.gameLog=[];p.stats={games:0,yards:0,td:0,tackles:0,sacks:0,int:0};return p}
function allPlayers(){const rows=[];if(state.school)for(const p of state.roster||[])rows.push({teamId:userId(),team:state.school.name,conference:state.school.conference,p,s:ensureStats(p)});for(const school of schools||[]){if(Number(school.id)===userId())continue;const conf=conferenceOf(school.id);for(const p of teamRoster(school.id))rows.push({teamId:Number(school.id),team:school.name,conference:conf,p,s:ensureStats(p)})}return rows}
function playerValue(row,key){const d=PLAYER_CATEGORIES[key],s=row.s,g=Math.max(1,n(s.games));if(d.field==='puntAvg')return n(s.punts)?n(s.puntYds)/n(s.punts):0;if(d.field==='fgPct')return n(s.fga)?n(s.fgm)/n(s.fga)*100:0;if(d.field==='passPct')return n(s.passAtt)?n(s.passComp)/n(s.passAtt)*100:0;if(d.field==='passEff')return n(s.passAtt)?(8.4*n(s.passYds)+330*n(s.passTD)+100*n(s.passComp)-200*n(s.passINT))/n(s.passAtt):0;if(d.field==='passYpg')return n(s.passYds)/g;if(d.field==='rushYpg')return n(s.rushYds)/g;if(d.field==='recYpg')return n(s.recYds)/g;if(d.field==='rushAvg')return n(s.rushAtt)?n(s.rushYds)/n(s.rushAtt):0;if(d.field==='recAvg')return n(s.rec)?n(s.recYds)/n(s.rec):0;return n(s[d.field])}
function filteredPlayerRows(){const d=PLAYER_CATEGORIES[ui.category]||PLAYER_CATEGORIES.PASS_YDS;let rows=allPlayers().filter(x=>(!d.positions||d.positions.includes(x.p.pos))&&n(x.s[d.min||'games'])>0);if(ui.conference!=='ALL')rows=rows.filter(x=>x.conference===ui.conference);if(ui.team!=='ALL')rows=rows.filter(x=>Number(x.teamId)===Number(ui.team));return rows.sort((a,b)=>playerValue(b,ui.category)-playerValue(a,ui.category)||n(b.p.ovr)-n(a.p.ovr)||a.p.name.localeCompare(b.p.name))}
function teamRows(){const rows=(schools||[]).map(s=>{const x=teamSeason(s.id),g=Math.max(1,n(x.games));return{teamId:Number(s.id),team:s.name,conference:conferenceOf(s.id),games:n(x.games),record:Number(s.id)===userId()?`${n(state.record?.w)}-${n(state.record?.l)}`:`${n(worldById(s.id)?.record?.w)}-${n(worldById(s.id)?.record?.l)}`,ppg:n(x.pointsFor)/g,paPg:n(x.pointsAgainst)/g,offYpg:n(x.totalYds)/g,defYpg:n(x.yardsAllowed)/g,passYpg:n(x.passYds)/g,rushYpg:n(x.rushYds)/g,passDefYpg:n(x.passYdsAllowed)/g,rushDefYpg:n(x.rushYdsAllowed)/g,sacks:n(x.sacks),takeaways:n(x.takeaways),turnovers:n(x.turnovers),turnoverMargin:n(x.takeaways)-n(x.turnovers)}});return rows}
function filteredTeamRows(){const d=TEAM_CATEGORIES[ui.category]||TEAM_CATEGORIES.PPG;let rows=teamRows().filter(x=>x.games>0);if(ui.conference!=='ALL')rows=rows.filter(x=>x.conference===ui.conference);if(ui.team!=='ALL')rows=rows.filter(x=>Number(x.teamId)===Number(ui.team));return rows.sort((a,b)=>d.ascending?n(a[d.field])-n(b[d.field]):n(b[d.field])-n(a[d.field])||a.team.localeCompare(b.team))}
function fmtPlayer(row,key){const v=playerValue(row,key);if(['PUNT_AVG','PASS_EFF','PASS_YPG','RUSH_YPG','REC_YPG','RUSH_AVG','REC_AVG'].includes(key))return v.toFixed(1);if(['PASS_PCT','FG_PCT'].includes(key))return `${v.toFixed(1)}%`;return Math.round(v).toLocaleString()}
function renderControls(){const categoryDefs=ui.view==='PLAYERS'?PLAYER_CATEGORIES:TEAM_CATEGORIES;if(!categoryDefs[ui.category])ui.category=ui.view==='PLAYERS'?'PASS_YDS':'PPG';const confs=[...new Set((schools||[]).map(s=>conferenceOf(s.id)))].sort(),teams=(schools||[]).slice().sort((a,b)=>a.name.localeCompare(b.name));return`<div class="national-stats-controls"><div class="toolbar compact"><select id="nationalStatsView"><option value="PLAYERS" ${ui.view==='PLAYERS'?'selected':''}>Player Leaders</option><option value="TEAMS" ${ui.view==='TEAMS'?'selected':''}>Team Rankings</option></select><select id="nationalStatsCategory">${Object.entries(categoryDefs).map(([k,d])=>`<option value="${k}" ${ui.category===k?'selected':''}>${esc(d.label)}</option>`).join('')}</select><select id="nationalStatsConference"><option value="ALL">All Conferences</option>${confs.map(x=>`<option ${ui.conference===x?'selected':''}>${esc(x)}</option>`).join('')}</select><select id="nationalStatsTeam"><option value="ALL">All Teams</option>${teams.map(s=>`<option value="${s.id}" ${String(ui.team)===String(s.id)?'selected':''}>${esc(s.name)}</option>`).join('')}</select></div><p class="muted">These are live dynasty statistics from the actual persistent rosters. AI games now create real player lines and team totals instead of placeholder national leaders.</p></div>`}
function renderPlayerNational(){const rows=filteredPlayerRows(),d=PLAYER_CATEGORIES[ui.category]||PLAYER_CATEGORIES.PASS_YDS,top=rows.slice(0,ui.limit);return`${renderControls()}<div class="metric-grid">${typeof metric==='function'?metric('Tracked Players',allPlayers().length)+metric('Teams with Stats',teamRows().filter(x=>x.games>0).length)+metric('Leader',top[0]?`${top[0].p.name} · ${fmtPlayer(top[0],ui.category)}`:'—')+metric('Scope',ui.team!=='ALL'?teamName(ui.team):ui.conference!=='ALL'?ui.conference:'National') :''}</div><div class="table-wrap"><table><thead><tr><th>Rank</th><th>Player</th><th>Team</th><th>Pos</th><th>G</th><th>${esc(d.label)}</th></tr></thead><tbody>${top.map((x,i)=>`<tr><td>${i+1}</td><td><button class="link-button" onclick="openNationalPlayerStats175(${x.teamId},'${String(x.p.id).replaceAll("'","\\'")}')">${esc(x.p.name)}</button></td><td>${esc(x.team)}</td><td>${x.p.pos}</td><td>${n(x.s.games)}</td><td><b>${fmtPlayer(x,ui.category)}</b></td></tr>`).join('')||'<tr><td colspan="6">No statistics recorded in this scope yet.</td></tr>'}</tbody></table></div>`}
function renderTeamNational(){const rows=filteredTeamRows(),d=TEAM_CATEGORIES[ui.category]||TEAM_CATEGORIES.PPG,top=rows.slice(0,ui.limit),decimals=['PPG','OFF_YPG','PASS_YPG','RUSH_YPG','SCORING_DEF','YARDS_DEF','PASS_DEF','RUSH_DEF'].includes(ui.category);return`${renderControls()}<div class="table-wrap"><table><thead><tr><th>Rank</th><th>Team</th><th>Conference</th><th>Record</th><th>G</th><th>${esc(d.label)}</th></tr></thead><tbody>${top.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.team)}</td><td>${esc(x.conference)}</td><td>${x.record}</td><td>${x.games}</td><td><b>${decimals?n(x[d.field]).toFixed(1):Math.round(n(x[d.field]))}</b></td></tr>`).join('')||'<tr><td colspan="6">No team statistics recorded yet.</td></tr>'}</tbody></table></div>`}
function wireNationalControls(){const view=document.getElementById('nationalStatsView'),cat=document.getElementById('nationalStatsCategory'),conf=document.getElementById('nationalStatsConference'),team=document.getElementById('nationalStatsTeam');if(view)view.onchange=e=>{ui.view=e.target.value;ui.category=ui.view==='PLAYERS'?'PASS_YDS':'PPG';renderNationalStats()};if(cat)cat.onchange=e=>{ui.category=e.target.value;renderNationalStats()};if(conf)conf.onchange=e=>{ui.conference=e.target.value;renderNationalStats()};if(team)team.onchange=e=>{ui.team=e.target.value;renderNationalStats()}}
function renderNationalStats(){const host=document.getElementById('nationalLeaderGrid');if(!host||!state.school)return;ensureNationalState();host.innerHTML=ui.view==='TEAMS'?renderTeamNational():renderPlayerNational();wireNationalControls()}
function awardScore(x){const s=x.s;return n(s.passYds)/18+n(s.passTD)*7-n(s.passINT)*4+n(s.rushYds)/10+n(s.rushTD)*7+n(s.recYds)/10+n(s.recTD)*7+n(s.tackles)+n(s.tfl)*1.8+n(s.sacks)*5+n(s.defINT)*7+n(s.points)/3+n(x.p.ovr)/4}
function renderAwardWatchNational(){const host=document.getElementById('awardWatchGrid');if(!host)return;const candidates=allPlayers().filter(x=>n(x.s.games)>0).sort((a,b)=>awardScore(b)-awardScore(a)).slice(0,12);host.innerHTML=candidates.map((x,i)=>`<div class="award-watch-card"><span class="eyebrow">#${i+1} NATIONAL BALLOT</span><h4>${esc(x.p.name)}</h4><b>${x.p.pos} · ${esc(x.team)} · OVR ${x.p.ovr}</b><span class="sub">${typeof playerStatLine==='function'&&Number(x.teamId)===userId()?esc(playerStatLine(x.p)):esc(statSummary(x.p))}</span></div>`).join('')||'<p class="muted">National award candidates emerge as games are played.</p>'}
function statSummary(p){const s=ensureStats(p);if(p.pos==='QB')return`${s.passComp}/${s.passAtt}, ${s.passYds} pass yds, ${s.passTD} TD, ${s.passINT} INT`;if(['RB','FB'].includes(p.pos))return`${s.rushAtt} car, ${s.rushYds} rush yds, ${s.rushTD} TD`;if(['WR','TE'].includes(p.pos))return`${s.rec} rec, ${s.recYds} yds, ${s.recTD} TD`;if(['EDGE','DL','LB','CB','S'].includes(p.pos))return`${s.tackles} tackles, ${s.tfl} TFL, ${s.sacks} sacks, ${s.defINT} INT`;if(p.pos==='K')return`${s.fgm}/${s.fga} FG, ${s.xpm}/${s.xpa} XP, ${s.points} pts`;if(p.pos==='P')return`${s.punts} punts, ${s.punts?(s.puntYds/s.punts).toFixed(1):'0.0'} avg`;return`${s.games} games`}
window.openNationalPlayerStats175=function(teamId,playerId){const school=teamById(teamId),p=teamRoster(teamId).find(x=>String(x.id)===String(playerId));if(!school||!p)return;const s=ensureStats(p),history=(p.statHistory||[]).slice().reverse();const body=document.getElementById('modalBody');if(!body)return;body.innerHTML=`<span class="eyebrow">NATIONAL PLAYER PROFILE</span><h2>${esc(p.name)}</h2><p class="muted">${esc(school.name)} · ${p.pos} · ${typeof classLabel==='function'?classLabel(p):`Year ${p.year}`} · ${p.ovr} OVR</p><div class="metric-grid">${typeof metric==='function'?metric('Games',s.games)+metric('Season',statSummary(p))+metric('OVR',p.ovr)+metric('Potential',p.pot):''}</div><h3>Weekly Game Log</h3><div class="game-log-grid">${(p.gameLog||[]).slice().reverse().map(g=>`<div class="game-log-card"><b>${esc(g.phase==='REGULAR'?`Week ${g.week}`:g.phase)} vs ${esc(g.opponent)}</b><span class="sub">${esc(g.result)} · ${Object.entries(g).filter(([k,v])=>!['year','week','opponent','result','phase'].includes(k)&&n(v)!==0).map(([k,v])=>`${k}: ${v}`).join(' · ')}</span></div>`).join('')||'<p class="muted">No games recorded yet.</p>'}</div><h3>Career History</h3><div class="stat-archive-grid">${history.map(h=>`<div class="stat-archive-card"><h4>Year ${h.year}</h4><b>${esc(h.team||school.name)} · ${h.games||0} games</b><span class="sub">${Object.entries(h).filter(([k,v])=>!['year','team','ovr','games'].includes(k)&&n(v)!==0).map(([k,v])=>`${k}: ${v}`).join(' · ')||'No recorded production'}</span></div>`).join('')||'<p class="muted">Career history appears after a completed season.</p>'}</div>`;document.getElementById('modal')?.classList.remove('hidden')}
function ensureNationalState(){if(!state.school)return;state.nationalGameResults??=[];state.nationalWorldWeeks??=[];state.teamSeasonStats??={};window.SDF_AI_ROSTERS?.ensureAll?.();let missing=false;for(const roster of Object.values(state.aiRosters||{})){if((roster||[]).some(p=>!p.seasonStats)){missing=true;break}}if(missing&&state.nationalGameResults.length)rebuildCurrentSeason();else for(const roster of Object.values(state.aiRosters||{}))for(const p of roster||[])ensureStats(p);refreshUserTeamFromRoster()}
function rehydrate(){if(!state.school)return;window.SDF_AI_ROSTERS?.ensureAll?.();state.teamSeasonStats={};if((state.nationalGameResults||[]).length)rebuildCurrentSeason();else{for(const roster of Object.values(state.aiRosters||{}))for(const p of roster||[])ensureStats(p);backfillLegacySeason();if((state.nationalGameResults||[]).length)rebuildCurrentSeason()}renderNationalStats()}
const priorBeginYear=window.beginYear;window.beginYear=function(...args){const out=priorBeginYear?.apply(this,args);if(state.school){state.nationalGameResults=[];state.nationalWorldWeeks=[];state.teamSeasonStats={};zeroCurrentAiStats();for(const roster of Object.values(state.aiRosters||{}))for(const p of roster||[])ensureStats(p)}return out};
const priorNeutral=window.simulateNeutralGame;if(typeof priorNeutral==='function')window.simulateNeutralGame=function(a,b,label,...args){const result=priorNeutral.call(this,a,b,label,...args);try{if(result&&Number(a?.id)!==userId()&&Number(b?.id)!==userId())recordGame({year:state.year,week:state.week,phase:'POSTSEASON',label,aId:a.id,bId:b.id,aScore:result.aScore,bScore:result.bScore,conference:a.conference===b.conference})}catch(err){console.warn('National postseason stats recovery',err)}return result};
function afterRender(){if(state.school){ensureNationalState();renderNationalStats();renderAwardWatchNational()}}
window.renderNationalLeaders=renderNationalStats;
window.openNationalPlayerProfile=function(teamId,playerId){if(Number(teamId)===userId())return window.openPlayerProfile?.(playerId);return window.openNationalPlayerStats175?.(teamId,playerId)};
window.SDF_V175={version:VERSION,STAT_FIELDS,PLAYER_CATEGORIES,TEAM_CATEGORIES,ensure:ensureNationalState,rehydrate,rebuildCurrentSeason,backfillLegacySeason,recordGame,recordLiveGame,afterQuickSim,archiveAiPlayerSeason,simulateWorldWeek:simulateWorldWeek175,renderNationalStats,afterRender,allPlayers,teamRows,statSummary};
if(state?.school)setTimeout(()=>{try{rehydrate();window.renderAll?.()}catch(err){console.warn('National stats migration recovered',err)}},0);
})();
(()=>{
'use strict';
const VERSION='1.5.0';
function checks(){
 const a=window.SDF_RECRUITING_V2?.ACTIONS||{};
 return{
  version:VERSION,
  hours:Number(state?.recruitingHoursCapacity||window.calculateRecruitingHours?.()||0),
  remaining:Number(state?.weeklyHours||0),
  contactCap:Number(window.SDF_RECRUITING_V2?.CONTACT_CAP||0),
  coachVisit:Number(a.COACH_VISIT?.hours||0),
  nilNegotiation:typeof window.submitNilOffer==='function',
  modernRenderer:window.renderRecruiting===window.SDF_RECRUITING_V2?.renderRecruitingV2||!!window.SDF_RECRUITING_V2?.renderRecruitingV2,
  financeProtected:Number(state?.budget||0)>=0,
  gameCenterRequired:window.SDF_V12_TEST?.requiredGameCenter===true
 }
}
function render(){
 const host=document.getElementById('cleanCoreVerification');if(!host||!state?.school)return;
 const c=checks(),ok=c.hours>=350&&c.contactCap===50&&c.coachVisit===50&&c.nilNegotiation&&c.modernRenderer&&c.financeProtected&&c.gameCenterRequired;
 host.className=`android-build-verification ${ok?'verified':'verification-error'}`;
 host.innerHTML=`<b>${ok?'✓ CLEAN CORE ACTIVE':'⚠ CLEAN CORE CHECK FAILED'} · V${VERSION}</b><span>${c.hours} weekly capacity · ${c.remaining} remaining · ${c.contactCap} max per recruit · Coach Visit ${c.coachVisit} hrs · Adjustable NIL · Game Center required</span>`;
}
function beforeRender(){window.migrateDynastyCore?.()}
function afterRender(out){render();return out}
window.SDF_CLEAN_CORE={VERSION,checks,render,lifecycle:{beforeRender,afterRender}};
})();
(()=>{
'use strict';
const VERSION='1.7.5';
const v163=window.SDF_V163||{};
const v170=window.SDF_V170||{};
const v175=window.SDF_V175||{};
const clean=window.SDF_CLEAN_CORE||{};
const base={
 renderAll:window.renderAll,
 start:window.start,
 offseason:window.offseason,
 finishSeason:window.finishSeason,
 finishOffseason:window.finishOffseason,
 acceptJob:window.acceptJob,
 openRecruit:window.openRecruit,
 openRecruitQuickMenu:window.openRecruitQuickMenu,
 teamRatings:window.teamRatings,
 simGame:window.simGame,
 openLiveGameCenter:window.openLiveGameCenter
};
const installed={};
function install(name,fn){window[name]=fn;installed[name]=fn}
function resolveAsync(value,done){return value&&typeof value.then==='function'?value.then(done):done(value)}

install('teamRatings',function(...args){
 const raw=base.teamRatings?.apply(this,args)||{offense:65,defense:65,special:65,overall:65};
 return v170.enhanceTeamRatings?v170.enhanceTeamRatings(raw):raw
});

install('simGame',function(...args){
 const week=args[0],before=state.schedule?.[Number(week)-1]?.result;
 const result=v170.runSimGame?v170.runSimGame(base.simGame,this,args):base.simGame?.apply(this,args);
 return resolveAsync(result,value=>{if(!before){try{v175.afterQuickSim?.(week,before)}catch(error){console.warn('National quick-sim stats recovery',error)}}return value})
});

install('openLiveGameCenter',function(...args){
 return v170.runOpenLive?v170.runOpenLive(base.openLiveGameCenter,this,args):base.openLiveGameCenter?.apply(this,args)
});

install('start',function(...args){
 v170.lifecycle?.beforeStart?.();
 const context=v163.lifecycle?.beforeStart?.()||{};
 const result=base.start?.apply(this,args);
 return resolveAsync(result,value=>{
  v163.lifecycle?.afterStart?.(context,value);
  v170.lifecycle?.afterStart?.(value);
  window.renderAll?.();
  return value
 })
});

install('acceptJob',function(...args){
 const context=v163.lifecycle?.beforeAcceptJob?.();
 const result=base.acceptJob?.apply(this,args);
 const finalized=v163.lifecycle?.afterAcceptJob?.(context,result)||{result,changed:false};
 if(finalized.changed)window.renderAll?.();
 return finalized.result
});

install('offseason',function(...args){
 v163.lifecycle?.beforeOffseason?.();
 const progressionSnapshot=v170.lifecycle?.beforeOffseason?.()||new Map();
 let result=v170.lifecycle?.invokeOffseason?v170.lifecycle.invokeOffseason(base.offseason,this,args):base.offseason?.apply(this,args);
 result=v163.lifecycle?.afterOffseason?.(result)??result;
 result=v170.lifecycle?.afterOffseason?.(progressionSnapshot,result)??result;
 return result
});

install('finishSeason',function(...args){
 v170.lifecycle?.beforeFinishSeason?.();
 let result=v170.lifecycle?.invokeFinishSeason?v170.lifecycle.invokeFinishSeason(base.finishSeason,this,args):base.finishSeason?.apply(this,args);
 result=v163.lifecycle?.afterFinishSeason?.(result)??result;
 result=v170.lifecycle?.afterFinishSeason?.(result)??result;
 window.renderAll?.();
 return result
});

install('finishOffseason',function(...args){
 const oldYear=state.year;
 const result=base.finishOffseason?.apply(this,args);
 return resolveAsync(result,value=>v170.lifecycle?.afterFinishOffseason?.(oldYear,value)??value)
});

install('openRecruit',function(id,...args){
 const result=base.openRecruit?.call(this,id,...args);
 v163.lifecycle?.afterRecruitOpen?.(id);
 v170.lifecycle?.afterRecruitOpen?.(id);
 return result
});

install('openRecruitQuickMenu',function(id,...args){
 const result=base.openRecruitQuickMenu?.call(this,id,...args);
 v163.lifecycle?.afterRecruitOpen?.(id);
 v170.lifecycle?.afterRecruitOpen?.(id);
 return result
});

let rendering=false;
install('renderAll',function(...args){
 if(rendering)return base.renderAll?.apply(this,args);
 rendering=true;
 try{
  clean.lifecycle?.beforeRender?.();
  v163.lifecycle?.beforeRender?.();
  v170.lifecycle?.beforeRender?.();
  let result=base.renderAll?.apply(this,args);
  result=v163.lifecycle?.afterRender?.(result)??result;
  result=v170.lifecycle?.afterRender?.(result)??result;
  v175.afterRender?.(result);
  result=clean.lifecycle?.afterRender?.(result)??result;
  return result
 }finally{rendering=false}
});

if(v175.simulateWorldWeek)window.simulateWorldWeek=v175.simulateWorldWeek;
else if(v170.simulateWorldWeek)window.simulateWorldWeek=v170.simulateWorldWeek;
else if(v163.simulateWorldWeek163)window.simulateWorldWeek=v163.simulateWorldWeek163;

window.SDF_V171={
 version:VERSION,
 architecture:'single-runtime-coordinator',
 installedFunctions:Object.keys(installed),
 baseFunctions:Object.fromEntries(Object.entries(base).map(([k,v])=>[k,typeof v==='function'])),
 verify(){
  const duplicates=[];
  for(const [name,fn] of Object.entries(installed))if(window[name]!==fn)duplicates.push(name);
  return{version:VERSION,pass:duplicates.length===0,overriddenAfterInstall:duplicates,installed:Object.keys(installed),latestFeatures:{v163:!!window.SDF_V163,v165:!!window.SDF_V165,v166:!!window.SDF_V166,v170:!!window.SDF_V170,v175:!!window.SDF_V175},worldSimulation:window.simulateWorldWeek===v175.simulateWorldWeek?'v175-national-stats':window.simulateWorldWeek===v170.simulateWorldWeek?'v170-final':'v163-fallback'}
 }
};
setTimeout(()=>{if(state?.school)window.renderAll?.()},0);
})();
